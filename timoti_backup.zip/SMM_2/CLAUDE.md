# CLAUDE.md — SMM Telegram Controller Bot

A Telegram **controller bot** (aiogram 3.x, fully async Python 3.12) that
manages SMM "start" campaigns for many **sub-bots**. Promotion logic is driven
by a background scheduler; actual SMM orders go through a pluggable *provider*
adapter.

## Run / build

```bash
# local
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # fill in BOT_TOKEN (and optionally TWIBOOST_API_KEY)
python -m app.main

# docker (bot + postgres + redis)
docker compose up --build
```

Docker CMD is `["python", "-m", "app.main"]`. The `bot` service mounts
`./app` as a volume for live reload; `db` (Postgres 16) and `redis` (7) are
health-checked dependencies.

## Config (`app/config.py`)

`pydantic-settings` `Settings` reads `.env` (utf-8). Single global `settings`
instance — **import it; do not re-instantiate.**

| Key | Default | Notes |
|-----|---------|-------|
| `BOT_TOKEN` | *required* | Telegram bot token |
| `DATABASE_URL` | `postgresql+asyncpg://postgres:postgres@localhost:5432/smm2` | async SQLAlchemy URL |
| `REDIS_URL` | `redis://localhost:6379/0` | used by the rate limiter |
| `TIMEZONE` | `Europe/Kyiv` | scheduler & window math |
| `ADMIN_IDS` | `[]` | comma-separated Telegram user IDs; if empty, the first `/start` caller becomes admin |
| `LOG_LEVEL` | `INFO` | |
| `PROVIDER_MODE` | `stub` | `stub` (deterministic) or `twiboost` (not yet implemented) |
| `TWIBOOST_API_KEY` | `""` | used when `PROVIDER_MODE=twiboost` |
| `RATE_LIMIT_MESSAGES_PER_SECOND` | `25` | outgoing token-bucket rate |

There is **no** `pyproject.toml` / `setup.py`. Dependencies live only in
`requirements.txt` (pip).

## Architecture

```
app/
├── main.py              # entry: init db/redis, build Bot, wire dp+scheduler, start polling
├── config.py            # pydantic-settings, global `settings`
├── bot/
│   ├── dispatcher.py    # create_dispatcher() + setup_middlewares() + setup_handlers()
│   ├── keyboards.py     # main_kb, inline menus, build_project_post_kb, project_card_kb, subbot_card_kb
│   ├── middleware/       # lang_filter (uk/ru/en only), rate_limiter
│   └── handlers/        # aiogram routers (order matters, see below)
├── core/
│   ├── db.py            # async engine, Base, get_session() ctx-mgr, init_db()
│   ├── redis.py         # async redis singleton + close_redis()
│   ├── rate_limiter.py  # Redis fixed-window token-bucket (AsyncRateLimiter)
│   ├── telegram_sender.py  # send_message_safe / send_photo_safe (flood-wait retry)
│   ├── models/          # SQLAlchemy 2.0 models (7)
│   ├── provider/        # ProviderAdapter ABC + stub + twiboost
│   └── services/        # business logic (admins, projects, subbots, promotion, stats, export, ping_health)
└── scheduler/jobs.py    # APScheduler AsyncIOScheduler: 3 interval jobs
```

### Request lifecycle
1. `LangFilterMiddleware` short-circuits non uk/ru/en messages (commands always pass).
2. `RateLimiterMiddleware` attaches a shared `AsyncRateLimiter` to handler `data`.
3. Routers run in registration order (first match wins).
4. Outgoing sends go through `send_message_safe` / `send_photo_safe`, which
   respect the limiter and retry once on `FloodWait`.

### Handler registration order (do NOT reorder without reason)
`start_resp → common → analytics → projects → subbots → profile → status_chat → menu`
(`start_resp` has the `/start <args>` filter before `common`'s plain `/start`;
`analytics` is before `menu` for the `📊 Аналитика` text; `common` is early
so `/cancel` works in every FSM flow.)

> Note: the `buttons` router referenced in earlier docs does not exist.

### Scheduler jobs (`app/scheduler/jobs.py`)
- `tick_promotion` — every **10 min**: plan daily windows, submit pending orders,
  poll in-progress orders, complete finished windows, advance steps.
- `tick_ping_health` — every **35 min**: `.ping` each ping-enabled sub-bot to its status chat.
- `tick_maintenance` — every **30 min**: submit a small daily regular order for
  sub-bots in maintenance mode.

All jobs catch per-subbot exceptions so one failure never aborts the whole tick.

## Data model (`app/core/models/`)

- **Admin** — `telegram_id` (unique), SMM profile fields (api_key, budget, limit, variance, ceiling).
- **Project** — belongs to `admin_id`; response mode (`text`/`post`), image + two URL
  buttons, global button texts, achievement stats. Has many **SubBot** (cascade delete).
- **SubBot** — belongs to a **Project**; stores its own `bot_token`, status/strategy/
  pause/shadow/maintenance flags, live delivery counters, and relations to **Order**,
  **StatWindow**, **StartEvent** (all cascade delete).
- **Order** — belongs to SubBot + Project; tracks provider order, service type
  (`regular`/`premium`), quantity, status, cost.
- **StatWindow** — daily plan per subbot: strategy, planned/delivered starts, cost, status.
- **StartEvent** — records every `/start` handled for a subbot (user, lang, premium,
  filtered flag, response type, processing time).
- **ProjectSetup** — short-lived FSM row tracking picture+links setup progress.

> Style note: most models use modern `Mapped` / `mapped_column`, but `ProjectSetup`
> and `Project` mix in legacy `Column(...)` declarations. Match the surrounding style
> when editing; don't "fix" one without the other.

## Provider adapters (`app/core/provider/`)

`ProviderAdapter` is the ABC (`create_order`, `get_status`, `get_balance`,
`list_services`). `get_provider_adapter(settings)` returns:
- `StubAdapter` (default) — deterministic, in-memory; an order completes on the
  **second** `get_status` call. Services: 928 (regular), 930 (premium).
- `TwiboostAdapter` — **not implemented**; every method raises
  `NotImplementedError` pointing you to `https://twiboost.com/developer`.

To add/implement a provider, extend the ABC and switch via `PROVIDER_MODE`.

## Key conventions

- **Async everything.** DB via `async with get_session() as session:` — the context
  manager commits on success, rolls back on exception. Redis via `get_redis()`.
- **Logging:** loggers are per-module via `logging.getLogger(__name__)`; main logger
  is `"main"`. Logging is configured in `main.setup_logging()`.
- **No tests, no linter, no CI.** There is no `pytest.ini`, `conftest.py`, ruff/black/mypy
  config, or `.github/workflows`. If you add any, create the configs (none exist yet).
- **FSM storage is `MemoryStorage`** — state is lost on restart. Don't rely on it
  across restarts.
- **Admin gating:** first `/start` with empty `ADMIN_IDS` promotes that user. The
  placeholder `0` in `ADMIN_IDS` is treated as "no admins yet".

## Migrations (Alembic)

```bash
alembic revision --autogenerate -m "description"
alembic upgrade head
```
`alembic/env.py` loads `DATABASE_URL` from env and imports `app.core.models.Base`.
Current head: `b082ddb7cb3d` (adds subbot timestamps). Add new models to
`app/core/models/__init__.py` so autogenerate sees them.

## Common tasks

- **Add a handler:** create a router in `app/bot/handlers/`, register it in
  `app/bot/dispatcher.setup_handlers()` in the correct position.
- **Add a model:** put it under `app/core/models/`, export from
  `app/core/models/__init__.py`, generate an alembic revision.
- **Add a periodic job:** add an async function in `app/scheduler/jobs.py` and
  `scheduler.add_job(...)` inside `create_scheduler()`.
- **Send a message from a handler:** use
  `app.core.telegram_sender.send_message_safe(bot, chat_id, text, data["rate_limiter"])`.

## Language / tone
UI strings and comments are primarily in **Russian/Ukrainian** (e.g. button labels
like `📁 Проекты`, `❌ Отмена`). Keep user-facing text consistent with the existing
language when editing handlers/keyboards.
