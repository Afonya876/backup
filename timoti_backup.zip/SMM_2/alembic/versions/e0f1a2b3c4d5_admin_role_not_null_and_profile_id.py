"""admin role not null and profile_id typed as varchar

Revision ID: e0f1a2b3c4d5
Revises: d8f9e0a1b2c3
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "e0f1a2b3c4d5"
down_revision: Union[str, None] = "d8f9e0a1b2c3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "admins",
        "role",
        existing_type=sa.Enum("owner", "admin", "member", name="admin_role"),
        nullable=False,
        existing_server_default=sa.text("'member'::admin_role"),
    )
    op.alter_column(
        "admins",
        "profile_id",
        existing_type=sa.String(length=50),
        type_=sa.String(length=50),
        existing_nullable=True,
    )


def downgrade() -> None:
    op.alter_column(
        "admins",
        "role",
        existing_type=sa.Enum("owner", "admin", "member", name="admin_role"),
        nullable=True,
        existing_server_default=sa.text("'member'::admin_role"),
    )
