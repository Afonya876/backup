"""add subbot timestamps

Revision ID: b082ddb7cb3d
Revises: 
Create Date: 2026-09-06 15:11:58.881409

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'b082ddb7cb3d'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Existing deployments may already contain the delivery counters.
    op.execute("ALTER TABLE subbots ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ")
    op.execute("ALTER TABLE subbots ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ")
    op.execute("UPDATE subbots SET created_at = COALESCE(created_at, NOW())")
    op.execute("UPDATE subbots SET updated_at = COALESCE(updated_at, NOW())")
    op.alter_column("subbots", "created_at", nullable=False,
                    existing_type=sa.DateTime(timezone=True))
    op.alter_column("subbots", "updated_at", nullable=False,
                    existing_type=sa.DateTime(timezone=True))


def downgrade() -> None:
    op.drop_column("subbots", "updated_at")
    op.drop_column("subbots", "created_at")
    # ### end Alembic commands ###
