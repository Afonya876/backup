"""add step_advanced and retry_count

Revision ID: f2a1b3c4d5e6
Revises: e6413e7659cb
Create Date: 2026-09-06 18:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'f2a1b3c4d5e6'
down_revision: Union[str, None] = 'e6413e7659cb'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'stat_windows',
        sa.Column('step_advanced', sa.Boolean(), server_default='false', nullable=False),
    )
    op.add_column(
        'orders',
        sa.Column('retry_count', sa.Integer(), server_default='0', nullable=False),
    )


def downgrade() -> None:
    op.drop_column('orders', 'retry_count')
    op.drop_column('stat_windows', 'step_advanced')
