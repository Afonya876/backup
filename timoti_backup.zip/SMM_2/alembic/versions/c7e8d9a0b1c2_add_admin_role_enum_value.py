"""add admin_role enum value

Revision ID: c7e8d9a0b1c2
Revises: 9c3d7a1e5b2f
Create Date: 2026-09-06 22:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'c7e8d9a0b1c2'
down_revision: Union[str, None] = '9c3d7a1e5b2f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Older databases have no role column and therefore may not have the enum
    # type either. Create the complete enum here; the following repair revision
    # adds the column and performs the legacy-data backfill.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'admin_role') THEN
                CREATE TYPE admin_role AS ENUM ('owner', 'admin', 'member');
            END IF;
        END
        $$;
        """
    )
    op.execute("ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'admin'")


def downgrade() -> None:
    # Postgres does not support removing enum values. We can demote any
    # 'admin' rows back to 'member' so the enum value is no longer used.
    op.execute(
        "UPDATE admins SET role = 'member', is_admin = FALSE WHERE role = 'admin'"
    )
