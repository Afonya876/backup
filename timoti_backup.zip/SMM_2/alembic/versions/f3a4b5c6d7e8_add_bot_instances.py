"""add controller bot instances

Revision ID: f3a4b5c6d7e8
Revises: e0f1a2b3c4d5
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "f3a4b5c6d7e8"
down_revision: Union[str, None] = "e0f1a2b3c4d5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "bot_instances",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("bot_token", sa.String(length=500), nullable=False),
        sa.Column("bot_username", sa.String(length=100), nullable=True),
        sa.Column("bot_name", sa.String(length=200), nullable=True),
        sa.Column("telegram_id", sa.BigInteger(), nullable=True),
        sa.Column("is_primary", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("bot_token"),
    )


def downgrade() -> None:
    op.drop_table("bot_instances")
