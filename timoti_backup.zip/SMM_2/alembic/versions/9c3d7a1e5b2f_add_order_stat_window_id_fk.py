"""add order stat_window_id fk

Revision ID: 9c3d7a1e5b2f
Revises: a1b2c3d4e5f6
Create Date: 2026-09-06 21:15:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '9c3d7a1e5b2f'
down_revision: Union[str, None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'orders',
        sa.Column('stat_window_id', sa.Integer(), nullable=True),
    )
    op.create_index(
        op.f('ix_orders_stat_window_id'), 'orders', ['stat_window_id'], unique=False
    )
    op.create_foreign_key(
        'fk_orders_stat_window_id',
        'orders',
        'stat_windows',
        ['stat_window_id'],
        ['id'],
        ondelete='SET NULL',
    )


def downgrade() -> None:
    op.drop_constraint('fk_orders_stat_window_id', 'orders', type_='foreignkey')
    op.drop_index(op.f('ix_orders_stat_window_id'), table_name='orders')
    op.drop_column('orders', 'stat_window_id')
