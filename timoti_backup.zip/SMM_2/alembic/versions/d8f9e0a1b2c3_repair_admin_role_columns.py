"""repair missing admin role/profile columns

Revision ID: d8f9e0a1b2c3
Revises: c7e8d9a0b1c2
"""
from typing import Sequence, Union

from alembic import op


revision: str = "d8f9e0a1b2c3"
down_revision: Union[str, None] = "c7e8d9a0b1c2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Use IF NOT EXISTS because some installations may already have one or
    # more columns from a manually applied model change.
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'admin_role') THEN
                CREATE TYPE admin_role AS ENUM ('owner', 'admin', 'member');
            ELSE
                ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'owner';
                ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'admin';
                ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'member';
            END IF;
        END
        $$;
        ALTER TABLE admins
            ADD COLUMN IF NOT EXISTS role admin_role NOT NULL DEFAULT 'member',
            ADD COLUMN IF NOT EXISTS profile_id VARCHAR(50),
            ADD COLUMN IF NOT EXISTS profile_name VARCHAR(200);
        UPDATE admins SET role = 'admin' WHERE is_admin = TRUE;
        """
    )


def downgrade() -> None:
    op.execute(
        """
        ALTER TABLE admins
            DROP COLUMN IF EXISTS profile_name,
            DROP COLUMN IF EXISTS profile_id,
            DROP COLUMN IF EXISTS role;
        """
    )
