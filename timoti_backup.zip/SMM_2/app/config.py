from pydantic import field_validator
from pydantic_settings import BaseSettings


def parse_admin_ids(v: str | list | None) -> list[int]:
    """Parse ADMIN_IDS from comma-separated string to list of ints.

    A single ``0`` or an empty string means "no admins yet" — the first
    user to send ``/start`` will be promoted to admin automatically.
    """
    if isinstance(v, list):
        ids = v
    elif isinstance(v, str) and v.strip():
        ids = [int(x.strip()) for x in v.split(",") if x.strip()]
    else:
        return []
    # Filter out placeholder zeros — they are not real Telegram user IDs.
    ids = [i for i in ids if i != 0]
    return ids


class Settings(BaseSettings):
    BOT_TOKEN: str
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/smm2"
    REDIS_URL: str = "redis://localhost:6379/0"
    TWIBOOST_API_KEY: str = ""
    SMMMAIN_API_KEY: str = ""
    SMMMAIN_API_URL: str = "https://smmmain.com/api/v2"
    TIMEZONE: str = "Europe/Kyiv"
    ADMIN_IDS: list[int] = []
    LOG_LEVEL: str = "INFO"
    PROVIDER_MODE: str = "stub"
    RATE_LIMIT_MESSAGES_PER_SECOND: int = 25

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
    }

    @field_validator("ADMIN_IDS", mode="before")
    @classmethod
    def validate_admin_ids(cls, v: str | list | None) -> list[int]:
        return parse_admin_ids(v)


settings = Settings()
