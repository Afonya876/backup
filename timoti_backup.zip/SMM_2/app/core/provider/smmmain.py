import logging

import httpx

from app.core.provider import (
    ProviderAdapter,
    ProviderBalanceResult,
    ProviderOrderResult,
    ProviderService,
    ProviderStatusResult,
)

logger = logging.getLogger(__name__)

# Status mapping: smmmain status string → internal status.
# Lower-cased before comparison.
_COMPLETED = frozenset({"completed", "done"})
_PARTIAL = frozenset({"partial"})
_CANCELLED = frozenset({"canceled", "cancelled", "refunded"})
_FAILED = frozenset({"failed", "error", "rejected"})
_IN_PROGRESS = frozenset({"in progress", "processing", "pending", "active", "in queue"})
_PENDING = frozenset({"new", "queued"})


class SmmmainAdapter(ProviderAdapter):
    """SMM-panel adapter for https://smmmain.com/api/v2."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://smmmain.com/api/v2",
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._http = httpx.AsyncClient(timeout=30.0)

    async def close(self) -> None:
        await self._http.aclose()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _post(self, **data: object) -> dict:
        """Send a form-encoded POST to the smmmain API and return the JSON body."""
        data["key"] = self._api_key
        for attempt in range(2):
            try:
                resp = await self._http.post(
                    self._base_url,
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
                body: dict = resp.json()
                if "error" in body:
                    logger.warning(
                        "smmmain API error (attempt %d): %s | request=%s",
                        attempt + 1,
                        body["error"],
                        {k: v for k, v in data.items() if k != "key"},
                    )
                    if attempt == 0 and resp.status_code == 429:
                        import asyncio
                        await asyncio.sleep(2)
                        continue
                    return body
                return body
            except httpx.HTTPStatusError as exc:
                logger.warning("smmmain HTTP %d (attempt %d)", exc.response.status_code, attempt + 1)
                if attempt == 0 and exc.response.status_code == 429:
                    import asyncio
                    await asyncio.sleep(2)
                    continue
                return {"error": f"HTTP {exc.response.status_code}"}
            except httpx.RequestError as exc:
                logger.warning("smmmain request error: %s", exc)
                return {"error": str(exc)}
        return {"error": "Max retries exceeded"}

    @staticmethod
    def _map_status(raw: str) -> tuple[str, bool]:
        """Map a smmmain status string to (internal_status, is_terminal).

        Returns (status, is_terminal) where is_terminal=True means the order
        will not change state further.
        """
        s = (raw or "").strip().lower()
        if s in _COMPLETED:
            return "completed", True
        if s in _PARTIAL:
            return "partial", True
        if s in _CANCELLED:
            return "cancelled", True
        if s in _FAILED:
            return "failed", True
        if s in _IN_PROGRESS:
            return "in_progress", False
        if s in _PENDING:
            return "pending", False
        # Unknown status — treat as in-progress so the poller retries later.
        logger.warning("Unknown smmmain status: %r — treating as in_progress", raw)
        return "in_progress", False

    # ------------------------------------------------------------------
    # ProviderAdapter implementation
    # ------------------------------------------------------------------

    async def create_order(
        self, service_id: int, target: str, quantity: int
    ) -> ProviderOrderResult:
        body = await self._post(action="add", service=service_id, link=target, quantity=quantity)
        if "error" in body:
            return ProviderOrderResult(
                success=False,
                order_id=None,
                service_id=service_id,
                quantity=quantity,
                cost=0.0,
                message=body["error"],
            )
        order_id = str(body.get("order", ""))
        # smmmain doesn't return charge in the add response; set cost to 0
        # and let get_status / billing handle it.
        return ProviderOrderResult(
            success=True,
            order_id=order_id,
            service_id=service_id,
            quantity=quantity,
            cost=0.0,
            message="Order submitted to smmmain.",
        )

    async def get_status(self, order_id: str) -> ProviderStatusResult:
        body = await self._post(action="status", order=order_id)
        if "error" in body:
            return ProviderStatusResult(
                order_id=order_id,
                status="failed",
                starts_remaining=0,
                message=body["error"],
            )
        raw_status = body.get("status", "")
        internal_status, _ = self._map_status(raw_status)
        remains = int(float(body.get("remains", body.get("start_count", 0)) or 0))
        charge = body.get("charge")
        msg = f"smmmain status: {raw_status}"
        if charge is not None:
            msg += f", charge={charge}"
        return ProviderStatusResult(
            order_id=order_id,
            status=internal_status,
            starts_remaining=remains,
            message=msg,
        )

    async def get_balance(self) -> ProviderBalanceResult:
        body = await self._post(action="balance")
        if "error" in body:
            return ProviderBalanceResult(
                balance=0.0,
                currency="USD",
                message=body["error"],
            )
        return ProviderBalanceResult(
            balance=float(body.get("balance", 0)),
            currency=body.get("currency", "USD"),
            message="Balance from smmmain.",
        )

    async def list_services(self) -> list[ProviderService]:
        body = await self._post(action="services")
        if "error" in body or not isinstance(body, list):
            return []
        return [
            ProviderService(
                service_id=int(s.get("service", 0)),
                name=s.get("name", ""),
                category=s.get("category", ""),
                rate_per_1000=float(s.get("rate", 0)),
                min_quantity=int(s.get("min", 0)),
                max_quantity=int(s.get("max", 0)),
            )
            for s in body
        ]
