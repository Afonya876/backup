from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ProviderOrderResult:
    """Result of creating an order."""

    success: bool
    order_id: str | None
    service_id: int
    quantity: int
    cost: float
    message: str


@dataclass
class ProviderStatusResult:
    """Status of an order.

    status values: pending | in_progress | completed | partial | failed | cancelled
    """

    order_id: str
    status: str
    starts_remaining: int
    message: str


@dataclass
class ProviderBalanceResult:
    """Balance info from the provider."""

    balance: float
    currency: str
    message: str


@dataclass
class ProviderService:
    """Service offered by the provider."""

    service_id: int
    name: str
    category: str
    rate_per_1000: float
    min_quantity: int
    max_quantity: int


class ProviderAdapter(ABC):
    """Abstract interface every SMM-panel adapter must implement."""

    @abstractmethod
    async def create_order(
        self, service_id: int, target: str, quantity: int
    ) -> ProviderOrderResult: ...

    @abstractmethod
    async def get_status(self, order_id: str) -> ProviderStatusResult: ...

    @abstractmethod
    async def get_balance(self) -> ProviderBalanceResult: ...

    @abstractmethod
    async def list_services(self) -> list[ProviderService]: ...


def _get_attr(settings, name: str, default=None):
    """Read an attribute from either a dict or an object."""
    if isinstance(settings, dict):
        return settings.get(name, default)
    return getattr(settings, name, default)


def get_provider_adapter(settings) -> ProviderAdapter:
    """Return the adapter configured by settings.PROVIDER_MODE."""
    mode = _get_attr(settings, "PROVIDER_MODE")

    if mode == "twiboost":
        from app.core.provider.twiboost import TwiboostAdapter

        return TwiboostAdapter(_get_attr(settings, "TWIBOOST_API_KEY", ""))

    if mode == "smmmain":
        from app.core.provider.smmmain import SmmmainAdapter

        return SmmmainAdapter(
            _get_attr(settings, "SMMMAIN_API_KEY", ""),
            base_url=_get_attr(settings, "SMMMAIN_API_URL", "https://smmmain.com/api/v2"),
        )

    from app.core.provider.stub import StubAdapter

    return StubAdapter()
