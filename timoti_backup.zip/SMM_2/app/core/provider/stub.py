from uuid import uuid4

from app.core.provider import (
    ProviderAdapter,
    ProviderBalanceResult,
    ProviderOrderResult,
    ProviderService,
    ProviderStatusResult,
)

# ---------------------------------------------------------------------------
# Stub provider – simulates a real SMM panel so the full promotion cycle
# (create → poll status → complete) can be tested end-to-end without an
# external API.
#
# Order lifecycle simulated in-memory:
#   call 1 to get_status  ->  in_progress, starts_remaining = quantity
#   call 2 to get_status  ->  completed,   starts_remaining = 0
#
# This deterministic two-call progression is enough for the promotion loop
# and avoids randomness that would complicate tests.
# ---------------------------------------------------------------------------

_SERVICES: list[ProviderService] = [
    ProviderService(
        service_id=928,
        name="Regular Telegram starts",
        category="Telegram",
        rate_per_1000=30.0,
        min_quantity=10,
        max_quantity=1000,
    ),
    ProviderService(
        service_id=930,
        name="Premium Telegram starts",
        category="Telegram",
        rate_per_1000=50.0,
        min_quantity=10,
        max_quantity=500,
    ),
]


class StubAdapter(ProviderAdapter):
    """Deterministic stub that tracks order progression in memory."""

    def __init__(self) -> None:
        # {order_id: {"calls": int, "status": str, "remaining": int, "service": int}}
        self._orders_db: dict[str, dict] = {}

    # ------------------------------------------------------------------
    # ProviderAdapter implementation
    # ------------------------------------------------------------------

    def _rate_for(self, service_id: int) -> float:
        for svc in _SERVICES:
            if svc.service_id == service_id:
                return svc.rate_per_1000
        return 30.0

    async def create_order(
        self, service_id: int, target: str, quantity: int
    ) -> ProviderOrderResult:
        order_id = f"STUB-{uuid4().hex[:12]}"
        rate_per_1000 = self._rate_for(service_id)
        cost = round(quantity * rate_per_1000 / 1000.0, 4)

        self._orders_db[order_id] = {
            "calls": 0,
            "status": "in_progress",
            "remaining": quantity,
            "service": service_id,
        }

        return ProviderOrderResult(
            success=True,
            order_id=order_id,
            service_id=service_id,
            quantity=quantity,
            cost=cost,
            message="Stub order created.",
        )

    async def get_status(self, order_id: str) -> ProviderStatusResult:
        record = self._orders_db.get(order_id)
        if record is None:
            return ProviderStatusResult(
                order_id=order_id,
                status="failed",
                starts_remaining=0,
                message=f"Order {order_id} not found.",
            )

        record["calls"] += 1

        if record["calls"] <= 1:
            # First poll: still in progress
            record["status"] = "in_progress"
            record["remaining"] = record.get("remaining", 0)
        else:
            # Second poll (and beyond): completed
            record["status"] = "completed"
            record["remaining"] = 0

        return ProviderStatusResult(
            order_id=order_id,
            status=record["status"],
            starts_remaining=record["remaining"],
            message=f"Stub status: {record['status']}.",
        )

    async def get_balance(self) -> ProviderBalanceResult:
        return ProviderBalanceResult(
            balance=1000.0,
            currency="RUB",
            message="Stub balance.",
        )

    async def list_services(self) -> list[ProviderService]:
        return list(_SERVICES)
