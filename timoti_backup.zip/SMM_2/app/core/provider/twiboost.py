import httpx  # noqa: F401 – will be used once real integration begins

from app.core.provider import (
    ProviderAdapter,
    ProviderBalanceResult,
    ProviderOrderResult,
    ProviderService,
    ProviderStatusResult,
)

# ---------------------------------------------------------------------------
# Twiboost adapter (placeholder)
#
# Twiboost is an SMM-panel provider.  The integration is not yet complete.
# Set PROVIDER_MODE=stub in .env to fall back to the deterministic stub
# provider while this adapter is being built.
#
# Service catalogue (from the Twiboost panel):
#   928 – Regular Telegram starts  (default for most users)
#   930 – Premium Telegram starts  (used for premium subscribers)
#
# Expected API endpoints (UNVERIFIED – confirm against
# https://twiboost.com/developer before implementing):
#
#   Base URL : https://twiboost.com/api/v2
#   Auth     : api_key query param or header (TBD)
#
#   POST /api/v2
#       action = add
#       service  (int)  – service id, e.g. 928 or 930
#       link     (str)  – target URL / username
#       runs     (int)  – quantity of starts
#       → returns { order: <order_id> } on success
#
#   POST /api/v2
#       action = status
#       order    (str)  – order id returned by the add action
#       → returns { status, starts_remaining, ... }
#
#   POST /api/v2
#       action = balance
#       → returns { balance, currency }
#
#   POST /api/v2
#       action = services
#       → returns list of service objects
#
# TODO: implement all four methods using the httpx async client once the
# Twiboost API docs are verified.  Each method currently raises
# NotImplementedError with guidance.
# ---------------------------------------------------------------------------

BASE_URL = "https://twiboost.com/api/v2"


class TwiboostAdapter(ProviderAdapter):
    """Real Twiboost SMM-panel adapter — not yet implemented."""

    def __init__(self, api_key: str) -> None:
        self._api_key = api_key

    async def create_order(
        self, service_id: int, target: str, quantity: int
    ) -> ProviderOrderResult:
        raise NotImplementedError(
            "Twiboost API not yet integrated. "
            "Set PROVIDER_MODE=stub in .env to use the stub provider. "
            "To integrate: implement create_order, get_status, get_balance, "
            "list_services using https://twiboost.com/developer API documentation."
        )

    async def get_status(self, order_id: str) -> ProviderStatusResult:
        raise NotImplementedError(
            "Twiboost API not yet integrated. "
            "Set PROVIDER_MODE=stub in .env to use the stub provider. "
            "To integrate: implement create_order, get_status, get_balance, "
            "list_services using https://twiboost.com/developer API documentation."
        )

    async def get_balance(self) -> ProviderBalanceResult:
        raise NotImplementedError(
            "Twiboost API not yet integrated. "
            "Set PROVIDER_MODE=stub in .env to use the stub provider. "
            "To integrate: implement create_order, get_status, get_balance, "
            "list_services using https://twiboost.com/developer API documentation."
        )

    async def list_services(self) -> list[ProviderService]:
        raise NotImplementedError(
            "Twiboost API not yet integrated. "
            "Set PROVIDER_MODE=stub in .env to use the stub provider. "
            "To integrate: implement create_order, get_status, get_balance, "
            "list_services using https://twiboost.com/developer API documentation."
        )
