"""
Async token-bucket rate limiter backed by Redis.

Uses a simple fixed-window ``INCR + EXPIRE`` strategy keyed per second,
so it is safe across processes and restarts without requiring Lua scripts.

Example::

    limiter = AsyncRateLimiter(redis, rate=25, burst=5)
    await limiter.acquire("send:123456")   # blocks until a token is free
"""

from __future__ import annotations

import asyncio
import logging
import time

import redis.asyncio as redis

logger = logging.getLogger(__name__)


class AsyncRateLimiter:
    """Redis-backed async token / fixed-window rate limiter."""

    def __init__(
        self,
        redis_client: redis.Redis,
        rate: int = 25,
        burst: int = 5,
    ) -> None:
        """
        Parameters
        ----------
        redis_client:
            An async Redis client (``redis.asyncio.Redis``).
        rate:
            Maximum number of ``acquire`` calls permitted per second.
        burst:
            Extra tokens that may be consumed beyond the per-second rate
            (allows small traffic spikes without blocking).
        """
        self._redis = redis_client
        self._rate = max(1, int(rate))
        self._burst = max(0, int(burst))
        self._capacity = self._rate + self._burst
        self._sleep_per_token = 1.0 / self._rate

    async def acquire(self, key: str) -> None:
        """Block until a token is available for *key*, then consume it."""
        while True:
            allowed = await self._try_consume(key)
            if allowed:
                return
            # Not enough budget – sleep one token interval and retry.
            await asyncio.sleep(self._sleep_per_token)

    async def can_send(self, key: str) -> bool:
        """Return ``True`` if a token could be consumed for *key*."""
        return await self._try_consume(key)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _try_consume(self, key: str) -> bool:
        """Attempt to consume one token. Returns ``True`` on success."""
        now = int(time.time())
        window_key = f"rl:{key}:{now}"

        pipe = self._redis.pipeline(transaction=False)
        pipe.incr(window_key)
        pipe.expire(window_key, 2)  # keep a little longer than the window
        results = await pipe.execute()

        current: int = results[0]
        # The very first incr is cheap; subsequent ones just read the counter.
        if current <= self._capacity:
            return True
        return False
