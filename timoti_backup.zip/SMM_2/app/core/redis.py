import redis.asyncio as redis

from app.config import settings

_pool: redis.ConnectionPool | None = None
_client: redis.Redis | None = None


def get_redis() -> redis.Redis:
    """Return a lazily-initialised async Redis client (singleton)."""
    global _pool, _client

    if _client is not None:
        return _client

    _pool = redis.ConnectionPool.from_url(
        settings.REDIS_URL,
        decode_responses=True,
    )
    _client = redis.Redis(connection_pool=_pool)
    return _client


async def close_redis() -> None:
    """Close the Redis connection and pool."""
    global _pool, _client

    if _client is not None:
        await _client.close()
        _client = None

    if _pool is not None:
        await _pool.disconnect()
        _pool = None
