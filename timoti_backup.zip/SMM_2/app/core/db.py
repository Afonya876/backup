from datetime import datetime
from contextlib import asynccontextmanager

from sqlalchemy import DateTime, func
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from app.config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
)

async_session = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )


@asynccontextmanager
async def get_session() -> AsyncSession:
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db() -> None:
    """Create all tables after registering every ORM model.

    Model modules import ``Base`` from this module, so importing them at module
    load time would create a circular import.  Importing the package here is
    deliberate: ``main`` calls ``init_db`` before importing handlers, and
    SQLAlchemy otherwise sees an empty metadata registry and creates no tables.
    """
    from app.core import models  # noqa: F401  # register ORM models

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
