from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Enum, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base

# Role enum — controls what a row may do in the controller bot.
#   owner  – full access + can manage other admins/users (the bootstrap role)
#   admin  – full access + can manage users, equals owner for all practical
#            purposes (kept as a distinct label so an owner can later demote
#            another admin to "member" without deleting them)
#   member – can view and operate bots/projects/analytics but CANNOT manage
#            admins, invite new users, or change profile/growth settings
ADMIN_ROLE_OWNER = "owner"
ADMIN_ROLE_ADMIN = "admin"
ADMIN_ROLE_MEMBER = "member"
ADMIN_ROLES = (ADMIN_ROLE_OWNER, ADMIN_ROLE_ADMIN, ADMIN_ROLE_MEMBER)
ADMIN_ROLES_FULL_ACCESS = {ADMIN_ROLE_OWNER, ADMIN_ROLE_ADMIN}


class Admin(Base):
    __tablename__ = "admins"

    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    full_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    role: Mapped[str] = mapped_column(
        Enum(*ADMIN_ROLES, name="admin_role"),
        nullable=False,
        default=ADMIN_ROLE_MEMBER,
        server_default=ADMIN_ROLE_MEMBER,
    )
    # Legacy authorization flag. Kept for backward compatibility. A row passes
    # ``is_admin_user()`` iff its role is in ADMIN_ROLES_FULL_ACCESS (or it is
    # the bootstrap owner). New code should prefer ``role`` checks.
    is_admin: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default="false"
    )
    profile_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    profile_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    api_key: Mapped[str | None] = mapped_column(String(200), nullable=True)
    daily_budget: Mapped[float | None] = mapped_column(Float, nullable=True)
    daily_limit: Mapped[int | None] = mapped_column(Integer, nullable=True)
    variance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    ceiling: Mapped[int | None] = mapped_column(Integer, nullable=True)
    provider_state: Mapped[str] = mapped_column(
        String(30), default="waiting_balance", server_default="waiting_balance"
    )
    growth_base: Mapped[int] = mapped_column(Integer, default=200)
    growth_step: Mapped[int] = mapped_column(Integer, default=100)
    growth_ceiling: Mapped[int] = mapped_column(Integer, default=2000)
    maintenance_service_id: Mapped[int] = mapped_column(Integer, default=928)
    maintenance_daily: Mapped[int] = mapped_column(Integer, default=200)
    maintenance_variance_pct: Mapped[float] = mapped_column(Float, default=5.0)
    daily_safeguard_usd: Mapped[float] = mapped_column(Float, default=31.0)
    profile_admins: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
