from datetime import datetime, timezone

from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base


class BotInstance(Base):
    """A running copy of the controller bot under a specific Telegram token.

    All instances share the same database (projects, sub-bots, admins, stats),
    dispatcher and FSM storage — they are literally the same bot reachable
    under different tokens. The ``is_primary`` row is the token from
    ``settings.BOT_TOKEN``; the rest are added by admins at runtime.
    """

    __tablename__ = "bot_instances"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bot_token: Mapped[str] = mapped_column(String(500), unique=True, nullable=False)
    bot_username: Mapped[str | None] = mapped_column(String(100), nullable=True)
    bot_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
