from sqlalchemy import BigInteger, Column, DateTime, ForeignKey, Integer, String, func

from app.core.db import Base


class ProjectSetup(Base):
    """Tracks in-progress project picture+links configuration (atomic FSM)."""

    __tablename__ = "project_setups"

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    # No FK — Telegram user IDs are opaque; admin registration is independent.
    admin_id = Column(BigInteger, nullable=False)
    image_file_id = Column(String, nullable=True)
    button1_url = Column(String, nullable=True)
    button2_url = Column(String, nullable=True)
    step = Column(Integer, default=0, nullable=False)
    # step: 0=waiting_image, 1=waiting_url1, 2=waiting_url2, 3=ready
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    # Note: no updated_at needed — setup rows are short-lived and deleted on completion.
