from datetime import datetime, timezone
from typing import TYPE_CHECKING

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base

if TYPE_CHECKING:
    from app.core.models.order import Order
    from app.core.models.project import Project
    from app.core.models.start_event import StartEvent
    from app.core.models.stat_window import StatWindow


class SubBot(Base):
    __tablename__ = "subbots"

    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id"), nullable=False
    )
    bot_token: Mapped[str] = mapped_column(String(500), unique=True, nullable=False)
    bot_username: Mapped[str | None] = mapped_column(String(100), nullable=True)
    bot_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[str] = mapped_column(
        Enum(
            "running",
            "stopped",
            "needs_setup",
            "unavailable",
            "error",
            name="subbot_status",
        ),
        default="stopped",
    )
    status_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    strategy: Mapped[str] = mapped_column(
        Enum("20_80", "100_premium", "none", name="subbot_strategy"),
        default="none",
    )
    is_paused: Mapped[bool] = mapped_column(Boolean, default=False)
    is_shadow: Mapped[bool] = mapped_column(Boolean, default=False)
    current_step: Mapped[int] = mapped_column(Integer, default=0)
    current_daily_plan: Mapped[int] = mapped_column(Integer, default=0)
    delivered_today: Mapped[int] = mapped_column(Integer, default=0)
    delivered_regular: Mapped[int] = mapped_column(Integer, default=0)
    delivered_premium: Mapped[int] = mapped_column(Integer, default=0)
    total_delivered: Mapped[int] = mapped_column(Integer, default=0)
    total_cost: Mapped[float] = mapped_column(Float, default=0.0)
    work_days_completed: Mapped[int] = mapped_column(Integer, default=0)
    needs_goal_check: Mapped[bool] = mapped_column(Boolean, default=False)
    promotion_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    last_window_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    restart_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    ping_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    ping_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    maintenance_mode: Mapped[bool] = mapped_column(Boolean, default=False)
    maintenance_daily: Mapped[int] = mapped_column(Integer, default=200)
    process_pid: Mapped[int | None] = mapped_column(Integer, nullable=True)

    project: Mapped["Project"] = relationship("Project", back_populates="subbots")

    orders: Mapped[list["Order"]] = relationship(
        "Order",
        back_populates="subbot",
        cascade="all, delete-orphan",
    )

    stat_windows: Mapped[list["StatWindow"]] = relationship(
        "StatWindow",
        back_populates="subbot",
        cascade="all, delete-orphan",
    )

    start_events: Mapped[list["StartEvent"]] = relationship(
        "StartEvent",
        back_populates="subbot",
        cascade="all, delete-orphan",
    )
