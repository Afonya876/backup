from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    BigInteger,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base

if TYPE_CHECKING:
    from app.core.models.order import Order
    from app.core.models.subbot import SubBot


class Project(Base):
    __tablename__ = "projects"

    admin_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    response_mode: Mapped[str] = mapped_column(
        Enum("text", "post", name="project_response_mode"),
        default="text",
    )
    image_file_id: Mapped[str | None] = mapped_column(String(500), nullable=True)
    button1_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    button2_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    button1_text_global: Mapped[str] = mapped_column(
        String(100), default="Перейти", server_default="Перейти"
    )
    button2_text_global: Mapped[str] = mapped_column(
        String(100), default="Перейти", server_default="Перейти"
    )
    achievement_mode: Mapped[str] = mapped_column(
        Enum("20_80", "100_premium", "none", name="project_achievement_mode"),
        default="none",
    )
    achievement_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    achievement_delivered_starts: Mapped[int | None] = mapped_column(
        Integer, nullable=True
    )
    achievement_regular_pct: Mapped[float | None] = mapped_column(
        Float, nullable=True
    )
    achievement_premium_pct: Mapped[float | None] = mapped_column(
        Float, nullable=True
    )
    achievement_steps: Mapped[int | None] = mapped_column(Integer, nullable=True)
    achievement_cost: Mapped[float | None] = mapped_column(Float, nullable=True)
    achieved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    subbots: Mapped[list["SubBot"]] = relationship(
        "SubBot",
        back_populates="project",
        cascade="all, delete-orphan",
    )
