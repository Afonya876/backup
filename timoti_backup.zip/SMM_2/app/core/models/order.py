from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class Order(Base):
    __tablename__ = "orders"

    subbot_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subbots.id"), nullable=False
    )
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id"), nullable=False
    )
    stat_window_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("stat_windows.id"), nullable=True, index=True,
    )
    provider_order_id: Mapped[str | None] = mapped_column(
        String(100), nullable=True
    )
    service_id: Mapped[int] = mapped_column(Integer, nullable=False)
    service_type: Mapped[str] = mapped_column(
        Enum("regular", "premium", name="order_service_type"),
        nullable=False,
    )
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(
        Enum(
            "pending",
            "in_progress",
            "completed",
            "partial",
            "failed",
            "cancelled",
            name="order_status",
        ),
        default="pending",
    )
    cost: Mapped[float | None] = mapped_column(Float, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    subbot: Mapped["SubBot"] = relationship("SubBot", back_populates="orders")

    project: Mapped["Project"] = relationship("Project")
