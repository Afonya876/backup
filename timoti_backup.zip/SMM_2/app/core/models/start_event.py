from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class StartEvent(Base):
    __tablename__ = "start_events"

    subbot_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subbots.id"), nullable=False
    )
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id"), nullable=False
    )
    user_telegram_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    is_new_user: Mapped[bool] = mapped_column(Boolean, nullable=False)
    language_code: Mapped[str | None] = mapped_column(String(10), nullable=True)
    payload: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    is_filtered: Mapped[bool] = mapped_column(Boolean, default=False)
    response_type: Mapped[str] = mapped_column(
        Enum("text", "post", "filtered", "error", name="start_event_response_type"),
        nullable=False,
    )
    processing_time_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    subbot: Mapped["SubBot"] = relationship("SubBot", back_populates="start_events")

    project: Mapped["Project"] = relationship("Project")
