from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class StatWindow(Base):
    __tablename__ = "stat_windows"

    subbot_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subbots.id"), nullable=False
    )
    project_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("projects.id"), nullable=False
    )
    window_date: Mapped[date] = mapped_column(Date, nullable=False)
    strategy: Mapped[str] = mapped_column(
        Enum("20_80", "100_premium", name="stat_window_strategy"),
        nullable=False,
    )
    planned_starts: Mapped[int] = mapped_column(Integer, nullable=False)
    delivered_regular: Mapped[int] = mapped_column(Integer, default=0)
    delivered_premium: Mapped[int] = mapped_column(Integer, default=0)
    total_delivered: Mapped[int] = mapped_column(Integer, default=0)
    cost: Mapped[float] = mapped_column(Float, default=0)
    step_advanced: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(
        Enum(
            "planned",
            "in_progress",
            "completed",
            "needs_check",
            name="stat_window_status",
        ),
        default="planned",
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    subbot: Mapped["SubBot"] = relationship("SubBot", back_populates="stat_windows")

    project: Mapped["Project"] = relationship("Project")
