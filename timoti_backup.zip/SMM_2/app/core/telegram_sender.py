"""
Thin wrappers around ``Bot.send_message`` / ``Bot.send_photo`` that apply
rate-limit back-off and retry on ``FloodWait``.

Typical usage inside a handler::

    from aiogram import Bot
    from app.core.redis import get_redis
    from app.core.rate_limiter import AsyncRateLimiter
    from app.core.telegram_sender import send_message_safe

    limiter = AsyncRateLimiter(get_redis(), rate=25, burst=5)
    await send_message_safe(bot, chat_id, "Hi!", limiter)
"""

from __future__ import annotations

import logging

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramRetryAfter
from aiogram.types import InlineKeyboardMarkup, Message

from app.core.rate_limiter import AsyncRateLimiter

logger = logging.getLogger(__name__)


async def send_message_safe(
    bot: Bot,
    chat_id: int,
    text: str,
    rate_limiter: AsyncRateLimiter,
    *,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs,
) -> Message | None:
    """Send a text message, respecting the rate limiter and flood-wait."""
    await rate_limiter.acquire(f"send:{chat_id}")
    return await _retry_send(
        lambda: bot.send_message(
            chat_id, text, reply_markup=reply_markup, **kwargs
        ),
        what="message",
    )


async def send_photo_safe(
    bot: Bot,
    chat_id: int,
    photo: str,
    caption: str,
    reply_markup: InlineKeyboardMarkup,
    rate_limiter: AsyncRateLimiter,
    **kwargs,
) -> Message | None:
    """Send a photo post, respecting the rate limiter and flood-wait."""
    await rate_limiter.acquire(f"send:{chat_id}")
    return await _retry_send(
        lambda: bot.send_photo(
            chat_id,
            photo=photo,
            caption=caption,
            reply_markup=reply_markup,
            **kwargs,
        ),
        what="photo",
    )


# ------------------------------------------------------------------
# Internal – single FloodWait retry wrapper
# ------------------------------------------------------------------


async def _retry_send(factory, what: str = "message"):
    """Call *factory* and retry once on ``TelegramRetryAfter``."""
    try:
        return await factory()
    except TelegramRetryAfter as exc:
        logger.warning("FloodWait (%s) — sleeping %ss", what, exc.timeout)
        try:
            await _sleep(exc.timeout)
            return await factory()
        except TelegramAPIError as retry_exc:
            logger.exception(
                "TelegramAPIError on retry (%s): %s", what, retry_exc
            )
            return None
    except TelegramAPIError as exc:
        logger.exception("TelegramAPIError sending %s: %s", what, exc)
        return None


async def _sleep(seconds: int) -> None:
    """Small async sleep used after a FloodWait response."""
    import asyncio

    await asyncio.sleep(seconds)
