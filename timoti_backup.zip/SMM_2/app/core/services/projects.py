from datetime import datetime, timezone

from sqlalchemy import select

from app.core.models import Project, SubBot, ProjectSetup


async def create_project(session, admin_id: int, name: str) -> Project:
    project = Project(admin_id=admin_id, name=name)
    session.add(project)
    await session.flush()
    return project


async def get_project(session, project_id: int) -> Project | None:
    result = await session.execute(
        select(Project).where(Project.id == project_id)
    )
    return result.scalar_one_or_none()


async def list_projects(session, admin_id: int) -> list[Project]:
    result = await session.execute(
        select(Project).where(Project.admin_id == admin_id).order_by(Project.id)
    )
    return list(result.scalars().all())


async def list_all_projects(session) -> list[Project]:
    """Return every project in the system (used by member-role users)."""
    result = await session.execute(select(Project).order_by(Project.id))
    return list(result.scalars().all())


async def list_subbots_for_project(session, project_id: int) -> list[SubBot]:
    result = await session.execute(
        select(SubBot).where(SubBot.project_id == project_id).order_by(SubBot.id)
    )
    return list(result.scalars().all())


async def delete_project_check(session, project_id: int) -> tuple[bool, str]:
    result = await session.execute(
        select(SubBot).where(SubBot.project_id == project_id)
    )
    subbots = result.scalars().all()
    if subbots:
        return (
            False,
            f"Нельзя удалить: в проекте {len(subbots)} суб-бот(ов). Сначала удалите их.",
        )
    return True, "OK"


async def delete_project(session, project_id: int):
    result = await session.execute(
        select(Project).where(Project.id == project_id)
    )
    project = result.scalar_one_or_none()
    if project:
        setups_result = await session.execute(
            select(ProjectSetup).where(ProjectSetup.project_id == project_id)
        )
        for setup in setups_result.scalars().all():
            await session.delete(setup)
        await session.delete(project)
        await session.flush()


# ---------------------------------------------------------------------------
# Atomic picture + links setup via ProjectSetup table
# ---------------------------------------------------------------------------


async def setup_start(session, admin_id: int) -> ProjectSetup:
    setup = ProjectSetup(admin_id=admin_id, step=0)
    session.add(setup)
    await session.flush()
    return setup


async def setup_set_image(session, setup_id: int, file_id: str):
    result = await session.execute(
        select(ProjectSetup).where(ProjectSetup.id == setup_id)
    )
    setup = result.scalar_one_or_none()
    if setup:
        setup.image_file_id = file_id
        setup.step = 1
        await session.flush()


async def setup_set_url1(session, setup_id: int, url1: str):
    result = await session.execute(
        select(ProjectSetup).where(ProjectSetup.id == setup_id)
    )
    setup = result.scalar_one_or_none()
    if setup:
        setup.button1_url = url1
        setup.step = 2
        await session.flush()


async def setup_set_url2(session, setup_id: int, url2: str) -> Project | None:
    result = await session.execute(
        select(ProjectSetup).where(ProjectSetup.id == setup_id)
    )
    setup = result.scalar_one_or_none()
    if setup is None:
        return None

    setup.button2_url = url2
    setup.step = 3

    if setup.project_id:
        proj_result = await session.execute(
            select(Project).where(Project.id == setup.project_id)
        )
        project = proj_result.scalar_one_or_none()
        if project:
            project.image_file_id = setup.image_file_id
            project.button1_url = setup.button1_url
            project.button2_url = setup.button2_url
    else:
        project = Project(
            admin_id=setup.admin_id,
            name=f"Project #{setup.admin_id}/{int(datetime.now(timezone.utc).timestamp())}",
            image_file_id=setup.image_file_id,
            button1_url=setup.button1_url,
            button2_url=setup.button2_url,
        )
        session.add(project)
        await session.flush()
        setup.project_id = project.id

    await session.delete(setup)
    await session.flush()
    return project


async def record_achievement(
    session,
    project_id: int,
    mode: str,
    days: int,
    total_starts: int,
    regular_pct: float,
    premium_pct: float,
    steps: int,
    cost: float,
) -> Project:
    result = await session.execute(
        select(Project).where(Project.id == project_id)
    )
    project = result.scalar_one_or_none()
    if project is None:
        raise ValueError(f"Project {project_id} not found")

    project.achievement_mode = mode
    project.achievement_days = days
    project.achievement_delivered_starts = total_starts
    project.achievement_regular_pct = regular_pct
    project.achievement_premium_pct = premium_pct
    project.achievement_steps = steps
    project.achievement_cost = cost
    project.achieved_at = datetime.now(timezone.utc)
    await session.flush()
    return project
