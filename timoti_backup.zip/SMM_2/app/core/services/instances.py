from datetime import datetime, timezone

from sqlalchemy import select

from app.core.models import BotInstance, SubBot


async def list_instances(session, *, active_only: bool = False) -> list[BotInstance]:
    """Return controller instances, optionally limited to active rows."""
    stmt = select(BotInstance).order_by(BotInstance.id)
    if active_only:
        stmt = stmt.where(BotInstance.is_active.is_(True))
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def get_instance_by_token(session, token: str) -> BotInstance | None:
    result = await session.execute(
        select(BotInstance).where(BotInstance.bot_token == token)
    )
    return result.scalar_one_or_none()


async def token_in_use(session, token: str) -> bool:
    """Return whether a token is already a controller or project sub-bot."""
    instance = await session.execute(
        select(BotInstance.id).where(BotInstance.bot_token == token).limit(1)
    )
    if instance.scalar_one_or_none() is not None:
        return True
    subbot = await session.execute(
        select(SubBot.id).where(SubBot.bot_token == token).limit(1)
    )
    return subbot.scalar_one_or_none() is not None


async def add_instance(
    session,
    *,
    token: str,
    username: str | None,
    name: str | None,
    telegram_id: int | None,
    is_primary: bool = False,
) -> BotInstance:
    """Persist a validated controller-bot token."""
    instance = BotInstance(
        bot_token=token,
        bot_username=username,
        bot_name=name,
        telegram_id=telegram_id,
        is_primary=is_primary,
        is_active=True,
    )
    session.add(instance)
    await session.flush()
    return instance


async def ensure_primary(
    session,
    *,
    token: str,
    username: str | None = None,
    name: str | None = None,
    telegram_id: int | None = None,
) -> BotInstance:
    """Ensure the configured ``BOT_TOKEN`` has a persistent active row."""
    instance = await get_instance_by_token(session, token)
    now = datetime.now(timezone.utc)
    if instance is None:
        instance = await add_instance(
            session,
            token=token,
            username=username,
            name=name,
            telegram_id=telegram_id,
            is_primary=True,
        )
    else:
        instance.is_primary = True
        instance.is_active = True
        if username is not None:
            instance.bot_username = username
        if name is not None:
            instance.bot_name = name
        if telegram_id is not None:
            instance.telegram_id = telegram_id
        instance.updated_at = now
        await session.flush()
    return instance
