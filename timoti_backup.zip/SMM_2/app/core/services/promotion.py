"""
Promotion engine — the brain of the SMM controller.

Pipeline per sub-bot, per day:

1. Read the **admin profile** for growth/maintenance/variance/safeguard values.
2. If no daily ``StatWindow`` exists for today → plan one (base ± variance).
3. Split Regular/Premium according to the chosen strategy (20/80 or 100% premium).
4. Chunk orders to pieces of 10–20 (safe delivery rate).
5. Submit pending orders to the provider adapter.
6. On poll: accumulate delivered/cost into the window; once the window's
   orders all reach a terminal state, mark the window ``completed``.
7. Advance the growth step when a completed window delivered ≥80% — but only
   if the next step does not exceed ``growth_ceiling`` AND no admin goal-check
   is pending.
8. Admin confirms the goal → freeze the achievement, switch to maintenance.
9. Admin can later ``extend`` back to growth.

The engine uses profile values instead of hardcoded constants so the profile
screen is no longer decorative.
"""

import logging
import random
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select

from app.core.db import get_session
from app.core.models import Admin, Order, Project, StatWindow, SubBot

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tunables (hard ceilings that even a misconfigured profile cannot exceed)
# ---------------------------------------------------------------------------

ORDER_SIZE_MIN = 10
ORDER_SIZE_MAX = 20
SAFE_MAX_PER_MINUTE = 1
SAFE_WINDOW_HOURS = 24
SAFE_MAX_ORDERS = SAFE_WINDOW_HOURS * 60 * SAFE_MAX_PER_MINUTE  # 1440
MAX_RETRY = 3  # before an order is marked ``failed``
MAX_STEP = 30  # paranoia cap; with default config you hit the ceiling long before

SERVICE_REGULAR = 928
SERVICE_PREMIUM = 930


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


def _today(tz_name: str) -> date:
    return datetime.now(ZoneInfo(tz_name)).date()


def _tz(tz_name: str) -> ZoneInfo:
    return ZoneInfo(tz_name)


def _profile_daily_target(step: int, admin: Admin) -> int:
    """Base target for the given step, using the admin's growth profile.

    Growth formula from the original controller:
        base + step*step_size  with ±variance_pct variation.
    """
    base = (admin.growth_base or 200) + step * (admin.growth_step or 100)
    variance_pct = (admin.maintenance_variance_pct or 5.0) / 100.0
    variation = base * variance_pct
    return max(ORDER_SIZE_MIN, int(round(base + random.uniform(-variation, variation))))


def _maintenance_daily(admin: Admin) -> int:
    daily = admin.maintenance_daily or 200
    variance_pct = (admin.maintenance_variance_pct or 5.0) / 100.0
    variation = daily * variance_pct
    return max(ORDER_SIZE_MIN, int(round(daily + random.uniform(-variation, variation))))


def distribute_orders(total: int) -> list[int]:
    """Split *total* into random chunks of ORDER_SIZE_MIN–ORDER_SIZE_MAX."""
    if total <= 0:
        return []
    chunks: list[int] = []
    remaining = total
    while remaining > 0:
        size = random.randint(ORDER_SIZE_MIN, ORDER_SIZE_MAX)
        if size > remaining:
            size = remaining
        chunks.append(size)
        remaining -= size
    return chunks


def compute_window_start(tz: ZoneInfo, now: datetime | None = None) -> datetime:
    """Next promotion window start: today 09:00 + random(5,15) min.

    If that time is already in the past (relative to *now*), returns tomorrow's
    window instead.
    """
    if now is None:
        now = datetime.now(timezone.utc).astimezone(tz)
    base = now.replace(hour=9, minute=0, second=0, microsecond=0)
    offset = timedelta(minutes=random.randint(5, 15))
    candidate = base + offset
    if candidate <= now:
        candidate += timedelta(days=1)
    return candidate


def target_link(subbot: SubBot) -> str:
    """Return a ``https://t.me/<username>`` link the SMM panel expects."""
    username = subbot.bot_username
    if username:
        clean = username.lstrip("@")
        return f"https://t.me/{clean}"
    return f"https://t.me/bot_{subbot.id}"


# ---------------------------------------------------------------------------
# Core promotion engine
# ---------------------------------------------------------------------------


async def plan_daily_window(
    session, subbot_id: int, provider, settings
) -> tuple[StatWindow | None, list[Order]]:
    """Plan the next daily promotion window for a sub-bot.

    Creates ``StatWindow`` + ``Order`` records but does **not** submit them
    to the provider yet (``submit_pending_orders`` does that).

    The target respects ``growth_ceiling`` and the per-order safe rate.
    """
    result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return None, []

    if subbot.strategy in ("none", None) or subbot.is_paused:
        return None, []

    if subbot.maintenance_mode is True:
        # Maintenance is handled by a separate pipeline.
        return None, []

    if subbot.needs_goal_check:
        # Waiting for admin confirmation — do not plan new orders.
        return None, []

    # Admin profile drives the numbers.
    admin_telegram_id = await _admin_id_for_subbot(session, subbot)
    admin_result = await session.execute(
        select(Admin).where(Admin.telegram_id == admin_telegram_id)
    )
    admin = admin_result.scalar_one_or_none()
    if admin is None:
        return None, []

    # Window date = today (server-local TZ). Skip if already planned for today.
    tz = _tz(getattr(settings, "TIMEZONE", "UTC"))
    today = _today(tz.key if hasattr(tz, "key") else getattr(settings, "TIMEZONE", "UTC"))
    existing_result = await session.execute(
        select(StatWindow).where(
            StatWindow.subbot_id == subbot_id,
            StatWindow.window_date == today,
        )
    )
    if existing_result.scalar_one_or_none() is not None:
        return None, []

    ceiling = admin.growth_ceiling or 2000
    if subbot.current_step >= MAX_STEP:
        logger.warning("Subbot %s already at MAX_STEP; refusing to plan.", subbot_id)
        return None, []

    target = _profile_daily_target(subbot.current_step, admin)

    # Hard ceiling on daily volume.
    target = min(target, ceiling)
    # Hard safe-rate ceiling (orders/min over the window).
    target = min(target, SAFE_MAX_ORDERS)

    # Split regular/premium by strategy.
    if subbot.strategy == "100_premium":
        regular_qty = 0
        premium_qty = target
    else:
        # Default 20/80 split (Premium 20%, Regular 80%).
        premium_qty = round(target * 0.20)
        regular_qty = target - premium_qty

    window = StatWindow(
        subbot_id=subbot_id,
        project_id=subbot.project_id,
        planned_starts=target,
        strategy=subbot.strategy,
        window_date=today,
        status="planned",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    session.add(window)
    await session.flush()

    orders: list[Order] = []
    now = datetime.now(timezone.utc)

    for qty in distribute_orders(regular_qty):
        orders.append(
            Order(
                subbot_id=subbot_id,
                project_id=subbot.project_id,
                stat_window_id=window.id,
                service_id=SERVICE_REGULAR,
                service_type="regular",
                quantity=qty,
                status="pending",
                created_at=now,
                updated_at=now,
            )
        )

    for qty in distribute_orders(premium_qty):
        orders.append(
            Order(
                subbot_id=subbot_id,
                project_id=subbot.project_id,
                stat_window_id=window.id,
                service_id=SERVICE_PREMIUM,
                service_type="premium",
                quantity=qty,
                status="pending",
                created_at=now,
                updated_at=now,
            )
        )

    for o in orders:
        session.add(o)

    subbot.current_daily_plan = target
    subbot.last_window_at = datetime.now(timezone.utc)
    await session.flush()
    return window, orders


async def submit_pending_orders(
    session, subbot_id: int, provider, settings
) -> int:
    """Submit pending orders for a sub-bot to the provider.

    An order is retried up to ``MAX_RETRY`` times; after that it is marked
    ``failed`` so it no longer blocks the daily window.
    """
    subbot_result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = subbot_result.scalar_one_or_none()
    if subbot is None:
        return 0

    pending_result = await session.execute(
        select(Order).where(
            Order.subbot_id == subbot_id, Order.status == "pending"
        )
    )
    orders = pending_result.scalars().all()

    submitted = 0
    for order in orders:
        if (order.retry_count or 0) >= MAX_RETRY:
            order.status = "failed"
            continue
        try:
            resp = await provider.create_order(
                service_id=order.service_id,
                target=target_link(subbot),
                quantity=order.quantity,
            )
            if resp.success:
                order.provider_order_id = resp.order_id
                order.cost = resp.cost
                order.status = "in_progress"
                submitted += 1
            else:
                # Provider refused; record as failed (no silent retry).
                order.status = "failed"
                logger.warning(
                    "Provider refused order %s for subbot %s: %s",
                    order.id,
                    subbot_id,
                    resp.message,
                )
        except Exception:
            order.retry_count = (order.retry_count or 0) + 1
            logger.exception(
                "submit_pending_orders: subbot %s order %s failed (attempt %s/%s)",
                subbot_id,
                order.id,
                order.retry_count,
                MAX_RETRY,
            )

    await session.flush()
    return submitted


async def check_and_advance_step(session, subbot_id: int) -> dict:
    """Advance ``current_step`` once per completed window.

    Only the most recent window whose ``step_advanced`` flag is False is
    considered. This prevents the previously-observed infinite increment.
    """
    result = await session.execute(
        select(StatWindow)
        .where(
            StatWindow.subbot_id == subbot_id,
            StatWindow.status == "completed",
            StatWindow.step_advanced.is_(False),
        )
        .order_by(StatWindow.id.desc())
        .limit(1)
    )
    window = result.scalar_one_or_none()
    if window is None:
        return {"advanced": False, "reason": "no_pending_window"}

    subbot_result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = subbot_result.scalar_one_or_none()
    if subbot is None:
        return {"advanced": False, "reason": "subbot_missing"}

    admin_telegram_id = await _admin_id_for_subbot(session, subbot)
    admin_result = await session.execute(
        select(Admin).where(Admin.telegram_id == admin_telegram_id)
    )
    admin = admin_result.scalar_one_or_none()
    ceiling = (admin.growth_ceiling or 2000) if admin else 2000

    delivered = window.total_delivered or 0
    planned = window.planned_starts or 0

    # Mark the window as processed regardless of outcome so we never loop.
    window.step_advanced = True
    window.updated_at = datetime.now(timezone.utc)

    if planned <= 0 or (delivered / planned) < 0.80:
        return {
            "advanced": False,
            "reason": "under_80_pct",
            "delivered": delivered,
            "planned": planned,
        }

    next_target = _profile_daily_target(subbot.current_step + 1, admin) if admin else 0
    if next_target > ceiling or subbot.current_step + 1 > MAX_STEP:
        # Ask the admin to confirm the goal instead of auto-advancing.
        subbot.needs_goal_check = True
        await session.flush()
        return {
            "advanced": False,
            "reason": "ceiling_or_cap_reached",
            "delivered": delivered,
            "planned": planned,
        }

    subbot.current_step += 1
    subbot.work_days_completed = (subbot.work_days_completed or 0) + 1
    await session.flush()
    return {
        "advanced": True,
        "step": subbot.current_step,
        "delivered": delivered,
        "planned": planned,
    }


async def confirm_goal(session, subbot_id: int, project_id: int) -> dict:
    """Record achievement and switch the sub-bot to maintenance mode.

    The achievement summarises **all** completed windows for this sub-bot.
    """
    subbot_result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = subbot_result.scalar_one_or_none()
    if subbot is None:
        return {"error": "Sub-bot not found"}

    admin_telegram_id = await _admin_id_for_subbot(session, subbot)
    admin_result = await session.execute(
        select(Admin).where(Admin.telegram_id == admin_telegram_id)
    )
    admin = admin_result.scalar_one_or_none()

    windows_result = await session.execute(
        select(StatWindow).where(
            StatWindow.subbot_id == subbot_id,
            StatWindow.status == "completed",
        )
    )
    windows = windows_result.scalars().all()

    total_starts = sum(w.total_delivered or 0 for w in windows)
    days = len(windows)
    strategy = subbot.strategy or "20_80"
    regular_pct = 80.0 if strategy == "20_80" else 0.0
    premium_pct = 20.0 if strategy == "20_80" else 100.0
    cost = sum(w.cost or 0 for w in windows)

    from app.core.services.projects import record_achievement

    achievement = await record_achievement(
        session,
        project_id=project_id,
        mode=strategy,
        days=days,
        total_starts=total_starts,
        regular_pct=regular_pct,
        premium_pct=premium_pct,
        steps=subbot.current_step,
        cost=cost,
    )

    subbot.promotion_confirmed = True
    subbot.needs_goal_check = False
    subbot.maintenance_mode = True
    # Maintenance uses the admin's configured daily amount (default 200).
    subbot.maintenance_daily = (admin.maintenance_daily or 200) if admin else 200
    await session.flush()

    return {"subbot": subbot, "achievement": achievement}


async def extend_promotion(session, subbot_id: int):
    """Return the sub-bot from maintenance into growth mode."""
    result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return
    subbot.current_step += 1
    subbot.needs_goal_check = False
    subbot.promotion_confirmed = False
    subbot.maintenance_mode = False
    await session.flush()


async def pause_promotion(session, subbot_id: int):
    """Pause promotion and cancel any not-yet-submitted orders."""
    result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return
    subbot.is_paused = True

    pending_result = await session.execute(
        select(Order).where(
            Order.subbot_id == subbot_id, Order.status == "pending"
        )
    )
    for order in pending_result.scalars().all():
        order.status = "cancelled"
    await session.flush()


async def resume_promotion(session, subbot_id: int):
    """Resume a paused promotion (flip the flag)."""
    result = await session.execute(select(SubBot).where(SubBot.id == subbot_id))
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return
    subbot.is_paused = False
    await session.flush()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _admin_id_for_subbot(session, subbot: SubBot) -> int | None:
    """Resolve the owning admin's telegram_id for a sub-bot."""
    project = await session.get(Project, subbot.project_id) if subbot else None
    return project.admin_id if project else None
