import io
import csv
import zipfile
from datetime import datetime, timezone

from sqlalchemy import select

from app.core.models import Project, SubBot, Order, StartEvent, StatWindow


def mask_bot(bot: SubBot, index: int) -> dict:
    """Return a safe representation of a SubBot with sensitive fields replaced."""
    return {
        "code": f"BOT-{index}",
        "status": bot.status,
        "strategy": bot.strategy,
        "current_step": bot.current_step,
        "is_paused": bot.is_paused,
        "shadow": bot.is_shadow,
        "maintenance_mode": bot.maintenance_mode,
        "maintenance_daily": bot.maintenance_daily,
        "ping_enabled": bot.ping_enabled,
        "work_days_completed": bot.work_days_completed,
    }


def _ts(dt) -> str | None:
    """Format a datetime as UTC ISO 8601, or return None."""
    if dt is None:
        return None
    if isinstance(dt, datetime):
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.isoformat()
    if isinstance(dt, str):
        return dt
    return str(dt)


def _csv_bytes(rows: list[list[str]]) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerows(rows)
    return output.getvalue()


async def generate_json_export(session, admin_id: int | None, settings) -> dict:
    """Build a full anonymised JSON export.

    When ``admin_id`` is None, exports every project/sub-bot in the system
    (used for member-role users with read access to all bots).
    """

    proj_stmt = select(Project)
    if admin_id is not None:
        proj_stmt = proj_stmt.where(Project.admin_id == admin_id)
    projects = (await session.execute(proj_stmt)).scalars().all()

    subbot_stmt = select(SubBot).join(Project, SubBot.project_id == Project.id)
    if admin_id is not None:
        subbot_stmt = subbot_stmt.where(Project.admin_id == admin_id)
    subbots = list((await session.execute(subbot_stmt)).scalars().all())

    subbot_ids = [sb.id for sb in subbots]
    bot_code_map = {sb.id: f"BOT-{i + 1}" for i, sb in enumerate(subbots)}

    # Start events
    events: list = []
    if subbot_ids:
        ev_result = await session.execute(
            select(StartEvent).where(StartEvent.subbot_id.in_(subbot_ids))
        )
        for ev in ev_result.scalars().all():
            events.append({
                "code": bot_code_map.get(ev.subbot_id, "BOT-?"),
                "project_id": ev.project_id,
                "is_new": ev.is_new_user,
                "is_premium": ev.is_premium,
                "lang_code": ev.language_code,
                "response_type": ev.response_type,
                "processing_time_ms": ev.processing_time_ms,
                "created_at": _ts(ev.created_at),
            })

    # Orders
    orders: list = []
    if subbot_ids:
        ord_result = await session.execute(
            select(Order).where(Order.subbot_id.in_(subbot_ids))
        )
        for o in ord_result.scalars().all():
            orders.append({
                "code": bot_code_map.get(o.subbot_id, "BOT-?"),
                "service_id": o.service_id,
                "quantity": o.quantity,
                "status": o.status,
                "created_at": _ts(o.created_at),
            })

    # Stat windows
    windows: list = []
    if subbot_ids:
        win_result = await session.execute(
            select(StatWindow).where(StatWindow.subbot_id.in_(subbot_ids))
        )
        for w in win_result.scalars().all():
            windows.append({
                "code": bot_code_map.get(w.subbot_id, "BOT-?"),
                "planned_starts": w.planned_starts,
                "delivered_starts": w.total_delivered,
                "strategy": w.strategy,
                "status": w.status,
                "window_date": str(w.window_date) if w.window_date else None,
                "created_at": _ts(w.created_at),
            })

    # Achievements
    achievements: list = []
    for p in projects:
        mode = p.achievement_mode
        if mode and mode != "none":
            achievements.append({
                "project_id": p.id,
                "mode": mode,
                "days": p.achievement_days or 0,
                "total_starts": p.achievement_delivered_starts or 0,
                "regular_pct": p.achievement_regular_pct or 0,
                "premium_pct": p.achievement_premium_pct or 0,
                "steps": p.achievement_steps or 0,
                "cost": p.achievement_cost or 0,
                "recorded_at": _ts(p.achieved_at),
            })

    # Data quality block
    incomplete_intervals = sum(
        1 for w in windows
        if w.get("status") != "completed" and w.get("delivered_starts", 0) == 0
    )
    unknown_premium = sum(1 for e in events if e.get("is_premium") is None)
    tech_errors = sum(1 for o in orders if o.get("status") == "error")

    return {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "admin_id": admin_id,
        "projects": [
            {
                "id": p.id,
                "name": p.name,
                "image_file_id": None,  # never export
                "button1_url": p.button1_url,
                "button2_url": p.button2_url,
                "created_at": _ts(p.created_at) if hasattr(p, "created_at") else None,
            }
            for p in projects
        ],
        "subbots": [
            {**mask_bot(sb, i + 1), "project_id": sb.project_id}
            for i, sb in enumerate(subbots)
        ],
        "start_events": events,
        "orders": orders,
        "stat_windows": windows,
        "project_promotion_achievements": achievements,
        "data_quality": {
            "incomplete_intervals": incomplete_intervals,
            "unknown_premium_count": unknown_premium,
            "tech_error_count": tech_errors,
        },
    }


async def generate_csv_zip(session, admin_id: int, settings) -> io.BytesIO:
    """Create an in-memory ZIP of CSV files with the same data."""

    data = await generate_json_export(session, admin_id, settings)
    buf = io.BytesIO()

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # hourly_metrics.csv
        rows: list[list[str]] = [["code", "hour", "starts", "new_users"]]
        hourly: dict[tuple[str, str], dict] = {}
        for ev in data["start_events"]:
            ts = ev.get("created_at", "")
            hour_key = ts[:13] if ts else "unknown"
            key = (ev["code"], hour_key)
            if key not in hourly:
                hourly[key] = {"starts": 0, "new": 0}
            hourly[key]["starts"] += 1
            if ev.get("is_new"):
                hourly[key]["new"] += 1
        for (code, hour), vals in sorted(hourly.items()):
            rows.append([code, hour, str(vals["starts"]), str(vals["new"])])
        zf.writestr("hourly_metrics.csv", _csv_bytes(rows))

        # daily_metrics.csv
        rows = [["code", "date", "starts", "new_users", "premium"]]
        daily: dict[tuple[str, str], dict] = {}
        for ev in data["start_events"]:
            ts = ev.get("created_at", "")
            day_key = ts[:10] if ts else "unknown"
            key = (ev["code"], day_key)
            if key not in daily:
                daily[key] = {"starts": 0, "new": 0, "premium": 0}
            daily[key]["starts"] += 1
            if ev.get("is_new"):
                daily[key]["new"] += 1
            if ev.get("is_premium"):
                daily[key]["premium"] += 1
        for (code, day), vals in sorted(daily.items()):
            rows.append(
                [code, day, str(vals["starts"]), str(vals["new"]), str(vals["premium"])]
            )
        zf.writestr("daily_metrics.csv", _csv_bytes(rows))

        # orders.csv
        rows = [["code", "service_id", "quantity", "status", "created_at"]]
        for o in data["orders"]:
            rows.append(
                [
                    o["code"],
                    str(o["service_id"]),
                    str(o["quantity"]),
                    o["status"],
                    o.get("created_at", ""),
                ]
            )
        zf.writestr("orders.csv", _csv_bytes(rows))

        # changes_log.csv
        rows = [
            ["code", "strategy", "planned_starts", "delivered_starts", "status", "window_date"]
        ]
        for w in data["stat_windows"]:
            rows.append(
                [
                    w["code"],
                    w["strategy"],
                    str(w["planned_starts"]),
                    str(w.get("delivered_starts", 0)),
                    w["status"],
                    w.get("window_date", ""),
                ]
            )
        zf.writestr("changes_log.csv", _csv_bytes(rows))

    buf.seek(0)
    return buf
