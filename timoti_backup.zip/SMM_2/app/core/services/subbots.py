from datetime import datetime, timezone

from aiogram import Bot
from aiogram.exceptions import TelegramRetryAfter
from sqlalchemy import select

from app.core.models import SubBot, StatWindow


async def add_subbots_from_tokens(
    session, project_id: int, tokens: list[str], project, bot: Bot | None = None
) -> dict:
    """Add sub-bots from a list of bot tokens.

    Each token is validated via a temporary Bot instance (get_me). On success
    the SubBot record is created. On error the token+message is collected.
    The project is used to auto-inherit its achievement strategy if set.

    Tokens already present in the database are skipped (idempotent).
    """
    added: list[dict] = []
    errors: list[dict] = []
    seen_tokens: set[str] = set()

    # Pre-load existing tokens for this project to avoid IntegrityError storms.
    existing_result = await session.execute(
        select(SubBot.bot_token).where(SubBot.project_id == project_id)
    )
    existing_tokens = {row[0] for row in existing_result.all()}

    for raw in tokens:
        token = (raw or "").strip()
        if not token:
            continue
        if token in seen_tokens or token in existing_tokens:
            continue
        seen_tokens.add(token)

        temp_bot = Bot(token=token)
        try:
            me = await temp_bot.get_me()
            # Auto-inherit strategy if project has a confirmed achievement.
            strategy = "none"
            if (
                project
                and project.achievement_mode
                and project.achievement_mode != "none"
            ):
                strategy = project.achievement_mode
            subbot = SubBot(
                project_id=project_id,
                bot_token=token,
                bot_username=me.username,
                bot_name=me.first_name,
                telegram_id=me.id,
                # get_me succeeded, so the newly registered sub-bot is
                # immediately available rather than misleadingly "stopped".
                status="running",
                status_message=f"OK — @{me.username}",
                strategy=strategy,
            )
            session.add(subbot)
            await session.flush()

            added.append({
                "id": subbot.id,
                "username": me.username,
                "name": me.first_name,
            })
        except Exception as exc:
            errors.append({"token": token[:8] + "...", "error": str(exc)})
        finally:
            await temp_bot.session.close()

    return {"added": added, "errors": errors}


async def get_subbot(session, subbot_id: int) -> SubBot | None:
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    return result.scalar_one_or_none()


async def list_subbots(
    session, project_id: int | None = None, admin_id: int | None = None
) -> list[SubBot]:
    stmt = select(SubBot)
    if project_id is not None:
        stmt = stmt.where(SubBot.project_id == project_id)
    if admin_id is not None:
        from app.core.models import Project

        stmt = stmt.join(Project, SubBot.project_id == Project.id).where(
            Project.admin_id == admin_id
        )
    stmt = stmt.order_by(SubBot.id)
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def list_all_subbots(session) -> list[SubBot]:
    """Return every sub-bot in the system (used by member-role users)."""
    result = await session.execute(select(SubBot).order_by(SubBot.id))
    return list(result.scalars().all())


async def delete_subbot(session, subbot_id: int):
    """Hard-delete a sub-bot. Accepted orders with the provider are NOT cancelled."""
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    subbot = result.scalar_one_or_none()
    if subbot:
        await session.delete(subbot)
        await session.flush()


async def set_strategy(session, subbot_id: int, strategy: str):
    """Set a sub-bot's strategy.

    We intentionally do **not** create a StatWindow here: the scheduler will
    plan the next window at the proper time using the admin's growth profile.
    """
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return
    subbot.strategy = strategy
    await session.flush()


async def set_paused(session, subbot_id: int, paused: bool):
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    subbot = result.scalar_one_or_none()
    if subbot:
        subbot.is_paused = paused
        await session.flush()


async def set_shadow(session, subbot_id: int, shadow: bool):
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    subbot = result.scalar_one_or_none()
    if subbot:
        subbot.is_shadow = shadow
        await session.flush()


async def check_subbot(session, subbot_id: int, bot: Bot) -> tuple[str, str]:
    """Healthcheck: creates temp Bot from stored token, calls get_me.

    Returns (status, message).
    """
    result = await session.execute(
        select(SubBot).where(SubBot.id == subbot_id)
    )
    subbot = result.scalar_one_or_none()
    if subbot is None:
        return "unavailable", "Суб-бот не найден"

    temp_bot = Bot(token=subbot.bot_token)
    try:
        me = await temp_bot.get_me()
        subbot.status = "running"
        subbot.status_message = f"OK — @{me.username}"
        await session.flush()
        return "running", f"OK — @{me.username}"
    except TelegramRetryAfter:
        # Transient flood-wait — don't change persisted status.
        msg = "Flood wait — skipped"
        return subbot.status, msg
    except Exception as exc:
        # Token revoked / bot deleted. Everything else (network blips) is
        # left as-is so a one-off timeout doesn't flip a healthy bot to ⚫.
        msg = str(exc)
        if "Unauthorized" in msg or "bot was deactivated" in msg.lower() or "bot was blocked" in msg.lower():
            subbot.status = "unavailable"
            subbot.status_message = msg
            await session.flush()
            return "unavailable", msg
        return subbot.status, msg
    finally:
        await temp_bot.session.close()
