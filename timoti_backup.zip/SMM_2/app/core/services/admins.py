"""
Admin authorization service.

Role-based access (flat within each tier):

* Roles:
    - ``owner``  – the bootstrap admin; full access + can manage everyone.
    - ``admin``  – full access, functionally identical to owner for day-to-day
      use. An owner may later demote an admin to ``member`` without deleting.
    - ``member`` – "user" role in the UI. May view and operate projects,
      sub-bots and analytics but CANNOT manage admins, invite new users, or
      change profile/growth/maintenance settings.

* A row has "full access" when ``role in {"owner", "admin"}``. The legacy
  ``is_admin`` boolean is kept in sync with the role for backward compatibility.

* Admins are managed by full-access admins only: such a user can invite a new
  admin/member (by telegram_id), promote/demote, or remove an existing one.
  Self-removal is forbidden; the last full-access admin cannot be removed.

* The very first /start with an empty admin table bootstraps an owner directly
  — so the controller is usable out of the box, but access is immediately
  transferrable to others.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timezone

from sqlalchemy import select

from app.core.db import get_session
from app.core.models import (
    ADMIN_ROLE_ADMIN,
    ADMIN_ROLE_MEMBER,
    ADMIN_ROLE_OWNER,
    ADMIN_ROLES,
    ADMIN_ROLES_FULL_ACCESS,
    Admin,
    Project,
    SubBot,
)


# ---------------------------------------------------------------------------
# Bootstrap / lookup
# ---------------------------------------------------------------------------


async def get_or_create_admin(
    session, telegram_id: int, full_name: str | None = None
) -> Admin:
    """Return the Admin row for telegram_id, creating one if absent.

    A freshly-created row starts with ``is_admin=False`` — it only becomes a
    real admin via ``grant_admin`` (either the bootstrap in ``is_admin_user``
    or an explicit invite by another admin).
    """
    result = await session.execute(
        select(Admin).where(Admin.telegram_id == telegram_id)
    )
    admin = result.scalar_one_or_none()
    if admin is None:
        admin = Admin(
            telegram_id=telegram_id,
            full_name=full_name,
            profile_id=secrets.token_hex(6).upper(),
            is_admin=False,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        session.add(admin)
        await session.flush()
    elif full_name and admin.full_name != full_name:
        admin.full_name = full_name
        admin.updated_at = datetime.now(timezone.utc)
    return admin


async def is_admin_user(telegram_id: int, *, promote_if_first: bool = False) -> bool:
    """Return True iff telegram_id holds full-access rights (owner/admin).

    With ``promote_if_first`` and an empty admin table the caller is
    bootstrapped as owner (the first-/start flow). Used by ``/start``.

    The bootstrap path serialises concurrent first-/start calls with a
    PostgreSQL advisory lock so two simultaneous /start messages cannot both
    be promoted to owner.
    """
    async with get_session() as session:
        if promote_if_first:
            # Serialise the check-then-act bootstrap across concurrent calls.
            # The lock is transaction-scoped and released on commit/rollback.
            from sqlalchemy import text

            await session.execute(text("SELECT pg_advisory_xact_lock(88213)"))

        result = await session.execute(select(Admin))
        admins = result.scalars().all()

        if not admins:
            if promote_if_first:
                a = await get_or_create_admin(session, telegram_id=telegram_id)
                a.role = ADMIN_ROLE_OWNER
                a.is_admin = True
                await session.commit()
                return True
            return False

        result = await session.execute(
            select(Admin).where(Admin.telegram_id == telegram_id)
        )
        row = result.scalar_one_or_none()
        return bool(row and row.role in ADMIN_ROLES_FULL_ACCESS)


async def can_use_bots(telegram_id: int) -> bool:
    """Return True if telegram_id may use the controller bot at all.

    Any known row (owner/admin/member) may view and operate bots. Unknown
    telegram_ids return False so first access still requires an invite.
    """
    async with get_session() as session:
        result = await session.execute(
            select(Admin).where(Admin.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none() is not None


# ---------------------------------------------------------------------------
# Admin management (any admin can do these)
# ---------------------------------------------------------------------------


async def list_admins(session) -> list[Admin]:
    result = await session.execute(select(Admin).order_by(Admin.created_at))
    return list(result.scalars().all())


async def grant_admin(
    session,
    actor_telegram_id: int,
    new_telegram_id: int,
    *,
    role: str = ADMIN_ROLE_ADMIN,
) -> dict:
    """Add (or promote) a user.

    Only a full-access admin may call this. ``role`` defaults to "admin" (full
    access); pass ``ADMIN_ROLE_MEMBER`` to invite a limited "user".
    Returns a status dict.
    """
    if role not in ADMIN_ROLES:
        return {"ok": False, "error": f"unknown_role:{role}"}

    actor = (
        await session.execute(select(Admin).where(Admin.telegram_id == actor_telegram_id))
    ).scalar_one_or_none()
    if actor is None or actor.role not in ADMIN_ROLES_FULL_ACCESS:
        return {"ok": False, "error": "not_admin"}

    target = (
        await session.execute(select(Admin).where(Admin.telegram_id == new_telegram_id))
    ).scalar_one_or_none()
    if target is None:
        now = datetime.now(timezone.utc)
        target = Admin(
            telegram_id=new_telegram_id,
            profile_id=secrets.token_hex(6).upper(),
            role=role,
            is_admin=(role in ADMIN_ROLES_FULL_ACCESS),
            created_at=now,
            updated_at=now,
        )
        session.add(target)
        await session.flush()
    else:
        if target.role == role:
            return {"ok": False, "error": "already_role"}
        # Guardrail: demoting the last full-access admin would lock out the
        # controller bot. grant_admin shares this rule with set_admin_role.
        if (
            target.role in ADMIN_ROLES_FULL_ACCESS
            and role not in ADMIN_ROLES_FULL_ACCESS
        ):
            remaining = (
                await session.execute(
                    select(Admin).where(Admin.role.in_(ADMIN_ROLES_FULL_ACCESS))
                )
            ).scalars().all()
            if len(remaining) <= 1:
                return {"ok": False, "error": "last_admin"}
        target.role = role
        target.is_admin = role in ADMIN_ROLES_FULL_ACCESS
        target.updated_at = datetime.now(timezone.utc)

    await session.flush()
    return {"ok": True, "admin": target}


async def revoke_admin(session, actor_telegram_id: int, target_telegram_id: int) -> dict:
    """Remove a full-access admin (demote to member or delete if previously member).

    No self-removal; the last full-access admin cannot be removed.
    """
    actor = (
        await session.execute(select(Admin).where(Admin.telegram_id == actor_telegram_id))
    ).scalar_one_or_none()
    if actor is None or actor.role not in ADMIN_ROLES_FULL_ACCESS:
        return {"ok": False, "error": "not_admin"}

    if actor_telegram_id == target_telegram_id:
        return {"ok": False, "error": "no_self_remove"}

    target = (
        await session.execute(select(Admin).where(Admin.telegram_id == target_telegram_id))
    ).scalar_one_or_none()
    if target is None:
        return {"ok": False, "error": "not_found"}
    if target.role not in ADMIN_ROLES_FULL_ACCESS:
        return {"ok": False, "error": "not_admin_target"}

    # Count full-access admins — never remove the last one.
    admin_count = (
        await session.execute(
            select(Admin).where(Admin.role.in_(ADMIN_ROLES_FULL_ACCESS))
        )
    ).scalars().all()
    if len(admin_count) <= 1:
        return {"ok": False, "error": "last_admin"}

    # Demote to member (keeps the row so the user keeps bot access, but loses
    # admin rights). This matches the user's request: a revoked admin should
    # still be able to "use the bots".
    target.role = ADMIN_ROLE_MEMBER
    target.is_admin = False
    target.updated_at = datetime.now(timezone.utc)
    await session.flush()
    return {"ok": True, "demoted_to": ADMIN_ROLE_MEMBER}


async def set_admin_role(
    session, actor_telegram_id: int, target_telegram_id: int, role: str
) -> dict:
    """Promote/demote a user to an arbitrary valid role."""
    if role not in ADMIN_ROLES:
        return {"ok": False, "error": f"unknown_role:{role}"}

    actor = (
        await session.execute(select(Admin).where(Admin.telegram_id == actor_telegram_id))
    ).scalar_one_or_none()
    if actor is None or actor.role not in ADMIN_ROLES_FULL_ACCESS:
        return {"ok": False, "error": "not_admin"}

    target = (
        await session.execute(select(Admin).where(Admin.telegram_id == target_telegram_id))
    ).scalar_one_or_none()
    if target is None:
        return {"ok": False, "error": "not_found"}

    # Guardrail: cannot leave the system without at least one full-access admin.
    if (
        target.role in ADMIN_ROLES_FULL_ACCESS
        and role not in ADMIN_ROLES_FULL_ACCESS
    ):
        remaining = (
            await session.execute(
                select(Admin).where(Admin.role.in_(ADMIN_ROLES_FULL_ACCESS))
            )
        ).scalars().all()
        if len(remaining) <= 1:
            return {"ok": False, "error": "last_admin"}

    target.role = role
    target.is_admin = role in ADMIN_ROLES_FULL_ACCESS
    target.updated_at = datetime.now(timezone.utc)
    await session.flush()
    return {"ok": True, "role": role}


# ---------------------------------------------------------------------------
# Profile helpers
# ---------------------------------------------------------------------------


async def set_admin_api_key(session, telegram_id: int, api_key: str):
    result = await session.execute(
        select(Admin).where(Admin.telegram_id == telegram_id)
    )
    admin = result.scalar_one_or_none()
    if admin is None:
        admin = Admin(
            telegram_id=telegram_id,
            api_key=api_key,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        session.add(admin)
    else:
        admin.api_key = api_key
        admin.updated_at = datetime.now(timezone.utc)
    await session.flush()


async def get_admin_profile(session, telegram_id: int) -> dict:
    result = await session.execute(
        select(Admin).where(Admin.telegram_id == telegram_id)
    )
    admin = result.scalar_one_or_none()
    if admin is None:
        return {}

    projects_result = await session.execute(
        select(Project).where(Project.admin_id == telegram_id)
    )
    projects = projects_result.scalars().all()

    subbots_result = await session.execute(
        select(SubBot)
        .join(Project, SubBot.project_id == Project.id)
        .where(Project.admin_id == telegram_id)
    )
    subbots = subbots_result.scalars().all()

    return {
        "api_key": admin.api_key,
        "daily_budget": admin.daily_budget,
        "daily_limit": admin.daily_limit,
        "projects_count": len(projects),
        "subbots_count": len(subbots),
    }
