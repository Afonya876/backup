import logging

from aiogram import Bot
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNotFound,
    TelegramRetryAfter,
    TelegramUnauthorizedError,
)
from sqlalchemy import select

from app.core.models import SubBot

logger = logging.getLogger(__name__)

# Statuses that mean the bot is effectively dead / can't operate.
BAD_STATUSES = {"unavailable", "needs_setup"}


async def enable_status_chat(session, chat_id: int, subbot_ids: list[int]):
    """Enable ping monitoring for the given sub-bots, storing the chat_id."""
    result = await session.execute(
        select(SubBot).where(SubBot.id.in_(subbot_ids))
    )
    for subbot in result.scalars().all():
        subbot.ping_enabled = True
        subbot.ping_chat_id = chat_id
    await session.flush()


async def disable_status_chat(session, subbot_ids: list[int]):
    """Clear ping fields for the given sub-bots."""
    result = await session.execute(
        select(SubBot).where(SubBot.id.in_(subbot_ids))
    )
    for subbot in result.scalars().all():
        subbot.ping_enabled = False
        subbot.ping_chat_id = None
    await session.flush()


async def run_ping_check(
    session, subbot_ids: list[int], bot: Bot, settings=None
) -> list[dict]:
    """Send a silent ".ping" message via each sub-bot to its status chat.

    Returns a list of result dicts with subbot_id, previous status, new status
    and message. Callers can use ``previous_status``/``status`` to detect
    transitions (e.g. running -> unavailable) and notify the team.
    """
    results: list[dict] = []

    result = await session.execute(
        select(SubBot).where(SubBot.id.in_(subbot_ids))
    )
    subbots = result.scalars().all()

    for subbot in subbots:
        previous_status = subbot.status
        entry = {
            "subbot_id": subbot.id,
            "bot_username": subbot.bot_username,
            "previous_status": previous_status,
            "status": subbot.status,
            "message": "",
        }

        if not subbot.ping_chat_id:
            entry["message"] = "No ping chat configured"
            results.append(entry)
            continue

        temp_bot = Bot(token=subbot.bot_token)
        try:
            await temp_bot.send_message(chat_id=subbot.ping_chat_id, text=".ping")
            subbot.status = "running"
            subbot.status_message = "Ping sent successfully"
            entry["status"] = "running"
            entry["message"] = "Ping sent successfully"
        except TelegramUnauthorizedError:
            # Token revoked or bot deleted by Telegram — no point retrying.
            subbot.status = "unavailable"
            subbot.status_message = "Invalid token or bot was deleted"
            entry["status"] = "unavailable"
            entry["message"] = "Invalid token or bot was deleted"
        except TelegramForbiddenError:
            # Bot is in the chat but cannot send messages (kicked/no rights).
            subbot.status = "needs_setup"
            subbot.status_message = "Bot cannot send messages in chat"
            entry["status"] = "needs_setup"
            entry["message"] = "Bot cannot send messages in chat"
        except TelegramBadRequest as exc:
            # "chat not found" (400) — the group was deleted, or the user chat
            # does not exist / was never opened. Telegram returns 400, not 404.
            msg = str(exc).lower()
            if "chat not found" in msg or "chat_id" in msg:
                subbot.status = "needs_setup"
                subbot.status_message = "Status chat not found (deleted?)"
                entry["status"] = "needs_setup"
                entry["message"] = "Status chat not found (deleted?)"
            else:
                # Some other malformed request — transient, don't change status.
                entry["message"] = f"Bad request: {exc}"
        except TelegramNotFound:
            # Message / peer not found — treat as needs_setup (no group access).
            subbot.status = "needs_setup"
            subbot.status_message = "Peer not found"
            entry["status"] = "needs_setup"
            entry["message"] = "Peer not found"
        except TelegramRetryAfter:
            # Flood-wait / rate-limit — do not change status.
            entry["message"] = "Flood wait — skipped"
        except Exception as exc:
            # Any other transient error — log but don't change status.
            entry["message"] = f"Network error: {exc}"
        finally:
            await temp_bot.session.close()

        results.append(entry)

        if entry["status"] in BAD_STATUSES and previous_status not in BAD_STATUSES:
            logger.warning(
                "SubBot %s (@%s) went from %s to %s: %s",
                subbot.id,
                subbot.bot_username,
                previous_status,
                entry["status"],
                entry["message"],
            )

    await session.flush()
    return results
