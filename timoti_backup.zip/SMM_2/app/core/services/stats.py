from datetime import date, datetime, timedelta, timezone

from sqlalchemy import select

from app.core.models import StartEvent, SubBot, Project


async def record_start_event(
    session,
    subbot_id: int,
    project_id: int,
    user_id: int,
    is_new: bool,
    lang_code: str | None,
    payload: str | None,
    is_premium: bool,
    response_type: str,
    processing_time_ms: int | None,
) -> StartEvent:
    event = StartEvent(
        subbot_id=subbot_id,
        project_id=project_id,
        user_telegram_id=user_id,
        is_new_user=is_new,
        language_code=lang_code,
        payload=payload,
        is_premium=is_premium,
        response_type=response_type,
        processing_time_ms=processing_time_ms,
        created_at=datetime.now(timezone.utc),
    )
    session.add(event)
    await session.flush()
    return event


async def record_direct_message(
    session, subbot_id: int, project_id: int, user_id: int
) -> StartEvent:
    return await record_start_event(
        session,
        subbot_id=subbot_id,
        project_id=project_id,
        user_id=user_id,
        is_new=False,
        lang_code=None,
        payload="direct",
        is_premium=False,
        response_type="text",
        processing_time_ms=None,
    )


def _date_range(from_date: date, to_date: date):
    start_dt = datetime.combine(from_date, datetime.min.time(), tzinfo=timezone.utc)
    end_dt = datetime.combine(
        to_date + timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc
    )
    return start_dt, end_dt


async def get_subbot_stats(
    session, subbot_id: int, from_date: date, to_date: date
) -> dict:
    start_dt, end_dt = _date_range(from_date, to_date)
    stmt = (
        select(StartEvent)
        .where(StartEvent.subbot_id == subbot_id)
        .where(StartEvent.created_at >= start_dt)
        .where(StartEvent.created_at < end_dt)
    )
    result = await session.execute(stmt)
    events = result.scalars().all()

    total = len(events)
    new_users = sum(1 for e in events if e.is_new_user)
    premium = sum(1 for e in events if e.is_premium)
    processing_vals = [
        e.processing_time_ms for e in events if e.processing_time_ms is not None
    ]
    avg_processing = sum(processing_vals) / len(processing_vals) if processing_vals else 0

    return {
        "subbot_id": subbot_id,
        "from_date": from_date.isoformat(),
        "to_date": to_date.isoformat(),
        "total_starts": total,
        "new_users": new_users,
        "returning_users": total - new_users,
        "premium_users": premium,
        "avg_processing_time_ms": round(avg_processing, 1),
    }


async def get_project_stats(
    session, project_id: int, from_date: date, to_date: date
) -> dict:
    start_dt, end_dt = _date_range(from_date, to_date)
    stmt = (
        select(StartEvent)
        .where(StartEvent.project_id == project_id)
        .where(StartEvent.created_at >= start_dt)
        .where(StartEvent.created_at < end_dt)
    )
    result = await session.execute(stmt)
    events = result.scalars().all()

    total = len(events)
    new_users = sum(1 for e in events if e.is_new_user)
    premium = sum(1 for e in events if e.is_premium)

    by_subbot: dict[int, int] = {}
    for e in events:
        by_subbot[e.subbot_id] = by_subbot.get(e.subbot_id, 0) + 1

    return {
        "project_id": project_id,
        "from_date": from_date.isoformat(),
        "to_date": to_date.isoformat(),
        "total_starts": total,
        "new_users": new_users,
        "returning_users": total - new_users,
        "premium_users": premium,
        "by_subbot": by_subbot,
    }


async def get_aggregated_stats(
    session, admin_id: int | None, from_date: date, to_date: date
) -> dict:
    """Get aggregated stats. If admin_id is None, include all projects (member role)."""
    start_dt, end_dt = _date_range(from_date, to_date)

    proj_stmt = select(Project.id)
    if admin_id is not None:
        proj_stmt = proj_stmt.where(Project.admin_id == admin_id)
    proj_result = await session.execute(proj_stmt)
    project_ids = [row[0] for row in proj_result.all()]

    if not project_ids:
        return {
            "admin_id": admin_id,
            "from_date": from_date.isoformat(),
            "to_date": to_date.isoformat(),
            "total_starts": 0,
            "new_users": 0,
            "returning_users": 0,
            "premium_users": 0,
            "projects_count": 0,
            "by_project": {},
        }

    stmt = (
        select(StartEvent)
        .where(StartEvent.project_id.in_(project_ids))
        .where(StartEvent.created_at >= start_dt)
        .where(StartEvent.created_at < end_dt)
    )
    result = await session.execute(stmt)
    events = result.scalars().all()

    total = len(events)
    new_users = sum(1 for e in events if e.is_new_user)
    premium = sum(1 for e in events if e.is_premium)

    by_project: dict[int, int] = {}
    for e in events:
        by_project[e.project_id] = by_project.get(e.project_id, 0) + 1

    return {
        "admin_id": admin_id,
        "from_date": from_date.isoformat(),
        "to_date": to_date.isoformat(),
        "total_starts": total,
        "new_users": new_users,
        "returning_users": total - new_users,
        "premium_users": premium,
        "projects_count": len(project_ids),
        "by_project": by_project,
    }
