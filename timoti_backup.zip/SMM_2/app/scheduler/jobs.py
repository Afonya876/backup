"""
Background job scheduler.

Runs periodic promotion-cycle ticks, ping healthchecks, and maintenance-mode
orders via APScheduler's AsyncIOScheduler.

The promotion tick is the heart of the system: it plans missing daily
windows, submits pending orders, polls in-progress orders, finalises
completed windows, and advances the growth step — all driven by the
admin's profile values (see ``app.core.services.promotion``).
"""

from __future__ import annotations

import logging
import random
from datetime import date, datetime, timedelta, timezone
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy import select
from zoneinfo import ZoneInfo

from app.core.db import get_session
from app.core.models import Admin, Order, Project, StatWindow, SubBot
from app.core.telegram_sender import send_message_safe
from app.core.provider import get_provider_adapter
from app.core.services.promotion import (
    check_and_advance_step,
    plan_daily_window,
    submit_pending_orders,
)
from app.core.services.ping_health import run_ping_check

logger = logging.getLogger(__name__)


def _today(tz_name: str) -> date:
    return datetime.now(ZoneInfo(tz_name)).date()


async def _admin_for_subbot(session, subbot: SubBot) -> Admin | None:
    project = await session.get(Project, subbot.project_id) if subbot else None
    if project is None:
        return None
    result = await session.execute(
        select(Admin).where(Admin.telegram_id == project.admin_id)
    )
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Job: promotion cycle
# ---------------------------------------------------------------------------


async def _tick_promotion(settings: dict[str, Any]) -> None:
    """
    Run the full promotion-cycle pipeline:

    1. Plan any missing daily windows.
    2. Submit all pending orders.
    3. Poll in-progress orders, advance stats, and complete windows.
    4. Advance the promotion step once a window is fully delivered.

    Errors for an individual subbot are logged and skipped so one broken
    subbot does not abort the whole cycle.
    """
    provider = get_provider_adapter(settings)
    today = _today(settings.get("TIMEZONE", "UTC"))

    async with get_session() as session:
        # --- 1. Subbots eligible for promotion -----------------------------
        result = await session.execute(
            select(SubBot).where(
                SubBot.strategy != "none",
                SubBot.is_paused.is_(False),
                SubBot.maintenance_mode.is_(False),
            )
        )
        subbots = result.scalars().all()

        # --- Plan missing daily windows ------------------------------------
        for subbot in subbots:
            try:
                await plan_daily_window(session, subbot.id, provider, settings)
            except Exception:
                logger.exception(
                    "Failed to plan daily window for subbot %s", subbot.id
                )

        await session.commit()

        # --- 2. Submit pending orders --------------------------------------
        for subbot in subbots:
            try:
                await submit_pending_orders(session, subbot.id, provider, settings)
            except Exception:
                logger.exception(
                    "Failed to submit pending orders for subbot %s", subbot.id
                )

        await session.commit()

        # --- 3. Poll in-progress orders & update stats ---------------------
        result = await session.execute(
            select(Order).where(Order.status == "in_progress")
        )
        in_progress_orders = result.scalars().all()

        subbot_ids_with_progress: set[int] = {o.subbot_id for o in in_progress_orders}

        for order in in_progress_orders:
            try:
                remote = await provider.get_status(order.provider_order_id)
                status = (remote.status or "").lower()

                if status in ("completed", "partial", "done"):
                    order.status = "completed" if status != "partial" else "partial"
                    order.completed_at = datetime.now(timezone.utc)

                    # delivered so far = quantity - remaining
                    remaining = max(0, remote.starts_remaining or 0)
                    done_qty = max(0, order.quantity - remaining)

                    # Credit delivery to the window the order actually belongs
                    # to (set at planning time via stat_window_id).
                    window = None
                    if order.stat_window_id is not None:
                        window = await session.get(StatWindow, order.stat_window_id)
                    if window is None:
                        # Fallback for legacy orders without stat_window_id.
                        win_result = await session.execute(
                            select(StatWindow)
                            .where(
                                StatWindow.subbot_id == order.subbot_id,
                                StatWindow.status != "completed",
                            )
                            .order_by(StatWindow.id.desc())
                            .limit(1)
                        )
                        window = win_result.scalar_one_or_none()
                    if window is not None:
                        if order.service_type == "regular":
                            window.delivered_regular += done_qty
                        else:
                            window.delivered_premium += done_qty
                        window.total_delivered += done_qty
                        window.cost += order.cost or 0.0

                    logger.info(
                        "Order %s for subbot %s completed (done=%d)",
                        order.id,
                        order.subbot_id,
                        done_qty,
                    )

                elif status in ("failed", "canceled", "cancelled", "error", "rejected"):
                    order.status = "failed"
                    logger.warning(
                        "Order %s for subbot %s failed (provider status=%s)",
                        order.id,
                        order.subbot_id,
                        status,
                    )

                elif status in ("processing", "in_progress", "inprogress", "pending"):
                    # Still in flight — nothing to do.
                    pass

                else:
                    logger.warning(
                        "Unknown provider status %r for order %s",
                        status,
                        order.id,
                    )
            except Exception:
                logger.exception("Failed to poll status for order %s", order.id)

        await session.commit()

        # --- 4. Complete finished windows ---------------------------------
        # Iterate ALL non-completed windows (not just those with currently
        # in-progress orders) so that windows whose orders all reached a
        # terminal state (incl. all-failed / all-cancelled) are finalized.
        try:
            win_result = await session.execute(
                select(StatWindow).where(StatWindow.status != "completed")
            )
            all_open_windows = win_result.scalars().all()
        except Exception:
            logger.exception("Failed to load open stat windows")
            all_open_windows = []

        for window in all_open_windows:
            try:
                ord_result = await session.execute(
                    select(Order).where(Order.stat_window_id == window.id)
                )
                window_orders = ord_result.scalars().all()
                # A window with no orders yet is not ready to finalize.
                if window_orders and all(
                    o.status in ("completed", "partial", "cancelled", "failed")
                    for o in window_orders
                ):
                    window.status = "completed"
                    window.updated_at = datetime.now(timezone.utc)
                    logger.info(
                        "StatWindow %s for subbot %s completed",
                        window.id,
                        window.subbot_id,
                    )
            except Exception:
                logger.exception(
                    "Failed to finalize stat window %s", window.id
                )

        await session.commit()

        # --- 5. Update subbot aggregate counters ---------------------------
        # Re-aggregate for ALL sub-bots (incl. maintenance mode) so that
        # maintenance-day deliveries are reflected in the live counters.
        try:
            all_subbots_result = await session.execute(select(SubBot))
            all_subbots = all_subbots_result.scalars().all()
        except Exception:
            logger.exception("Failed to load subbots for aggregation")
            all_subbots = subbots

        for subbot in all_subbots:
            try:
                agg_result = await session.execute(
                    select(StatWindow).where(
                        StatWindow.subbot_id == subbot.id,
                        StatWindow.status == "completed",
                    )
                )
                windows = agg_result.scalars().all()
                subbot.delivered_regular = sum(w.delivered_regular for w in windows)
                subbot.delivered_premium = sum(w.delivered_premium for w in windows)
                subbot.total_delivered = sum(w.total_delivered for w in windows)
                subbot.total_cost = sum(w.cost or 0.0 for w in windows)
            except Exception:
                logger.exception(
                    "Failed to aggregate counters for subbot %s", subbot.id
                )

        await session.commit()

        # --- 6. Advance steps ----------------------------------------------
        for subbot in subbots:
            try:
                await check_and_advance_step(session, subbot.id)
            except Exception:
                logger.exception(
                    "Failed to advance step for subbot %s", subbot.id
                )

        await session.commit()


# ---------------------------------------------------------------------------
# Job: ping healthcheck
# ---------------------------------------------------------------------------


async def _tick_ping_health(settings: dict[str, Any], bot: Any) -> None:
    """Run a ping healthcheck across all subbots with ping_enabled=True.

    Whenever a bot transitions from a live status to a bad one (unavailable or
    needs_setup), we notify every authorised controller user via Telegram so the
    owner can react to a deleted/revoked bot or a lost group.
    """
    from app.core.rate_limiter import AsyncRateLimiter
    from app.core.redis import get_redis

    rate_limiter = AsyncRateLimiter(
        get_redis(),
        rate=settings.get("RATE_LIMIT_MESSAGES_PER_SECOND", 25),
        burst=5,
    )

    async with get_session() as session:
        # Health monitoring is independent of promotion pause: a paused bot
        # still needs to be checked for deletion, revocation, or group access.
        result = await session.execute(
            select(SubBot.id).where(SubBot.ping_enabled.is_(True))
        )
        ping_enabled_ids = [row[0] for row in result.all()]

    if not ping_enabled_ids:
        logger.debug("No ping-enabled subbots; skipping healthcheck.")
        return

    logger.info("Running ping healthcheck for %d subbot(s)", len(ping_enabled_ids))

    # Load admin recipients before the check so we can notify them after.
    async with get_session() as session:
        admin_rows = (
            await session.execute(select(Admin.telegram_id))
        ).scalars().all()
        admin_ids = [int(tid) for tid in admin_rows]

    try:
        async with get_session() as session:
            results = await run_ping_check(session, ping_enabled_ids, bot, settings)
    except Exception:
        logger.exception("Ping healthcheck failed")
        return

    # Collect transitions to bad states; we batch these into one message per
    # recipient to avoid flooding the chat with individual notifications.
    deaths: list[dict] = [
        r
        for r in results
        if r["status"] in {"unavailable", "needs_setup"}
        and r["previous_status"] not in {"unavailable", "needs_setup"}
    ]
    if not deaths:
        return

    lines = []
    for death in deaths:
        uname = death.get("bot_username") or "неизвестный"
        lines.append(
            f"🤖 @{uname} (id {death['subbot_id']}): "
            f"{death['previous_status']} → {death['status']}\n"
            f"   {death['message']}"
        )
    text = (
        "⚠️ Внимание: суб-бот(ы) стали недоступны!\n\n"
        + "\n\n".join(lines)
        + "\n\nПроверьте токен бота."
    )

    try:
        from app.bot.keyboards import build_ping_control_kb
        reply_markup = build_ping_control_kb()
    except Exception:
        reply_markup = None

    logger.info(
        "Notifying %d admin(s) about %d dead bot(s)",
        len(admin_ids),
        len(deaths),
    )
    for tid in admin_ids:
        try:
            await send_message_safe(
                bot, tid, text, rate_limiter, reply_markup=reply_markup
            )
        except Exception:
            logger.exception("Failed to notify admin %s about dead bot(s)", tid)


# ---------------------------------------------------------------------------
# Job: maintenance-mode orders
# ---------------------------------------------------------------------------


async def _tick_maintenance(settings: dict[str, Any]) -> None:
    """For subbots in maintenance mode, submit a small daily Regular order.

    Uses the admin's configured ``maintenance_service_id`` and
    ``maintenance_daily`` values.
    """
    provider = get_provider_adapter(settings)
    today = _today(settings.get("TIMEZONE", "UTC"))

    async with get_session() as session:
        result = await session.execute(
            select(SubBot).where(
                SubBot.maintenance_mode.is_(True),
                SubBot.is_paused.is_(False),
            )
        )
        subbots = result.scalars().all()

        now = datetime.now(timezone.utc)
        for subbot in subbots:
            try:
                admin = await _admin_for_subbot(session, subbot)
                service_id = (admin.maintenance_service_id or 928) if admin else 928
                daily = (admin.maintenance_daily or 200) if admin else 200
                variance_pct = (admin.maintenance_variance_pct or 5.0) if admin else 5.0
                variation = daily * variance_pct / 100.0
                qty = max(10, int(round(daily + random.uniform(-variation, variation))))

                # Skip if a window already exists today.
                win_result = await session.execute(
                    select(StatWindow).where(
                        StatWindow.subbot_id == subbot.id,
                        StatWindow.window_date == today,
                    )
                )
                if win_result.scalar_one_or_none() is not None:
                    continue

                window = StatWindow(
                    subbot_id=subbot.id,
                    project_id=subbot.project_id,
                    planned_starts=qty,
                    strategy="20_80",
                    window_date=today,
                    status="planned",
                    created_at=now,
                    updated_at=now,
                )
                session.add(window)
                await session.flush()

                order = Order(
                    subbot_id=subbot.id,
                    project_id=subbot.project_id,
                    service_id=service_id,
                    service_type="regular",
                    quantity=qty,
                    status="pending",
                    created_at=now,
                    updated_at=now,
                )
                session.add(order)
                await session.flush()

                from app.core.services.promotion import target_link

                resp = await provider.create_order(
                    service_id=service_id,
                    target=target_link(subbot),
                    quantity=qty,
                )
                if resp.success:
                    order.provider_order_id = resp.order_id
                    order.cost = resp.cost
                    order.status = "in_progress"
                else:
                    order.status = "failed"
                    logger.warning(
                        "Maintenance order refused for subbot %s: %s",
                        subbot.id,
                        resp.message,
                    )

                logger.info(
                    "Maintenance window submitted for subbot %s (qty=%d)",
                    subbot.id,
                    qty,
                )
            except Exception:
                logger.exception(
                    "Maintenance tick failed for subbot %s", subbot.id
                )

        await session.commit()


# ---------------------------------------------------------------------------
# Scheduler lifecycle
# ---------------------------------------------------------------------------


def create_scheduler(settings: dict[str, Any], bot: Any) -> AsyncIOScheduler:
    """Create and configure the APScheduler with all background jobs."""
    tz_name = settings.get("TIMEZONE", "UTC")
    scheduler = AsyncIOScheduler(timezone=ZoneInfo(tz_name))

    scheduler.add_job(
        _tick_promotion,
        "interval",
        minutes=10,
        args=[settings],
        id="tick_promotion",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        _tick_ping_health,
        "interval",
        minutes=35,
        args=[settings, bot],
        id="tick_ping_health",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        _tick_maintenance,
        "interval",
        minutes=30,
        args=[settings],
        id="tick_maintenance",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    logger.info(
        "Scheduler created with jobs: tick_promotion(10m), "
        "tick_ping_health(35m), tick_maintenance(30m)"
    )
    return scheduler


def start_scheduler(scheduler: AsyncIOScheduler) -> None:
    """Start the scheduler if it is not already running."""
    if not scheduler.running:
        scheduler.start()
        logger.info("Scheduler started")
    else:
        logger.warning("Scheduler already running; start ignored")


def stop_scheduler(scheduler: AsyncIOScheduler) -> None:
    """Shut the scheduler down."""
    if scheduler.running:
        scheduler.shutdown(wait=True)
        logger.info("Scheduler stopped")
    else:
        logger.warning("Scheduler not running; stop ignored")
