"""
Common handlers – ``/start`` and ``/cancel`` (and the ❌ Отмена button).

Authorization is database-backed: a user is an admin iff their ``Admin`` row
has ``is_admin=True``. The very first /start with an empty admin table
bootstraps that user as the owner. After that, only existing admins can add
more admins (see the admin-management UI in the profile section).
"""

from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app.bot.keyboards import main_kb
from app.core.services.admins import can_use_bots, is_admin_user

logger = logging.getLogger(__name__)

router = Router(name="common")

MAIN_MENU_TEXT = (
    "👋 <b>Добро пожаловать в SMM Bot!</b>\n\n"
    "Я помогу вам продвигать ваши Telegram-боты.\n"
    "Выберите действие из меню ниже."
)


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    """Handle /start — bootstrap first user as owner, then gate by DB role."""
    await state.clear()

    # Ignore non-private chats for admin bootstrap.
    if message.chat.type != ChatType.PRIVATE:
        await message.answer("Этот бот работает в личных сообщениях.")
        return

    uid = message.from_user.id

    try:
        is_admin = await is_admin_user(uid, promote_if_first=True)
    except Exception:
        logger.exception("DB error in /start for uid=%s", uid)
        await message.answer("⚠️ Временная ошибка. Попробуйте ещё раз через минуту.")
        return

    if is_admin:
        await message.answer(MAIN_MENU_TEXT, reply_markup=main_kb)
        return

    try:
        has_access = await can_use_bots(uid)
    except Exception:
        logger.exception("DB error in can_use_bots for uid=%s", uid)
        await message.answer("⚠️ Временная ошибка. Попробуйте ещё раз через минуту.")
        return

    if has_access:
        # A member (limited "user" role) may use the controller bot but
        # cannot manage admins/settings.
        await message.answer(MAIN_MENU_TEXT, reply_markup=main_kb)
    else:
        await message.answer(
            "⛔ У вас нет доступа к боту.\n"
            "Обратитесь к администратору, чтобы получить доступ."
        )


@router.message(Command("cancel"))
@router.message(F.text.casefold() == "❌ отмена")
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    """Clear FSM state and return to the main menu."""
    await state.clear()
    await message.answer("Действие отменено.", reply_markup=main_kb)
