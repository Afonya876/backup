"""
``/start`` preview simulation and start-event recording helpers.

The controller bot's plain ``/start`` is handled by :mod:`app.bot.handlers.common`.
This module deals with the *sub-bot side* of ``/start`` in the controller:

* ``/start preview <subbot_id>`` and the ``?start=bot`` deep-link payload preview
  how a sub-bot would answer ``/start`` (text or post mode) and record the event.
* ``/simulate_start <subbot_id> [lang_code]`` — admin-only simulation of a user
  ``/start`` on a sub-bot, with language filtering.
* ``/last_starts [n]`` — show the last *n* recorded start_events.
* :func:`simulate_start_response` — reusable helper for sub-bot processes.

The router is registered *before* the common router so its ``/start preview``
filter (which only matches when arguments are present) takes priority over the
plain ``/start`` handler — plain ``/start`` falls through to ``common.py``.
"""

from __future__ import annotations

import logging
import random
import re

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from app.config import settings
from app.core.db import get_session
from app.core.models import Project, StartEvent, SubBot
from app.core.services.projects import get_project
from app.core.services.stats import record_start_event
from app.core.services.subbots import get_subbot, list_subbots
from app.core.telegram_sender import send_message_safe, send_photo_safe

from app.bot.keyboards import build_project_post_kb

router = Router(name="start_resp")

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_TEXT_RESPONSES: list[str] = [
    "Добро пожаловать! Рады видеть вас в нашем проекте. Оставайтесь с нами!",
    "Привет! Спасибо, что зашли. Здесь вы найдёте много полезного и интересного.",
    "Здравствуйте! Добро пожаловать — вы точно в нужном месте.",
    "Рады приветствовать! У нас много интересного — загляните по ссылкам ниже.",
    "Приветствуем вас! Если что-то понадобится — мы на связи.",
]

SUPPORTED_LANGS: set[str] = {"uk", "ru"}

# Matches: /start, /start@botname, /start preview 5, /start bot, ...
_START_RE = re.compile(r"^(/start)(@\w+)?\s*(.*)$", re.DOTALL)


# ---------------------------------------------------------------------------
# Admin helper
# ---------------------------------------------------------------------------


async def _is_admin(user_id: int) -> bool:
    """Return True if *user_id* is a DB-backed admin."""
    from app.core.services.admins import is_admin_user

    return await is_admin_user(user_id)


# ---------------------------------------------------------------------------
# Custom filter: only /start with "preview" or "bot" arguments
# ---------------------------------------------------------------------------


class StartPreviewFilter:
    """Matches ``/start preview ...`` and ``/start bot`` but NOT plain /start.

    Plain ``/start`` (no args) returns ``False`` so the common router's
    ``CommandStart()`` handler runs instead.
    """

    __slots__ = ()

    # NOTE: must be SYNC — aiogram 3.x does not await filter coroutines
    # passed to @router.message(), so an async filter would always be
    # truthy (the coroutine object itself) and match every message.
    def __call__(self, message: Message) -> bool:
        text = message.text or ""
        match = _START_RE.match(text)
        if not match:
            return False
        rest = (match.group(3) or "").strip().split()
        if not rest:
            return False  # plain /start → let common.py handle it
        return rest[0] in ("preview", "bot")


# ---------------------------------------------------------------------------
# Reusable helper for sub-bot processes
# ---------------------------------------------------------------------------


async def simulate_start_response(
    session,
    subbot_id: int,
    user_id: int,
    lang_code: str | None,
    payload: str | None,
    is_premium: bool,
    bot,
    rate_limiter,
) -> dict:
    """Simulate how a sub-bot answers ``/start`` from a user.

    Records a :class:`StartEvent` and returns a dict with at least
    ``"response_type"`` (``"text"``, ``"post"``, ``"filtered"`` or ``"error"``).
    """
    result: dict = {"response_type": "error", "subbot_id": subbot_id}

    try:
        subbot = await get_subbot(session, subbot_id)
        if subbot is None:
            result["error"] = "subbot_not_found"
            return result

        project = await get_project(session, subbot.project_id)
        if project is None:
            result["error"] = "project_not_found"
            return result

        # Language filtering — unsupported langs are recorded and dropped.
        if lang_code and lang_code not in SUPPORTED_LANGS:
            await record_start_event(
                session,
                subbot_id=subbot.id,
                project_id=project.id,
                user_id=user_id,
                is_new=False,
                lang_code=lang_code,
                payload=payload,
                is_premium=is_premium,
                response_type="filtered",
                processing_time_ms=None,
            )
            await session.flush()
            result["response_type"] = "filtered"
            result["reason"] = f"lang={lang_code}"
            return result

        # Decide text vs post mode.
        urls_ok = bool(project.button1_url and project.button2_url)
        if project.response_mode == "post" and project.image_file_id and urls_ok:
            kb = build_project_post_kb(
                button1_url=project.button1_url,  # type: ignore[arg-type]
                button1_text=project.button1_text_global,
                button2_url=project.button2_url,  # type: ignore[arg-type]
                button2_text=project.button2_text_global,
            )
            try:
                await send_photo_safe(
                    bot,
                    chat_id=user_id,
                    photo=project.image_file_id,
                    caption=project.name or "",
                    reply_markup=kb,
                    rate_limiter=rate_limiter,
                )
                response_type = "post"
            except Exception:
                logger.exception("send_photo failed in simulate; falling back to text")
                response_type = "text"
        else:
            text = random.choice(DEFAULT_TEXT_RESPONSES)
            await send_message_safe(
                bot,
                chat_id=user_id,
                text=text,
                rate_limiter=rate_limiter,
            )
            response_type = "text"

        await record_start_event(
            session,
            subbot_id=subbot.id,
            project_id=project.id,
            user_id=user_id,
            is_new=True,
            lang_code=lang_code,
            payload=payload,
            is_premium=is_premium,
            response_type=response_type,
            processing_time_ms=None,
        )
        await session.flush()
        result["response_type"] = response_type
        result["project_id"] = project.id
    except Exception:
        logger.exception("simulate_start_response failed for subbot %s", subbot_id)
        result["error"] = "exception"

    return result


# ---------------------------------------------------------------------------
# /start preview <subbot_id> and /start bot (payload)
# ---------------------------------------------------------------------------


@router.message(StartPreviewFilter())
async def cmd_start_preview(message: Message, rate_limiter) -> None:
    """Preview how a sub-bot answers ``/start`` (text or post), recording it."""
    admin_id = message.from_user.id
    if not await _is_admin(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    match = _START_RE.match(message.text or "")
    if match is None:  # pragma: no cover - filter guarantees a match
        return

    rest = (match.group(3) or "").strip().split()
    kind = rest[0]
    subbot_id_str = rest[1] if len(rest) > 1 else None

    # ``?start=bot`` payload → random text preview of the first available bot.
    if kind == "bot":
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            if not subbots:
                await message.answer("Нет суб-ботов для превью.")
                return
            subbot = subbots[0]
            project = await get_project(session, subbot.project_id)
            if project is None:
                await message.answer("Проект суб-бота не найден.")
                return

            text = random.choice(DEFAULT_TEXT_RESPONSES)
            await send_message_safe(
                message.bot,
                message.chat.id,
                text,
                rate_limiter,
            )
            await record_start_event(
                session,
                subbot_id=subbot.id,
                project_id=project.id,
                user_id=admin_id,
                is_new=True,
                lang_code=None,
                payload="bot",
                is_premium=False,
                response_type="text",
                processing_time_ms=None,
            )
        return

    # ``preview <subbot_id>``
    if subbot_id_str is None or not subbot_id_str.isdigit():
        await message.answer("Использование: /start preview <subbot_id>")
        return
    subbot_id = int(subbot_id_str)

    async with get_session() as session:
        subbot = await get_subbot(session, subbot_id)
        if subbot is None:
            await message.answer("Суб-бот не найден.")
            return
        result = await simulate_start_response(
            session,
            subbot.id,
            admin_id,
            None,
            None,
            False,
            message.bot,
            rate_limiter,
        )

    await message.answer(f"✅ Симулировано: response_type=<b>{result['response_type']}</b>")


# ---------------------------------------------------------------------------
# /simulate_start <subbot_id> [lang_code]  (admin only)
# ---------------------------------------------------------------------------


@router.message(Command("simulate_start"))
async def cmd_simulate_start(
    message: Message,
    command: CommandObject,
    rate_limiter,
) -> None:
    """Admin-only: simulate a user ``/start`` on a given sub-bot."""
    admin_id = message.from_user.id
    if not await _is_admin(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    args = (command.args or "").strip().split()
    if not args or not args[0].isdigit():
        await message.answer(
            "Использование: <code>/simulate_start &lt;subbot_id&gt; [lang_code]</code>"
        )
        return

    subbot_id = int(args[0])
    lang_code = args[1] if len(args) > 1 else None

    async with get_session() as session:
        subbot = await get_subbot(session, subbot_id)
        if subbot is None:
            await message.answer("Суб-бот не найден.")
            return

        if lang_code and lang_code not in SUPPORTED_LANGS:
            await record_start_event(
                session,
                subbot_id=subbot.id,
                project_id=subbot.project_id,
                user_id=admin_id,
                is_new=False,
                lang_code=lang_code,
                payload="simulate",
                is_premium=False,
                response_type="filtered",
                processing_time_ms=None,
            )
            await message.answer(f"Traffic filtered (lang={lang_code})")
            return

        result = await simulate_start_response(
            session,
            subbot.id,
            admin_id,
            lang_code,
            "simulate",
            False,
            message.bot,
            rate_limiter,
        )

    await message.answer(f"✅ Симуляция: response_type=<b>{result['response_type']}</b>")


# ---------------------------------------------------------------------------
# /last_starts [n]  (admin only)
# ---------------------------------------------------------------------------


@router.message(Command("last_starts"))
async def cmd_last_starts(message: Message, command: CommandObject) -> None:
    """Show the last *n* start_events across all admin's projects."""
    admin_id = message.from_user.id
    if not await _is_admin(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    args = (command.args or "").strip().split()
    n = int(args[0]) if args and args[0].isdigit() else 10

    async with get_session() as session:
        from sqlalchemy import desc, select

        proj_rows = await session.execute(
            select(Project.id).where(Project.admin_id == admin_id)
        )
        project_ids = [row[0] for row in proj_rows.all()]

        if not project_ids:
            await message.answer("Нет проектов.")
            return

        stmt = (
            select(StartEvent)
            .where(StartEvent.project_id.in_(project_ids))
            .order_by(desc(StartEvent.created_at))
            .limit(n)
        )
        events = (await session.execute(stmt)).scalars().all()

    if not events:
        await message.answer("Нет записанных /start событий.")
        return

    lines = []
    for ev in events:
        lines.append(
            f"• #{ev.id} sb={ev.subbot_id} user={ev.user_telegram_id} "
            f"lang={ev.language_code} resp={ev.response_type} payload={ev.payload}"
        )
    await message.answer("📋 <b>Последние /start</b>\n\n" + "\n".join(lines))
