"""
Projects router — CRUD for projects, picture/links setup, and adding sub-bots.

All DB work is wrapped in ``async with get_session() as session:`` and every
write path commits explicitly with ``await session.commit()``.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import cancel_kb, main_kb, project_card_kb
from app.config import settings
from app.core.db import get_session
from app.core.models import ADMIN_ROLES_FULL_ACCESS
from app.core.services import projects as projects_svc
from app.core.services import subbots as subbots_svc
from app.core.services.admins import can_use_bots, is_admin_user

router = Router(name="projects")


# ---------------------------------------------------------------------------
# FSM states
# ---------------------------------------------------------------------------


class ProjectCreate(StatesGroup):
    waiting_name = State()


class ProjectSetupFlow(StatesGroup):
    waiting_image = State()
    waiting_url1 = State()
    waiting_url2 = State()


class AddSubbotsFlow(StatesGroup):
    waiting_tokens = State()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_normalize = lambda s: (s or "").strip().lower()  # noqa: E731


async def _user_can_use(user_id: int) -> bool:
    """Any registered user (owner/admin/member) can use projects & bots."""
    return await can_use_bots(user_id)


async def _user_is_full_admin(user_id: int) -> bool:
    """Only owner/admin can modify projects, add bots, change settings."""
    return await is_admin_user(user_id)


# ---------------------------------------------------------------------------
# a) Create project — ask for name
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "projects:list")
async def projects_list_callback(callback: CallbackQuery) -> None:
    """Show the list of projects from inline button."""
    if not await _user_can_use(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await _send_projects_screen(callback, callback.from_user.id)
    await callback.answer()


@router.callback_query(F.data == "projects:create")
async def projects_create(callback: CallbackQuery, state: FSMContext) -> None:
    """Ask for the new project's name and wait for it. Admin-only."""
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(ProjectCreate.waiting_name)
    await callback.message.edit_text(
        "Введите название проекта:",
        reply_markup=None,
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# b) Receive project name — create and show card
# ---------------------------------------------------------------------------


@router.message(ProjectCreate.waiting_name)
async def projects_create_name(message: Message, state: FSMContext) -> None:
    """Create the project and present its card."""
    name = message.text.strip()
    admin_id = message.from_user.id

    data = await state.get_data()
    rename_project_id = data.get("rename_project_id")

    async with get_session() as session:
        if rename_project_id:
            project = await projects_svc.get_project(session, int(rename_project_id))
            if project is None:
                await message.answer("Проект не найден.", reply_markup=main_kb)
                await state.clear()
                return
            project.name = name
        else:
            project = await projects_svc.create_project(session, admin_id=admin_id, name=name)
        await session.commit()
        subbots = await projects_svc.list_subbots_for_project(session, project.id)

    await state.clear()
    action = "переименован" if rename_project_id else "создан"
    await message.answer(f"✅ Проект «{name}» {action}.", reply_markup=main_kb)
    await message.answer(
        f"📁 <b>Проект: {name}</b>",
        reply_markup=project_card_kb(project.id, subbots, project.response_mode),
    )


# ---------------------------------------------------------------------------
# c) Menu entry — list projects
# ---------------------------------------------------------------------------


@router.message(F.text.casefold() == _normalize("📁 проекты"))
async def projects_list_menu(message: Message) -> None:
    """Render the Projects screen exactly like the original controller."""
    if not await _user_can_use(message.from_user.id):
        await message.answer("🚫 Нет доступа")
        return
    await _send_projects_screen(message, message.from_user.id)


async def _send_projects_screen(target, admin_id: int) -> None:
    """Send the project list and its inline actions."""
    async with get_session() as session:
        # Members see every project in the system (they are not owners of any).
        if await _user_is_full_admin(admin_id):
            projects = await projects_svc.list_projects(session, admin_id=admin_id)
        else:
            projects = await projects_svc.list_all_projects(session)
        # Count sub-bots per project without relying on lazy relationships.
        from sqlalchemy import func, select
        from app.core.models import SubBot

        bot_counts: dict[int, int] = {}
        if projects:
            counts_result = await session.execute(
                select(SubBot.project_id, func.count(SubBot.id))
                .where(SubBot.project_id.in_([p.id for p in projects]))
                .group_by(SubBot.project_id)
            )
            bot_counts = {project_id: count for project_id, count in counts_result.all()}

    if not projects:
        text = "📁 <b>Проекты</b>\n\nНет проектов. Создайте первый."
    else:
        lines = ["📁 <b>Проекты</b>"]
        for project in projects:
            mode = "текст" if project.response_mode == "text" else "пост"
            lines.append(
                f"ID {project.id} · {project.name} · режим {mode} · "
                f"ботов: {bot_counts.get(project.id, 0)}"
            )
        text = "\n".join(lines)

    markup = _projects_inline_list(projects)
    if isinstance(target, Message):
        await target.answer(text, reply_markup=markup)
    else:
        await target.message.edit_text(text, reply_markup=markup)


def _projects_inline_list(projects) -> "InlineKeyboardMarkup":
    """Build the original project list keyboard."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    rows = [
        [
            InlineKeyboardButton(
                text=f"ID {project.id} · {project.name} · "
                f"{'текст' if project.response_mode == 'text' else 'пост'}",
                callback_data=f"project:card:{project.id}",
            )
        ]
        for project in projects
    ]
    rows.extend(
        [
            [InlineKeyboardButton(text="➕ Создать проект", callback_data="projects:create")],
            [InlineKeyboardButton(text="⬅️ В меню", callback_data="projects:menu")],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "projects:menu")
async def projects_back_to_menu(callback: CallbackQuery) -> None:
    """Return from the project list to the main reply keyboard."""
    await callback.message.edit_text("Возвращаемся в меню.", reply_markup=None)
    await callback.message.answer("Выберите действие:", reply_markup=main_kb)
    await callback.answer()


# ---------------------------------------------------------------------------
# d) Setup flow — start with picture
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("projects:setup:"))
async def projects_setup(callback: CallbackQuery, state: FSMContext) -> None:
    """Start the picture+links setup flow for a project. Admin-only."""
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])
    admin_id = callback.from_user.id

    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id)
        if project is None or project.admin_id != admin_id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return
        setup = await projects_svc.setup_start(session, admin_id=admin_id)
        # Link the setup to the project if the service supports it.
        from app.core.models import ProjectSetup

        setup_obj = (
            await session.execute(
                __import__("sqlalchemy").select(ProjectSetup).where(
                    ProjectSetup.id == setup.id
                )
            )
        ).scalar_one_or_none()
        if setup_obj is not None:
            setup_obj.project_id = project_id
        await session.commit()

    await state.set_state(ProjectSetupFlow.waiting_image)
    await state.update_data(setup_id=setup.id, project_id=project_id)
    await callback.message.edit_text(
        "Отправьте картинку проекта:",
        reply_markup=None,
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# e) Receive picture — store file_id and ask for URL 1
# ---------------------------------------------------------------------------


@router.message(ProjectSetupFlow.waiting_image, F.photo)
async def projects_setup_image(message: Message, state: FSMContext) -> None:
    """Store the picture and ask for the first button URL."""
    data = await state.get_data()
    setup_id = data["setup_id"]
    file_id = message.photo[-1].file_id

    async with get_session() as session:
        await projects_svc.setup_set_image(session, setup_id=setup_id, file_id=file_id)
        await session.commit()

    await state.set_state(ProjectSetupFlow.waiting_url1)
    await message.answer("Теперь отправьте URL первой кнопки:", reply_markup=cancel_kb)


# ---------------------------------------------------------------------------
# f) Receive URL 1 — ask for URL 2
# ---------------------------------------------------------------------------


@router.message(ProjectSetupFlow.waiting_url1)
async def projects_setup_url1(message: Message, state: FSMContext) -> None:
    """Store the first URL and ask for the second one."""
    data = await state.get_data()
    setup_id = data["setup_id"]
    url1 = message.text.strip()

    async with get_session() as session:
        await projects_svc.setup_set_url1(session, setup_id=setup_id, url1=url1)
        await session.commit()

    await state.set_state(ProjectSetupFlow.waiting_url2)
    await message.answer("Отправьте URL второй кнопки:", reply_markup=cancel_kb)


# ---------------------------------------------------------------------------
# g) Receive URL 2 — finish setup
# ---------------------------------------------------------------------------


@router.message(ProjectSetupFlow.waiting_url2)
async def projects_setup_url2(message: Message, state: FSMContext) -> None:
    """Store the second URL and finish the setup."""
    data = await state.get_data()
    setup_id = data["setup_id"]
    url2 = message.text.strip()

    async with get_session() as session:
        project = await projects_svc.setup_set_url2(
            session, setup_id=setup_id, url2=url2
        )
        await session.commit()

    await state.clear()
    project_id = project.id if project else data.get("project_id")
    await message.answer(
        "✅ Кнопки и картинка проекта обновлены!",
        reply_markup=main_kb,
    )
    if project_id:
        await message.answer(
            f"📁 <b>{project.name if project else 'Проект'}</b>",
            reply_markup=project_card_kb(project_id),
        )


# ---------------------------------------------------------------------------
# h) Add sub-bots — ask for tokens
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("projects:add_bots:"))
async def projects_add_bots(callback: CallbackQuery, state: FSMContext) -> None:
    """Ask for sub-bot tokens. Admin-only."""
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id)
        if project is None or project.admin_id != callback.from_user.id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return
    await state.set_state(AddSubbotsFlow.waiting_tokens)
    await state.update_data(project_id=project_id)
    await callback.message.edit_text(
        "Отправьте токены суб-ботов (каждый с новой линии):",
        reply_markup=None,
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# i) Receive tokens — add sub-bots and report
# ---------------------------------------------------------------------------


@router.message(AddSubbotsFlow.waiting_tokens)
async def projects_add_bots_tokens(message: Message, state: FSMContext) -> None:
    """Parse tokens, add sub-bots, and reply with a report."""
    data = await state.get_data()
    project_id = data["project_id"]
    tokens = [t for t in message.text.splitlines() if t.strip()]
    bot = message.bot

    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id=project_id)
        result = await subbots_svc.add_subbots_from_tokens(
            session,
            project_id=project_id,
            tokens=tokens,
            project=project,
            bot=bot,
        )
        await session.commit()

    await state.clear()

    added = result["added"]
    errors = result["errors"]

    lines = [f"Добавлено: {len(added)}"]
    if added:
        lines += [f"  + @{a['username']}" for a in added]
    lines.append(f"Ошибки: {len(errors)}")
    if errors:
        lines += [f"  ✗ {e['token']}: {e['error']}" for e in errors]

    await message.answer("\n".join(lines), reply_markup=main_kb)


# ---------------------------------------------------------------------------
# j) Delete project — check then delete
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("projects:delete:"))
async def projects_delete(callback: CallbackQuery) -> None:
    """Delete a project if it has no sub-bots. Admin-only."""
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id)
        if project is None or project.admin_id != callback.from_user.id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return

    async with get_session() as session:
        ok, msg = await projects_svc.delete_project_check(session, project_id=project_id)
        if not ok:
            await callback.answer(msg, show_alert=True)
            return
        await projects_svc.delete_project(session, project_id=project_id)
        await session.commit()

    await callback.answer("Проект удалён", show_alert=False)
    await callback.message.edit_text(
        f"✅ Проект #{project_id} удалён.",
        reply_markup=None,
    )


# ---------------------------------------------------------------------------
# k) Project card actions
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("projects:toggle_post:"))
async def projects_toggle_post(callback: CallbackQuery) -> None:
    """Toggle text/post response mode for the project. Admin-only."""
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id)
        if project is None or project.admin_id != callback.from_user.id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return
        project.response_mode = "text" if project.response_mode == "post" else "post"
        await session.commit()
        mode = project.response_mode
    await callback.answer(f"Режим ответа: {mode}")
    await project_card(callback)


@router.callback_query(F.data.startswith("projects:rename:"))
async def projects_rename(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _user_is_full_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id)
        if project is None or project.admin_id != callback.from_user.id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return
    await state.set_state(ProjectCreate.waiting_name)
    await state.update_data(rename_project_id=project_id)
    await callback.message.edit_text(
        "✏️ Отправь название нового проекта. Например: проект1",
        reply_markup=None,
    )
    await callback.answer()


@router.callback_query(F.data.startswith("project:card:"))
async def project_card(callback: CallbackQuery) -> None:
    """Show the project card exactly like the original controller."""
    if not await _user_can_use(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    project_id = int(callback.data.split(":")[2])

    async with get_session() as session:
        project = await projects_svc.get_project(session, project_id=project_id)
        if project is None:
            await callback.answer("Проект не найден", show_alert=True)
            return
        # Admins see only their own projects; members see all projects.
        if await _user_is_full_admin(callback.from_user.id) and project.admin_id != callback.from_user.id:
            await callback.answer("Нет доступа к проекту", show_alert=True)
            return
        subbots = await projects_svc.list_subbots_for_project(session, project_id)

    image_state = "настроены" if project.image_file_id and project.button1_url and project.button2_url else "не настроены"
    mode_label = "пост" if project.response_mode == "post" else "текст"
    achievement = (
        "успешного эталона есть"
        if project.achievement_mode and project.achievement_mode != "none"
        else "успешного эталона пока нет"
    )

    lines = [
        f"📁 <b>Проект: {project.name}</b>",
        "",
        f"ID: {project.id}",
        f"Режим ответа: <b>{mode_label}</b>",
        f"Картинка и ссылки: {image_state}",
        f"Суб-боты: {len(subbots)}",
        f"Обучение продвижения: {achievement}",
    ]
    if subbots:
        lines.append("")
        for sb in subbots:
            status_icon = {
                "running": "🟢",
                "stopped": "🔴",
                "needs_setup": "🟡",
                "unavailable": "⚫",
                "error": "❗",
            }.get(sb.status, "⚪")
            lines.append(f"{status_icon} @{sb.bot_username} · {sb.status}")
    else:
        lines.append("")
        lines.append("Суб-ботов пока нет. Добавьте через кнопку ниже.")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=project_card_kb(project.id, subbots, project.response_mode),
    )
    await callback.answer()
