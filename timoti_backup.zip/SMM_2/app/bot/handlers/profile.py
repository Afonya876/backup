"""
Profile router — view and configure the admin's SMM profile, and manage
other admins.

Admin management (flat, no hierarchy — "похуй кто какой касты"):

* Any admin can add another admin by telegram_id.
* Any admin can remove another admin.
* An admin cannot remove themselves.
* The last admin cannot be removed (avoids lockout).
"""

from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app.bot.keyboards import cancel_kb, main_kb, menu_inline_profile
from app.config import settings
from app.core.db import get_session
from app.core.models import ADMIN_ROLE_ADMIN, ADMIN_ROLE_MEMBER, ADMIN_ROLES
from app.core.services.admins import (
    can_use_bots,
    get_admin_profile,
    get_or_create_admin,
    grant_admin,
    list_admins,
    revoke_admin,
)

router = Router(name="profile")
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# FSM states
# ---------------------------------------------------------------------------


class ProfileSetup(StatesGroup):
    waiting_api_key = State()
    waiting_budget = State()
    waiting_limit = State()
    waiting_variance = State()
    waiting_ceiling = State()
    waiting_growth_base = State()
    waiting_growth_step = State()
    waiting_growth_ceiling = State()
    waiting_maintenance_daily = State()
    waiting_maintenance_variance = State()
    waiting_safeguard = State()
    waiting_new_admin_id = State()
    waiting_new_user_id = State()
    waiting_new_user_role = State()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _normalize(s: str) -> str:
    return (s or "").strip().lower()


def _mask_api_key(api_key: str | None) -> str:
    if not api_key:
        return "<i>не задан</i>"
    visible = api_key[:8]
    return f"<code>{visible}</code>..."


async def _check_admin(callback_or_message) -> bool:
    """True iff the user has full access (owner/admin)."""
    from app.core.services.admins import is_admin_user

    uid = callback_or_message.from_user.id
    return await is_admin_user(uid)


async def _check_member(callback_or_message) -> bool:
    """True iff the user may use the controller bot at all (any role)."""
    uid = callback_or_message.from_user.id
    return await can_use_bots(uid)


# ---------------------------------------------------------------------------
# a) Profile summary
# ---------------------------------------------------------------------------


def _profile_inline_kb(admin: "Admin") -> "InlineKeyboardMarkup":
    """Build the profile inline keyboard based on the user's role.

    Full-access admins (owner/admin) see growth/maintenance/provider/admin
    management buttons. Members (limited users) see read-only buttons only.
    """
    rows = []
    if admin.role in ("owner", "admin"):
        rows.append([
            InlineKeyboardButton(text="🔑 SMMain API", callback_data="profile:api_key"),
            InlineKeyboardButton(text="⚙️ Состояние провайдера", callback_data="profile:provider"),
        ])
        rows.append([
            InlineKeyboardButton(text="📈 Рост", callback_data="profile:growth"),
            InlineKeyboardButton(text="🛡 Поддержка", callback_data="profile:maintenance"),
        ])
        rows.append([
            InlineKeyboardButton(text="💵 Дневной предохранитель", callback_data="profile:safeguard"),
        ])
        rows.append([
            InlineKeyboardButton(text="👥 Администраторы", callback_data="profile:admins:list"),
        ])
        rows.append([
            InlineKeyboardButton(text="➕ Добавить пользователя", callback_data="profile:user:add"),
        ])
        rows.append([
            InlineKeyboardButton(text="🤖 Добавить бота-копию", callback_data="profile:bot:add"),
        ])
    # Members see no extra buttons beyond what the reply keyboard provides.
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.casefold() == _normalize("👤 профиль"))
async def profile_menu(message: Message) -> None:
    """Show the user's profile summary.

    Any registered user (owner/admin/member) can open the profile. Full-access
    admins additionally see the management inline keyboard.
    """
    await _render_profile(telegram_id=message.from_user.id, message=message)


async def _render_profile(telegram_id: int, message: Message) -> None:
    """Render the profile screen for *telegram_id* onto *message*.

    ``message`` may be a callback's bot message — the access check always uses
    the explicit ``telegram_id``, never ``message.from_user`` (which would be
    the bot itself for edited inline messages).
    """
    try:
        if not await can_use_bots(telegram_id):
            await message.answer("🚫 Нет доступа")
            return

        async with get_session() as session:
            admin = await get_or_create_admin(session, telegram_id=telegram_id)
            profile_data = await get_admin_profile(session, telegram_id)

        role_label = {
            "owner": "👑 Владелец",
            "admin": "🛡 Администратор",
            "member": "👤 Пользователь",
        }.get(admin.role, admin.role)

        api_key_status = "настроен" if admin.api_key else "не настроен"
        provider_state = admin.provider_state or "waiting_balance"
        admins_count = admin.profile_admins or 1

        lines = [
            f"👤 <b>Профиль: {telegram_id}</b>\n",
            f"🆔 Код: <code>{admin.profile_id or 'не задан'}</code>",
            f"👥 Роль: <b>{role_label}</b>",
            f"📁 Проектов: <b>{profile_data.get('projects_count', 0)}</b>",
            f"🤖 Суб-ботов: <b>{profile_data.get('subbots_count', 0)}</b>",
        ]
        if admin.role in ("owner", "admin"):
            lines += [
                f"🔑 SMMain API: <b>{api_key_status}</b>",
                f"⚙️ Состояние провайдера: <b>{provider_state}</b>",
                f"👥 Администраторов профиля: <b>{admins_count}</b>\n",
                "─" * 20,
                "",
                "📈 <b>Рост:</b>",
                f"  {admin.growth_base} + {admin.growth_step}/день до {admin.growth_ceiling},",
                f"  количество ±{admin.maintenance_variance_pct}%.\n",
                "🛡 <b>Поддержка:</b>",
                f"  Service {admin.maintenance_service_id}, {admin.maintenance_daily}/день",
                f"  ±{admin.maintenance_variance_pct}%.\n",
                "💵 <b>Дневной предохранитель расходов:</b>",
                f"  {admin.daily_safeguard_usd:.2f} USD.",
            ]

        await message.answer("\n".join(lines), reply_markup=_profile_inline_kb(admin))
    except Exception:
        # Never let the profile menu silently swallow an error — the user
        # would just see "nothing happens" with no clue why.
        logger.exception("profile_menu failed for user %s", message.from_user.id)
        await message.answer(
            "❌ Не удалось открыть профиль. Проверьте подключение к базе данных.",
            reply_markup=main_kb,
        )


# ---------------------------------------------------------------------------
# b) API key
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:api_key")
async def profile_api(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(ProfileSetup.waiting_api_key)
    await callback.message.edit_text(
        "Отправьте SMM API ключ (или /cancel для отмены):",
        reply_markup=None,
    )
    await callback.answer()


@router.message(ProfileSetup.waiting_api_key)
async def profile_api_save(message: Message, state: FSMContext) -> None:
    api_key = message.text.strip()
    telegram_id = message.from_user.id
    async with get_session() as session:
        admin = await get_or_create_admin(session, telegram_id=telegram_id)
        admin.api_key = api_key
        await session.commit()
    await state.clear()
    await message.answer("✅ API ключ сохранён", reply_markup=main_kb)


# ---------------------------------------------------------------------------
# c) Provider state (read-only display)
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:provider")
async def profile_provider(callback: CallbackQuery) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        admin = await get_or_create_admin(session, telegram_id=callback.from_user.id)
    await callback.message.edit_text(
        "⚙️ <b>Состояние провайдера</b>\n\n"
        f"Режим: <b>{settings.PROVIDER_MODE}</b>\n"
        f"Состояние: <b>{admin.provider_state}</b>\n\n"
        "SMM-заказы отправляются через выбранного провайдера.\n"
        "Для смены режима измените <code>PROVIDER_MODE</code> в <code>.env</code>.",
        reply_markup=menu_inline_profile,
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# d) Growth settings
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:growth")
async def profile_growth(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(ProfileSetup.waiting_growth_base)
    await callback.message.edit_text(
        "📈 <b>Настройка роста</b>\n\n"
        "Шаг 1/3 — базовый объём стартов в первый день (например, 200):",
        reply_markup=cancel_kb,
    )
    await callback.answer()


@router.message(ProfileSetup.waiting_growth_base)
async def profile_growth_base_save(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число. Попробуйте ещё раз:")
        return
    await state.update_data(growth_base=value)
    await state.set_state(ProfileSetup.waiting_growth_step)
    await message.answer("Шаг 2/3 — прирост в день (например, 100):")


@router.message(ProfileSetup.waiting_growth_step)
async def profile_growth_step_save(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число. Попробуйте ещё раз:")
        return
    await state.update_data(growth_step=value)
    await state.set_state(ProfileSetup.waiting_growth_ceiling)
    await message.answer("Шаг 3/3 — потолок стартов в день (например, 2000):")


@router.message(ProfileSetup.waiting_growth_ceiling)
async def profile_growth_ceiling_save(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число. Попробуйте ещё раз:")
        return
    data = await state.get_data()
    async with get_session() as session:
        admin = await get_or_create_admin(session, telegram_id=message.from_user.id)
        admin.growth_base = data.get("growth_base", 200)
        admin.growth_step = data.get("growth_step", 100)
        admin.growth_ceiling = value
        await session.commit()
    await state.clear()
    await message.answer("✅ Настройки роста сохранены", reply_markup=main_kb)


# ---------------------------------------------------------------------------
# e) Maintenance settings
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:maintenance")
async def profile_maintenance(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(ProfileSetup.waiting_maintenance_daily)
    await callback.message.edit_text(
        "🛡 <b>Настройка поддержки</b>\n\n"
        "Шаг 1/2 — объём поддержки в день (например, 200):",
        reply_markup=cancel_kb,
    )
    await callback.answer()


@router.message(ProfileSetup.waiting_maintenance_daily)
async def profile_maintenance_daily_save(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число. Попробуйте ещё раз:")
        return
    await state.update_data(maintenance_daily=value)
    await state.set_state(ProfileSetup.waiting_maintenance_variance)
    await message.answer("Шаг 2/2 — процент варьирования (например, 5):")


@router.message(ProfileSetup.waiting_maintenance_variance)
async def profile_maintenance_variance_save(message: Message, state: FSMContext) -> None:
    try:
        value = float(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно число. Попробуйте ещё раз:")
        return
    data = await state.get_data()
    async with get_session() as session:
        admin = await get_or_create_admin(session, telegram_id=message.from_user.id)
        admin.maintenance_daily = data.get("maintenance_daily", 200)
        admin.maintenance_variance_pct = value
        await session.commit()
    await state.clear()
    await message.answer("✅ Настройки поддержки сохранены", reply_markup=main_kb)


# ---------------------------------------------------------------------------
# f) Daily safeguard
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:safeguard")
async def profile_safeguard(callback: CallbackQuery, state: FSMContext) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(ProfileSetup.waiting_safeguard)
    await callback.message.edit_text(
        "💵 <b>Дневной предохранитель расходов</b>\n\n"
        "Укажите максимум расходов в USD в день (например, 31):",
        reply_markup=cancel_kb,
    )
    await callback.answer()


@router.message(ProfileSetup.waiting_safeguard)
async def profile_safeguard_save(message: Message, state: FSMContext) -> None:
    try:
        value = float(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно число. Попробуйте ещё раз:")
        return
    async with get_session() as session:
        admin = await get_or_create_admin(session, telegram_id=message.from_user.id)
        admin.daily_safeguard_usd = value
        await session.commit()
    await state.clear()
    await message.answer("✅ Дневной предохранитель сохранён", reply_markup=main_kb)


# ---------------------------------------------------------------------------
# g) Admin management
# ---------------------------------------------------------------------------


def admin_management_kb() -> "InlineKeyboardMarkup":
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👥 Список админов", callback_data="profile:admins:list")],
        [InlineKeyboardButton(text="➕ Добавить админа", callback_data="profile:admins:add")],
        [InlineKeyboardButton(text="➕ Добавить пользователя", callback_data="profile:user:add")],
        [InlineKeyboardButton(text="➖ Удалить админа", callback_data="profile:admins:remove")],
        [InlineKeyboardButton(text="⬅️ В профиль", callback_data="profile:menu")],
    ])


@router.callback_query(F.data == "profile:menu")
async def profile_back(callback: CallbackQuery) -> None:
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await callback.message.edit_text("Возврат в профиль…", reply_markup=None)
    await _render_profile(telegram_id=callback.from_user.id, message=callback.message)
    await callback.answer()


@router.callback_query(F.data == "profile:admins:list")
async def profile_admins_list(callback: CallbackQuery) -> None:
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        async with get_session() as session:
            admins = await list_admins(session)
        lines = ["👥 <b>Список пользователей</b>\n"]
        for a in admins:
            role_label = {
                "owner": "👑 владелец",
                "admin": "🛡 админ",
                "member": "👤 пользователь",
            }.get(a.role, a.role)
            name = a.full_name or "—"
            lines.append(f"• <code>{a.telegram_id}</code> · {name} · {role_label}")
        await callback.message.edit_text(
            "\n".join(lines),
            reply_markup=admin_management_kb(),
        )
        await callback.answer()
    except Exception:
        logger.exception("profile_admins_list failed")
        await callback.answer("❌ Ошибка загрузки списка", show_alert=True)


@router.callback_query(F.data == "profile:admins:add")
async def profile_admins_add(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        await state.set_state(ProfileSetup.waiting_new_admin_id)
        await callback.message.edit_text(
            "➕ <b>Добавить администратора</b>\n\n"
            "Отправьте Telegram ID нового админа (целое число):",
            # This is an edited inline message; ReplyKeyboardMarkup is not
            # accepted by Telegram's editMessageText API. /cancel remains
            # available through the common handler.
            reply_markup=None,
        )
        await callback.answer()
    except Exception:
        logger.exception("profile_admins_add failed")
        await callback.answer("❌ Ошибка", show_alert=True)


@router.message(ProfileSetup.waiting_new_admin_id)
async def profile_admins_add_save(message: Message, state: FSMContext) -> None:
    try:
        new_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число (Telegram ID). Попробуйте ещё раз:")
        return
    try:
        async with get_session() as session:
            result = await grant_admin(session, message.from_user.id, new_id)
        if result["ok"]:
            await message.answer(
                f"✅ Администратор <code>{new_id}</code> добавлен.",
                reply_markup=main_kb,
            )
        else:
            await message.answer(
                f"❌ Не удалось добавить: {result['error']}",
                reply_markup=main_kb,
            )
        await state.clear()
    except Exception:
        logger.exception("profile_admins_add_save failed")
        await message.answer("❌ Ошибка при добавлении администратора.", reply_markup=main_kb)
        await state.clear()


# ---------------------------------------------------------------------------
# h) Add a new user (admin-only, FSM: id → role)
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "profile:user:add")
async def profile_user_add(callback: CallbackQuery, state: FSMContext) -> None:
    """Start FSM to invite a new user by Telegram ID."""
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        await state.set_state(ProfileSetup.waiting_new_user_id)
        await callback.message.edit_text(
            "➕ <b>Добавить пользователя</b>\n\n"
            "Отправьте Telegram ID (целое число):",
            # editMessageText accepts only inline keyboards, not the reply
            # keyboard used by cancel_kb.
            reply_markup=None,
        )
        await callback.answer()
    except Exception:
        logger.exception("profile_user_add failed")
        await callback.answer("❌ Ошибка", show_alert=True)


@router.message(ProfileSetup.waiting_new_user_id)
async def profile_user_add_id(message: Message, state: FSMContext) -> None:
    """User entered an ID — ask for the role."""
    try:
        new_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Нужно целое число (Telegram ID). Попробуйте ещё раз:")
        return
    await state.update_data(new_user_id=new_id)
    await state.set_state(ProfileSetup.waiting_new_user_role)
    await message.answer(
        f"Пользователь <code>{new_id}</code>.\nВыберите роль:",
        reply_markup=_role_choices_kb(new_id),
    )


def _role_choices_kb(user_id: int) -> "InlineKeyboardMarkup":
    """Inline keyboard picking the role for a new/updated user."""
    rows = [
        [
            InlineKeyboardButton(
                text="🛡 Администратор",
                callback_data=f"profile:user:set_role:{user_id}:{ADMIN_ROLE_ADMIN}",
            ),
            InlineKeyboardButton(
                text="👤 Пользователь",
                callback_data=f"profile:user:set_role:{user_id}:{ADMIN_ROLE_MEMBER}",
            ),
        ],
        [
            InlineKeyboardButton(text="❌ Отмена", callback_data="profile:menu"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data.startswith("profile:user:set_role:"))
async def profile_user_set_role(callback: CallbackQuery, state: FSMContext) -> None:
    """Apply the chosen role to the pending new user."""
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        # Only accept this callback while we are genuinely waiting for a role
        # choice on the pending user. A stale/replayed callback must not apply
        # a role change outside the FSM flow.
        if await state.get_state() != ProfileSetup.waiting_new_user_role:
            await callback.answer("❌ Сессия истекла, начните заново", show_alert=True)
            return
        parts = callback.data.split(":")
        if len(parts) != 5:
            await callback.answer("❌ Ошибка формата", show_alert=True)
            await state.clear()
            return
        _, _, _, user_id_str, role = parts
        target_id = int(user_id_str)
        if role not in ADMIN_ROLES:
            await callback.answer("❌ Неизвестная роль", show_alert=True)
            return

        async with get_session() as session:
            result = await grant_admin(session, callback.from_user.id, target_id, role=role)

        role_label = {"owner": "Владелец", "admin": "Администратор", "member": "Пользователь"}.get(role, role)
        if result["ok"]:
            await callback.message.edit_text(
                f"✅ Пользователь <code>{target_id}</code> добавлен с ролью <b>{role_label}</b>.",
                reply_markup=None,
            )
        else:
            await callback.message.edit_text(
                f"❌ Не удалось добавить: {result['error']}",
            )
        await callback.answer()
        await state.clear()
    except Exception:
        logger.exception("profile_user_set_role failed")
        await callback.answer("❌ Ошибка", show_alert=True)


@router.callback_query(F.data == "profile:admins:remove")
async def profile_admins_remove(callback: CallbackQuery) -> None:
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        await _render_admins_remove(callback)
        await callback.answer()
    except Exception:
        logger.exception("profile_admins_remove failed")
        await callback.answer("❌ Ошибка", show_alert=True)


async def _render_admins_remove(callback: CallbackQuery) -> None:
    """Render the remove-admin list (without answering the callback)."""
    async with get_session() as session:
        admins = await list_admins(session)
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    rows = []
    me = callback.from_user.id
    for a in admins:
        if not a.is_admin or a.telegram_id == me:
            continue
        label = f"Удалить {a.telegram_id}"
        if a.full_name:
            label = f"Удалить {a.full_name} ({a.telegram_id})"
        rows.append([InlineKeyboardButton(text=label[:40], callback_data=f"profile:admins:revoke:{a.telegram_id}")])
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data="profile:admins:list")])
    await callback.message.edit_text(
        "➖ <b>Удалить администратора</b>\n\n"
        "Выберите админа для удаления:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )


@router.callback_query(F.data.startswith("profile:admins:revoke:"))
async def profile_admins_revoke(callback: CallbackQuery) -> None:
    try:
        if not await _check_admin(callback):
            await callback.answer("🚫 Нет доступа", show_alert=True)
            return
        parts = callback.data.split(":")
        if len(parts) < 4:
            await callback.answer("❌ Ошибка формата", show_alert=True)
            return
        target_id = int(parts[3])
        async with get_session() as session:
            result = await revoke_admin(session, callback.from_user.id, target_id)
        if result["ok"]:
            await callback.answer("✅ Администратор удалён", show_alert=False)
        else:
            await callback.answer(f"❌ {result['error']}", show_alert=True)
        await _render_admins_remove(callback)
    except Exception:
        logger.exception("profile_admins_revoke failed")
        await callback.answer("❌ Ошибка", show_alert=True)
