"""Admin flow for adding another controller-bot token."""

from __future__ import annotations

import re

from aiogram import F, Bot, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.bot.instance_manager import get_instance_manager
from app.bot.keyboards import main_kb
from app.config import settings
from app.core.db import get_session
from app.core.services import instances as instances_svc
from app.core.services.admins import is_admin_user

router = Router(name="instances")
_TOKEN_RE = re.compile(r"^\d{6,}:[A-Za-z0-9_-]{30,}$")


class BotAddFlow(StatesGroup):
    waiting_token = State()


@router.callback_query(F.data == "profile:bot:add")
async def profile_bot_add(callback: CallbackQuery, state: FSMContext) -> None:
    if not await is_admin_user(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(BotAddFlow.waiting_token)
    await callback.message.edit_text(
        "🤖 <b>Добавить бота-копию</b>\n\n"
        "Отправьте токен нового бота, полученный у @BotFather:\n"
        "<code>123456:AA...</code>",
        reply_markup=None,
    )
    await callback.answer()


@router.message(BotAddFlow.waiting_token)
async def profile_bot_add_token(message: Message, state: FSMContext) -> None:
    token = (message.text or "").strip()
    if not _TOKEN_RE.fullmatch(token):
        await message.answer(
            "❌ Похоже, это не токен Telegram-бота.\n"
            "Отправьте токен в формате <code>123456:AA...</code> или нажмите /cancel."
        )
        return

    if token == settings.BOT_TOKEN:
        await state.clear()
        await message.answer("❌ Это уже токен основного бота.", reply_markup=main_kb)
        return

    async with get_session() as session:
        if await instances_svc.token_in_use(session, token):
            await state.clear()
            await message.answer(
                "❌ Этот токен уже используется в системе.", reply_markup=main_kb
            )
            return

    # Validate before writing anything, following the existing sub-bot pattern.
    temp_bot = Bot(token=token)
    try:
        me = await temp_bot.get_me()
    except Exception as exc:
        await state.clear()
        await message.answer(
            f"❌ Telegram не принял токен: {exc}", reply_markup=main_kb
        )
        return
    finally:
        await temp_bot.session.close()

    async with get_session() as session:
        # Re-check under the write transaction to avoid a duplicate race.
        if await instances_svc.token_in_use(session, token):
            await state.clear()
            await message.answer(
                "❌ Этот токен уже используется в системе.", reply_markup=main_kb
            )
            return
        await instances_svc.add_instance(
            session,
            token=token,
            username=me.username,
            name=me.first_name,
            telegram_id=me.id,
        )
        await session.commit()

    try:
        manager = get_instance_manager()
        await manager.add_instance(token)
    except Exception as exc:
        await state.clear()
        await message.answer(
            "⚠️ Токен сохранён, но запустить копию сейчас не удалось: "
            f"{exc}",
            reply_markup=main_kb,
        )
        return

    await state.clear()
    username = f"@{me.username}" if me.username else me.first_name or "бот"
    await message.answer(
        f"✅ Бот {username} добавлен и работает как копия контроллера.\n"
        "Данные общие с основным ботом.",
        reply_markup=main_kb,
    )
