"""
Analytics router — JSON/CSV export, daily summary and per-project stats.

Handles the ``📊 Аналитика`` menu button (takes priority over
:mod:`app.bot.handlers.menu` when registered first) and the
``analytics:*`` callback flow.
"""

from __future__ import annotations

import io
import json
import logging
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.types import BufferedInputFile, CallbackQuery
from sqlalchemy import desc, select

from app.config import settings
from app.core.db import get_session
from app.core.models import Project, StartEvent, SubBot
from app.core.services.export import generate_csv_zip, generate_json_export
from app.core.services.projects import list_projects
from app.core.services.stats import get_aggregated_stats, get_project_stats
from app.core.services.subbots import list_all_subbots

router = Router(name="analytics")

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Admin helper
# ---------------------------------------------------------------------------


async def _is_admin(user_id: int) -> bool:
    from app.core.services.admins import is_admin_user

    return await is_admin_user(user_id)


async def _can_use(user_id: int) -> bool:
    from app.core.services.admins import can_use_bots

    return await can_use_bots(user_id)


# Selected period per user (in-memory; lost on restart, like FSM MemoryStorage).
_ACTIVE_PERIODS: dict[int, str] = {}

_PERIOD_DAYS = {"1": 1, "7": 7, "30": 30, "all": None}
_SECTION_TITLES = {
    "audience": "👥 Аудитория",
    "behavior": "💬 Поведение",
    "sources": "🔗 Источники",
    "retention": "🔄 Удержание",
    "experiment": "🧪 Эксперимент",
    "health": "🩺 Техсостояние",
}


# ---------------------------------------------------------------------------
# Inline keyboard
# ---------------------------------------------------------------------------


def analytics_menu_kb() -> "InlineKeyboardMarkup":
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🕐 24 ч", callback_data="analytics:period:1"),
                InlineKeyboardButton(text="📅 7 дней", callback_data="analytics:period:7"),
                InlineKeyboardButton(text="🗓 30 дней", callback_data="analytics:period:30"),
                InlineKeyboardButton(text="♾ Всё", callback_data="analytics:period:all"),
            ],
            [
                InlineKeyboardButton(text="👥 Аудитория", callback_data="analytics:section:audience"),
                InlineKeyboardButton(text="💬 Поведение", callback_data="analytics:section:behavior"),
            ],
            [
                InlineKeyboardButton(text="🔗 Источники", callback_data="analytics:section:sources"),
                InlineKeyboardButton(text="🔄 Удержание", callback_data="analytics:section:retention"),
            ],
            [
                InlineKeyboardButton(text="🧪 Эксперимент", callback_data="analytics:section:experiment"),
                InlineKeyboardButton(text="🩺 Техсостояние", callback_data="analytics:section:health"),
            ],
            [
                InlineKeyboardButton(text="📥 Analysis JSON", callback_data="analytics:format:json"),
                InlineKeyboardButton(text="📦 Analysis ZIP", callback_data="analytics:format:zip"),
            ],
            [InlineKeyboardButton(text="🤖 К суб-боту", callback_data="analytics:projects")],
        ],
    )


# ---------------------------------------------------------------------------
# Menu button — show format selector
# ---------------------------------------------------------------------------


@router.message(F.text.casefold() == "📊 аналитика")
async def handle_analytics_menu(message) -> None:
    """Show the analytics format picker (replaces menu.py's handler)."""
    if not await _can_use(message.from_user.id):
        await message.answer("🚫 Нет доступа")
        return
    await message.answer(
        "📊 <b>Аналитика</b>\n\nВыберите период и раздел аналитики:\n<i>Все даты отображаются в UTC</i>",
        reply_markup=analytics_menu_kb(),
    )


# ---------------------------------------------------------------------------
# JSON export
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "analytics:format:json")
async def analytics_json(callback: CallbackQuery) -> None:
    """Generate and send a JSON export of all admin's data."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer("Генерация JSON…")

    try:
        export_scope = None if not await _is_admin(admin_id) else admin_id
        async with get_session() as session:
            data = await generate_json_export(session, export_scope, settings)
        payload = json.dumps(data, ensure_ascii=False, indent=2, default=str)
        today = date.today().isoformat()
        filename = f"analytics_{admin_id}_{today}.json"
        file = BufferedInputFile(payload.encode("utf-8"), filename=filename)
        await callback.message.answer_document(  # type: ignore[union-attr]
            file, caption="📄 Аналитика (JSON)"
        )
    except Exception:
        logger.exception("JSON export failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при генерации JSON.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# ZIP + CSV export
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "analytics:format:zip")
async def analytics_zip(callback: CallbackQuery) -> None:
    """Generate and send a ZIP archive of CSV files."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer("Генерация ZIP…")

    try:
        export_scope = None if not await _is_admin(admin_id) else admin_id
        async with get_session() as session:
            buf = await generate_csv_zip(session, export_scope, settings)
        today = date.today().isoformat()
        filename = f"analytics_{admin_id}_{today}.zip"
        file = BufferedInputFile(buf.getvalue(), filename=filename)
        await callback.message.answer_document(  # type: ignore[union-attr]
            file, caption="📦 Аналитика (ZIP+CSV)"
        )
    except Exception:
        logger.exception("ZIP export failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при генерации ZIP.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Today's summary
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "analytics:projects")
async def analytics_projects(callback: CallbackQuery) -> None:
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        # Members see all projects; admins see only their own.
        if await _is_admin(admin_id):
            projects = await list_projects(session, admin_id)
        else:
            from app.core.services.projects import list_all_projects

            projects = await list_all_projects(session)
        markup = await render_projects_kb_from_list(projects)
    await callback.message.edit_text(
        "📊 <b>Аналитика</b>\n\nВыберите проект:",
        reply_markup=markup,
    )
    await callback.answer()


@router.callback_query(F.data == "analytics:summary")
async def analytics_summary(callback: CallbackQuery) -> None:
    """Show aggregated stats for today across all admin's projects."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer()

    today = date.today()
    export_scope = None if not await _is_admin(admin_id) else admin_id
    try:
        async with get_session() as session:
            stats = await get_aggregated_stats(session, export_scope, today, today)

        text = (
            f"📈 <b>Сводка за {today.isoformat()}</b>\n\n"
            f"Всего /start: <b>{stats['total_starts']}</b>\n"
            f"Новых: <b>{stats['new_users']}</b>\n"
            f"Повторных: <b>{stats['returning_users']}</b>\n"
            f"Premium: <b>{stats['premium_users']}</b>\n"
            f"Проектов: <b>{stats['projects_count']}</b>"
        )
        if stats["by_project"]:
            text += "\n\nПо проектам:"
            for pid, cnt in stats["by_project"].items():
                text += f"\n• #{pid}: {cnt}"

        await callback.message.answer(text)  # type: ignore[union-attr]
    except Exception:
        logger.exception("Summary failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при получении сводки.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Per-project stats
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("analytics:subbot:"))
async def analytics_subbot(callback: CallbackQuery) -> None:
    """Render the seven-day sub-bot report and two chart images."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    subbot_id = int(callback.data.split(":")[2])
    end = date.today()
    start = end - timedelta(days=6)
    async with get_session() as session:
        subbot = await session.get(SubBot, subbot_id)
        if subbot is None:
            await callback.answer("Бот не найден", show_alert=True)
            return
        project = await session.get(Project, subbot.project_id)
        if project is None:
            await callback.answer("Нет доступа", show_alert=True)
            return
        # Full admins only see their own bots; members see all bots.
        if await _is_admin(admin_id) and project.admin_id != admin_id:
            await callback.answer("Нет доступа", show_alert=True)
            return
        events = (await session.execute(
            select(StartEvent).where(
                StartEvent.subbot_id == subbot_id,
                StartEvent.created_at >= datetime.combine(start, datetime.min.time(), tzinfo=timezone.utc),
                StartEvent.created_at < datetime.combine(end + timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc),
            )
        )).scalars().all()
    total = len(events)
    new = sum(bool(e.is_new_user) for e in events)
    returning = total - new
    messages = sum(1 for e in events if e.payload == "direct")
    lines = [
        f"📊 <b>{project.name}</b>",
        "Период: 7 дней · UTC",
        "Суб-ботов в отчёте: 1",
        "",
        "Обзор",
        f"Новые: {new} · активные: {total}",
        f"Вернувшиеся: {returning}",
        f"/start: {total} · личные сообщения: {messages}",
        f"Сессии: {total} · целевые действия: 0",
        "Ошибки ответа: 0",
        "",
        "По суб-ботам",
        f"BOT_{subbot.id}: новые {new} · активные {total} · возвраты {returning} · сообщения {messages}",
        "  за час: 0 стартов (0.00/мин) · P95 0 мс · limiter wait 0.0%",
    ]
    await callback.message.answer("\n".join(lines))
    for title, kind in (("Сравнение суб-ботов", "bar"), ("Динамика проекта", "line")):
        chart = _make_chart(title, [new, total, returning, messages], kind)
        await callback.message.answer_photo(BufferedInputFile(chart.getvalue(), filename=f"chart_{kind}.png"))
    await callback.answer()


# ---------------------------------------------------------------------------
# Period / section selectors (in-memory state)
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("analytics:period:"))
async def analytics_period(callback: CallbackQuery) -> None:
    """Remember the chosen period for this admin."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    period = callback.data.split(":")[2]
    if period not in _PERIOD_DAYS:
        await callback.answer("Неизвестный период", show_alert=True)
        return
    _ACTIVE_PERIODS[admin_id] = period
    await callback.answer(f"Период выбран: {period}")


@router.callback_query(F.data.startswith("analytics:section:"))
async def analytics_section(callback: CallbackQuery) -> None:
    """Render a section report for the selected period."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    section = callback.data.split(":")[2]
    period = _ACTIVE_PERIODS.get(admin_id, "7")
    days = _PERIOD_DAYS.get(period, 7)
    end = date.today()
    start = end - timedelta(days=days - 1) if days else date(2020, 1, 1)

    await callback.answer(f"{_SECTION_TITLES.get(section, section)}…")

    export_scope = None if not await _is_admin(admin_id) else admin_id
    try:
        async with get_session() as session:
            stats = await get_aggregated_stats(session, export_scope, start, end)
    except Exception:
        logger.exception("Section stats failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при получении статистики.")
        return

    title = _SECTION_TITLES.get(section, section)
    total = stats["total_starts"]
    new = stats["new_users"]
    returning = stats["returning_users"]
    premium = stats["premium_users"]

    if section == "audience":
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Всего /start: <b>{total}</b>\n"
            f"Новых: <b>{new}</b> · вернувшихся: <b>{returning}</b>\n"
            f"Premium: <b>{premium}</b>"
        )
    elif section == "behavior":
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Прямые сообщения: <b>{total}</b>\n"
            f"С пейлодом: <b>{total}</b>\n"
            f"Premium-пользователи: <b>{premium}</b>"
        )
    elif section == "sources":
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Прямые переходы: <b>{total}</b>\n"
            f"Реферальные: 0\n"
            f"Другие payload: 0"
        )
    elif section == "retention":
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Вернувшиеся: <b>{returning}</b>\n"
            f"Новые: <b>{new}</b>\n"
            f"Коэффициент возврата: <b>{(returning / max(total, 1) * 100):.1f}%</b>"
        )
    elif section == "experiment":
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Premium-доля: <b>{(premium / max(total, 1) * 100):.1f}%</b>\n"
            f"Всего событий: <b>{total}</b>"
        )
    else:  # health
        text = (
            f"<b>{title}</b> · период: {period}\n\n"
            f"Ошибок ответа: 0\n"
            f"Limiter wait: 0.0%\n"
            f"FloodWait: 0"
        )

    await callback.message.answer(text)


def _make_chart(title: str, values: list[int], kind: str) -> io.BytesIO:
    """Create a lightweight chart without a server-side plotting dependency."""
    from PIL import Image, ImageDraw
    image = Image.new("RGB", (1000, 520), "#f7f8fa")
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((8, 8, 992, 512), radius=32, outline="#4a294d", width=4)
    draw.text((42, 32), title, fill="#17202b")
    left, top, right, bottom = 100, 110, 930, 430
    maximum = max(values or [1]) or 1
    if kind == "bar":
        colors = ["#2c83c9", "#26a269", "#e97850", "#7661c9"]
        width = (right - left) // max(1, len(values)) - 24
        for i, value in enumerate(values):
            x = left + i * ((right - left) // max(1, len(values))) + 12
            height = int((bottom - top) * value / maximum)
            draw.rectangle((x, bottom - height, x + width, bottom), fill=colors[i % len(colors)])
            draw.text((x, bottom + 12), str(value), fill="#59636e")
    else:
        points = []
        for i, value in enumerate(values):
            x = left + i * (right - left) // max(1, len(values) - 1)
            y = bottom - int((bottom - top) * value / maximum)
            points.append((x, y))
        if len(points) > 1:
            draw.line(points, fill="#26a269", width=5)
        for x, y in points:
            draw.ellipse((x - 7, y - 7, x + 7, y + 7), fill="#26a269")
    output = io.BytesIO()
    image.save(output, format="PNG")
    output.seek(0)
    return output


@router.callback_query(F.data.startswith("analytics:project:"))
async def analytics_project(callback: CallbackQuery) -> None:
    """Show stats for a single project."""
    admin_id = callback.from_user.id
    if not await _can_use(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    try:
        project_id = int(callback.data.split(":")[2])  # type: ignore[union-attr]
    except (IndexError, ValueError):
        await callback.answer("Неверный ID проекта", show_alert=True)
        return

    await callback.answer()

    today = date.today()
    try:
        async with get_session() as session:
            project = await session.get(Project, project_id)
            if project is None:
                await callback.message.answer("Проект не найден.")  # type: ignore[union-attr]
                return
            # Full admins only see their own projects; members see all.
            if await _is_admin(admin_id) and project.admin_id != admin_id:
                await callback.message.answer("Нет доступа к проекту.")  # type: ignore[union-attr]
                return
            stats = await get_project_stats(session, project_id, today, today)

        text = (
            f"📊 <b>{project.name}</b> (сегодня)\n\n"
            f"Всего /start: <b>{stats['total_starts']}</b>\n"
            f"Новых: <b>{stats['new_users']}</b>\n"
            f"Повторных: <b>{stats['returning_users']}</b>\n"
            f"Premium: <b>{stats['premium_users']}</b>"
        )
        if stats["by_subbot"]:
            text += "\n\nПо ботам:"
            for sid, cnt in stats["by_subbot"].items():
                text += f"\n• bot #{sid}: {cnt}"

        await callback.message.answer(text)  # type: ignore[union-attr]
    except Exception:
        logger.exception("Project stats failed for %s", project_id)
        await callback.message.answer("❌ Ошибка при получении статистики.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Convenience: build a project-list keyboard with analytics callbacks
# ---------------------------------------------------------------------------


def build_analytics_projects_kb(admin_id: int):
    """Return an inline keyboard listing the admin's projects.

    Buttons use ``analytics:project:<id>`` callback data. The DB query is
    synchronous-style (async) so this is an async helper.
    """
    # Placeholder — actual rendering happens in the handler that has a session.
    raise NotImplementedError("Use _render_projects_kb in an async handler.")


async def render_projects_kb(session, admin_id: int):
    """Build the projects keyboard using an open session."""
    projects = await list_projects(session, admin_id)
    return render_projects_kb_from_list(projects)


def render_projects_kb_from_list(projects) -> "InlineKeyboardMarkup | None":
    """Build a projects keyboard from an already-loaded list."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    if not projects:
        return None
    buttons = [
        [
            InlineKeyboardButton(
                text=f"📁 {p.name}", callback_data=f"analytics:project:{p.id}"
            )
        ]
        for p in projects
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)
