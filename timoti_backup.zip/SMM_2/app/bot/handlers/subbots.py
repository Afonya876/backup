"""
Sub-bots router — card view, strategy toggles, pause/resume, goal/extend,
shadow, status, check, and delete for individual sub-bots.

Every mutation validates that the caller **owns** the project the sub-bot
belongs to (no cross-admin access).
"""

from __future__ import annotations

from datetime import datetime

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from app.core.models import Project, StatWindow

from app.bot.keyboards import main_kb, subbot_card_kb
from app.config import settings
from app.core.db import get_session
from app.core.services import subbots as subbots_svc
from app.core.services import promotion as promotion_svc
from app.core.services.admins import can_use_bots, is_admin_user

router = Router(name="subbots")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_STATUS_EMOJI = {
    "running": "🟢",
    "stopped": "🔴",
    "needs_setup": "🟡",
    "unavailable": "⚫",
    "error": "❗",
}

_STRATEGY_LABEL = {
    "20_80": "20% Premium / 80% Regular",
    "100_premium": "100% Premium",
    "none": "не задана",
}


def _normalize(s: str) -> str:
    return (s or "").strip().lower()


def _mask_username(subbot) -> str:
    """Mask a sub-bot username as `@username` or a token-derived code."""
    if subbot.bot_username:
        return f"@{subbot.bot_username}"
    token = subbot.bot_token or ""
    return f"bot:{token[:6]}...{token[-4:]}" if len(token) > 10 else "bot:..."


def _truncate(value: str, limit: int) -> str:
    return value if len(value) <= limit else value[: max(1, limit - 1)] + "…"


async def _load_owned_subbot(
    session, admin_id: int, subbot_id: int
) -> "object | None":
    """Return the SubBot if the caller may view it.

    * Full admins: only sub-bots in projects they own.
    * Members: any sub-bot in the system.
    """
    subbot = await subbots_svc.get_subbot(session, subbot_id=subbot_id)
    if subbot is None:
        return None
    project = await session.get(Project, subbot.project_id)
    if project is None:
        return None
    if await is_admin_user(admin_id) and project.admin_id != admin_id:
        return None
    return subbot


async def _check_admin(callback: CallbackQuery) -> bool:
    return await is_admin_user(callback.from_user.id)


async def _check_user(callback: CallbackQuery) -> bool:
    """Any registered user (owner/admin/member) may view/check bots."""
    return await can_use_bots(callback.from_user.id)


# ---------------------------------------------------------------------------
# a) Sub-bot card
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:card:"))
async def sb_card(callback: CallbackQuery) -> None:
    """Show the sub-bot promotion card exactly like the original controller."""
    if not await _check_user(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    subbot_id = int(callback.data.split(":")[2])

    async with get_session() as session:
        subbot = await _load_owned_subbot(session, callback.from_user.id, subbot_id)
        project = await session.get(Project, subbot.project_id) if subbot else None
        latest_window = None
        if subbot:
            latest_window = (
                await session.execute(
                    select(StatWindow)
                    .where(StatWindow.subbot_id == subbot_id)
                    .order_by(StatWindow.window_date.desc(), StatWindow.id.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()

    if subbot is None:
        await callback.answer("Суб-бот не найден", show_alert=True)
        return

    text = _render_card_text(subbot, project, latest_window)
    await callback.message.edit_text(
        text,
        reply_markup=subbot_card_kb(subbot.id),
    )
    await callback.answer()


def _render_card_text(subbot, project, latest_window) -> str:
    """Build the full promotion-card text (shared by card and refresh)."""
    username = subbot.bot_username or _mask_username(subbot)
    strategy_label = _STRATEGY_LABEL.get(subbot.strategy, subbot.strategy)
    state_label = _state_label(subbot)
    shadow_label = "✅ да" if subbot.is_shadow else "❌ нет"
    next_launch = _next_launch_label(subbot)

    lines = [
        f"🚀 <b>Продвижение @{username}</b>",
        "",
        f"📌 Стратегия: <b>{strategy_label}</b>",
        f"📊 Состояние: <b>{state_label}</b>",
        f"📈 Уровень роста: <b>{subbot.current_step}</b>",
        f"🎯 База следующего окна: <b>{subbot.current_daily_plan or 200}</b>",
        f"👻 Тень: {shadow_label}",
        "",
        "─" * 20,
        "📊 <b>Итог текущего роста</b>",
        "",
        f"📅 Рабочих дней: <b>{subbot.work_days_completed}</b>",
        f"🚀 Доставлено: <b>{subbot.total_delivered}</b>",
        f"📦 Regular / Premium: <b>{subbot.delivered_regular}</b> / <b>{subbot.delivered_premium}</b>",
        f"💰 Фактические расходы: <b>{subbot.total_cost:.4f} USD</b>",
    ]

    if project and project.achievement_mode and project.achievement_mode != "none":
        ach_strategy = _STRATEGY_LABEL.get(project.achievement_mode, project.achievement_mode)
        ach_days = project.achievement_days or 0
        ach_delivered = project.achievement_delivered_starts or 0
        ach_cost = project.achievement_cost or 0.0
        lines += [
            "",
            "─" * 20,
            "🏆 <b>Обученный эталон проекта</b>",
            "",
            f"📌 Режим: <b>{ach_strategy}</b>",
            f"📅 Рабочих дней: <b>{ach_days}</b>",
            f"🚀 Доставлено: <b>{ach_delivered}</b>",
            f"💰 Исторические расходы: <b>{ach_cost:.4f} USD</b>",
        ]

    if project and project.achievement_mode and project.achievement_mode != "none":
        ach_days = project.achievement_days or 0
        ach_delivered = project.achievement_delivered_starts or 0
        days_done = subbot.work_days_completed or 0
        delivered_done = subbot.total_delivered or 0
        lines += [
            "",
            "─" * 20,
            "🎯 <b>Автоматическая цель этого бота</b>",
            "",
            f"📅 Дни: <b>{days_done}/{ach_days}</b>",
            f"🚀 Старты: <b>{delivered_done}/{ach_delivered}</b>",
            "",
            "ℹ️ После воспроизведения эталона новые заказы",
            "остановятся для проверки позиции.",
        ]

    lines += [
        "",
        "─" * 20,
        f"🕐 <b>Следующий запуск:</b>",
        f"   {next_launch}",
    ]

    if latest_window:
        lines.append("")
        lines.append(f"📅 Последний день: <b>{latest_window.window_date}</b>")
        lines.append(f"📊 План: {latest_window.planned_starts} | 🚀 Доставлено: {latest_window.total_delivered}")
        lines.append(f"💰 Стоимость: <b>{latest_window.cost:.4f} USD</b>")

    return "\n".join(lines)


def _state_label(subbot) -> str:
    """Map subbot state to the original's human-readable label."""
    if subbot.is_paused:
        return "пауза"
    if subbot.maintenance_mode:
        return "поддержка"
    if subbot.strategy == "none":
        return "стратегия не выбрана"
    status_map = {
        "running": "активно",
        "stopped": "остановлен",
        "needs_setup": "требует настройки",
        "unavailable": "недоступен",
        "error": "ошибка",
    }
    return status_map.get(subbot.status, subbot.status)


def _next_launch_label(subbot) -> str:
    """Format the next launch date like the original controller."""
    from zoneinfo import ZoneInfo

    tz = ZoneInfo(getattr(settings, "TIMEZONE", "Europe/Kiev"))
    when = subbot.last_window_at or datetime.now(tz)
    try:
        local = when.astimezone(tz) if when.tzinfo else when.replace(tzinfo=tz)
    except Exception:
        local = when
    date_str = local.strftime("%d.%m.%Y %H:%M")
    return f"{date_str} ({tz.key})"


# ---------------------------------------------------------------------------
# Detailed technical bot card
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:details:"))
async def sb_details(callback: CallbackQuery) -> None:
    """Show the technical bot details screen from the bots list."""
    if not await _check_user(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    subbot_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        subbot = await _load_owned_subbot(session, callback.from_user.id, subbot_id)
    if subbot is None:
        await callback.answer("Бот не найден", show_alert=True)
        return

    status = subbot.status or "stopped"
    status_label = {
        "running": "🟢 running",
        "stopped": "🔴 stopped",
        "needs_setup": "🟡 needs setup",
        "unavailable": "⚫ unavailable",
        "error": "❗ error",
    }.get(status, f"⚪ {status}")
    active = "✅ Да" if status == "running" else "❌ Нет"
    username = f"@{subbot.bot_username}" if subbot.bot_username else "не задан"
    telegram_id = subbot.telegram_id or "не известен"
    checked = getattr(subbot, "updated_at", None)
    checked_text = checked.strftime("%Y-%m-%d %H:%M:%S") if checked else "ещё не проверен"
    created = getattr(subbot, "created_at", None)
    created_text = created.strftime("%Y-%m-%d %H:%M:%S") if created else "неизвестно"
    health = subbot.status_message or "Проверка не выполнялась"

    text = (
        "📄 <b>Детали бота</b>\n\n"
        "👤 <b>Идентификация</b>\n"
        f"  🆔 ID: <code>{subbot.id}</code>\n"
        f"  🤖 Telegram bot ID: <code>{telegram_id}</code>\n"
        f"  🏷 Имя: <b>{subbot.bot_name or 'не задано'}</b>\n"
        f"  🔗 Username: <b>{username}</b>\n\n"
        "📡 <b>Состояние</b>\n"
        f"  📊 Статус: <b>{status_label}</b>\n"
        f"  ⚡ Активен: {active}\n"
        f"  📁 Проект ID: <code>{subbot.project_id}</code>\n"
        "  ⚙️ Настройки ответа: наследуются от проекта\n\n"
        "🕐 <b>Время</b>\n"
        f"  ➕ Создан: <code>{created_text}</code>\n"
        f"  🔍 Проверен: <code>{checked_text}</code>\n\n"
        f"💬 <b>Сообщение</b>\n{health}"
    )
    await callback.message.edit_text(text, reply_markup=bot_details_kb(subbot.id))
    await callback.answer()


def bot_details_kb(subbot_id: int):
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📈 Продвижение", callback_data=f"sb:card:{subbot_id}")],
        [InlineKeyboardButton(text="📊 Аналитика", callback_data=f"analytics:subbot:{subbot_id}")],
        [InlineKeyboardButton(text="🩺 Проверить токен", callback_data=f"sb:check:{subbot_id}")],
        [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"sb:delete:{subbot_id}")],
        [InlineKeyboardButton(text="🤖 К списку ботов", callback_data="sb:list")],
        [InlineKeyboardButton(text="⬅️ В меню", callback_data="projects:menu")],
    ])


@router.callback_query(F.data == "sb:list")
async def sb_list_callback(callback: CallbackQuery) -> None:
    if not await _check_user(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await callback.message.delete()
    await bots_menu(callback.message)
    await callback.answer()


# ---------------------------------------------------------------------------
# b) Strategy 20/80
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:strategy:") & F.data.endswith(":20_80"))
async def sb_strategy_20_80(callback: CallbackQuery) -> None:
    """Enable the 20/80 strategy."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await subbots_svc.set_strategy(session, subbot_id=subbot_id, strategy="20_80")
        await session.commit()
    await callback.answer("✅ Стратегия 20/80 включена", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# c) Strategy 100% Premium
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:strategy:") & F.data.endswith(":100_premium"))
async def sb_strategy_100_premium(callback: CallbackQuery) -> None:
    """Enable the 100% Premium strategy."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await subbots_svc.set_strategy(
            session, subbot_id=subbot_id, strategy="100_premium"
        )
        await session.commit()
    await callback.answer("✅ Стратегия 100% Premium включена", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# d) Pause
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:pause:"))
async def sb_pause(callback: CallbackQuery) -> None:
    """Pause promotion (SMM orders only — never the Telegram bot itself)."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await promotion_svc.pause_promotion(session, subbot_id=subbot_id)
        await session.commit()
    await callback.answer("⏸ Продвижение приостановлено", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# e) Resume
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:resume:"))
async def sb_resume(callback: CallbackQuery) -> None:
    """Resume promotion."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await promotion_svc.resume_promotion(session, subbot_id=subbot_id)
        await session.commit()
    await callback.answer("▶️ Рост продолжен", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# f) Goal reached
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:goal:"))
async def sb_goal(callback: CallbackQuery) -> None:
    """Confirm the goal achievement for a sub-bot."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        subbot = await _load_owned_subbot(session, callback.from_user.id, subbot_id)
        if subbot is None:
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await promotion_svc.confirm_goal(
            session, subbot_id=subbot.id, project_id=subbot.project_id
        )
        await session.commit()
    await callback.answer("🎯 Цель достигнута! Зафиксировано.", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# g) Extend promotion
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:extend:"))
async def sb_extend(callback: CallbackQuery) -> None:
    """Extend promotion by one step."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await promotion_svc.extend_promotion(session, subbot_id=subbot_id)
        await session.commit()
    await callback.answer("📈 Продвижение продлено на один этап", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# h) Toggle shadow
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:shadow:"))
async def sb_shadow(callback: CallbackQuery) -> None:
    """Toggle shadow mode for a sub-bot."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        subbot = await _load_owned_subbot(session, callback.from_user.id, subbot_id)
        if subbot is None:
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        new_value = not subbot.is_shadow
        await subbots_svc.set_shadow(session, subbot_id=subbot.id, shadow=new_value)
        await session.commit()
    label = "включён" if new_value else "выключен"
    await callback.answer(f"👻 Тень {label}", show_alert=False)
    await _refresh_card(callback, subbot_id)


# ---------------------------------------------------------------------------
# i) Status
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:status:"))
async def sb_status(callback: CallbackQuery) -> None:
    """Show current status and stat window info."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        subbot = await _load_owned_subbot(session, callback.from_user.id, subbot_id)

    if subbot is None:
        await callback.answer("Нет доступа к этому боту", show_alert=True)
        return

    emoji = _STATUS_EMOJI.get(subbot.status, "❓")
    lines = [
        f"📊 <b>Статус</b>",
        f"{emoji} {subbot.status}",
    ]
    if subbot.status_message:
        lines.append(f"<i>{subbot.status_message}</i>")

    lines += [
        "",
        f"Шаг: {subbot.current_step}",
        f"План на день: {subbot.current_daily_plan}",
        f"Доставлено сегодня: {subbot.delivered_today}",
        f"Всего доставлено: {subbot.total_delivered}",
        f"Рабочих дней: {subbot.work_days_completed}",
    ]

    if subbot.stat_windows:
        w = subbot.stat_windows[-1]
        lines += [
            "",
            f"📅 Окно: {w.window_date}",
            f"Стратегия: {w.strategy}",
            f"План: {w.planned_starts}",
            f"Доставлено: {w.total_delivered}",
            f"Стоимость: {w.cost}",
        ]

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=subbot_card_kb(subbot.id),
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# j) Check sub-bot
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:check:"))
async def sb_check(callback: CallbackQuery) -> None:
    """Run a healthcheck on a sub-bot (token → get_me only, no process start)."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_user(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        status, msg = await subbots_svc.check_subbot(
            session, subbot_id=subbot_id, bot=callback.bot
        )
        await session.commit()
    emoji = _STATUS_EMOJI.get(status, "❓")
    await callback.message.answer(f"{emoji} {msg}")
    await callback.answer()


# ---------------------------------------------------------------------------
# k) Delete sub-bot
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("sb:delete:"))
async def sb_delete(callback: CallbackQuery) -> None:
    """Delete a sub-bot (SMM orders are NOT cancelled with the provider)."""
    subbot_id = int(callback.data.split(":")[2])
    if not await _check_admin(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if not await _load_owned_subbot(session, callback.from_user.id, subbot_id):
            await callback.answer("Нет доступа к этому боту", show_alert=True)
            return
        await subbots_svc.delete_subbot(session, subbot_id=subbot_id)
        await session.commit()
    await callback.answer("🗑 Суб-бот удалён", show_alert=False)
    await callback.message.edit_text("🗑 Суб-бот удалён.", reply_markup=None)


# ---------------------------------------------------------------------------
# l) Menu entry — list all sub-bots
# ---------------------------------------------------------------------------


@router.message(F.text.casefold() == _normalize("🤖 боты"))
async def bots_menu(message: Message) -> None:
    """List all sub-bots grouped by project."""
    admin_id = message.from_user.id
    if not await can_use_bots(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    async with get_session() as session:
        # Members see every bot in the system; admins see only their own.
        if await is_admin_user(admin_id):
            subbots = await subbots_svc.list_subbots(session, admin_id=admin_id)
        else:
            subbots = await subbots_svc.list_all_subbots(session)

    if not subbots:
        await message.answer(
            "🤖 <b>Мои боты</b>\n\nНет добавленных ботов.",
            reply_markup=main_kb,
        )
        return

    from collections import defaultdict

    by_project: dict[int, list] = defaultdict(list)
    for sb in subbots:
        by_project[sb.project_id].append(sb)

    lines: list[str] = ["🤖 <b>Список подключённых ботов</b>", ""]
    lines.append(f"📊 Всего ботов: <b>{len(subbots)}</b>")
    lines.append("")
    for project_id, group in by_project.items():
        lines.append(f"📁 <b>Проект #{project_id}</b>")
        for sb in group:
            emoji = _STATUS_EMOJI.get(sb.status, "❓")
            strategy = _STRATEGY_LABEL.get(sb.strategy, sb.strategy)
            mask = _mask_username(sb)
            lines.append(f"  {emoji} <b>ID {sb.id}</b> · {mask}")
            lines.append(f"     📌 {strategy} · 📈 шаг {sb.current_step}")
        lines.append("")

    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    buttons = [
        [
            InlineKeyboardButton(
                text=(
                    f"🟢 ID {sb.id} | "
                    f"{_truncate(sb.bot_name or 'Без имени', 16)} "
                    f"(@{sb.bot_username or 'unknown'})"
                ),
                callback_data=f"sb:details:{sb.id}",
            )
        ]
        for sb in subbots
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)

    await message.answer("\n".join(lines), reply_markup=main_kb)
    await message.answer("Выберите бота:", reply_markup=keyboard)


# ---------------------------------------------------------------------------
# Internal helper — refresh the card after a mutation (full card)
# ---------------------------------------------------------------------------


async def _refresh_card(callback: CallbackQuery, subbot_id: int) -> None:
    """Re-render the full promotion card after a state change."""
    async with get_session() as session:
        subbot = await subbots_svc.get_subbot(session, subbot_id=subbot_id)
        project = await session.get(Project, subbot.project_id) if subbot else None
        latest_window = None
        if subbot:
            latest_window = (
                await session.execute(
                    select(StatWindow)
                    .where(StatWindow.subbot_id == subbot_id)
                    .order_by(StatWindow.window_date.desc(), StatWindow.id.desc())
                    .limit(1)
                )
            ).scalar_one_or_none()

    if subbot is None:
        return

    try:
        await callback.message.edit_text(
            _render_card_text(subbot, project, latest_window),
            reply_markup=subbot_card_kb(subbot.id),
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# m) bots:check — check the most recent sub-bot via getMe
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "bots:check")
async def bots_check(callback: CallbackQuery) -> None:
    """Check the most recent sub-bot's token via Telegram getMe."""
    if not await _check_user(callback):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    async with get_session() as session:
        if await is_admin_user(callback.from_user.id):
            subbots = await subbots_svc.list_subbots(session, admin_id=callback.from_user.id)
        else:
            subbots = await subbots_svc.list_all_subbots(session)
    if not subbots:
        await callback.answer("Нет добавленных ботов", show_alert=True)
        return
    subbot = subbots[-1]
    async with get_session() as session:
        ok, result = await subbots_svc.check_subbot(session, subbot_id=subbot.id, bot=callback.bot)
    if ok == "running":
        await callback.answer(f"✅ {_mask_username(subbot)} работает", show_alert=False)
    else:
        await callback.answer(f"⚠️ {_mask_username(subbot)}: {result}", show_alert=True)


# ---------------------------------------------------------------------------
# n) proj:list — return to the projects list
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "proj:list")
async def proj_list(callback: CallbackQuery) -> None:
    """Return from a sub-bot card back to the project list."""
    from app.bot.handlers.projects import _send_projects_screen

    await _send_projects_screen(callback, callback.from_user.id)
    await callback.answer()
