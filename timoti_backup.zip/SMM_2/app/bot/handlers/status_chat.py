"""
Ping-healthcheck controls for the controller bot.

Handles:

* ``/status_chat`` (admin only) — enable ping monitoring for the admin's
  sub-bots. In a group, the group is used as the status chat; in a private
  chat, the admin's own chat is used. This means an admin can monitor bots
  in DM (private chat) without creating a dedicated group.
* ``/status_chat_off`` (admin only) — disable ping monitoring.
* ``ping:check_now`` callback — manually run a ping check right now.
* ``ping:disable_all`` callback — disable all admin's sub-bots.
* ``ping:toggle_all`` callback — enable or disable ping for all admin's
  sub-bots right inside the controller chat.
"""

from __future__ import annotations

import logging

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import build_ping_control_kb
from app.config import settings
from app.core.db import get_session
from app.core.services.ping_health import (
    disable_status_chat,
    enable_status_chat,
    run_ping_check,
)
from app.core.services.subbots import list_subbots

router = Router(name="status_chat")

logger = logging.getLogger(__name__)

GROUP_TYPES = {ChatType.GROUP, ChatType.SUPERGROUP}


# ---------------------------------------------------------------------------
# Admin helper
# ---------------------------------------------------------------------------


async def _is_admin(user_id: int) -> bool:
    from app.core.services.admins import is_admin_user

    return await is_admin_user(user_id)


# ---------------------------------------------------------------------------
# /status_chat — enable ping monitoring (any chat)
# ---------------------------------------------------------------------------


@router.message(Command("status_chat"))
async def cmd_status_chat_enable(message: Message) -> None:
    """Enable ping-healthcheck for the admin's sub-bots.

    In a group/supergroup, the group itself is the status chat. In a private
    chat, the admin's own DM is used — so an admin can receive ping alerts
    without creating a dedicated group.
    """
    admin_id = message.from_user.id
    if not await _is_admin(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    # Determine the target chat: the group we're in, or the admin's DM.
    if message.chat.type in GROUP_TYPES:
        target_chat_id = message.chat.id
        location_label = "в этой группе"
    elif message.chat.type == ChatType.PRIVATE:
        target_chat_id = admin_id
        location_label = "в этом ЛС"
    else:
        await message.answer("Команда работает в ЛС или групповом чате")
        return

    try:
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            subbot_ids = [sb.id for sb in subbots]
            if not subbot_ids:
                await message.answer("У вас нет суб-ботов для мониторинга.")
                return
            await enable_status_chat(session, target_chat_id, subbot_ids)
        await message.answer(
            f"✅ Ping-healthcheck включен для {len(subbot_ids)} ботов. "
            "Цикл 30-40 мин. При падении бота придёт уведомление сюда."
        )
    except Exception:
        logger.exception("Failed to enable status_chat for admin %s", admin_id)
        await message.answer("❌ Ошибка при включении ping-healthcheck.")


# ---------------------------------------------------------------------------
# /status_chat_off — disable ping monitoring
# ---------------------------------------------------------------------------


@router.message(Command("status_chat_off"))
async def cmd_status_chat_disable(message: Message) -> None:
    """Disable ping-healthcheck for the admin's sub-bots."""
    admin_id = message.from_user.id
    if not await _is_admin(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    try:
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            subbot_ids = [sb.id for sb in subbots]
            if not subbot_ids:
                await message.answer("У вас нет суб-ботов.")
                return
            await disable_status_chat(session, subbot_ids)
        await message.answer("❌ Ping-healthcheck отключен.")
    except Exception:
        logger.exception("Failed to disable status_chat for admin %s", admin_id)
        await message.answer("❌ Ошибка при отключении ping-healthcheck.")


# ---------------------------------------------------------------------------
# ping:check_now — manual ping check
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "ping:check_now")
async def ping_check_now(callback: CallbackQuery) -> None:
    """Run a manual ping check for all the admin's sub-bots."""
    admin_id = callback.from_user.id
    if not await _is_admin(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer("Запуск проверки…")

    try:
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            subbot_ids = [sb.id for sb in subbots]
            if not subbot_ids:
                await callback.message.answer("Нет суб-ботов для проверки.")  # type: ignore[union-attr]
                return
            results = await run_ping_check(
                session, subbot_ids, callback.bot, settings
            )

        lines = ["📡 <b>Результат ping:</b>"]
        for r in results:
            lines.append(
                f"• bot #{r['subbot_id']}: <b>{r['status']}</b> — {r['message']}"
            )
        await callback.message.answer(  # type: ignore[union-attr]
            "\n".join(lines),
            reply_markup=build_ping_control_kb(),
        )
    except Exception:
        logger.exception("Manual ping check failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при проверке.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# ping:disable_all — disable all admin's sub-bots
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "ping:disable_all")
async def ping_disable_all(callback: CallbackQuery) -> None:
    """Disable ping monitoring for all the admin's sub-bots."""
    admin_id = callback.from_user.id
    if not await _is_admin(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer()

    try:
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            subbot_ids = [sb.id for sb in subbots]
            if not subbot_ids:
                await callback.message.answer("Нет суб-ботов.")  # type: ignore[union-attr]
                return
            await disable_status_chat(session, subbot_ids)
        await callback.message.edit_text(  # type: ignore[union-attr]
            f"❌ Ping-healthcheck отключен для {len(subbot_ids)} ботов.",
            reply_markup=build_ping_control_kb(),
        )
    except Exception:
        logger.exception("Disable-all failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка при отключении.")  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# ping:toggle_all — enable ping for all admin's sub-bots in one click
# ---------------------------------------------------------------------------


@router.callback_query(F.data == "ping:toggle_all")
async def ping_toggle_all(callback: CallbackQuery) -> None:
    """Toggle ping monitoring for all the admin's sub-bots in the controller.

    The status chat is the admin's own DM (the chat the callback came from),
    so no separate group is required — bots will be pinged and death alerts
    will arrive right here.
    """
    admin_id = callback.from_user.id
    if not await _is_admin(admin_id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return

    await callback.answer()

    try:
        async with get_session() as session:
            subbots = await list_subbots(session, admin_id=admin_id)
            subbot_ids = [sb.id for sb in subbots]
            if not subbot_ids:
                await callback.message.answer("Нет суб-ботов для мониторинга.")  # type: ignore[union-attr]
                return

            any_enabled = any(sb.ping_enabled for sb in subbots)
            if any_enabled:
                await disable_status_chat(session, subbot_ids)
                text = f"⛔️ Ping-healthcheck выключен ({len(subbot_ids)} ботов)"
            else:
                # Use the admin's own chat (DM) as the status chat.
                await enable_status_chat(session, admin_id, subbot_ids)
                text = (
                    f"✅ Ping-healthcheck включен ({len(subbot_ids)} ботов). "
                    "Цикл 30-40 мин. При падении придёт уведомление сюда."
                )
        await callback.message.edit_text(  # type: ignore[union-attr]
            text,
            reply_markup=build_ping_control_kb(),
        )
    except Exception:
        logger.exception("Toggle-all failed for admin %s", admin_id)
        await callback.message.answer("❌ Ошибка.")  # type: ignore[union-attr]


# Avoid an unused-name lint for the ``Message`` import used by decorators.
_ = Message
