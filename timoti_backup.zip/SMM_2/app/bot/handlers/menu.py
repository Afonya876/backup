"""
Main-menu handlers – react to the reply-keyboard buttons.

Note: the ``👤 Профиль``, ``🤖 Боты``, and ``📊 Аналитика`` buttons are
handled by their dedicated routers (profile.py, subbots.py, analytics.py)
which are registered BEFORE this router in ``dispatcher.setup_handlers()``.
This file only handles buttons that do not have a dedicated section router:
``📡 Ping-healthcheck`` and ``📋 Инструкция``.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import Message

from app.bot.keyboards import build_ping_control_kb, main_kb

router = Router(name="menu")


_normalize = lambda s: (s or "").strip().lower()  # noqa: E731


# ---------------------------------------------------------------------------
# a) Ping-healthcheck
# ---------------------------------------------------------------------------


@router.message(F.text.casefold() == _normalize("📡 ping-healthcheck"))
async def handle_ping_health(message: Message) -> None:
    """Show ping-healthcheck status and controls."""
    from app.core.db import get_session
    from app.core.services import subbots as subbots_svc
    from app.core.services.admins import can_use_bots, is_admin_user

    admin_id = message.from_user.id
    if not await can_use_bots(admin_id):
        await message.answer("🚫 Нет доступа")
        return

    async with get_session() as session:
        if await is_admin_user(admin_id):
            subbots = await subbots_svc.list_subbots(session, admin_id=admin_id)
        else:
            subbots = await subbots_svc.list_all_subbots(session)

    ping_enabled = [sb for sb in subbots if sb.ping_enabled]
    enabled_label = "✅ Включён" if ping_enabled else "⛔️ Выключен"

    await message.answer(
        "📡 <b>Ping-healthcheck</b>\n\n"
        f"Статус: <b>{enabled_label}</b>\n"
        f"Активных: {len(ping_enabled)}",
        reply_markup=build_ping_control_kb(),
    )


# ---------------------------------------------------------------------------
# b) Инструкция
# ---------------------------------------------------------------------------


@router.message(F.text.casefold() == _normalize("📋 инструкция"))
async def handle_info(message: Message) -> None:
    """Show the help sections menu (matches the original 1:1)."""
    sections = [
        "1. Быстрый старт",
        "2. Проекты и суб-боты",
        "3. Картинка, ссылки и ответы",
        "4. Пользователи и языковой фильтр",
        "5. Стратегии и дневное окно",
        "6. Управление продвижением",
        "7. Ping-healthcheck",
        "8. Аналитика и выгрузка",
        "9. Статусы и устранение проблем",
    ]
    await message.answer(
        "📋 <b>Инструкция</b>\n\n" + "\n".join(sections),
        reply_markup=main_kb,
    )
