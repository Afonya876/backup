"""Runtime manager for controller-bot instances.

All controller tokens use one Dispatcher and one shared database. aiogram's
polling runner accepts multiple bots, so adding an instance restarts the
polling runner with the expanded bot list. Bot sessions stay open between
restarts and are closed only during application shutdown.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import suppress

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.config import settings
from app.core.db import get_session
from app.core.services import instances as instances_svc

logger = logging.getLogger(__name__)

_manager: "BotInstanceManager | None" = None


class BotInstanceManager:
    def __init__(self, dp: Dispatcher) -> None:
        self.dp = dp
        self.bots: list[Bot] = []
        self._polling_task: asyncio.Task | None = None
        self._shutdown = asyncio.Event()
        self._restarting = False
        self._restart_lock = asyncio.Lock()

    @property
    def primary_bot(self) -> Bot:
        if not self.bots:
            raise RuntimeError("Bot instances have not been started")
        return self.bots[0]

    async def load_and_start(self) -> None:
        """Load persisted instances, ensure the configured primary, and poll."""
        primary = self._new_bot(settings.BOT_TOKEN)
        try:
            me = await primary.get_me()
        except Exception:
            await primary.session.close()
            raise

        async with get_session() as session:
            await instances_svc.ensure_primary(
                session,
                token=settings.BOT_TOKEN,
                username=me.username,
                name=me.first_name,
                telegram_id=me.id,
            )
            persisted = await instances_svc.list_instances(session, active_only=True)
            await session.commit()

        # Keep the configured primary first and avoid duplicate Bot objects.
        self.bots = [primary]
        seen = {settings.BOT_TOKEN}
        for row in persisted:
            if row.bot_token in seen:
                continue
            seen.add(row.bot_token)
            self.bots.append(self._new_bot(row.bot_token))

        logger.info("Loaded %d controller bot instance(s)", len(self.bots))
        await self._start_polling_task()

    async def add_instance(self, token: str) -> dict[str, str | int | None]:
        """Add a validated token to the live polling set."""
        bot = self._new_bot(token)
        try:
            me = await bot.get_me()
        except Exception:
            await bot.session.close()
            raise

        self.bots.append(bot)
        try:
            await self._restart_polling()
        except Exception:
            self.bots.remove(bot)
            await bot.session.close()
            raise

        return {"username": me.username, "name": me.first_name, "telegram_id": me.id}

    async def _restart_polling(self) -> None:
        async with self._restart_lock:
            self._restarting = True
            try:
                old_task = self._polling_task
                if old_task is not None and not old_task.done():
                    old_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await old_task
                await self._start_polling_task()
            finally:
                self._restarting = False

    async def _start_polling_task(self) -> None:
        if not self.bots:
            raise RuntimeError("At least one controller bot is required")
        self._polling_task = asyncio.create_task(
            self.dp.start_polling(
                *self.bots,
                handle_signals=True,
                close_bot_session=False,
            )
        )
        self._polling_task.add_done_callback(self._on_polling_done)

    def _on_polling_done(self, task: asyncio.Task) -> None:
        if self._restarting or self._shutdown.is_set():
            # A restart replaces the polling task or a shutdown is in progress —
            # do not treat the old task's completion as a fatal stop.
            return
        if task.cancelled():
            logger.info("Controller polling task cancelled")
        elif task.exception() is not None:
            logger.error("Controller polling task stopped", exc_info=task.exception())
        else:
            logger.warning("Controller polling task stopped")
        self._shutdown.set()

    async def wait(self) -> None:
        """Wait until polling ends for a real shutdown or fatal stop."""
        await self._shutdown.wait()

    async def shutdown(self) -> None:
        """Stop polling and close all HTTP sessions."""
        self._shutdown.set()
        task = self._polling_task
        if task is not None and not task.done():
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
        for bot in self.bots:
            with suppress(Exception):
                await bot.session.close()
        self.bots.clear()
        self._polling_task = None

    @staticmethod
    def _new_bot(token: str) -> Bot:
        return Bot(
            token=token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )


def init_instance_manager(dp: Dispatcher) -> BotInstanceManager:
    global _manager
    _manager = BotInstanceManager(dp)
    return _manager


def get_instance_manager() -> BotInstanceManager:
    if _manager is None:
        raise RuntimeError("Bot instance manager has not been initialized")
    return _manager
