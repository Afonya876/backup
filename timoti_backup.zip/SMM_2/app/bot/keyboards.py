"""
aiogram 3.x keyboard definitions for the admin bot.

Main reply-keyboard (always visible at bottom) — 1:1 copy of the original:
    Row 1: 📁 Проекты | 🤖 Боты
    Row 2: 📊 Аналитика | 👤 Профиль
    Row 3: ⚙️ Настройки кнопок | 📡 Ping-healthcheck
    Row 4: 📋 Инструкция

Inline keyboards shown contextually inside each section.
"""

from __future__ import annotations

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

# ---------------------------------------------------------------------------
# Reply keyboard – main menu
# ---------------------------------------------------------------------------

main_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="📁 Проекты"),
            KeyboardButton(text="🤖 Боты"),
        ],
        [
            KeyboardButton(text="📊 Аналитика"),
            KeyboardButton(text="👤 Профиль"),
        ],
        [
            KeyboardButton(text="📡 Ping-healthcheck"),
            KeyboardButton(text="📋 Инструкция"),
        ],
    ],
    resize_keyboard=True,
    is_persistent=True,
)

# ---------------------------------------------------------------------------
# Cancel button (used inside FSM flows)
# ---------------------------------------------------------------------------

cancel_kb = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="❌ Отмена")]],
    resize_keyboard=True,
)

# ---------------------------------------------------------------------------
# Inline keyboards for each main-menu section
# ---------------------------------------------------------------------------

menu_inline_projects = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="➕ Создать проект", callback_data="projects:create"),
            InlineKeyboardButton(text="📋 Мои проекты", callback_data="projects:list"),
        ],
    ],
)

menu_inline_profile = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="🔑 SMMain API", callback_data="profile:api_key"),
            InlineKeyboardButton(text="⚙️ Состояние провайдера", callback_data="profile:provider"),
        ],
        [
            InlineKeyboardButton(text="📈 Рост", callback_data="profile:growth"),
            InlineKeyboardButton(text="🛡 Поддержка", callback_data="profile:maintenance"),
        ],
        [
            InlineKeyboardButton(text="💵 Дневной предохранитель", callback_data="profile:safeguard"),
        ],
        [
            InlineKeyboardButton(text="👥 Администраторы", callback_data="profile:admins:list"),
        ],
    ],
)

menu_inline_bots = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="Проверить бота", callback_data="bots:check"
            ),
        ],
    ],
)

menu_inline_analytics = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📄 JSON", callback_data="analytics:format:json"
            ),
            InlineKeyboardButton(
                text="📦 ZIP+CSV", callback_data="analytics:format:zip"
            ),
        ],
    ],
)


# ---------------------------------------------------------------------------
# Dynamic keyboards
# ---------------------------------------------------------------------------


def build_project_post_kb(
    button1_url: str,
    button1_text: str,
    button2_url: str,
    button2_text: str,
) -> InlineKeyboardMarkup:
    """Return a single-row InlineKeyboardMarkup with two URL buttons."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=button1_text, url=button1_url),
                InlineKeyboardButton(text=button2_text, url=button2_url),
            ],
        ],
    )


def project_card_kb(project_id: int, subbots=(), response_mode: str = "text") -> InlineKeyboardMarkup:
    """Project-card actions for text-mode promotion.

    Image/link post configuration is intentionally not exposed: the controller
    uses text responses only, so the card contains only bot and project actions.
    ``response_mode`` remains accepted for compatibility with existing callers.
    """
    rows = [
        [InlineKeyboardButton(
            text="➕ Добавить суб-ботов",
            callback_data=f"projects:add_bots:{project_id}",
        )],
    ]
    rows.extend(
        [
            [InlineKeyboardButton(
                text=f"🤖 @{sb.bot_username} · управление",
                callback_data=f"sb:card:{sb.id}",
            )]
            for sb in subbots
            if sb.bot_username
        ]
    )
    rows.extend([
        [
            InlineKeyboardButton(
                text="✏️ Переименовать",
                callback_data=f"projects:rename:{project_id}",
            ),
            InlineKeyboardButton(
                text="🗑 Удалить",
                callback_data=f"projects:delete:{project_id}",
            ),
        ],
        [InlineKeyboardButton(
            text="📁 К проектам", callback_data="projects:list"
        )],
        [InlineKeyboardButton(
            text="⬅️ В меню", callback_data="projects:menu"
        )],
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ---------------------------------------------------------------------------
# Ping-healthcheck inline controls (shown under the ping status message)
# ---------------------------------------------------------------------------


def build_ping_control_kb() -> InlineKeyboardMarkup:
    """Inline keyboard with a single on/off toggle."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🔄 Включить / Выключить",
                    callback_data="ping:toggle_all",
                ),
            ],
        ],
    )


def subbot_card_kb(subbot_id: int) -> InlineKeyboardMarkup:
    """Buttons shown when viewing a single sub-bot's card."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Стратегия 20/80",
                    callback_data=f"sb:strategy:{subbot_id}:20_80",
                ),
                InlineKeyboardButton(
                    text="Стратегия 100% Premium",
                    callback_data=f"sb:strategy:{subbot_id}:100_premium",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Пауза",
                    callback_data=f"sb:pause:{subbot_id}",
                ),
                InlineKeyboardButton(
                    text="Продолжить рост",
                    callback_data=f"sb:resume:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Цель достигнута · Поддержка",
                    callback_data=f"sb:goal:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Продлить продвижение",
                    callback_data=f"sb:extend:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Тень",
                    callback_data=f"sb:shadow:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Статус",
                    callback_data=f"sb:status:{subbot_id}",
                ),
                InlineKeyboardButton(
                    text="Проверить",
                    callback_data=f"sb:check:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Удалить",
                    callback_data=f"sb:delete:{subbot_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="Назад", callback_data="proj:list"
                ),
            ],
        ],
    )
