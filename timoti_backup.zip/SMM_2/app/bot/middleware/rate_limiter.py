"""
RateLimiterMiddleware – lightweight aiogram 3.x middleware.

The actual rate-limit logic lives in :class:`app.core.rate_limiter.AsyncRateLimiter`.
This middleware only wires the limiter into the dispatcher so handlers can
use :func:`app.core.telegram_sender.send_message_safe` for outgoing traffic.

Incoming messages are not throttled here (Telegram already enforces chat
limits); the middleware exists as a hook point for future per-user
incoming limits if needed.
"""

from __future__ import annotations

import logging

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from app.core.rate_limiter import AsyncRateLimiter
from app.core.redis import get_redis

logger = logging.getLogger(__name__)


class RateLimiterMiddleware(BaseMiddleware):
    """Attaches a shared :class:`AsyncRateLimiter`` to handler ``data``."""

    def __init__(self, rate: int = 25, burst: int = 5) -> None:
        self._rate = rate
        self._burst = burst
        self._limiter: AsyncRateLimiter | None = None

    async def __call__(
        self,
        handler,
        event: TelegramObject,
        data: dict,
    ):
        if self._limiter is None:
            self._limiter = AsyncRateLimiter(
                get_redis(), rate=self._rate, burst=self._burst
            )
        data["rate_limiter"] = self._limiter
        return await handler(event, data)
