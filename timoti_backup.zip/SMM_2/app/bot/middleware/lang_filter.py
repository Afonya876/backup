"""
LangFilterMiddleware — blocks unsupported languages before handlers run.

Rules
-----
* Extract ``language_code`` from ``event.from_user``.
* If it is missing or not in ``{'uk', 'ru', 'en'}``:
    * For ``/start`` commands and other bot commands — always let through
      (the admin panel must respond regardless of the user's Telegram UI
      language).
    * For any other message — short-circuit by raising ``CancelHandler``.

The middleware is registered **before** the rate limiter so that blocked
users never consume rate-limit budget.

Implementation note: aiogram 3.x class-based middleware uses the single
``__call__`` hook. The old v2 ``on_process_message`` hook is NOT invoked by
the aiogram v3 dispatcher, so we intentionally do **not** define it here.
Defining both would leave the v2 stub silently dead (confusing anyone who
later reads the code).
"""

from __future__ import annotations

import logging

from aiogram import BaseMiddleware
from aiogram.dispatcher.event.bases import CancelHandler
from aiogram.types import Message, TelegramObject

logger = logging.getLogger(__name__)

ALLOWED_LANGUAGES: set[str] = {"uk", "ru", "en"}

# Commands that must always pass through regardless of language (admin panel).
COMMAND_PREFIXES: tuple[str, ...] = ("/",)


class LangFilterMiddleware(BaseMiddleware):
    """Filter incoming messages by the user's language code.

    * Allows ``/commands`` and supported languages.
    * For unsupported languages: the command still passes (admin panel is
      language-agnostic), but plain text is blocked.
    """

    async def __call__(
        self,
        handler,
        event: TelegramObject,
        data: dict,
    ):
        if not isinstance(event, Message):
            return await handler(event, data)

        user = event.from_user
        language_code = user.language_code if user else None

        if language_code in ALLOWED_LANGUAGES:
            return await handler(event, data)

        # Always let bot commands through (/start, /cancel, ...) — the admin
        # panel must respond even when the user's Telegram UI language is not
        # Ukrainian/Russian/English.
        text = event.text or ""
        if text.lstrip().startswith(COMMAND_PREFIXES):
            return await handler(event, data)

        if user is not None:
            logger.info(
                "Filtered message from user %s (lang=%s): not in %s",
                user.id,
                language_code,
                ALLOWED_LANGUAGES,
            )
        raise CancelHandler()
