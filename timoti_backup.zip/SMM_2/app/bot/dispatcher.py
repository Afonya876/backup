"""
Dispatcher factory.

Creates the aiogram 3.x :class:`Dispatcher`, wires FSM storage, middlewares,
and handlers. A ``settings`` dict is passed in (not imported from
``app.config``) to avoid circular imports at module load time.
"""

from __future__ import annotations

import logging

from aiogram import Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

logger = logging.getLogger(__name__)


def create_dispatcher() -> Dispatcher:
    """Create a :class:`Dispatcher` with :class:`MemoryStorage` for FSM."""
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    _register_error_handler(dp)
    return dp


def _register_error_handler(dp: Dispatcher) -> None:
    """Log unhandled handler exceptions so they don't vanish silently."""
    from aiogram.types import ErrorEvent

    @dp.errors()
    async def on_unhandled_error(event: ErrorEvent) -> None:
        logger.exception("Unhandled error in handler: %s", event.exception)


def setup_middlewares(dp: Dispatcher, settings: dict) -> None:
    """
    Register global middlewares.

    Parameters
    ----------
    dp:
        The aiogram dispatcher.
    settings:
        A dict with optional keys:
        * ``rate_limit_messages_per_second`` (int, default 25)
    """
    from app.bot.middleware.rate_limiter import RateLimiterMiddleware

    rate = int(settings.get("rate_limit_messages_per_second", 25))

    # NOTE: the language filter (LangFilterMiddleware) is intentionally NOT
    # registered on the controller bot. The controller bot is an admin panel:
    # an admin may have any Telegram UI language (uk/ru/en/de/...), and
    # blocking plain text by language made every reply-keyboard button
    # silently dead for those admins — "bot молчит" while /start worked.
    # Language filtering for sub-bot /start responses is implemented in
    # ``app.bot.handlers.start_resp.simulate_start_response`` instead, which
    # is where it belongs (it filters *end users* of the sub-bots, not the
    # admin panel users).

    dp.message.middleware(RateLimiterMiddleware(rate=rate))
    dp.callback_query.middleware(RateLimiterMiddleware(rate=rate))


def setup_handlers(dp: Dispatcher) -> None:
    """Import and include all router modules.

    Order matters — first registered router wins when filters overlap:
    * ``start_resp`` has /start with args and must come BEFORE ``common``'s plain /start.
    * ``analytics`` has 📊 Аналитика text handler and must come BEFORE ``menu``'s handler.
    * ``projects`` and ``subbots`` have callback handlers that don't overlap with menu.
    """
    from app.bot.handlers.start_resp import router as start_resp_router
    from app.bot.handlers.analytics import router as analytics_router
    from app.bot.handlers.projects import router as projects_router
    from app.bot.handlers.subbots import router as subbots_router
    from app.bot.handlers.profile import router as profile_router
    from app.bot.handlers.instances import router as instances_router
    from app.bot.handlers.status_chat import router as status_chat_router
    from app.bot.handlers.common import router as common_router
    from app.bot.handlers.menu import router as menu_router

    # Overlapping handlers first.
    dp.include_router(start_resp_router)
    # Keep /start and /cancel ahead of FSM routers so every input flow can exit.
    dp.include_router(common_router)
    dp.include_router(analytics_router)

    # Section handlers (callback-based, no text overlap).
    dp.include_router(projects_router)
    dp.include_router(subbots_router)
    dp.include_router(profile_router)
    dp.include_router(instances_router)

    # Group-chat ping controls.
    dp.include_router(status_chat_router)

    # General catch-all handlers last.
    dp.include_router(menu_router)
