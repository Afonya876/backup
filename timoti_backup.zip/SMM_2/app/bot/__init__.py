"""
``app.bot`` package.

Exposes the list of aiogram ``Router`` objects used by the dispatcher, and a
``register_all(dp)`` helper that wires them up alongside middlewares.

The ``main.py`` entry point currently does this wiring itself; this module
is a convenient alternative entry point for tests or alternative launchers.
"""

from __future__ import annotations

from aiogram import Dispatcher

from app.bot.dispatcher import setup_handlers, setup_middlewares

# List of routers – imported lazily to avoid circular imports at package load.
routers: list = []


def _collect_routers() -> list:
    """Import and return all handler routers."""
    from app.bot.handlers.common import router as common_router
    from app.bot.handlers.menu import router as menu_router

    return [common_router, menu_router]


def register_all(dp: Dispatcher, settings: dict | None = None) -> None:
    """
    Register middlewares and all handler routers on *dp*.

    Parameters
    ----------
    dp:
        The aiogram dispatcher.
    settings:
        Optional settings dict forwarded to ``setup_middlewares``.
    """
    if settings is None:
        settings = {}
    setup_middlewares(dp, settings)
    setup_handlers(dp)
    routers.extend(_collect_routers())


__all__ = [
    "register_all",
    "routers",
    "setup_handlers",
    "setup_middlewares",
]
