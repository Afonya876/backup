import asyncio
import logging
import sys

from aiogram import Dispatcher

from app.bot.dispatcher import (
    create_dispatcher,
    setup_handlers,
    setup_middlewares,
)
from app.bot.instance_manager import init_instance_manager
from app.config import settings
from app.core.db import engine, init_db
from app.core.redis import close_redis, get_redis
from app.scheduler.jobs import (
    create_scheduler,
    start_scheduler,
    stop_scheduler,
)

logger = logging.getLogger("main")


def setup_logging() -> None:
    logging.basicConfig(
        level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        stream=sys.stdout,
    )


async def main() -> None:
    setup_logging()

    # Initialise DB + Redis before polling starts
    await init_db()
    get_redis()
    logger.info("DB and Redis initialised.")

    dp = create_dispatcher()

    # Build settings dict for middlewares/handlers
    settings_dict = {
        "TIMEZONE": settings.TIMEZONE,
        "ADMIN_IDS": settings.ADMIN_IDS,
        "PROVIDER_MODE": settings.PROVIDER_MODE,
        "TWIBOOST_API_KEY": settings.TWIBOOST_API_KEY,
        "SMMMAIN_API_KEY": settings.SMMMAIN_API_KEY,
        "SMMMAIN_API_URL": settings.SMMMAIN_API_URL,
        "RATE_LIMIT_MESSAGES_PER_SECOND": settings.RATE_LIMIT_MESSAGES_PER_SECOND,
    }

    setup_middlewares(dp, settings_dict)
    setup_handlers(dp)

    manager = init_instance_manager(dp)
    await manager.load_and_start()

    scheduler = create_scheduler(settings_dict, manager.primary_bot)
    start_scheduler(scheduler)

    logger.info("Starting polling...")
    try:
        await manager.wait()
    finally:
        stop_scheduler(scheduler)
        await manager.shutdown()
        await close_redis()
        await engine.dispose()
        logger.info("Shutdown complete.")


if __name__ == "__main__":
    asyncio.run(main())
