#!/usr/bin/env bash

set -euo pipefail

PROJECT_DIR="${1:-/root/centurypass6}"
SERVICE_NAME="${2:-centurypass6-bot}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}.service"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run this script as root." >&2
  exit 1
fi

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Project directory not found: $PROJECT_DIR" >&2
  exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "This installer currently supports Debian/Ubuntu servers with apt-get." >&2
  exit 1
fi

echo "==> Installing system packages"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip

echo "==> Preparing virtual environment"
cd "$PROJECT_DIR"
"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel
.venv/bin/pip install -r requirements.txt

mkdir -p data
if [[ ! -s data/bots.json ]]; then
  printf '[]\n' > data/bots.json
fi

echo "==> Writing systemd service: $SERVICE_PATH"
cat > "$SERVICE_PATH" <<SERVICEEOF
[Unit]
Description=centurypass6 bot service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$PROJECT_DIR/.venv/bin/python $PROJECT_DIR/bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICEEOF

echo "==> Reloading systemd and starting service"
systemctl daemon-reload
systemctl enable --now "$SERVICE_NAME"

echo "==> Service status"
systemctl --no-pager --full status "$SERVICE_NAME"

echo
echo "Done. Useful commands:"
echo "  systemctl status $SERVICE_NAME"
echo "  journalctl -u $SERVICE_NAME -f"
echo "  curl http://127.0.0.1:18749/health"
