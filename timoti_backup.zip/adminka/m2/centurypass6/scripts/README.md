# Деплой centurypass6 на сервер

## Первоначальная установка

1. Скопируйте папку `centurypass6` на сервер:
   ```bash
   scp -r centurypass6 root@your-server:/root/
   ```

2. Зайдите на сервер и запустите установку:
   ```bash
   ssh root@your-server
   cd /root/centurypass6
   bash scripts/install_server.sh
   ```

3. Создайте `.env` файл:
   ```bash
   cd /root/centurypass6
   nano .env
   ```
   
   Содержимое `.env`:
   ```
   API_HOST=127.0.0.1
   API_PORT=18749
   MASTER_API_KEY=centurypass6-secret-key-2026
   BOT_TOKEN=CENTURYPASS6_BOT_TOKEN_HERE
   ```

4. Обновите `data/bots.json` с реальным токеном бота

5. Запустите бота:
   ```bash
   systemctl restart centurypass6-bot
   systemctl status centurypass6-bot
   ```

## Обновление кода

Используйте скрипт `upload_to_server.sh`:

```bash
cd centurypass6
./scripts/upload_to_server.sh root@your-server
```

Затем перезапустите бота:
```bash
ssh root@your-server 'systemctl restart centurypass6-bot'
```

## Полезные команды

```bash
# Статус сервиса
systemctl status centurypass6-bot

# Логи в реальном времени
journalctl -u centurypass6-bot -f

# Перезапуск
systemctl restart centurypass6-bot

# Остановка
systemctl stop centurypass6-bot

# Проверка health endpoint
curl http://127.0.0.1:18749/health
```

## Интеграция с мультиадминкой

Добавьте в `multy_admin/central_admin/.env`:
```
CENTURYPASS6_API_BASE=http://your-server:18749
CENTURYPASS6_API_KEY=centurypass6-secret-key-2026
```

Затем добавьте в `multy_admin/central_admin/bot.py`:
```python
"centurypass6": FamilyService(
    "centurypass6",
    "CENTURYPASS6",
    ROOT_DIR.parent / "centurypass6" / ".env",
    "CENTURYPASS6_API_BASE",
    "CENTURYPASS6_API_KEY",
),
```

И в `multy_admin/central_admin/webapp.py`:
```python
"centurypass6": "CENTURYPASS6",
```

Затем перезапустите мультиадминку.
