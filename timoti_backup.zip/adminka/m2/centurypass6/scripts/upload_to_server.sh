#!/usr/bin/env bash

set -euo pipefail

SERVER="${1:-root@your-server}"
REMOTE_DIR="${2:-/root/centurypass6}"
LOCAL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> Syncing centurypass6 to $SERVER:$REMOTE_DIR"
echo "Local directory: $LOCAL_DIR"

rsync -avz --delete \
  --exclude='.venv' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='.env' \
  --exclude='data/*.json' \
  --exclude='СКРИНЫ ИНТЕРФЕЙСА' \
  "$LOCAL_DIR/" "$SERVER:$REMOTE_DIR/"

echo
echo "==> Sync complete"
echo
echo "To restart the bot on server, run:"
echo "  ssh $SERVER 'systemctl restart centurypass6-bot'"
echo
echo "To view logs:"
echo "  ssh $SERVER 'journalctl -u centurypass6-bot -f'"
