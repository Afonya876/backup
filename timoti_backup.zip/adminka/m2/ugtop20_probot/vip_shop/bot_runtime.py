from __future__ import annotations

from dataclasses import dataclass

import asyncio

import json
import logging
import random
import re
from decimal import Decimal, ROUND_CEILING
import qrcode
import io
import string
from html import escape
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
)
from aiogram.types import FSInputFile

from vip_shop.config import (
    Settings,
    get_settings,
    load_family_state,
    FamilyState,
    TemplateOverrides,
    build_visible_start_cities,
)
from vip_shop.crypto_rates import (
    convert_pln_to_crypto,
    convert_amount,
    get_usdt_uah_rate,
    get_ltc_usdt_rate,
    get_btc_usdt_rate,
    refresh_pln_rate,
    refresh_market_rates,
)
from vip_shop.captcha import generate_captcha_image, generate_captcha_text
from vip_shop.template import (
    format_payment_method_button_title,
    method_coin,
    resolve_payment_requisites,
)
from vip_shop.orders_store import (
    create_order,
    get_order,
    get_user_pending_order,
    cancel_order,
    mark_paid,
    extend_reservation,
    get_remaining_minutes,
    record_cancel,
    get_cancel_count_24h,
    is_banned,
    claim_expiring_orders,
    claim_expired_orders,
    expire_order,
    update_order,
)

logger = logging.getLogger(__name__)

router = Router()


class CaptchaState(StatesGroup):
    waiting = State()


_CAPTCHA_FILE: Path | None = None

_CAPTCHA_MAX_ATTEMPTS = 5


def _generate_math_captcha() -> dict:
    """Generate a simple math problem with 4 answer options (1 correct)."""
    op = random.choice(["+", "-", "×"])
    if op == "+":
        a = random.randint(1, 20)
        b = random.randint(1, 20)
        answer = a + b
        question = f"{a} + {b}"
    elif op == "-":
        a = random.randint(5, 30)
        b = random.randint(1, a - 1)
        answer = a - b
        question = f"{a} - {b}"
    else:
        a = random.randint(2, 12)
        b = random.randint(2, 12)
        answer = a * b
        question = f"{a} × {b}"

    # Generate 3 wrong answers close to the correct one
    wrong = set()
    while len(wrong) < 3:
        offset = random.choice([-3, -2, -1, 1, 2, 3])
        w = answer + offset
        if w != answer and w >= 0 and w not in wrong:
            wrong.add(w)

    options = [answer] + list(wrong)
    random.shuffle(options)

    return {
        "question": question,
        "answer": answer,
        "options": options,
        "captcha_id": random.randint(1000, 9999),
    }


def _get_captcha_path() -> Path:
    global _CAPTCHA_FILE
    if _CAPTCHA_FILE is None:
        settings = get_settings()
        _CAPTCHA_FILE = settings.data_path.with_name("evila_captcha.json")
    return _CAPTCHA_FILE


def _load_captcha_data() -> dict:
    path = _get_captcha_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_captcha_data(data: dict) -> None:
    path = _get_captcha_path()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _is_captcha_passed(user_id: int) -> bool:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return bool(user.get("passed"))


def _set_captcha_passed(user_id: int) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = True
    data[str(user_id)]["captcha_text"] = None
    _save_captcha_data(data)


def _set_captcha_challenge(user_id: int, text: str) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = False
    data[str(user_id)]["captcha_text"] = text
    _save_captcha_data(data)


def _get_captcha_attempts(user_id: int) -> int:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return int(user.get("attempts", 0))


def _increment_captcha_attempts(user_id: int) -> int:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    current = int(data[str(user_id)].get("attempts", 0))
    data[str(user_id)]["attempts"] = current + 1
    _save_captcha_data(data)
    return current + 1


def _reset_captcha_attempts(user_id: int) -> None:
    data = _load_captcha_data()
    if str(user_id) in data:
        data[str(user_id)]["attempts"] = 0
        _save_captcha_data(data)


def _get_captcha_text(user_id: int) -> str | None:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return user.get("captcha_text")

_template_cache: FamilyState | None = None


def _get_family_state() -> FamilyState:
    settings = get_settings()
    return load_family_state(settings.data_path)


def _get_template() -> TemplateOverrides:
    """Load template from bots.json (with simple caching)."""
    global _template_cache
    settings = get_settings()
    state = load_family_state(settings.data_path)
    return state.template


def _main_menu_markup() -> InlineKeyboardMarkup:
    cities = build_visible_start_cities(get_settings().cities)
    rows = []
    for index in range(0, len(cities), 2):
        pair = cities[index:index + 2]
        rows.append([
            InlineKeyboardButton(text=city.label, callback_data=f"city:{city.key}")
            for city in pair
        ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _main_menu_text(user_id: int = 0, bot_username: str = "Evila_devila_bot") -> str:
    return (
        "👋 Unknown, Вас вітає бот автопродаж магазину Underground!\n\n"
        "Перелік усіх команд - /help\n"
        "Ознайомтеся з правилами - /rules\n"
        "Потрібна допомога? - /ticket\n"
        "Цікавить робота? - /job\n\n"
        "➖➖➖➖➖➖➖\n"
        "🤖 Інфобот: @under2_godbot\n"
        "🌐 Інфосайт: under24.info\n"
        "👨‍💻 Оператор: @ug_helper\n"
        "🔊 Канал: /channel\n"
        "➖➖➖➖➖➖➖\n\n"
        "🏙 Оберіть потрібне місто:"
    )


async def edit_or_send(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    try:
        return await message.edit_text(text, reply_markup=markup)
    except TelegramBadRequest:
        pass
    if message.photo:
        try:
            await message.delete()
            return await message.answer(text, reply_markup=markup)
        except TelegramBadRequest:
            pass
    return await message.answer(text, reply_markup=markup)


async def send_new(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    return await message.answer(text, reply_markup=markup)


def _back_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
    ])


_HELP_TEXT = (
    "/register [логін] - реєстрація в системі\n"
    "/newpass [пароль] - змінити пароль\n"
    "/profile - інформація про профіль\n"
    "/pin - повідомляє ваш ПІН(ід)\n"
    "/balance - баланс вашого рахунку\n"
    "/addbalance [сума] - поповнити баланс\n"
    "/status або /last - останнє замовлення\n"
    "/send [повідомлення] - надіслати повідомлення до підтримки\n"
    "/ticket - інформація щодо створення тікету\n"
    "/review [відгук] - залишити відгук\n"
    "/reviews - усі останні відгуки\n"
    "/price - прайс\n"
    "/optprice - оптовий прайс\n"
    "/rules - правила магазину\n"
    "/channel - наш телеграм-канал\n"
    "/job - робота у нас\n"
    "/mybot [токен] - створити персонального Пробота\n\n"
    "⁉️ Деякі команди працюватимуть тільки тоді, коли вказаний [аргумент] – текстовий або числовий.\n\n"
    "Його потрібно писати після пробілу одразу за командою та без дужок! Наприклад:\n"
    "• /addbalance 666\n"
    "• /review Все сподобалось, дякую!\n"
    "• тощо.\n\n"
    "ℹ️ Якщо у вас виникли питання – зв'яжіться з саппортом через тікет на сайті або з оператором в телеграм.\n\n"
    "🆘 Якщо у вас проблема з замовленням, в т.ч з пошуком або оплатою – для вирішення необхідно створювати тікет за номером проблемного замовлення!\n\n\n"
    "🌤🌤🌤🌤🌤🌤🌤\n"
    "/start - повернутись на головну ↩"
)

_TICKET_TEXT = (
    "У разі виникнення проблем із замовленням (в т.ч. з пошуком скарбниці) "
    "необхідно написати оператору @ug_helper"
)

_JOB_TEXT = (
    "Приєднуйся до команди Underground Shop - місця, де стабільність і люди завжди на першому місці!\n\n"
    "⚡️ ШУКАЄМО КУР'ЄРІВ! ⚡️\n\n"
    "✅ Що ми пропонуємо?\n"
    "● Високу оплату: від 150 до 300грн/клад;\n"
    "● Стабільні виплати двічі на тиждень;\n"
    "● Повне навчання з нуля - усьому навчимо, навіть якщо немає досвіду;\n"
    "● Ментори з досвідом роботи понад 7 років - безцінний досвід і підтримка;\n"
    "● Бонуси, премії, знижка 50% на весь товар;\n"
    "● Жодних обмежень у заробітку - скільки працюєш, стільки й отримуєш;\n"
    "● Твоя безпека і якість роботи - наша відповідальність.\n\n"
    "✅ Для початку роботи необхідно внести заставний депозит у розмірі 1000 грн - "
    "ця сума є підтвердженням серйозності ваших намірів та готовності до співпраці.\n\n"
    "📩 З питань працевлаштування або уточнення деталей звертайтесь до оператора: @hrunder\n\n"
    "🌤🌤🌤🌤🌤🌤🌤\n"
    "/start - повернутись на головну ↩"
)

_RULES_PHOTO_URL = "http://underpix.top/PYSPlj7Aa2/O9Xzii2M.jpg"


@router.message(Command("help"))
async def on_help(message: Message) -> None:
    await message.answer(_HELP_TEXT)


@router.message(Command("ticket"))
async def on_ticket(message: Message) -> None:
    await message.answer(_TICKET_TEXT)


@router.message(Command("job"))
async def on_job(message: Message) -> None:
    await message.answer(_JOB_TEXT)


@router.message(Command("rules"))
async def on_rules_command(message: Message) -> None:
    try:
        await message.answer_photo(_RULES_PHOTO_URL)
    except TelegramBadRequest:
        await message.answer(f"🖼 {_RULES_PHOTO_URL}")


def _option_price_display(option_key: str) -> str:
    parts = option_key.split("_")
    if len(parts) == 2:
        return f"{parts[0].upper()} - {parts[1]} $"
    return option_key


_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _resolve_product_photo(product) -> FSInputFile | None:
    if not product.photo_path:
        return None
    photo_path = Path(product.photo_path)
    if not photo_path.is_absolute():
        photo_path = _PROJECT_ROOT / photo_path
    if photo_path.exists():
        return FSInputFile(str(photo_path))
    return None


async def _edit_to_photo_or_send(
    message: Message,
    text: str,
    markup: InlineKeyboardMarkup | None,
    photo: FSInputFile | None,
) -> Message:
    if photo is None:
        return await edit_or_send(message, text, markup)
    try:
        media = InputMediaPhoto(media=photo, caption=text)
        return await message.edit_media(media, reply_markup=markup)
    except TelegramBadRequest:
        pass
    try:
        await message.delete()
    except TelegramBadRequest:
        pass
    return await message.answer_photo(photo, caption=text, reply_markup=markup)


async def safe_answer(callback: CallbackQuery, text: str = "", show_alert: bool = False) -> None:
    try:
        await callback.answer(text, show_alert=show_alert)
    except TelegramBadRequest:
        pass


@router.message(CommandStart())
async def on_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    user_id = message.from_user.id if message.from_user else 0
    
    if not _is_captcha_passed(user_id):
        await _send_math_captcha(message, user_id, state)
        return
    
    bot_username = (await message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    await message.answer(text, reply_markup=_main_menu_markup())


async def _send_math_captcha(message: Message, user_id: int, state: FSMContext, chat_id: int | None = None) -> None:
    """Send a math captcha challenge with 4 answer buttons."""
    attempts = _get_captcha_attempts(user_id)
    if attempts >= _CAPTCHA_MAX_ATTEMPTS:
        if chat_id:
            await message.bot.send_message(chat_id, "❌ Ви вичерпали всі спроби. Доступ заблоковано.")
        else:
            await message.answer("❌ Ви вичерпали всі спроби. Доступ заблоковано.")
        return

    captcha = _generate_math_captcha()
    _set_captcha_challenge(user_id, str(captcha["answer"]))
    # Store full captcha data for callback verification
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["captcha_data"] = captcha
    _save_captcha_data(data)

    attempt_num = attempts + 1
    header_text = f"# {captcha['captcha_id']} Просмотр капчи {attempt_num} из {_CAPTCHA_MAX_ATTEMPTS}."
    question_text = f"Решите пример: {captcha['question']} = ?"

    rows = []
    for i in range(0, len(captcha["options"]), 2):
        pair = captcha["options"][i:i + 2]
        rows.append([
            InlineKeyboardButton(text=str(v), callback_data=f"CAPTCHA_answer:{v}")
            for v in pair
        ])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)

    if chat_id:
        await message.bot.send_message(chat_id, header_text)
        await message.bot.send_message(chat_id, question_text, reply_markup=markup)
    else:
        await message.answer(header_text)
        await message.answer(question_text, reply_markup=markup)
    await state.set_state(CaptchaState.waiting)


@router.callback_query(F.data.startswith("CAPTCHA_answer:"))
async def on_captcha_answer(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    user_id = callback.from_user.id if callback.from_user else 0
    user_answer = int(callback.data.split(":")[1])

    data = _load_captcha_data()
    user_data = data.get(str(user_id), {})
    captcha_data = user_data.get("captcha_data")

    if not captcha_data:
        await safe_answer(callback, "Капча не знайдена. Натисніть /start", show_alert=True)
        return

    correct_answer = captcha_data["answer"]

    if user_answer == correct_answer:
        _set_captcha_passed(user_id)
        _reset_captcha_attempts(user_id)
        await state.clear()
        bot_username = (await callback.message.bot.get_me()).username
        text = _main_menu_text(user_id, bot_username=bot_username)
        await callback.message.edit_text("✅ Капча пройдена!")
        await callback.message.answer(text, reply_markup=_main_menu_markup())
    else:
        attempts = _increment_captcha_attempts(user_id)
        if attempts >= _CAPTCHA_MAX_ATTEMPTS:
            await callback.message.edit_text("❌ Ви вичерпали всі спроби. Доступ заблоковано.")
            await state.clear()
            return
        # Delete old captcha messages and send new one
        chat_id = callback.message.chat.id
        try:
            await callback.message.delete()
        except TelegramBadRequest:
            pass
        await _send_math_captcha(callback.message, user_id, state, chat_id=chat_id)


@router.message(CaptchaState.waiting)
async def on_captcha_input(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id if message.from_user else 0
    # Ignore text input during captcha — user must click buttons
    await message.answer("👆 Натисніть на правильну відповідь кнопкою нижче.")


@router.callback_query(F.data == "MAIN_MENU_REQUEST_CALLBACK")
async def on_choose_city(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    rows = []
    cities = settings.cities
    for index in range(0, len(cities), 2):
        pair = cities[index:index + 2]
        rows.append([
            InlineKeyboardButton(text=city.label, callback_data=f"city:{city.key}")
            for city in pair
        ])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    await edit_or_send(callback.message, "Выбери город:", markup)


@router.callback_query(F.data.startswith("city:"))
async def on_city_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    city_key = callback.data.split(":", 1)[1]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, "Город не найден.", _back_markup())
        return
    # Show all options of all products directly as buttons
    rows = []
    for product in city.products:
        for option in product.options:
            rows.append([InlineKeyboardButton(
                text=f"{product.label} {option.label}",
                callback_data=f"option:{city_key}:{product.key}:{option.key}"
            )])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = f"Ви обрали місто <b>{escape(city.label)}</b>\n\n💊 Який товар вас цікавить?"
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("product:"))
async def on_product_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key = parts[1], parts[2]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, "Город не найден.", _back_markup())
        return
    product = next((p for p in city.products if p.key == product_key), None)
    if not product:
        await edit_or_send(callback.message, "Товар не найден.", _back_markup())
        return
    rows = []
    for option in product.options:
        rows.append([InlineKeyboardButton(text=option.label, callback_data=f"option:{city_key}:{product_key}:{option.key}")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = f"Отличный выбор!\nА теперь выбери вариант товара {product.label}:"
    photo = _resolve_product_photo(product)
    await _edit_to_photo_or_send(callback.message, text, markup, photo)


@router.callback_query(F.data.startswith("option:"))
async def on_option_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = None
    option = None
    if city:
        product = next((p for p in city.products if p.key == product_key), None)
    if product:
        option = next((o for o in product.options if o.key == option_key), None)
    option_districts = option.districts if option and option.districts else None
    product_districts = product.districts if product else None
    active_districts = option_districts or product_districts or city.districts
    # Randomly pick a subset of districts (2 to min(6, len)) for this product
    if len(active_districts) > 2:
        subset_size = random.randint(2, min(6, len(active_districts)))
        selected_districts = random.sample(active_districts, subset_size)
    else:
        selected_districts = list(active_districts)
    # Store the selected subset in state so district: handler uses the same list
    await state.update_data(active_districts=selected_districts)
    district_rows = []
    for i in range(0, len(selected_districts), 2):
        pair = selected_districts[i:i + 2]
        district_rows.append([
            InlineKeyboardButton(
                text=district, callback_data=f"district:{city_key}:{product_key}:{option_key}:{i + j}"
            )
            for j, district in enumerate(pair)
        ])
    markup = InlineKeyboardMarkup(inline_keyboard=district_rows)
    # Build "Ви обрали" text
    price_uah = 0
    if option and option.key:
        try:
            key_parts = option.key.split('_')
            if len(key_parts) >= 2:
                price_uah = int(key_parts[-1])
        except (ValueError, IndexError):
            pass
    description = (product.description or "").strip() if product else ""
    lines = [f"Ви обрали: {escape(product.label)} {escape(option.label)}"]
    if description:
        lines.append(f"Коротко про товар: {escape(description)}")
    lines.append(f"Ціна: {price_uah} грн.")
    lines.append("")
    lines.append("🏠 Який район бажаєте обрати?")
    text = "\n".join(lines)
    if callback.message.photo:
        try:
            await callback.message.delete()
            await callback.message.answer(text, reply_markup=markup)
            return
        except TelegramBadRequest:
            pass
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("district:"))
async def on_district_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    district_idx = int(parts[4])
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = None
    option = None
    if city:
        product = next((p for p in city.products if p.key == product_key), None)
    if product:
        option = next((o for o in product.options if o.key == option_key), None)
    # Use the randomly selected subset stored in state
    data = await state.get_data()
    active_districts = data.get("active_districts")
    if not active_districts:
        option_districts = option.districts if option and option.districts else None
        product_districts = product.districts if product else None
        active_districts = option_districts or product_districts or (city.districts if city else [])
    district = active_districts[district_idx] if 0 <= district_idx < len(active_districts) else "Неизвестно"
    # Extract numeric price from option key (e.g., "8g_1850" -> 1850) — price is in UAH
    price_uah = 0
    if option and option.key:
        try:
            key_parts = option.key.split('_')
            if len(key_parts) >= 2:
                price_uah = int(key_parts[-1])
        except (ValueError, IndexError):
            pass
    await state.update_data(
        selected_price=price_uah,
        order_city_key=city_key,
        order_product_key=product_key,
        order_option_key=option_key,
        order_district=district,
        order_product_label=product.label if product else "N/A",
        order_option_label=option.label if option else "N/A",
    )

    # Create the order reservation immediately (before method selection)
    data = await state.get_data()
    order_id = data.get("order_id")
    if order_id is None:
        order_id = random.randint(1000000, 9999999)
        await state.update_data(order_id=order_id)
    user_id = callback.from_user.id if callback.from_user else 0
    create_order(
        order_id=order_id, user_id=user_id, price_uah=price_uah,
        product_label=product.label if product else "N/A",
        option_label=option.label if option else "N/A",
        city_label=city.label if city else "", district=district,
        method_key="", method_label="",
        payable_amount="", requisites="",
        reservation_minutes=60,
    )

    # Delete districts message, send confirmation + payment selection as new messages
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass
    await callback.message.answer("Замовлення створенно! Адреса заброньована!")
    await _show_payment_selection(callback.message, state, price_uah)


@router.callback_query(F.data == "MAIN_MENU_LK_CALLBACK")
async def on_payin(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    # Save selected_price before clearing state
    data = await state.get_data()
    selected_price = data.get("selected_price", 85)
    await state.clear()
    # Restore selected_price after clearing
    await state.update_data(selected_price=selected_price)
    await _show_payment_selection(callback.message, state, selected_price)


async def _show_payment_selection(message: Message, state: FSMContext, price_uah: int) -> None:
    """Show payment method selection with calculated amounts for each method."""
    family_state = _get_family_state()
    methods = family_state.payment_methods

    usdt_uah_rate = get_usdt_uah_rate()
    ltc_usdt_rate = get_ltc_usdt_rate()
    btc_usdt_rate = get_btc_usdt_rate()

    rows: list[list[InlineKeyboardButton]] = []
    for index, method in enumerate(methods):
        method_title = format_payment_method_button_title(method)
        coin = method_coin(method)

        if coin is None:
            # Card / fiat method — apply commission
            commission_text = (method.commission_text or "").strip()
            payable = price_uah
            if commission_text:
                m = re.match(r"^\s*\+\s*(\d+(?:[.,]\d+)?)\s*%\s*$", commission_text)
                if m:
                    pct = Decimal(m.group(1).replace(",", "."))
                    payable = int((Decimal(price_uah) * (Decimal("1") + pct / Decimal("100"))).to_integral_value(rounding=ROUND_CEILING))
            button_text = f"{method_title}. К оплате: {payable}"
        elif coin == "USDT":
            if usdt_uah_rate and usdt_uah_rate > 0:
                amount = (Decimal(price_uah) / usdt_uah_rate).quantize(Decimal("0.01"), rounding=ROUND_CEILING)
                amount_str = _format_crypto_amount(amount)
            else:
                amount_str = "—"
            button_text = f"{method_title}. К оплате: {amount_str}"
        elif coin == "LTC":
            if usdt_uah_rate and usdt_uah_rate > 0 and ltc_usdt_rate and ltc_usdt_rate > 0:
                usdt_amount = Decimal(price_uah) / usdt_uah_rate
                amount = (usdt_amount / ltc_usdt_rate).quantize(Decimal("0.00001"), rounding=ROUND_CEILING)
                amount_str = _format_crypto_amount(amount)
            else:
                amount_str = "—"
            button_text = f"{method_title}. К оплате: {amount_str}"
        elif coin == "BTC":
            if usdt_uah_rate and usdt_uah_rate > 0 and btc_usdt_rate and btc_usdt_rate > 0:
                usdt_amount = Decimal(price_uah) / usdt_uah_rate
                amount = (usdt_amount / btc_usdt_rate).quantize(Decimal("0.00001"), rounding=ROUND_CEILING)
                amount_str = _format_crypto_amount(amount)
            else:
                amount_str = "—"
            button_text = f"{method_title}. К оплате: {amount_str}"
        else:
            button_text = method_title

        rows.append([InlineKeyboardButton(text=button_text, callback_data=f"PAYMENT_method:{index}")])

    data = await state.get_data()
    order_id = data.get("order_id")
    if order_id is None:
        order_id = random.randint(1000000, 9999999)
        await state.update_data(order_id=order_id)

    rows.append([InlineKeyboardButton(text="Скасувати замовлення", callback_data=f"PAYMENT_cancel_confirm:{order_id}")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)

    product_label = data.get("order_product_label", "N/A")
    option_label = data.get("order_option_label", "N/A")
    district = data.get("order_district", "N/A")
    city_key = data.get("order_city_key", "")
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    city_label = city.label if city else "Доставка поштою"

    text = (
        f"🛍 Ваше замовлення: №{order_id}\n"
        f"🏙 Місто: <b>{escape(city_label)}</b>\n"
        f"🏠 Район: <b>{escape(district)}</b>\n"
        f"💊 Товар: <b>{escape(product_label)} {escape(option_label)}</b>\n"
        f"💵 Ціна: <b>{price_uah} грн.</b>\n\n"
        f"Впевнені, що ваша праця коштує більше? <tg-spoiler>Ми теж - /job 😉</tg-spoiler>\n\n"
        f"💸 Оберіть зручний спосіб оплати:"
    )
    await message.answer(text, reply_markup=markup)


def _format_crypto_amount(amount: Decimal) -> str:
    """Format crypto amount: strip trailing zeros but keep meaningful precision."""
    s = format(amount, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s or "0"


@router.callback_query(F.data.startswith("PAYMENT_method:"))
async def on_payment_method_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    method_index = int(callback.data.split(":")[1])
    family_state = _get_family_state()
    methods = family_state.payment_methods
    if method_index < 0 or method_index >= len(methods):
        await edit_or_send(callback.message, "Метод не найден.", _back_markup())
        return
    method = methods[method_index]
    coin = method_coin(method)

    data = await state.get_data()
    price_uah = data.get("selected_price", 0)
    order_id = data.get("order_id", 0)
    product_label = data.get("order_product_label", "N/A")
    option_label = data.get("order_option_label", "N/A")
    district = data.get("order_district", "N/A")
    city_key = data.get("order_city_key", "")
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    city_label = city.label if city else "Доставка поштою"
    user_id = callback.from_user.id if callback.from_user else 0

    if coin is None:
        # Card payment
        commission_text = (method.commission_text or "").strip()
        payable = price_uah
        if commission_text:
            m = re.match(r"^\s*\+\s*(\d+(?:[.,]\d+)?)\s*%\s*$", commission_text)
            if m:
                pct = Decimal(m.group(1).replace(",", "."))
                payable = int((Decimal(price_uah) * (Decimal("1") + pct / Decimal("100"))).to_integral_value(rounding=ROUND_CEILING))

        requisites = resolve_payment_requisites(method) or "не указаны"
        # Format card number with spaces
        card_display = re.sub(r"(\d{4})", r"\1 ", requisites).strip()

        update_order(
            order_id,
            method_key=method.key, method_label=method.label,
            payable_amount=f"{payable} грн.", requisites=requisites,
        )

        text = _build_card_payment_text(order_id, city_label, district, product_label, option_label, price_uah, method.label, card_display, str(payable))
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="Переглянути статус", callback_data=f"PAYMENT_status:{order_id}"),
                InlineKeyboardButton(text="Скасувати замовлення", callback_data=f"PAYMENT_cancel_confirm:{order_id}"),
            ],
        ])
        try:
            await callback.message.delete()
        except TelegramBadRequest:
            pass
        await callback.message.answer(text, reply_markup=markup)
        return

    # Crypto payment
    usdt_uah_rate = get_usdt_uah_rate()
    ltc_usdt_rate = get_ltc_usdt_rate()
    btc_usdt_rate = get_btc_usdt_rate()

    if coin == "USDT":
        if usdt_uah_rate and usdt_uah_rate > 0:
            amount = (Decimal(price_uah) / usdt_uah_rate).quantize(Decimal("0.01"), rounding=ROUND_CEILING)
            amount_str = _format_crypto_amount(amount)
        else:
            amount_str = "—"
    elif coin == "LTC":
        if usdt_uah_rate and usdt_uah_rate > 0 and ltc_usdt_rate and ltc_usdt_rate > 0:
            usdt_amount = Decimal(price_uah) / usdt_uah_rate
            amount = (usdt_amount / ltc_usdt_rate).quantize(Decimal("0.00001"), rounding=ROUND_CEILING)
            amount_str = _format_crypto_amount(amount)
        else:
            amount_str = "—"
    elif coin == "BTC":
        if usdt_uah_rate and usdt_uah_rate > 0 and btc_usdt_rate and btc_usdt_rate > 0:
            usdt_amount = Decimal(price_uah) / usdt_uah_rate
            amount = (usdt_amount / btc_usdt_rate).quantize(Decimal("0.00001"), rounding=ROUND_CEILING)
            amount_str = _format_crypto_amount(amount)
        else:
            amount_str = "—"
    else:
        amount_str = "—"

    requisites = resolve_payment_requisites(method) or "не указаны"

    update_order(
        order_id,
        method_key=method.key, method_label=method.label,
        payable_amount=f"{amount_str} {coin}", requisites=requisites,
    )

    text = _build_crypto_payment_text(order_id, city_label, district, product_label, option_label, price_uah, method.label, coin, amount_str, requisites)
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Переглянути статус", callback_data=f"PAYMENT_status:{order_id}"),
            InlineKeyboardButton(text="Скасувати замовлення", callback_data=f"PAYMENT_cancel_confirm:{order_id}"),
        ],
    ])
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass
    await callback.message.answer(text, reply_markup=markup)


def _build_card_payment_text(
    order_id: int, city_label: str, district: str,
    product_label: str, option_label: str, price_uah: int,
    method_label: str, card_display: str, payable_str: str,
) -> str:
    return (
        f"🛍 Ваше замовлення: №{order_id}\n"
        f"🏙 Місто: <b>{escape(city_label)}</b>\n"
        f"🏠 Район: <b>{escape(district)}</b>\n"
        f"💊 Товар: <b>{escape(product_label)} {escape(option_label)}</b>\n"
        f"💵 Ціна: <b>{price_uah} грн.</b>\n\n"
        f"➖➖➖➖➖➖\n\n"
        f"Обрано спосіб оплати: <b>{escape(method_label)}</b>\n"
        f"⏰ На здійснення оплати: <b>30 хвилин</b>.\n\n"
        f"Сплатіть на картку <b>{escape(card_display)}</b> суму <b>{payable_str} грн.</b>\n\n"
        f"Після оплати, товар буде видано автоматично протягом 5-10 хвилин.\n"
        f"Щоб перевірити статус замовлення натисніть кнопку \"Переглянути статус\" або введіть команду /status\n"
        f"➖➖➖➖➖\n"
        f"❗ <b>Сплачувати потрібно точну суму одним платежем!</b> Обов'язково враховуйте комісію вашого банку, інакше оплата не буде підтверджена автоматично та може зарахуватися іншому.\n"
        f"❗ <b>Рекомендуємо робити переказ онлайн.</b> Оскільки термінали можуть затримати надходження коштів та створити проблеми з підтвердженням оплати.\n"
        f"❓ Якщо минуло понад 10 хвилин з моменту оплати, а статус замовлення не змінився, зверніться до служби підтримки чи оператора, або створіть тикет на сайті. Як створити тикет: /ticket"
    )


def _build_crypto_payment_text(
    order_id: int, city_label: str, district: str,
    product_label: str, option_label: str, price_uah: int,
    method_label: str, coin: str, amount_str: str, requisites: str,
) -> str:
    return (
        f"⏳ Оплата очікується\n"
        f"Якщо ви сплатили замовлення, і з моменту оплати минуло не більше 10 хвилин, не варто хвилюватися.\n\n"
        f"🛍 Ваше замовлення: №{order_id}\n"
        f"🏙 Місто: <b>{escape(city_label)}</b>\n"
        f"🏠 Район: <b>{escape(district)}</b>\n"
        f"💊 Товар: <b>{escape(product_label)} {escape(option_label)}</b>\n"
        f"💵 Ціна: <b>{price_uah} грн.</b>\n\n"
        f"Ви обрали спосіб оплати - <b>{escape(method_label)}</b>.\n"
        f"Для отримання товару, переведіть на гаманець <b><code>{escape(requisites)}</code></b> суму - <b>{amount_str} {coin}</b>. "
        f"Комісію за переказ необхідно вказувати високу (пріоритетну), щоб переказ встиг отримати одне підтвердження мережі до закінчення бронювання.\n"
        f"Після оплати натисніть кнопку \"Переглянути статус\" або введіть \"/status\".\n\n"
        f"(Не забудьте, що на здійснення оплати дається всього 60 хвилин. У випадку, якщо Ви не встигаєте здійснити переказ за вказаний час, натисніть кнопки \"Подивитися статус\" та \"Продовжити час бронювання\")"
    )


def _build_order_status_text(order: dict, remaining: int) -> str:
    """Build the status view text for an order."""
    order_id = order["order_id"]
    method_label = order.get("method_label", "")
    payable = order.get("payable_amount", "")
    requisites = order.get("requisites", "")
    coin = _method_coin_key(method_label)

    lines = [
        "⏳ Оплата очікується",
        "Якщо ви сплатили замовлення, і з моменту оплати минуло не більше 10 хвилин, не варто хвилюватися.",
        "",
        f"🛍 Ваше замовлення: №{order_id}",
        f"🏙 Місто: <b>{escape(order.get('city_label', ''))}</b>",
        f"🏠 Район: <b>{escape(order.get('district', ''))}</b>",
        f"💊 Товар: <b>{escape(order.get('product_label', ''))} {escape(order.get('option_label', ''))}</b>",
        f"💵 Ціна: <b>{order.get('price_uah', 0)} грн.</b>",
        "",
        f"Ви обрали спосіб оплати - <b>{escape(method_label)}</b>.",
    ]

    if coin is None:
        card_display = re.sub(r"(\d{4})", r"\1 ", requisites).strip()
        lines.append(f"Для отримання товару, сплатіть на картку <b>{escape(card_display)}</b> суму - <b>{escape(payable)}</b>.")
    else:
        lines.append(f"Для отримання товару, переведіть на гаманець <b><code>{escape(requisites)}</code></b> суму - <b>{escape(payable)}</b>. "
                     f"Комісію за переказ необхідно вказувати високу (пріоритетну), щоб переказ встиг отримати одне підтвердження мережі до закінчення бронювання.")

    lines.extend([
        "Після оплати натисніть кнопку \"Переглянути статус\" або введіть \"/status\".",
        "",
        f"(Не забудьте, що на здійснення оплати дається всього 60 хвилин. У випадку, якщо Ви не встигаєте здійснити переказ за вказаний час, натисніть кнопки \"Подивитися статус\" та \"Продовжити час бронювання\")"
        f"Час бронювання, що залишився: <b>{remaining} хвилин</b> ⏰",
    ])
    return "\n".join(lines)


def _order_status_markup(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Допомога", callback_data=f"PAYMENT_help:{order_id}")],
        [InlineKeyboardButton(text="Скасувати замовлення", callback_data=f"PAYMENT_cancel_confirm:{order_id}")],
        [InlineKeyboardButton(text="Продовжити час бронювання", callback_data=f"PAYMENT_extend:{order_id}")],
        [InlineKeyboardButton(text="Оновити стан", callback_data=f"PAYMENT_status:{order_id}")],
    ])


def _method_coin_key(method_label: str) -> str | None:
    """Determine coin from method label."""
    src = method_label.casefold()
    if "btc" in src or "bitcoin" in src:
        return "BTC"
    if "ltc" in src or "litecoin" in src:
        return "LTC"
    if "usdt" in src or "trc" in src:
        return "USDT"
    return None


@router.callback_query(F.data.startswith("PAYMENT_status:"))
async def on_payment_status(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    order_id = int(callback.data.split(":")[1])
    order = get_order(order_id)
    if not order:
        await edit_or_send(callback.message, "Замовлення не знайдено.", _back_markup())
        return
    remaining = get_remaining_minutes(order_id)
    text = _build_order_status_text(order, remaining)
    await edit_or_send(callback.message, text, _order_status_markup(order_id))


@router.callback_query(F.data.startswith("PAYMENT_help:"))
async def on_payment_help(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    order_id = int(callback.data.split(":")[1])
    text = (
        "Помощь по боту автопродаж\n"
        "Доступные команды:\n"
        "/status или /last - последний заказ.\n"
        "/pin - узнать свой пин.\n"
        "/bots - список ботов для покупок.\n"
        "/reviews - последние отзывы.\n"
        "/balance - проверить баланс.\n"
        "/addbalance - пополнить баланс.\n\n"
        "Отправить мнение о продукции магазина:\n"
        "/review Отличный товар, вес и место!\n"
        "Пишем команду /review и сразу после - текст отзыва о приобретенном товаре.\n"
        "Аналогичным образом можно отправить боту сообщение, используя форму send:\n"
        "/send Скажите, когда ждать расширения ассортимента?\n\n"
        "Для регистрации на сайте, выполните команду:\n"
        "/register username (вместо username напишите жилаемый логин), в результате которой бот пришлет пароль к учетной записи.\n"
        "/newpassword passnew или /newpass passnew позволит изменить свой пароль на сайте\n"
        "/profile просмотреть свой профайл\n"
        "Реферальная система для ботов 🤖 по команде /referal"
    )
    await callback.message.answer(text)


@router.callback_query(F.data.startswith("PAYMENT_extend:"))
async def on_payment_extend(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    order_id = int(callback.data.split(":")[1])
    order = get_order(order_id)
    if not order or order["status"] != "pending":
        await safe_answer(callback, "Замовлення не знайдено або вже неактивне.", show_alert=True)
        return
    extended = extend_reservation(order_id, extra_minutes=30)
    if extended:
        await safe_answer(callback, "Час бронювання продовжено на 30 хвилин!")
        remaining = get_remaining_minutes(order_id)
        text = _build_order_status_text(extended, remaining)
        await edit_or_send(callback.message, text, _order_status_markup(order_id))
    else:
        await safe_answer(callback, "Не вдалося продовжити бронювання.", show_alert=True)


@router.callback_query(F.data.startswith("PAYMENT_cancel_confirm:"))
async def on_payment_cancel_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    order_id = int(callback.data.split(":")[1])
    order = get_order(order_id)
    text = f"Заказ № {order_id} будет отменен. Ты уверен?!"
    # If order exists in store, "Сплатити" goes back to status view;
    # otherwise (still on payment selection screen) go back to main menu
    back_callback = f"PAYMENT_status:{order_id}" if order else "BACK_TO_MAIN_MENU_CALLBACK"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Сплатити", callback_data=back_callback),
            InlineKeyboardButton(text="Скасувати", callback_data=f"PAYMENT_cancel_do:{order_id}"),
        ],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_cancel_do:"))
async def on_payment_cancel_do(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    order_id = int(callback.data.split(":")[1])
    user_id = callback.from_user.id if callback.from_user else 0

    order = get_order(order_id)
    if order and order["status"] == "pending":
        cancel_order(order_id)
        cancel_count = record_cancel(user_id)
        text = (
            f"За останню добу Ви вже скасували {cancel_count} замовлень. "
            f"Якщо скасувати більше 7 замовлень протягом 24 годин, будут задіяні санкції у вигляді блокування назавжди."
        )
    else:
        text = "Замовлення скасовано."

    markup = InlineKeyboardMarkup(inline_keyboard=[
    ])
    await edit_or_send(callback.message, text, markup)
    await state.clear()


@router.callback_query(F.data == "PAYMENT_ltc")
async def on_payment_ltc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="LTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_ltc = convert_pln_to_crypto(amount_pln, "LTC")
    if amount_ltc is None:
        amount_ltc = Decimal("0.01")
    await state.update_data(amount_usd=amount_usd, amount_ltc=str(amount_ltc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: LTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_ltc} LTC</code>\n"
        f"☝️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только LTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👌 Подтвердить", callback_data="PAYMENT_confirm_ltc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_btc")
async def on_payment_btc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="BTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_btc = convert_pln_to_crypto(amount_pln, "BTC")
    if amount_btc is None:
        amount_btc = Decimal("0.001")
    await state.update_data(amount_usd=amount_usd, amount_btc=str(amount_btc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: BTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_btc} BTC</code>\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только BTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_btc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_usdt")
async def on_payment_usdt(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="USDT")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    # USDT is 1:1 with USD, so convert PLN to USDT
    amount_usdt = amount_pln * Decimal("0.2564")  # Approx PLN to USDT rate
    await state.update_data(amount_usd=amount_usd, amount_usdt=str(amount_usdt.quantize(Decimal("0.01"))))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: USDT TRC20\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount_usdt.quantize(Decimal('0.01'))} USDT\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только USDT (TRC20) на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_usdt")],
        [InlineKeyboardButton(text=" Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_confirm_"))
async def on_payment_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    request_id = data.get("request_id", 0)
    amount = data.get(f"amount_{coin.lower()}", "0.01")
    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh" if coin == "LTC" else "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    if coin.upper() == "USDT":
        wallet = "USDT_TRC20_WALLET_HERE"
    coin_marker = coin.lower()
    for pm in family_state.payment_methods:
        pm_key = pm.key.lower()
        # match by exact key OR by prefix (e.g. usdt_trc20 matches coin=USDT)
        if pm_key == coin_marker or pm_key.startswith(coin_marker + "_") or pm_key.startswith(coin_marker + "-"):
            if pm.requisites and "HERE" not in pm.requisites:
                wallet = pm.requisites
            break
    await state.update_data(wallet=wallet)
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: {coin}\n"
        f"На баланс: {data.get('amount_usd', 85)} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount} {coin}\n\n"
        f"Реквизиты для оплаты:\n"
        f"<code>{escape(wallet)}</code>\n"
        f"☝️ ☝️\n\n\n"
        f"Заявка подтверждена\n"
        f"Ожидайте генерации адреса {coin}. Время для оплаты - 60 минут.\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только {coin} на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"Для вас сгенерирован уникальный адрес для пополнения.\n"
        f"Отправьте {coin} на указанный адрес.\n\n"
        f"Вы можете отправить любую сумму — баланс будет пересчитан автоматически.\n"
        f"Рекомендуем отправить чуть больше указанной суммы, чтобы начисленного баланса точно хватило на покупку.\n\n"
        f"После 1 подтверждения в сети средства будут зачислены автоматически."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📱 LTC QRCODE 1", callback_data="PAYMENT_qr1")],
        [InlineKeyboardButton(text="📱 LTC QRCODE 2", callback_data="PAYMENT_qr2")],
        [InlineKeyboardButton(text="👍 Оплачено!", callback_data="PAYMENT_paid")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_message")
async def on_payment_message(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = "Вы можете написать оператору технической поддержки: @EvilSUPPORT_AU"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_paid")
async def on_payment_paid(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = "Ваша заявка принята на проверку. Ожидайте подтверждения от оператора.\n\nКонтакты оператора: @EvilSUPPORT_AU"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_cancel")
async def on_payment_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = "Замовлення скасовано."
    markup = InlineKeyboardMarkup(inline_keyboard=[
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_qr"))
async def on_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    wallet = data.get("wallet", "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh")
    
    # Generate QR code
    try:
        if coin == "LTC":
            qr_data = f"litecoin:{wallet}"
        elif coin == "BTC":
            qr_data = f"bitcoin:{wallet}"
        else:
            qr_data = wallet
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        bio = io.BytesIO()
        img.save(bio, format='PNG')
        bio.seek(0)
        qr_photo = BufferedInputFile(bio.read(), filename="qr_code.png")
        
        await callback.message.answer_photo(qr_photo, caption=f"QR код для {coin}:\n<code>{escape(wallet)}</code>")
    except Exception as e:
        logger.warning(f"Could not generate QR: {e}")
        await callback.message.answer(f"Не удалось сгенерировать QR код. Адрес: <code>{escape(wallet)}</code>")


@router.callback_query(F.data == "MAIN_MENU_BONUS_CALLBACK")
async def on_bonus(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = (
        "Условия получения бонусов:\n    \n"
        "Мы готовы делиться с тобой прибылью с каждой продажи! "
        "Просто разошли эту ссылку своим друзьям и с каждой их покупки "
        "ты будешь получать до 5%!\n\n"
        f"👉 https://t.me/{bot_username}?start={user_id} 👈\n\n"
        "Считай сам - твои друзья совершат пару покупок, а для тебя будет уже "
        "хорошая скидка! А ведь ты можешь рассылать ссылку в любые чаты, "
        "где люди будут готовы совершить покупки! И тогда счет пойдет уже на десятки ;)"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_RULES_CALLBACK")
async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Всех приветствуем в разделе где можно узнать правила подачи заявления о ненаходе\n\n"
        "Сразу приступим к тому как делать не нужно: \n\n"
        "-Не нужно спамить, умолять оператора выдать пз, угрожать и тд\n"
        "-Не нужно писать со всех возможных аккаунтов, это расценивается как попытка обмана\n\n"
        "Как правильно сообщить о ненаходе: \n\n"
        "-При подходе к месту снимаем видео (разрывать яму не нужно)\n"
        "-Ищем клад в глубине 3-4см и в радиусе 5см от точки\n"
        "-Если клада нет - делаем два фото с ракурса как у курьера\n\n"
        "Предоставление данных оператору в случае ненахода:\n\n"
        "-Ссылка на клад\n"
        "-Фото с места и видео ДО НАЧАЛА ПОИСКОВ\n"
        "-Ваш ник в боте  или номер заказа (его можно посмотреть в профиле или выполнив команду /start\n\n"
        "⚠️⚠️ ЕСЛИ АДРЕС НЕ СООТВЕТСТВУЕТ ФОТО/КОРДИНАТАМ ⚠️⚠️\n\n"
        " предоставьте, пожалуйста, 4 фотографии местности с отметкой координат. "
        "Координаты на Ваших фото должны совпадать с координатами в заказе, "
        "желательно в таком же ракурсе как у курьера. "
        "Для того чтобы получить фотографии с отметкой GPS координат, "
        "можете использовать Notecam если у Вас Android, или Solocator если используете iOS. "
        "Ожидаю фотографии в пределах регламентного времени\n\n"
        "☝️☝️ВАЖНО ЗНАТЬ! РАССМОТРЕНИЕ И УТОЧНЕНИЕ ВАШЕЙ ЗАЯВКИ ДОПУСТИМО В ТЕЧЕНИИ 3 ЧАСОВ С МОМЕНТА ПОКУПКИ!\n\n"
        "‼️ВНИМАНИЕ‼️\n"
        "❌ПОЧЕМУ ВАМ МОЖЕТ БЫТЬ ОТКАЗАНО В РАССМОТРЕНИИ?❌\n\n"
        "1. Мы оставляем за собой право на отказ в обслуживании, УТОЧНЕНИЯХ или решении той или иной проблемы без каких-либо разъяснений.\n\n"
        "2. Претензии по ненаходам, недовесам и другим проблемам в заказах принимаются в течение 3-х  часов с момента покупки  и решаются только через ЛС!\n\n"
        "3. Передача информации о кладе третьим лицам запрещена - это лишает Вас права на помощь в поисках  в случае ненахода!\n\n"
        "4. Шантаж плохими отзывами, хамство, оскорбления сотрудников магазина и не пристойное поведение - АВТОМАТИЧЕСКИ лишает Вас права на получение помощи в поисках  в случае ненахода!\n"
        "Нет видео поисков - нет перезаклада! Замены на перезаклад нет!"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_NEWLIST_CALLBACK")
async def on_showcase(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    lines: list[str] = []
    counter = 1
    for city in settings.cities:
        if not city.products:
            continue
        lines.append(f'Доступные товары "{city.label}"')
        for product in city.products:
            for option in product.options:
                lines.append(f"📁 {product.label}")
                price_display = _option_price_display(option.key)
                lines.append(f"{counter}) {product.label} {price_display}")
                option_districts = option.districts or product.districts or city.districts
                for district in option_districts:
                    lines.append(f"{district} ✅ КУПИТЬ")
                lines.append("")
                counter += 1
    text = "\n".join(lines) if lines else "Товары временно отсутствуют."
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_INFO_CALLBACK")
async def on_info(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "📌 Информация\n\n"
        "🛒 Как сделать покупку:\n"
        "1. Пополните баланс через раздел «🖥️ Пополнить счет»\n"
        "2. Выберите город в разделе «🗺 Выбрать город»\n"
        "3. Выберите товар и район\n"
        "4. Нажмите «Купить» — сумма спишется с баланса\n"
        "5. После покупки вы получите инструкцию с координатами и фото\n\n"
        "⏳ Время ожидания:\n"
        "После оплаты товар выдаётся мгновенно. Если возникли проблемы — напишите оператору.\n\n"
        "🔒 Гарантии:\n"
        "Мы гарантируем выдачу товара или возврат средств. Все спорные ситуации решаются в течение 3 часов с момента покупки.\n\n"
        "⚠️ Правила безопасности:\n"
        "- Не сообщайте свой пароль или код от сайта третьим лицам\n"
        "- При получении товара убедитесь, что вы находитесь в безопасном месте\n"
        "- Не передавайте информацию о покупке другим лицам\n\n"
        "💬 По всем вопросам обращайтесь в раздел «🧾 Поддержка»"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_REVIEWS_CALLBACK")
async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Рейтинг магазина: ⭐ 3,9/5 (64 шт.)\n\n"
        "Ваши отзывы делают наш магазин лучше!\n\n"
        "⭐ | MEFEDRON 2G (Evil Georgia)\n"
        "📍 ТБИЛИСИ\n"
        "ძველი ადრესია ეს ყლეობა\n"
        "от 27.06.2026 02:59\n\n\n"
        "Отзывы можно оставлять только к совершенным покупкам."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="<--", callback_data="REVIEW_PREV"),
            InlineKeyboardButton(text="-->", callback_data="REVIEW_NEXT"),
        ],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.in_({"REVIEW_PREV", "REVIEW_NEXT"}))
async def on_review_page(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback, "Нет других отзывов", show_alert=True)


@router.callback_query(F.data == "CREATE_PRIVATE_BOT_CALLBACK")
async def on_private_bot(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Вы не можете создавать личных ботов, пока не совершите необходимое кол-во покупок.\n\n"
        "Всего покупок: 0\n"
        "Необходимо покупок для создания бота: 1"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_WEB_AUTH_CODE")
async def on_web_auth(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    site_code = f"fission-{random.randint(10000, 99999)}-viper"
    text = (
        f"🔑 Ваш код для входа на сайт:\n\n"
        f"{site_code}\n\n"
        f"Нажмите на скрытый текст, чтобы увидеть код.\n\n"
        f"Этот код вы можете использовать для авторизации на сайте или в мобильном приложении.\n\n"
        f"⚠️ Никому никогда не сообщайте этот код — используя его можно получить доступ "
        f"к вашему аккаунту, истории покупок и балансу."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "BUY_NOW_CALLBACK")
async def on_buy_now(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    user_id = callback.from_user.id if callback.from_user else 0

    # Check if user is banned (7+ cancels in 24h)
    if is_banned(user_id):
        text = "❌ Ви заблоковані назавжди через надмірну кількість скасувань замовлень."
        markup = InlineKeyboardMarkup(inline_keyboard=[
        ])
        await edit_or_send(callback.message, text, markup)
        return

    # Check for existing unpaid order
    pending_order = get_user_pending_order(user_id)
    if pending_order:
        pending_id = pending_order["order_id"]
        text = (
            f"У Вас вже є неоплачене замовлення <b>№{pending_id}</b>\n"
            f"Перш ніж робити нове замовлення, сплатіть поточне або скасуйте його"
        )
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="Сплатити", callback_data=f"PAYMENT_status:{pending_id}"),
                InlineKeyboardButton(text="Скасувати", callback_data=f"PAYMENT_cancel_confirm:{pending_id}"),
            ],
            [InlineKeyboardButton(text="Перевірити статус", callback_data=f"PAYMENT_status:{pending_id}")],
        ])
        await edit_or_send(callback.message, text, markup)
        return

    # Save selected_price before clearing state
    data = await state.get_data()
    selected_price = data.get("selected_price", 85)
    await state.clear()
    # Restore selected_price and order info after clearing
    await state.update_data(
        selected_price=selected_price,
        order_city_key=data.get("order_city_key", ""),
        order_product_key=data.get("order_product_key", ""),
        order_option_key=data.get("order_option_key", ""),
        order_district=data.get("order_district", ""),
        order_product_label=data.get("order_product_label", "N/A"),
        order_option_label=data.get("order_option_label", "N/A"),
    )
    await _show_payment_selection(callback.message, state, selected_price)


@router.callback_query(F.data == "BACK_TO_MAIN_MENU_CALLBACK")
async def on_back_to_main(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    try:
        await callback.message.edit_text(text, reply_markup=_main_menu_markup())
    except TelegramBadRequest:
        await callback.message.answer(text, reply_markup=_main_menu_markup())


def _clone_router(src: Router) -> Router:
    """Create a fresh Router that mirrors src's handlers/middleware without sharing state."""
    dst = Router(name=f"evila_{id(src)}")
    for event_name, observer in src.observers.items():
        dst_observer = dst.observers[event_name]
        for handler in observer.handlers:
            dst_observer.handlers.append(handler)
        for mw in observer.middleware:
            dst_observer.middleware(mw)
        for mw in observer.outer_middleware:
            dst_observer.outer_middleware(mw)
    for sub in src.sub_routers:
        dst.include_router(_clone_router(sub))
    return dst


def create_bot_runtime(settings: Settings) -> Router:
    return _clone_router(router)


def build_bot(token: str, settings: Settings, proxy_url: str | None = None) -> tuple[Bot, Dispatcher]:
    if proxy_url:
        session = AiohttpSession(proxy=proxy_url)
        bot = Bot(token=token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    else:
        bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    dp.include_router(_clone_router(router))
    return bot, dp


@dataclass(slots=True)
class BotRuntime:
    spec: "BotSpec"
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task
    reminder_task: asyncio.Task | None = None


async def start_runtime(
    settings: Settings,
    spec: "BotSpec",
    persist_spec=None,
    register_bot=None,
    list_bots=None,
    remove_bot_by_id=None,
    toggle_bot_pause_by_id=None,
    sync_payment_methods_for_all=None,
    sync_start_text_for_all=None,
    sync_admin_ids_for_all=None,
    sync_template_for_all=None,
    proxy_url: str | None = None,
) -> BotRuntime:
    # Refresh rates without blocking the event loop (sync urlopen inside).
    try:
        await asyncio.to_thread(refresh_market_rates)
    except Exception:
        pass
    try:
        await asyncio.to_thread(refresh_pln_rate)
    except Exception:
        pass
    bot, dp = build_bot(spec.token, settings, proxy_url=proxy_url)
    try:
        await bot.delete_webhook(drop_pending_updates=False)
    except Exception:
        pass
    task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
    reminder_task = asyncio.create_task(_reservation_reminder_loop(bot))
    if proxy_url:
        logger.info("Started bot @%s via proxy %s", spec.bot_username, proxy_url.split("@")[-1])
    else:
        logger.info("Started bot @%s", spec.bot_username)
    return BotRuntime(spec=spec, dispatcher=dp, bot=bot, task=task, reminder_task=reminder_task)


async def stop_runtime(runtime: BotRuntime) -> None:
    runtime.task.cancel()
    if runtime.reminder_task:
        runtime.reminder_task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    if runtime.reminder_task:
        try:
            await runtime.reminder_task
        except asyncio.CancelledError:
            pass
    try:
        await runtime.bot.session.close()
    except Exception:
        pass
    await asyncio.sleep(1)


async def _reservation_reminder_loop(bot: Bot) -> None:
    """Background task: remind users about expiring orders."""
    while True:
        await asyncio.sleep(30)
        try:
            # Send one plain-text reminder for orders about to expire
            expiring = claim_expiring_orders()
            for order in expiring:
                user_id = order["user_id"]
                order_id = order["order_id"]
                text = f"Время бронирования заказа №{order_id} скоро истечет, пожалуйста, оплатите в срок или продлите время бронирования!"
                try:
                    await bot.send_message(user_id, text)
                except Exception:
                    pass

            # Silently expire orders that passed deadline (no message)
            claim_expired_orders()
        except Exception:
            pass
