from __future__ import annotations

import json
import time
from pathlib import Path

_ORDERS_PATH: Path | None = None


def _get_orders_path() -> Path:
    global _ORDERS_PATH
    if _ORDERS_PATH is None:
        from vip_shop.config import get_settings
        settings = get_settings()
        _ORDERS_PATH = settings.data_path.with_name("orders.json")
    return _ORDERS_PATH


def _load_orders() -> dict:
    path = _get_orders_path()
    if not path.exists():
        return {"orders": {}, "cancel_log": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"orders": {}, "cancel_log": {}}


def _save_orders(data: dict) -> None:
    path = _get_orders_path()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def create_order(
    order_id: int,
    user_id: int,
    price_uah: int,
    product_label: str,
    option_label: str,
    city_label: str,
    district: str,
    method_key: str,
    method_label: str,
    payable_amount: str,
    requisites: str,
    reservation_minutes: int = 30,
) -> dict:
    data = _load_orders()
    now = time.time()
    order = {
        "order_id": order_id,
        "user_id": user_id,
        "status": "pending",
        "price_uah": price_uah,
        "product_label": product_label,
        "option_label": option_label,
        "city_label": city_label,
        "district": district,
        "method_key": method_key,
        "method_label": method_label,
        "payable_amount": payable_amount,
        "requisites": requisites,
        "created_at": now,
        "deadline_at": now + reservation_minutes * 60,
        "reservation_minutes": reservation_minutes,
    }
    data["orders"][str(order_id)] = order
    _save_orders(data)
    return order


def get_order(order_id: int) -> dict | None:
    data = _load_orders()
    return data["orders"].get(str(order_id))


def get_user_pending_order(user_id: int) -> dict | None:
    data = _load_orders()
    now = time.time()
    for order in data["orders"].values():
        if order["user_id"] == user_id and order["status"] == "pending":
            if now < order["deadline_at"]:
                return order
    return None


def cancel_order(order_id: int) -> None:
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order:
        order["status"] = "cancelled"
        _save_orders(data)


def mark_paid(order_id: int) -> None:
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order:
        order["status"] = "paid"
        _save_orders(data)


def update_order(order_id: int, **kwargs) -> None:
    """Update fields of an existing order."""
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order:
        order.update(kwargs)
        _save_orders(data)


def extend_reservation(order_id: int, extra_minutes: int = 30) -> dict | None:
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order and order["status"] == "pending":
        order["deadline_at"] = time.time() + extra_minutes * 60
        order["reservation_minutes"] = extra_minutes
        _save_orders(data)
    return order


def get_remaining_minutes(order_id: int) -> int:
    order = get_order(order_id)
    if not order or order["status"] != "pending":
        return 0
    remaining = int((order["deadline_at"] - time.time()) / 60)
    return max(0, remaining)


def record_cancel(user_id: int) -> int:
    """Record a cancel event and return count of cancels in last 24h."""
    data = _load_orders()
    now = time.time()
    user_key = str(user_id)
    if user_key not in data["cancel_log"]:
        data["cancel_log"][user_key] = []
    data["cancel_log"][user_key].append(now)
    # Keep only last 24h
    cutoff = now - 24 * 3600
    data["cancel_log"][user_key] = [t for t in data["cancel_log"][user_key] if t > cutoff]
    _save_orders(data)
    return len(data["cancel_log"][user_key])


def get_cancel_count_24h(user_id: int) -> int:
    data = _load_orders()
    now = time.time()
    cutoff = now - 24 * 3600
    user_key = str(user_id)
    timestamps = data["cancel_log"].get(user_key, [])
    return len([t for t in timestamps if t > cutoff])


def is_banned(user_id: int) -> bool:
    return get_cancel_count_24h(user_id) >= 7


REMINDER_THRESHOLD_MINUTES = 5  # remind when 5 minutes left


def claim_expiring_orders() -> list[dict]:
    """Atomically claim pending orders about to expire (marks them reminded)."""
    data = _load_orders()
    now = time.time()
    threshold = REMINDER_THRESHOLD_MINUTES * 60
    result = []
    changed = False
    for order in data["orders"].values():
        if order["status"] != "pending":
            continue
        if order.get("reminded"):
            continue
        remaining = order["deadline_at"] - now
        if 0 < remaining <= threshold:
            order["reminded"] = True
            changed = True
            result.append(dict(order))
    if changed:
        _save_orders(data)
    return result


def mark_reminded(order_id: int) -> None:
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order:
        order["reminded"] = True
        _save_orders(data)


def claim_expired_orders() -> list[dict]:
    """Atomically claim expired pending orders (marks them expired)."""
    data = _load_orders()
    now = time.time()
    result = []
    changed = False
    for order in data["orders"].values():
        if order["status"] != "pending":
            continue
        if now >= order["deadline_at"]:
            order["status"] = "expired"
            changed = True
            result.append(dict(order))
    if changed:
        _save_orders(data)
    return result


def expire_order(order_id: int) -> None:
    data = _load_orders()
    order = data["orders"].get(str(order_id))
    if order:
        order["status"] = "expired"
        _save_orders(data)
