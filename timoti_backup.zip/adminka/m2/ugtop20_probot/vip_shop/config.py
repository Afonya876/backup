from __future__ import annotations

import json
import os
import re
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field, HttpUrl, ValidationError, model_validator


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_PATH = PROJECT_ROOT / "data" / "bots.json"
DEFAULT_CATALOG_PATH = PROJECT_ROOT / "data" / "catalog.json"
DEFAULT_PRODUCT_PHOTO_RULES_PATH = PROJECT_ROOT / "data" / "product_photo_rules.json"
DOTENV_PATH = PROJECT_ROOT / ".env"
DEFAULT_PRODUCT_PHOTO = PROJECT_ROOT / "СКРИНЫ ИНТЕРФЕЙСА" / "start.png"
DEFAULT_RANDOM_PRODUCT_PHOTO_DIR = PROJECT_ROOT / "RandomFoto"
DEFAULT_START_TEXT_PATH = PROJECT_ROOT / "СКРИНЫ ИНТЕРФЕЙСА" / "start.txt"
DEFAULT_GENERIC_DISTRICTS = [
    "Заполните районы",
]

# Underground start-menu buttons (all entries are handled as city-like selections).
DEFAULT_SCREENSHOT_CITY_ORDER: list[str] = [
    "ОПТ",
    "Доставка на адресу",
    "Доставка поштою",
    "Миколаїв",
    "Одеса",
    "Дніпро",
    "Львів",
    "Запоріжжя",
    "Житомир",
    "Вінниця",
    "Івано-Франківськ",
    "Коростень",
    "Самар",
    "Первомайськ",
    "Вознесенськ",
    "Південноукраїнськ",
    "Нова Одеса",
    "Розпродаж -50%",
    "РОБОТА 1000$ В ТИЖДЕНЬ",
]


def get_city_districts(city_label: str, fallback: list[str] | None = None) -> list[str]:
    if fallback is not None:
        return list(fallback)
    return list(DEFAULT_GENERIC_DISTRICTS)


def load_default_start_text() -> str:
    try:
        text = DEFAULT_START_TEXT_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        text = ""
    if text:
        return text
    return "Добро пожаловать.\n\nВыберите свой город из списка ниже."


DEFAULT_START_TEXT = load_default_start_text()

PAYMENT_REQUISITES_PLACEHOLDER = "{requisites}"
LEGACY_LTC_REQUISITES_PLACEHOLDER = "LTC_WALLET_HERE"
LEGACY_BTC_REQUISITES_PLACEHOLDER = "BTC_WALLET_HERE"
_LTC_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>(?:ltc1[ac-hj-np-z02-9]{{10,}}|[LM3][a-km-zA-HJ-NP-Z1-9]{{26,33}}|{re.escape(LEGACY_LTC_REQUISITES_PLACEHOLDER)}))(?=\s|$)",
    re.IGNORECASE,
)
_BTC_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>(?:bc1[a-z0-9]{{6,87}}|[13][a-km-zA-HJ-NP-Z1-9]{{25,34}}|{re.escape(LEGACY_BTC_REQUISITES_PLACEHOLDER)}))(?=\s|$)",
    re.IGNORECASE,
)
_LEGACY_REQUISITES_HINT_PATTERN = re.compile(
    rf"^\s*Замените\s+(?:{re.escape(LEGACY_LTC_REQUISITES_PLACEHOLDER)}|"
    rf"{re.escape(LEGACY_BTC_REQUISITES_PLACEHOLDER)})\b.*$",
    re.IGNORECASE,
)


def _normalize_requisites_value(raw_value: object | None) -> str | None:
    if raw_value is None:
        return None
    value = str(raw_value).strip()
    if not value:
        return None
    uppercase_value = value.upper()
    if uppercase_value == LEGACY_LTC_REQUISITES_PLACEHOLDER:
        return LEGACY_LTC_REQUISITES_PLACEHOLDER
    if uppercase_value == LEGACY_BTC_REQUISITES_PLACEHOLDER:
        return LEGACY_BTC_REQUISITES_PLACEHOLDER
    return value


def extract_payment_requisites(details_text: str) -> str | None:
    for pattern in (_LTC_REQUISITES_PATTERN, _BTC_REQUISITES_PATTERN):
        wallet_match = pattern.search(details_text)
        if wallet_match is not None:
            return _normalize_requisites_value(wallet_match.group("wallet"))
    return None


def normalize_payment_details_template(details_text: str, requisites: str | None = None) -> str:
    del requisites
    text = (details_text or "").strip()
    if not text:
        return ""

    cleaned_lines: list[str] = []
    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if _LEGACY_REQUISITES_HINT_PATTERN.fullmatch(stripped):
            continue

        normalized_line = raw_line.rstrip()
        if PAYMENT_REQUISITES_PLACEHOLDER not in normalized_line:
            for pattern in (_LTC_REQUISITES_PATTERN, _BTC_REQUISITES_PATTERN):
                normalized_line, replacements = pattern.subn(PAYMENT_REQUISITES_PLACEHOLDER, normalized_line, count=1)
                if replacements:
                    break
        cleaned_lines.append(normalized_line)

    while cleaned_lines and not cleaned_lines[-1].strip():
        cleaned_lines.pop()
    return "\n".join(cleaned_lines).strip()


class ProductOption(BaseModel):
    key: str
    label: str
    districts: list[str] | None = None


class ProductConfig(BaseModel):
    key: str
    label: str
    options: list[ProductOption]
    button_label: str | None = None
    description: str | None = None
    photo_id: str | None = None
    photo_url: str | None = None
    photo_path: str | None = None
    districts: list[str] | None = None  # Per-product districts; if None, uses city districts


class CityConfig(BaseModel):
    key: str
    label: str
    icon: str
    districts: list[str]
    district_selection_percent: int = Field(default=100, ge=1, le=100)
    products: list[ProductConfig]
    photo_path: str | None = None


class PaymentMethodConfig(BaseModel):
    key: str
    label: str
    commission_text: str | None = None
    requisites: str | None = None
    details_text: str
    qr_enabled: bool = False

    @model_validator(mode="before")
    @classmethod
    def _normalize_payload(cls, value: object) -> object:
        if isinstance(value, BaseModel):
            payload = value.model_dump(mode="python")
        elif isinstance(value, dict):
            payload = dict(value)
        else:
            return value

        details_text = str(payload.get("details_text") or "").strip()
        requisites = _normalize_requisites_value(payload.get("requisites"))
        if details_text:
            if requisites is None:
                requisites = extract_payment_requisites(details_text)
            payload["details_text"] = normalize_payment_details_template(details_text, requisites)
        payload["requisites"] = requisites
        return payload


class ProductPhotoRule(BaseModel):
    name_contains: str
    photo_url: HttpUrl
    description: str | None = None


class ExchangerLink(BaseModel):
    label: str
    url: str


def default_exchangers() -> list["ExchangerLink"]:
    return []


class TemplateOverrides(BaseModel):
    shop_name: str = "Evila"
    operator_username: str = "EvilSUPPORT_AU"
    operator_url: HttpUrl | None = None
    work_url: HttpUrl | None = None
    vip_price_url: HttpUrl | None = None
    reviews_url: HttpUrl | None = None
    site_url: HttpUrl | None = None
    chat_url: HttpUrl | None = None
    complaints_url: HttpUrl | None = None
    questions_url: HttpUrl | None = None
    payment_support_url: HttpUrl | None = None
    contacts_text: str = "Контакты магазина Evila"
    start_text: str = DEFAULT_START_TEXT
    exchangers: list[ExchangerLink] = Field(default_factory=default_exchangers)


class BotSpec(BaseModel):
    token: str = Field(min_length=20)
    template: TemplateOverrides = Field(default_factory=TemplateOverrides)
    payment_methods: list[PaymentMethodConfig] = Field(default_factory=list)
    admin_ids: list[int] = Field(default_factory=list)
    is_paused: bool = False
    bot_id: int | None = None
    bot_username: str | None = None
    bot_name: str | None = None
    created_at: str | None = None


class CreateBotRequest(BaseModel):
    token: str = Field(min_length=20)
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None


class BotSummary(BaseModel):
    bot_id: int
    bot_username: str | None = None
    bot_name: str | None = None
    token: str
    created_at: str | None = None
    is_running: bool
    is_paused: bool = False
    admin_ids: list[int] = Field(default_factory=list)
    template: TemplateOverrides


class ProxyConfig(BaseModel):
    url: str
    label: str | None = None


class FamilyState(BaseModel):
    template: TemplateOverrides = Field(default_factory=TemplateOverrides)
    payment_methods: list[PaymentMethodConfig] = Field(default_factory=list)
    admin_ids: list[int] = Field(default_factory=list)
    proxies: list[ProxyConfig] = Field(default_factory=list)


class Settings(BaseModel):
    api_host: str = "127.0.0.1"
    api_port: int = 18746
    master_api_key: str = "change-me"
    data_path: Path = Path("data/bots.json")
    catalog_path: Path = Path("data/catalog.json")
    product_photo_rules_path: Path = DEFAULT_PRODUCT_PHOTO_RULES_PATH
    default_admin_ids: list[int] = Field(default_factory=list)
    default_product_photo: Path = DEFAULT_PRODUCT_PHOTO
    random_product_photo_dir: Path = DEFAULT_RANDOM_PRODUCT_PHOTO_DIR
    product_photo_rules: list[ProductPhotoRule] = Field(default_factory=list)
    default_payment_methods: list[PaymentMethodConfig]
    cities: list[CityConfig]
    rules_text: str
    instructions_text: str
    payment_text: str
    purchase_stub_text: str
    promo_applied_text: str


# ---------------------------------------------------------------------------
# DEFAULT_CITIES — loaded from data/catalog.json at startup.
# Products: MEFEDRON, KETAMINE, ALPHA PVP.  Currency: UAH.
# ---------------------------------------------------------------------------
DEFAULT_CITIES: list[CityConfig] = []


RULES_TEXT = """/start - вернуться к выбору города
-------------------------------
Помощь: @EvilSUPPORT_AU
Саппорт: покупки в боте, ненаходы
-------------------------------

Как правильно искать клад

1. Подойдя к месту заклада, выбери ракурс обзора места, как на фото курьера
2. Выбирай видимые ориентиры, на фото адреса и найди их на местности.
3. Сделайте соотношение пропорции расстояния от ориентира на местности, до отметки клада на фото.
4. Рекомендуем искать только в светлое время суток и без спешки!
Только после этих трёх пунктов - начинайте поиски.

Условия выдачи перезаклада

Возврат денег по оплаченным покупкам не предусмотрлен!
Гарантия доверия - 5 УСПЕШНЫХ покупок!
Заявка подана не позже 8 часов с момента покупки
Вы искали точно по метке

Отправьте саппорту: @EvilSUPPORT_AU

- описание проблемы
- заказ с бота
- видео запись процесса съёма клада
- фото места до и после поиска с того же ракурса, что и фото курьера
- Ожидайте ответа оператора без флуда и мата

Причины отказа в рассмотрении заявки

Мат, негатив о шопе или его сотрудниках
Настойчивый флуд в ЛС оператору
Дача заведомо ложной информации
Отсутствие фото/видео поиска
Частые ненаходы с 1 акка

Перезаклад не даётся на:

1-3 покупку (4-5 на усмотрение оператора)
Заявки позже 8 часов с момента покупки
Свежий клад (менее 24 часа)
Перезаклад
бонус, приз, пробу
более 1 ненахода подряд"""

INSTRUCTIONS_TEXT = """1. Выберите город.
2. Откройте нужный товар.
3. Выберите количество.
4. Выберите район.
5. Подтвердите заказ и переходите к оплате."""

PAYMENT_TEXT = """Выберите способ оплаты:"""

PURCHASE_STUB_TEXT = """После подтверждения заказа бот покажет карточку товара и переведет к оплате."""

PROMO_APPLIED_TEXT = """Промокод сохранен в шаблоне.

Проверка и начисление скидки пока не подключены."""


DEFAULT_PAYMENT_METHODS = [
    PaymentMethodConfig(
        key="card",
        label="Переказ на картку",
        commission_text="+15%",
        requisites="4874070029568506",
        details_text="Сплатіть на картку {requisites} суму {amount} грн.\n\nПісля оплати, товар буде видано автоматично протягом 5-10 хвилин.\nЩоб перевірити статус замовлення натисніть кнопку \"Переглянути статус\" або введіть команду /status",
        qr_enabled=False,
    ),
    PaymentMethodConfig(
        key="ltc",
        label="LTC",
        requisites=LEGACY_LTC_REQUISITES_PLACEHOLDER,
        details_text=f"Реквизиты для оплаты в LTC:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
    PaymentMethodConfig(
        key="btc",
        label="BTC",
        requisites=LEGACY_BTC_REQUISITES_PLACEHOLDER,
        details_text=f"Реквизиты для оплаты в BTC:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
]


def normalize_template(template: object | None) -> TemplateOverrides:
    if template is None:
        return TemplateOverrides()
    if isinstance(template, BaseModel):
        payload = template.model_dump(mode="python")
    elif isinstance(template, dict):
        payload = dict(template)
    else:
        payload = {}
    return TemplateOverrides.model_validate(payload)


def normalize_city_label(raw_label: str) -> str:
    return " ".join(raw_label.split()).strip()


def city_label_marker(raw_label: str) -> str:
    marker = normalize_city_label(raw_label)
    return marker.casefold()


def unique_city_labels(labels: list[str]) -> list[str]:
    unique_labels: list[str] = []
    seen: set[str] = set()
    for raw_label in labels:
        label = normalize_city_label(raw_label)
        marker = city_label_marker(label)
        if not label or marker in seen:
            continue
        seen.add(marker)
        unique_labels.append(label)
    return unique_labels


def extract_city_labels(start_text: str) -> list[str]:
    labels: list[str] = []
    seen: set[str] = set()
    for raw_line in start_text.splitlines():
        line = raw_line.strip()
        if not line.startswith("✅"):
            continue
        label = line.removeprefix("✅").strip()
        if not label or label.casefold().startswith("и другие города"):
            continue
        normalized_label = normalize_city_label(label)
        marker = city_label_marker(normalized_label)
        if marker in seen:
            continue
        seen.add(marker)
        labels.append(normalized_label)
    return labels


def build_screenshot_city_labels() -> list[str]:
    return unique_city_labels(DEFAULT_SCREENSHOT_CITY_ORDER)


def clone_products(products: list[ProductConfig]) -> list[ProductConfig]:
    return [product.model_copy(deep=True) for product in products]


def clone_cities(cities: list[CityConfig]) -> list[CityConfig]:
    return [city.model_copy(deep=True) for city in cities]


def dedupe_cities_by_label(cities: list[CityConfig]) -> list[CityConfig]:
    deduped: list[CityConfig] = []
    city_indexes: dict[str, int] = {}
    for city in cities:
        marker = city_label_marker(city.label)
        existing_index = city_indexes.get(marker)
        if existing_index is None:
            city_indexes[marker] = len(deduped)
            deduped.append(city.model_copy(deep=True))
            continue

        merged_city = deduped[existing_index]
        if has_placeholder_districts(merged_city.districts) and not has_placeholder_districts(city.districts):
            merged_city.districts = list(city.districts)
        if len(city.products) > len(merged_city.products):
            merged_city.products = clone_products(city.products)
        deduped[existing_index] = merged_city
    return deduped


def has_placeholder_districts(districts: list[str]) -> bool:
    normalized = [district.strip().casefold() for district in districts if district.strip()]
    if not normalized:
        return True
    placeholder_markers = {
        "заполните районы этого города",
        "заполните районы",
    }
    return all(marker in placeholder_markers for marker in normalized)


def build_start_screen_cities() -> list[CityConfig]:
    city_labels = build_screenshot_city_labels()
    if not city_labels:
        city_labels = extract_city_labels(DEFAULT_START_TEXT)
    if not city_labels:
        return []

    cities: list[CityConfig] = []

    for index, city_label in enumerate(city_labels, start=1):
        cities.append(
            CityConfig(
                key=f"city_{index}",
                label=city_label,
                icon="",
                districts=get_city_districts(city_label),
                district_selection_percent=100,
                products=[],
            )
        )
    return cities


def sync_catalog_cities(
    existing_cities: list[CityConfig],
    fallback_cities: list[CityConfig],
) -> list[CityConfig]:
    existing_by_key = {city.key: city for city in existing_cities}
    existing_by_label = {city_label_marker(city.label): city for city in existing_cities}
    merged: list[CityConfig] = []
    used_keys: set[str] = set()
    used_labels: set[str] = set()

    for fallback_city in fallback_cities:
        current_city = existing_by_key.get(fallback_city.key)
        if current_city is None:
            current_city = existing_by_label.get(city_label_marker(fallback_city.label))
        if current_city is None:
            merged.append(fallback_city.model_copy(deep=True))
            used_keys.add(fallback_city.key)
            continue

        merged_city = current_city.model_copy(deep=True)
        merged_city.key = fallback_city.key
        merged_city.label = fallback_city.label
        if has_placeholder_districts(merged_city.districts):
            merged_city.districts = list(fallback_city.districts)
        merged.append(merged_city)
        used_keys.add(merged_city.key)
        used_labels.add(city_label_marker(merged_city.label))

    for city in existing_cities:
        if city.key in used_keys or city_label_marker(city.label) in used_labels:
            continue
        merged.append(city.model_copy(deep=True))
    return merged


def cities_payload(cities: list[CityConfig]) -> list[dict[str, object]]:
    return [city.model_dump(mode="json") for city in cities]


def build_visible_start_cities(cities: list[CityConfig]) -> list[CityConfig]:
    ordered_labels = build_screenshot_city_labels()
    if not ordered_labels:
        ordered_labels = extract_city_labels(DEFAULT_START_TEXT)
    if not ordered_labels:
        return clone_cities(cities)

    cities_by_marker = {city_label_marker(city.label): city for city in cities}
    visible_cities: list[CityConfig] = []
    for label in ordered_labels:
        city = cities_by_marker.get(city_label_marker(label))
        if city is None:
            continue
        start_city = city.model_copy(deep=True)
        start_city.label = label
        visible_cities.append(start_city)
    return visible_cities or clone_cities(cities)


def save_catalog_cities(path: Path, cities: list[CityConfig]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = [city.model_dump(mode="json") for city in cities]
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_catalog_cities(path: Path, fallback_cities: list[CityConfig] | None = None) -> list[CityConfig]:
    fallback = clone_cities(fallback_cities or build_start_screen_cities())
    if not path.exists():
        save_catalog_cities(path, fallback)
        return fallback
    try:
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read catalog from {path}") from exc
    if not isinstance(raw_data, list):
        raise RuntimeError(f"Catalog file {path} must contain a list of cities.")
    try:
        existing_cities = [CityConfig.model_validate(item) for item in raw_data]
    except ValidationError as exc:
        raise RuntimeError(f"Invalid catalog data in {path}") from exc
    existing_cities = dedupe_cities_by_label(existing_cities)
    synced_cities = sync_catalog_cities(existing_cities, fallback)
    if cities_payload(synced_cities) != cities_payload(existing_cities):
        save_catalog_cities(path, synced_cities)
    return synced_cities


def parse_admin_ids(raw_value: str | None) -> list[int]:
    if not raw_value:
        return []
    admin_ids: list[int] = []
    for chunk in raw_value.split(","):
        value = chunk.strip()
        if not value:
            continue
        admin_ids.append(int(value))
    return admin_ids


def load_product_photo_rules(path: Path) -> list[ProductPhotoRule]:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[]\n", encoding="utf-8")
        return []
    try:
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read product photo rules from {path}") from exc
    if not isinstance(raw_data, list):
        raise RuntimeError(f"Product photo rules file {path} must contain a list.")
    try:
        return [ProductPhotoRule.model_validate(item) for item in raw_data]
    except ValidationError as exc:
        raise RuntimeError(f"Invalid product photo rules data in {path}") from exc


def apply_product_rules_to_cities(
    cities: list[CityConfig],
    rules: list[ProductPhotoRule],
) -> list[CityConfig]:
    if not rules:
        return cities
    updated_cities: list[CityConfig] = []
    for city in cities:
        updated_city = city.model_copy(deep=True)
        for product in updated_city.products:
            marker = product.label.casefold()
            for rule in rules:
                pattern = rule.name_contains.strip().casefold()
                if not pattern or pattern not in marker:
                    continue
                if not (product.description or "").strip() and (rule.description or "").strip():
                    product.description = rule.description
                if not (product.photo_url or "").strip() and not (product.photo_path or "").strip():
                    product.photo_url = str(rule.photo_url)
                break
        updated_cities.append(updated_city)
    return updated_cities


def load_family_state(data_path: Path) -> FamilyState:
    """Load family state (template, payment_methods, admin_ids) from bots.json."""
    if not data_path.exists():
        return FamilyState()
    try:
        raw = json.loads(data_path.read_text(encoding="utf-8"))
        if isinstance(raw, list) and raw:
            entry = raw[0]
        elif isinstance(raw, dict):
            entry = raw
        else:
            return FamilyState()
        template_data = entry.get("template", {})
        template = TemplateOverrides(**template_data) if template_data else TemplateOverrides()
        payment_methods = [
            PaymentMethodConfig(**pm) for pm in entry.get("payment_methods", [])
        ]
        admin_ids = [int(aid) for aid in entry.get("admin_ids", [])]
        return FamilyState(template=template, payment_methods=payment_methods, admin_ids=admin_ids)
    except Exception:
        return FamilyState()


def save_family_state(data_path: Path, state: FamilyState) -> None:
    """Save family state to bots.json, preserving token and bot metadata."""
    existing: list | dict = []
    if data_path.exists():
        try:
            existing = json.loads(data_path.read_text(encoding="utf-8"))
        except Exception:
            existing = []
    if isinstance(existing, list) and existing:
        entry = existing[0]
    elif isinstance(existing, dict):
        entry = existing
    else:
        entry = {}
    entry["template"] = state.template.model_dump(mode="json")
    entry["payment_methods"] = [pm.model_dump(mode="json") for pm in state.payment_methods]
    entry["admin_ids"] = list(state.admin_ids)
    if isinstance(existing, list):
        if existing:
            existing[0] = entry
        else:
            existing.append(entry)
        data_path.write_text(json.dumps(existing, ensure_ascii=False, indent=4), encoding="utf-8")
    else:
        data_path.write_text(json.dumps(entry, ensure_ascii=False, indent=4), encoding="utf-8")


def resolve_path(raw_value: str | None, default_path: Path) -> Path:
    if not raw_value:
        return default_path
    path = Path(raw_value).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    load_dotenv(DOTENV_PATH)
    catalog_path = resolve_path(os.getenv("CATALOG_DATA_PATH"), DEFAULT_CATALOG_PATH)
    product_photo_rules_path = resolve_path(
        os.getenv("PRODUCT_PHOTO_RULES_PATH"),
        DEFAULT_PRODUCT_PHOTO_RULES_PATH,
    )
    product_photo_rules = load_product_photo_rules(product_photo_rules_path)
    cities = load_catalog_cities(catalog_path, build_start_screen_cities())
    cities = apply_product_rules_to_cities(cities, product_photo_rules)
    return Settings(
        api_host=os.getenv("API_HOST", "127.0.0.1"),
        api_port=int(os.getenv("API_PORT", "18746")),
        master_api_key=os.getenv("MASTER_API_KEY", "change-me"),
        data_path=resolve_path(os.getenv("BOTS_DATA_PATH"), DEFAULT_DATA_PATH),
        catalog_path=catalog_path,
        product_photo_rules_path=product_photo_rules_path,
        default_admin_ids=parse_admin_ids(os.getenv("DEFAULT_ADMIN_IDS")),
        default_product_photo=resolve_path(os.getenv("DEFAULT_PRODUCT_PHOTO"), DEFAULT_PRODUCT_PHOTO),
        random_product_photo_dir=resolve_path(
            os.getenv("RANDOM_PRODUCT_PHOTO_DIR"),
            DEFAULT_RANDOM_PRODUCT_PHOTO_DIR,
        ),
        product_photo_rules=product_photo_rules,
        default_payment_methods=[method.model_copy(deep=True) for method in DEFAULT_PAYMENT_METHODS],
        cities=cities,
        rules_text=RULES_TEXT,
        instructions_text=INSTRUCTIONS_TEXT,
        payment_text=PAYMENT_TEXT,
        purchase_stub_text=PURCHASE_STUB_TEXT,
        promo_applied_text=PROMO_APPLIED_TEXT,
    )
