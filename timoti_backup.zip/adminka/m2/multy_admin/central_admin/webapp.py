from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl

import aiohttp
from aiohttp import web
from dotenv import dotenv_values, load_dotenv


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = Path(__file__).resolve().with_name(".env")
STATE_PATH = Path(__file__).resolve().with_name("central_admin_state.json")

DEFAULT_WEBAPP_HOST = os.getenv("WEBAPP_HOST", "127.0.0.1")
DEFAULT_WEBAPP_PORT = int(os.getenv("WEBAPP_PORT", "18820"))
DEFAULT_WEBAPP_URL = os.getenv("CENTRAL_WEBAPP_URL", f"http://{DEFAULT_WEBAPP_HOST}:{DEFAULT_WEBAPP_PORT}")
ALLOW_INSECURE = os.getenv("WEBAPP_ALLOW_INSECURE", "1").strip().casefold() in {"1", "true", "yes", "on"}

FAMILY_LABEL_OVERRIDES = {
    "11-7": "11-7",
    "eleven7": "11-7",
    "evilco": "Evilco",
    "d4bot": "d4bot",
    "mdz24sk": "MDZ24SK",
    "piohano": "Piohano",
    "lepricon": "Lepricon",
    "neon": "NEON",
    "miami": "Miami",
    "larek": "Larek",
    "vip": "VIP",
    "mak": "Mak",
    "tds24": "tds24",
    "bobrik": "BOBRIK",
    "varik": "VARIK",
    "bgreenday": "B_Green_Day (UA)",
    "black": "Black",
    "wyvern": "WYVERN",
    "glasscr": "Glass Cr",
    "totalblack": "TotalBlack",
    "netrc": "NETRC",
    "gus": "GUS",
    "solo": "SOLO",
    "bignewsanders": "BigNewSanders",
    "kissmyacid": "kissmyacid",
    "shishka": "Shishka",
    "donbass": "DONBASS",
    "kfc": "KFC",
    "vip1": "VIP1",
    "centurypass6": "CENTURYPASS6",
    "ugtop20": "UGTOP20",
}

LOCAL_FAMILY_ROOT_OVERRIDES = {
    "d4bot": [ROOT_DIR.parent / "4dmap", ROOT_DIR / "4dmap"],
    "mdz24sk": [ROOT_DIR.parent / "MDZ24SK", ROOT_DIR / "MDZ24SK"],
    "ugtop20": [ROOT_DIR.parent / "ugtop20_probot", ROOT_DIR / "ugtop20_probot"],
}


@dataclass(frozen=True, slots=True)
class ServiceSpec:
    key: str
    label: str
    base_url_env: str
    api_key_env: str
    base_url: str
    api_key: str


def parse_admin_ids(raw_value: str | None) -> set[int]:
    values: set[int] = set()
    if not raw_value:
        return values
    for chunk in raw_value.replace(" ", "").split(","):
        if not chunk:
            continue
        try:
            values.add(int(chunk))
        except ValueError:
            logger.warning("Skipping invalid admin id from env: %r", chunk)
    return values


def load_central_env() -> dict[str, str]:
    load_dotenv(ENV_PATH)
    return {key: str(value) for key, value in dotenv_values(ENV_PATH).items() if value is not None}


def load_central_settings() -> dict[str, Any]:
    raw = {}
    if STATE_PATH.exists():
        try:
            raw = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            raw = {}
    if not isinstance(raw, dict):
        raw = {}
    return {
        "global_admin_ids": sorted({admin_id for admin_id in raw.get("global_admin_ids", []) if isinstance(admin_id, int)}),
        "clone_bot_tokens": [token for token in raw.get("clone_bot_tokens", []) if isinstance(token, str) and token.strip()],
    }


def _safe_read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def save_central_settings(settings: dict[str, Any]) -> dict[str, Any]:
    normalized = {
        "global_admin_ids": sorted({int(admin_id) for admin_id in settings.get("global_admin_ids", []) if isinstance(admin_id, int) or str(admin_id).isdigit()}),
        "clone_bot_tokens": [str(token).strip() for token in settings.get("clone_bot_tokens", []) if str(token).strip()],
    }
    STATE_PATH.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding="utf-8")
    return normalized


def resolve_service_label(family_key: str) -> str:
    if family_key in FAMILY_LABEL_OVERRIDES:
        return FAMILY_LABEL_OVERRIDES[family_key]
    return family_key.replace("_", " ").title()


def load_service_specs() -> list[ServiceSpec]:
    env = load_central_env()
    specs: list[ServiceSpec] = []
    for env_key, base_url in env.items():
        if not env_key.endswith("_API_BASE") or not base_url.strip():
            continue
        family_key = env_key[:-9].lower()
        base_url_env = env_key
        api_key_env = f"{family_key.upper()}_API_KEY"
        api_key = env.get(api_key_env) or env.get("CENTRAL_DEFAULT_API_KEY") or "change-me"
        specs.append(
            ServiceSpec(
                key=family_key,
                label=resolve_service_label(family_key),
                base_url_env=base_url_env,
                api_key_env=api_key_env,
                base_url=base_url.rstrip("/"),
                api_key=api_key,
            )
        )

    priority = {"11-7": 0, "evilco": 1, "piohano": 2}
    specs.sort(key=lambda item: (priority.get(item.key, 100), item.label.casefold()))
    return specs


def resolve_local_family_root(spec: ServiceSpec) -> Path | None:
    override_roots = LOCAL_FAMILY_ROOT_OVERRIDES.get(spec.key, [])
    for override_root in override_roots:
        if override_root.exists():
            return override_root

    candidate_roots = [
        ROOT_DIR,
        ROOT_DIR.parent,
        ROOT_DIR / "multy_admin" / "bots",
        ROOT_DIR.parent / "multy_admin" / "bots",
    ]
    candidates: list[Path] = []
    for base in candidate_roots:
        candidates.extend([
            base / spec.label,
            base / spec.label.replace(" ", ""),
            base / spec.key,
        ])
    seen: set[Path] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.exists():
            return candidate
    return None


def _first_existing_path(paths: list[Path]) -> Path | None:
    seen: set[Path] = set()
    for candidate in paths:
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.exists():
            return candidate
    return None


def _resolve_local_settings_path(root: Path) -> Path:
    return _first_existing_path([
        root / "data" / "shared_settings.json",
        root / "data" / "family.json",
    ]) or (root / "data" / "shared_settings.json")


def _resolve_local_bots_path(root: Path) -> Path | None:
    return _first_existing_path([
        root / "data" / "bots.json",
        root / "data" / "bots.local.json",
    ]) or (root / "data" / "bots.json")


def load_local_family_payload(spec: ServiceSpec) -> dict[str, Any] | None:
    root = resolve_local_family_root(spec)
    if root is None:
        return None

    family_path = _resolve_local_settings_path(root)
    bots_path = _resolve_local_bots_path(root)
    family = _safe_read_json(family_path, {}) if family_path.exists() else {}
    bots = _safe_read_json(bots_path, []) if bots_path is not None else []
    if not isinstance(family, dict):
        family = {}
    if not isinstance(bots, list):
        bots = []

    template = family.get("template", {}) if isinstance(family.get("template"), dict) else {}
    if not template and bots and isinstance(bots[0], dict) and isinstance(bots[0].get("template"), dict):
        template = bots[0]["template"]

    return {
        "template": template,
        "admin_ids": family.get("admin_ids", []) if isinstance(family.get("admin_ids"), list) else [],
        "payment_methods": family.get("payment_methods", []) if isinstance(family.get("payment_methods"), list) else [],
        "bots_count": len([item for item in bots if isinstance(item, dict)]),
        "running_count": 0,
        "recipients_count": family.get("recipients_count", 0) if isinstance(family.get("recipients_count"), int) else 0,
        "bots": [item for item in bots if isinstance(item, dict)],
    }


def build_data_check_string(params: dict[str, str]) -> str:
    return "\n".join(f"{key}={value}" for key, value in sorted(params.items()))


def verify_webapp_init_data(init_data: str, bot_token: str) -> dict[str, Any]:
    if not init_data:
        raise web.HTTPUnauthorized(text="Missing Telegram init data")

    params = dict(parse_qsl(init_data, keep_blank_values=True))
    hash_value = params.pop("hash", "")
    if not hash_value:
        raise web.HTTPUnauthorized(text="Missing Telegram signature")

    data_check_string = build_data_check_string(params)
    secret_key = hmac.new(key=b"WebAppData", msg=bot_token.encode("utf-8"), digestmod=hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), digestmod=hashlib.sha256).hexdigest()
    if not hmac.compare_digest(computed_hash, hash_value):
        raise web.HTTPUnauthorized(text="Invalid Telegram signature")

    user_raw = params.get("user", "{}")
    try:
        user = json.loads(user_raw)
    except json.JSONDecodeError as exc:
        raise web.HTTPUnauthorized(text="Invalid Telegram user payload") from exc
    if not isinstance(user, dict):
        raise web.HTTPUnauthorized(text="Invalid Telegram user payload")
    return user


async def api_request(spec: ServiceSpec, method: str, path: str, *, json_body: dict[str, Any] | None = None, timeout_total: float = 12) -> Any:
    timeout = aiohttp.ClientTimeout(total=timeout_total)
    headers = {"X-API-Key": spec.api_key}
    url = f"{spec.base_url}{path}"
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.request(method, url, headers=headers, json=json_body) as response:
                if response.status >= 400:
                    detail = await response.text()
                    raise web.HTTPBadGateway(text=f"{spec.label}: API {response.status} {detail[:240]}")
                content_type = response.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    return await response.json()
                return await response.text()
    except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
        raise web.HTTPBadGateway(text=f"{spec.label}: {exc}") from exc


async def fetch_family(spec: ServiceSpec) -> dict[str, Any]:
    try:
        payload = await api_request(spec, "GET", "/admin/family")
    except Exception as exc:  # noqa: BLE001
        local_payload = load_local_family_payload(spec)
        if local_payload is not None:
            logger.warning("Using local family fallback for %s", spec.label)
            return {
                "key": spec.key,
                "label": spec.label,
                "status": "offline",
                "error": getattr(exc, "text", str(exc)),
                "base_url": spec.base_url,
                **local_payload,
            }
        return {
            "key": spec.key,
            "label": spec.label,
            "status": "offline",
            "error": getattr(exc, "text", str(exc)),
            "bots_count": 0,
            "running_count": 0,
            "recipients_count": 0,
            "payment_methods": [],
            "admin_ids": [],
            "bots": [],
            "template": {},
        }

    if not isinstance(payload, dict):
        payload = {}
    bots = [item for item in payload.get("bots", []) if isinstance(item, dict)]
    template = payload.get("template", {}) if isinstance(payload.get("template"), dict) else {}
    local_payload = load_local_family_payload(spec)
    api_bots_count = int(payload.get("bots_count") or len(bots))
    api_running_count = int(payload.get("running_count") or 0)
    if local_payload and local_payload.get("bots_count", 0) > 0 and api_bots_count == 0 and api_running_count == 0:
        logger.warning("Using local family overlay for %s because API returned empty counts", spec.label)
        return {
            "key": spec.key,
            "label": spec.label,
            "status": "offline",
            "base_url": spec.base_url,
            **local_payload,
        }
    return {
        "key": spec.key,
        "label": spec.label,
        "status": "online",
        "base_url": spec.base_url,
        "bots_count": api_bots_count,
        "running_count": api_running_count,
        "recipients_count": int(payload.get("recipients_count") or 0),
        "payment_methods": payload.get("payment_methods", []) if isinstance(payload.get("payment_methods"), list) else [],
        "admin_ids": payload.get("admin_ids", []) if isinstance(payload.get("admin_ids"), list) else [],
        "bots": bots,
        "template": template,
    }


async def fetch_dashboard() -> dict[str, Any]:
    env = load_central_env()
    settings = load_central_settings()
    specs = load_service_specs()

    results = await asyncio.gather(*(fetch_family(spec) for spec in specs))
    families = sorted(results, key=lambda item: (0 if item["key"] == "eleven7" else 1 if item["key"] == "evilco" else 2, item["label"].casefold()))

    central_admin_ids = sorted({admin_id for admin_id in parse_admin_ids(env.get("CENTRAL_ADMIN_IDS")) | set(settings["global_admin_ids"])})
    clone_tokens = settings["clone_bot_tokens"]
    totals = {
        "families": len(families),
        "bots": sum(int(item.get("bots_count", 0)) for item in families),
        "active": sum(int(item.get("running_count", 0)) for item in families),
        "payments": sum(len(item.get("payment_methods", [])) for item in families),
        "admins": len(central_admin_ids),
        "clones": len(clone_tokens),
    }
    selected_key = "eleven7" if any(item["key"] == "eleven7" for item in families) else (families[0]["key"] if families else "")
    selected_family = next((item for item in families if item["key"] == selected_key), families[0] if families else {})
    return {
        "families": families,
        "totals": totals,
        "settings": {
            "global_admin_ids": settings["global_admin_ids"],
            "clone_bot_tokens": clone_tokens,
        },
        "selected_key": selected_key,
        "selected_family": selected_family,
    }


async def resolve_allowed_admin_ids() -> set[int]:
    env = load_central_env()
    settings = load_central_settings()
    admin_ids = parse_admin_ids(env.get("CENTRAL_ADMIN_IDS"))
    admin_ids.update(settings["global_admin_ids"])

    async def load_family_admins(spec: ServiceSpec) -> set[int]:
        family = await fetch_family(spec)
        return {admin_id for admin_id in family.get("admin_ids", []) if isinstance(admin_id, int)}

    results = await asyncio.gather(*(load_family_admins(spec) for spec in load_service_specs()))
    for family_admins in results:
        admin_ids.update(family_admins)
    return admin_ids


async def authorize_request(request: web.Request) -> dict[str, Any]:
    if ALLOW_INSECURE and not request.query.get("init_data"):
        return {"id": 0, "first_name": "Local", "username": "local"}

    env = load_central_env()
    bot_token = env.get("CENTRAL_BOT_TOKEN", "").strip()
    if not bot_token:
        raise web.HTTPUnauthorized(text="Central bot token is not configured")

    init_data = request.query.get("init_data") or request.headers.get("X-Telegram-Init-Data") or ""
    user = verify_webapp_init_data(init_data, bot_token)
    user_id = int(user.get("id") or 0)
    allowed_ids = await resolve_allowed_admin_ids()
    if user_id not in allowed_ids:
        raise web.HTTPForbidden(text="Access only for administrators")
    return user


async def handle_bootstrap(request: web.Request) -> web.Response:
    user = await authorize_request(request)
    data = await fetch_dashboard()
    data["current_user"] = {
        "id": int(user.get("id") or 0),
        "first_name": str(user.get("first_name") or ""),
        "username": str(user.get("username") or ""),
    }
    data["webapp_url"] = DEFAULT_WEBAPP_URL
    return web.json_response(data)


async def handle_family(request: web.Request) -> web.Response:
    await authorize_request(request)
    family_key = request.match_info["family_key"]
    spec = next((item for item in load_service_specs() if item.key == family_key), None)
    if spec is None:
        raise web.HTTPNotFound(text="Family not found")
    if request.method == "PATCH":
        payload = await request.json()
        admin_ids_raw = payload.get("admin_ids", [])
        if not isinstance(admin_ids_raw, list):
            raise web.HTTPBadRequest(text="admin_ids must be a list")
        admin_ids = sorted({int(item) for item in admin_ids_raw if str(item).isdigit()})
        await api_request(spec, "PATCH", "/admin/family", json_body={"admin_ids": admin_ids})
        return web.json_response({"ok": True, "admin_ids": admin_ids})
    return web.json_response(await fetch_family(spec))


async def handle_global_admins(request: web.Request) -> web.Response:
    await authorize_request(request)
    payload = await request.json()
    action = str(payload.get("action") or "").strip().casefold()
    try:
        admin_id = int(payload.get("admin_id"))
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(text="admin_id must be an integer")

    settings = load_central_settings()
    admin_ids = list(settings["global_admin_ids"])
    if action == "add":
        admin_ids = sorted(set(admin_ids + [admin_id]))
    elif action == "remove":
        admin_ids = [item for item in admin_ids if item != admin_id]
    else:
        raise web.HTTPBadRequest(text="Unsupported action")

    settings["global_admin_ids"] = admin_ids
    save_central_settings(settings)

    errors: list[str] = []
    for spec in load_service_specs():
        try:
            family = await fetch_family(spec)
            family_admin_ids = sorted({item for item in family.get("admin_ids", []) if isinstance(item, int)})
            updated_admin_ids = sorted(set(family_admin_ids + [admin_id])) if action == "add" else [item for item in family_admin_ids if item != admin_id]
            if updated_admin_ids != family_admin_ids:
                await api_request(spec, "PATCH", "/admin/family", json_body={"admin_ids": updated_admin_ids})
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{spec.label}: {exc}")

    return web.json_response({"ok": True, "global_admin_ids": admin_ids, "errors": errors})


async def handle_health(_: web.Request) -> web.Response:
    return web.json_response({"status": "ok", "service": "central-admin-web"})


async def handle_family_broadcast(request: web.Request) -> web.Response:
    await authorize_request(request)
    family_key = request.match_info["family_key"]
    spec = next((item for item in load_service_specs() if item.key == family_key), None)
    if spec is None:
        raise web.HTTPNotFound(text="Family not found")
    payload = await request.json()
    text = str(payload.get("text", "")).strip()
    if not text:
        raise web.HTTPBadRequest(text="text is required")
    result = await api_request(spec, "POST", "/admin/family/broadcast", json_body={"text": text}, timeout_total=180)
    return web.json_response(result if isinstance(result, dict) else {"ok": True})


PAGE_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title>Центральная админка</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #070707;
      --bg-deep: #0d0d0d;
      --panel: rgba(18, 18, 18, 0.88);
      --panel-soft: rgba(24, 24, 24, 0.78);
      --line: rgba(255, 255, 255, 0.09);
      --line-strong: rgba(255, 255, 255, 0.16);
      --text: #f5f1e8;
      --muted: #a19a8e;
      --muted-strong: #cdc6bb;
      --accent: #f3a42b;
      --accent-soft: rgba(243, 164, 43, 0.16);
      --accent-strong: #ffc54f;
      --good: #57cc78;
      --bad: #f76f61;
      --shadow: 0 24px 80px rgba(0, 0, 0, 0.45);
      --radius-xl: 28px;
      --radius-lg: 22px;
      --radius-md: 18px;
      --radius-sm: 14px;
      --mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      --sans: "IBM Plex Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; min-height: 100%; background: var(--bg); color: var(--text); font-family: var(--sans); }
    body {
      background:
        radial-gradient(circle at 20% 0%, rgba(243, 164, 43, 0.14), transparent 26%),
        radial-gradient(circle at 80% 0%, rgba(255, 197, 79, 0.08), transparent 18%),
        radial-gradient(circle at 100% 100%, rgba(255, 255, 255, 0.06), transparent 30%),
        linear-gradient(180deg, #090909 0%, #070707 48%, #060606 100%);
      overflow-x: hidden;
    }
    .noise {
      position: fixed; inset: 0; pointer-events: none; opacity: 0.06; mix-blend-mode: screen;
      background-image:
        linear-gradient(rgba(255,255,255,.7) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,.7) 1px, transparent 1px);
      background-size: 68px 68px, 68px 68px;
      mask-image: radial-gradient(circle at center, black 20%, transparent 78%);
    }
    .shell {
      position: relative;
      max-width: 1440px;
      margin: 0 auto;
      padding: 22px 18px 30px;
    }
    .hero {
      border: 1px solid var(--line);
      border-radius: var(--radius-xl);
      background: linear-gradient(180deg, rgba(20,20,20,.94), rgba(12,12,12,.96));
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }
    .hero::before {
      content: "";
      position: absolute;
      inset: -1px;
      background: linear-gradient(120deg, rgba(243,164,43,.14), transparent 18%, transparent 82%, rgba(255,197,79,.10));
      pointer-events: none;
      opacity: .7;
    }
    .hero-inner {
      position: relative;
      padding: 20px 20px 18px;
      display: grid;
      gap: 18px;
    }
    .topbar {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; flex-wrap: wrap;
    }
    .brand {
      display: flex; align-items: center; gap: 14px;
    }
    .brand-mark {
      width: 54px; height: 54px; border-radius: 18px;
      border: 1px solid rgba(255, 197, 79, 0.24);
      background: linear-gradient(180deg, rgba(255,197,79,.18), rgba(255,255,255,.03));
      display: grid; place-items: center;
      box-shadow: inset 0 1px 0 rgba(255,255,255,.08);
      font-size: 23px;
    }
    .eyebrow {
      color: var(--muted);
      font-size: 12px;
      letter-spacing: .18em;
      text-transform: uppercase;
      margin-bottom: 6px;
    }
    h1 {
      margin: 0;
      font-size: clamp(28px, 3.6vw, 46px);
      line-height: 1;
      letter-spacing: -0.04em;
    }
    .subline {
      margin-top: 7px;
      color: var(--muted-strong);
      max-width: 58ch;
      font-size: 14px;
      line-height: 1.55;
    }
    .status-row {
      display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
    }
    .pill {
      display: inline-flex; align-items: center; gap: 8px;
      height: 34px; padding: 0 12px;
      border-radius: 999px;
      border: 1px solid var(--line);
      background: rgba(255,255,255,.03);
      color: var(--muted-strong);
      font-size: 13px;
    }
    .pill strong { color: var(--text); font-weight: 600; }
    .pill.live {
      border-color: rgba(87, 204, 120, 0.28);
      background: rgba(87, 204, 120, 0.08);
      color: #bfecca;
    }
    .actions {
      display: flex; flex-wrap: wrap; gap: 10px; justify-content: flex-end;
    }
    .topbar .actions { display: none; }
    .btn {
      appearance: none; border: 0; text-decoration: none; color: #111;
      display: inline-flex; align-items: center; gap: 10px;
      min-height: 42px; padding: 0 16px;
      border-radius: 14px;
      font-weight: 700; font-size: 14px;
      background: linear-gradient(180deg, var(--accent-strong), var(--accent));
      box-shadow: 0 12px 22px rgba(243, 164, 43, 0.20);
      cursor: pointer;
      transition: transform .16s ease, filter .16s ease, box-shadow .16s ease;
    }
    .btn:hover { transform: translateY(-1px); filter: brightness(1.03); box-shadow: 0 14px 30px rgba(243, 164, 43, 0.24); }
    .btn.secondary {
      color: var(--text);
      background: rgba(255,255,255,.04);
      border: 1px solid var(--line);
      box-shadow: none;
    }
    .btn.secondary:hover { background: rgba(255,255,255,.06); }
    .metrics {
      display: grid;
      grid-template-columns: repeat(6, minmax(0, 1fr));
      gap: 12px;
    }
    .metric {
      padding: 14px 15px;
      border-radius: 18px;
      background: linear-gradient(180deg, rgba(255,255,255,.04), rgba(255,255,255,.02));
      border: 1px solid var(--line);
      min-height: 88px;
    }
    .metric .label {
      display: flex; align-items: center; gap: 8px;
      color: var(--muted);
      font-size: 12px; letter-spacing: .08em; text-transform: uppercase;
    }
    .metric .value {
      margin-top: 12px;
      font-size: 28px;
      line-height: 1;
      font-weight: 700;
      letter-spacing: -0.04em;
    }
    .metric .hint { margin-top: 8px; color: var(--muted); font-size: 12px; }
    .layout {
      margin-top: 16px;
      display: grid;
      grid-template-columns: 390px minmax(0, 1fr);
      gap: 16px;
      align-items: start;
    }
    .panel {
      border: 1px solid var(--line);
      border-radius: var(--radius-xl);
      background: var(--panel);
      box-shadow: var(--shadow);
      overflow: hidden;
    }
    .panel-head {
      padding: 16px 16px 14px;
      border-bottom: 1px solid var(--line);
      display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
    }
    .panel-title {
      display: grid; gap: 6px;
    }
    .panel-title h2 {
      margin: 0; font-size: 18px; letter-spacing: -0.03em;
    }
    .panel-title p {
      margin: 0; color: var(--muted); font-size: 13px;
    }
    .search {
      width: 100%;
      margin-top: 12px;
      display: grid; grid-template-columns: 1fr auto; gap: 10px;
    }
    .search input, .field input, .field textarea {
      width: 100%;
      color: var(--text);
      background: rgba(255,255,255,.035);
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 12px 13px;
      font: inherit;
      outline: none;
      transition: border-color .16s ease, background .16s ease, transform .16s ease;
    }
    .search input:focus, .field input:focus, .field textarea:focus {
      border-color: rgba(243,164,43,.42);
      background: rgba(255,255,255,.05);
    }
    .search button {
      min-width: 110px;
    }
    .family-list {
      display: grid;
      gap: 10px;
      padding: 14px;
    }
    .family-card {
      position: relative;
      display: grid;
      gap: 12px;
      text-align: left;
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 18px;
      background: rgba(255,255,255,.03);
      padding: 14px;
      cursor: pointer;
      transition: transform .18s ease, border-color .18s ease, background .18s ease, box-shadow .18s ease;
    }
    .family-card:hover { transform: translateY(-1px); border-color: var(--line-strong); }
    .family-card.active {
      border-color: rgba(243,164,43,.56);
      background: linear-gradient(180deg, rgba(243,164,43,.12), rgba(255,255,255,.03));
      box-shadow: 0 18px 30px rgba(243,164,43,0.06);
    }
    .family-card .row {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 10px;
    }
    .family-name {
      font-size: 18px; font-weight: 700; letter-spacing: -0.03em;
    }
    .family-shop {
      color: var(--muted-strong); font-size: 13px; margin-top: 6px;
    }
    .chip-row {
      display: flex; flex-wrap: wrap; gap: 8px;
    }
    .chip {
      display: inline-flex; align-items: center; gap: 6px;
      min-height: 28px; padding: 0 10px;
      border-radius: 999px;
      background: rgba(255,255,255,.04);
      border: 1px solid var(--line);
      color: var(--muted-strong);
      font-size: 12px;
    }
    .chip.accent {
      color: #1a1408;
      background: linear-gradient(180deg, var(--accent-strong), var(--accent));
      border-color: transparent;
    }
    .icon-btn {
      appearance: none;
      border: 1px solid var(--line);
      background: rgba(255,255,255,.04);
      color: var(--text);
      width: 34px;
      height: 34px;
      border-radius: 12px;
      display: inline-grid;
      place-items: center;
      cursor: pointer;
      transition: transform .16s ease, border-color .16s ease, background .16s ease;
    }
    .icon-btn:hover {
      transform: translateY(-1px);
      border-color: var(--line-strong);
      background: rgba(255,255,255,.06);
    }
    .metrics { display: none; }
    .layout { grid-template-columns: 1fr; }
    .detail {
      display: grid;
      gap: 16px;
    }
    .detail-top {
      padding: 18px;
      display: grid;
      gap: 14px;
    }
    .detail-hero {
      display: flex; align-items: flex-start; justify-content: space-between; gap: 14px; flex-wrap: wrap;
    }
    .detail-hero .title-block {
      display: grid; gap: 7px;
    }
    .detail-label {
      color: var(--accent-strong); font-size: 12px; letter-spacing: .18em; text-transform: uppercase;
    }
    .detail-name {
      margin: 0;
      font-size: clamp(30px, 4vw, 48px);
      line-height: .95;
      letter-spacing: -0.05em;
    }
    .detail-shop {
      color: var(--muted-strong); font-size: 15px; line-height: 1.5;
      max-width: 64ch;
    }
    .detail-actions {
      display: flex; flex-wrap: wrap; gap: 10px; justify-content: flex-end;
    }
    .detail-grid {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 12px;
    }
    .mini-stat {
      padding: 14px;
      border-radius: 18px;
      border: 1px solid var(--line);
      background: rgba(255,255,255,.03);
    }
    .mini-stat .k { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .12em; }
    .mini-stat .v { margin-top: 10px; font-size: 22px; font-weight: 700; letter-spacing: -.03em; }
    .mini-stat .s { margin-top: 7px; color: var(--muted); font-size: 12px; }
    .subgrid {
      display: grid;
      grid-template-columns: 1.15fr .85fr;
      gap: 16px;
      padding: 0 18px 18px;
    }
    .subcard {
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      background: var(--panel-soft);
      overflow: hidden;
    }
    .subcard-head {
      padding: 14px 14px 12px;
      border-bottom: 1px solid var(--line);
      display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap;
    }
    .subcard-head h3 {
      margin: 0; font-size: 15px; letter-spacing: -.02em;
    }
    .subcard-body { padding: 14px; }
    .stack { display: grid; gap: 10px; }
    .bot-item {
      display: flex; align-items: center; justify-content: space-between; gap: 10px;
      border: 1px solid var(--line);
      border-radius: 16px;
      background: rgba(255,255,255,.03);
      padding: 12px 13px;
    }
    .bot-main { display: grid; gap: 5px; min-width: 0; }
    .bot-main .name { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .bot-main .meta { color: var(--muted); font-size: 12px; font-family: var(--mono); }
    .bot-status {
      flex: 0 0 auto;
      padding: 6px 10px;
      border-radius: 999px;
      font-size: 12px;
      border: 1px solid var(--line);
      color: var(--muted-strong);
      background: rgba(255,255,255,.03);
    }
    .bot-status.good { color: #d6f7df; border-color: rgba(87,204,120,.28); background: rgba(87,204,120,.10); }
    .bot-status.warn { color: #ffe4b8; border-color: rgba(243,164,43,.28); background: rgba(243,164,43,.12); }
    .field {
      display: grid;
      gap: 8px;
    }
    .field label {
      color: var(--muted);
      font-size: 12px;
      letter-spacing: .12em;
      text-transform: uppercase;
    }
    .field textarea {
      min-height: 120px;
      resize: vertical;
      font-family: var(--mono);
      line-height: 1.55;
    }
    .help {
      color: var(--muted);
      font-size: 12px;
      line-height: 1.5;
    }
    .admin-list {
      display: flex; flex-wrap: wrap; gap: 8px;
    }
    .admin-pill {
      display: inline-flex; align-items: center; gap: 10px;
      min-height: 32px;
      padding: 0 10px 0 12px;
      border-radius: 999px;
      background: rgba(255,255,255,.04);
      border: 1px solid var(--line);
      color: var(--text);
      font-family: var(--mono);
      font-size: 12px;
    }
    .admin-pill button {
      border: 0; background: transparent; color: var(--bad); cursor: pointer; font: inherit;
      width: 24px; height: 24px; border-radius: 999px;
    }
    .form-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 10px;
      align-items: start;
    }
    .muted { color: var(--muted); }
    .toast {
      position: fixed;
      left: 50%;
      top: 14px;
      transform: translateX(-50%) translateY(-12px);
      z-index: 99;
      min-width: 280px;
      max-width: min(96vw, 560px);
      padding: 12px 14px;
      border-radius: 14px;
      background: rgba(20,20,20,.96);
      color: var(--text);
      border: 1px solid var(--line-strong);
      box-shadow: 0 20px 44px rgba(0,0,0,.35);
      opacity: 0;
      transition: opacity .18s ease, transform .18s ease;
      pointer-events: none;
    }
    .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
    .toast.good { border-color: rgba(87,204,120,.30); }
    .toast.bad { border-color: rgba(247,111,97,.30); }
    .modal-backdrop {
      position: fixed;
      inset: 0;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 18px;
      background: rgba(0,0,0,.72);
      z-index: 40;
    }
    .modal-backdrop.show { display: flex; }
    .modal-window {
      width: min(1160px, 100%);
      max-height: 92vh;
      overflow: auto;
    }
    .footer-note {
      padding: 0 2px;
      color: var(--muted);
      font-size: 12px;
      line-height: 1.45;
    }
    .empty-state {
      padding: 24px;
      color: var(--muted);
    }
    @media (max-width: 1200px) {
      .detail-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .subgrid { grid-template-columns: 1fr; }
    }
    @media (max-width: 720px) {
      .shell { padding: 14px 12px 22px; }
      .hero-inner { padding: 16px 14px 14px; }
      .topbar { gap: 12px; }
      .actions, .detail-actions { width: 100%; justify-content: flex-start; }
      .btn { width: 100%; justify-content: center; }
      .search { grid-template-columns: 1fr; }
      .search button { width: 100%; }
      .form-row { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="noise"></div>
  <div id="toast" class="toast" role="status" aria-live="polite"></div>
  <main class="shell">
    <section class="hero">
      <div class="hero-inner">
        <div class="topbar">
          <div class="brand">
            <div class="brand-mark">◼</div>
          </div>
          <div class="actions">
            <a class="btn secondary" href="#" id="copySelectedBtn">📋 Копировать</a>
            <button class="btn secondary" id="refreshBtn" type="button">⟲ Обновить</button>
            <button class="btn" id="openFamilyBtn" type="button">↗ Открыть</button>
          </div>
        </div>
        <div class="status-row" id="statusRow">
          <span class="pill live">● <strong>Загрузка</strong> панели</span>
        </div>
        <div class="metrics" id="metrics"></div>
      </div>
    </section>

    <section class="layout">
      <aside class="panel">
        <div class="panel-head">
          <div class="panel-title">
            <h2>Семьи</h2>
          </div>
        </div>
        <div class="search">
          <input id="familySearch" type="search" placeholder="Поиск семьи или магазина">
          <button class="btn secondary" id="clearSearchBtn" type="button">Сброс</button>
        </div>
        <div class="family-list" id="familyList">
          <div class="empty-state">Загрузка...</div>
        </div>
      </aside>
    </section>
  </main>

  <div class="modal-backdrop" id="familyModalBackdrop" aria-hidden="true">
    <div class="modal-window">
      <section class="detail panel">
        <div class="detail-top">
          <div class="detail-hero">
            <div class="title-block">
              <div class="detail-label" id="detailLabel">Выбранная семья</div>
              <h2 class="detail-name" id="detailName">—</h2>
              <div class="detail-shop" id="detailShop">—</div>
            </div>
            <div class="detail-actions">
              <a class="btn secondary" id="detailApiBtn" href="#" target="_blank" rel="noreferrer">↗ API</a>
              <a class="btn secondary" id="detailTelegramBtn" href="#" target="_blank" rel="noreferrer">✈ Telegram</a>
              <button class="btn secondary" id="modalCloseBtn" type="button">✕ Закрыть</button>
            </div>
          </div>
          <div class="detail-grid" id="detailGrid"></div>
        </div>

        <div class="subgrid">
          <div class="subcard">
            <div class="subcard-head">
              <h3>Боты семейства</h3>
              <span class="muted" id="botCountLabel">0 ботов</span>
            </div>
            <div class="subcard-body">
              <div class="stack" id="botList"></div>
            </div>
          </div>

          <div class="stack">
            <div class="subcard">
              <div class="subcard-head">
                <h3>Настройки семьи</h3>
                <span class="muted">⚙</span>
              </div>
              <div class="subcard-body stack">
                <div class="admin-list" id="familyAdminsList"></div>
                <div class="form-row">
                  <div class="field">
                    <label>Добавить админа</label>
                    <input id="familyAdminInput" type="text" inputmode="numeric" placeholder="8224636125">
                  </div>
                  <button class="btn" id="addFamilyAdminBtn" type="button">+ Add</button>
                </div>
                <div class="help">Админы применяются только к выбранной семье.</div>
              </div>
            </div>

            <div class="subcard">
              <div class="subcard-head">
                <h3>Глобальные админы</h3>
                <span class="muted" id="globalAdminsCount">0</span>
              </div>
              <div class="subcard-body stack">
                <div class="admin-list" id="globalAdminsList"></div>
                <div class="form-row">
                  <div class="field">
                    <label>Добавить ID</label>
                    <input id="globalAdminInput" type="text" inputmode="numeric" placeholder="8224636125">
                  </div>
                  <button class="btn" id="addGlobalAdminBtn" type="button">+ Add</button>
                </div>
                <div class="help">Глобальные админы применяются ко всей общей админке и автоматически расходятся по семействам.</div>
              </div>
            </div>

            <div class="subcard">
              <div class="subcard-head">
                <h3>Клон-боты</h3>
                <span class="muted" id="cloneCount">0</span>
              </div>
              <div class="subcard-body stack">
                <div class="admin-list" id="cloneTokenList"></div>
                <div class="help">
                  Токены клонов управляются в центральной админке и показывают, сколько дополнительных экземпляров сейчас обслуживается.
                </div>
              </div>
            </div>
          </div>

          <div class="subcard" style="grid-column: 1 / -1;">
            <div class="subcard-head">
              <h3>Рассылка</h3>
              <span class="muted" id="broadcastRecipients">📣 0 получателей</span>
            </div>
            <div class="subcard-body stack">
              <div class="field">
                <label>Текст сообщения</label>
                <textarea id="broadcastText" placeholder="Сообщение уйдёт всем получателям выбранного семейства..."></textarea>
              </div>
              <div class="form-row">
                <button class="btn" id="sendBroadcastBtn" type="button">📣 Отправить рассылку</button>
              </div>
              <div class="help" id="broadcastResult"></div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>

  <script>
    const appBase = new URL('./', window.location.href);
    const state = {
      bootstrap: null,
      selectedKey: new URLSearchParams(window.location.search).get('family') || 'eleven7',
      search: '',
    };

    const telegram = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
    if (telegram) {
      telegram.ready();
      telegram.expand();
    }

    const toastEl = document.getElementById('toast');
    const metricsEl = document.getElementById('metrics');
    const statusRowEl = document.getElementById('statusRow');
    const familyListEl = document.getElementById('familyList');
    const familyModalBackdropEl = document.getElementById('familyModalBackdrop');
    const modalCloseBtn = document.getElementById('modalCloseBtn');
    const detailLabelEl = document.getElementById('detailLabel');
    const detailNameEl = document.getElementById('detailName');
    const detailShopEl = document.getElementById('detailShop');
    const detailGridEl = document.getElementById('detailGrid');
    const botListEl = document.getElementById('botList');
    const familyAdminsListEl = document.getElementById('familyAdminsList');
    const familyAdminInput = document.getElementById('familyAdminInput');
    const addFamilyAdminBtn = document.getElementById('addFamilyAdminBtn');
    const globalAdminsListEl = document.getElementById('globalAdminsList');
    const cloneTokenListEl = document.getElementById('cloneTokenList');
    const globalAdminsCountEl = document.getElementById('globalAdminsCount');
    const cloneCountEl = document.getElementById('cloneCount');
    const botCountLabelEl = document.getElementById('botCountLabel');
    const broadcastRecipientsEl = document.getElementById('broadcastRecipients');
    const broadcastTextEl = document.getElementById('broadcastText');
    const sendBroadcastBtn = document.getElementById('sendBroadcastBtn');
    const broadcastResultEl = document.getElementById('broadcastResult');
    const familySearchEl = document.getElementById('familySearch');
    const refreshBtn = document.getElementById('refreshBtn');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const addGlobalAdminBtn = document.getElementById('addGlobalAdminBtn');
    const globalAdminInput = document.getElementById('globalAdminInput');
    const copySelectedBtn = document.getElementById('copySelectedBtn');
    const openFamilyBtn = document.getElementById('openFamilyBtn');
    const detailApiBtn = document.getElementById('detailApiBtn');
    const detailTelegramBtn = document.getElementById('detailTelegramBtn');

    let toastTimer = null;

    function showToast(text, tone = 'good') {
      toastEl.textContent = text;
      toastEl.className = `toast show ${tone === 'bad' ? 'bad' : 'good'}`;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        toastEl.className = 'toast';
      }, 2400);
    }

    function escapeHtml(value) {
      return String(value || '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[char]));
    }

    function familyDisplayName(family) {
      return family.label || family.key;
    }

    function familyShopName(family) {
      const template = family.template || {};
      return (template.shop_name || family.label || family.key).trim();
    }

    function openFamilyModal() {
      familyModalBackdropEl.classList.add('show');
      familyModalBackdropEl.setAttribute('aria-hidden', 'false');
    }

    function closeFamilyModal() {
      familyModalBackdropEl.classList.remove('show');
      familyModalBackdropEl.setAttribute('aria-hidden', 'true');
    }

    function familiesFiltered() {
      const q = state.search.trim().toLowerCase();
      const families = (state.bootstrap && state.bootstrap.families) ? state.bootstrap.families : [];
      if (!q) return families;
      return families.filter((family) => {
        const haystack = [
          family.key,
          family.label,
          familyShopName(family),
          String(family.bots_count || ''),
          String(family.running_count || ''),
        ].join(' ').toLowerCase();
        return haystack.includes(q);
      });
    }

    function selectedFamily() {
      const families = (state.bootstrap && state.bootstrap.families) ? state.bootstrap.families : [];
      return families.find((family) => family.key === state.selectedKey) || families[0] || null;
    }

    function renderMetrics() {
      const totals = (state.bootstrap && state.bootstrap.totals) || {};
      const cards = [
        ['families', '🏷 Семьи', totals.families ?? 0, 'отдельные контуры управления'],
        ['bots', '🤖 Боты', totals.bots ?? 0, 'сейчас настроены'],
        ['active', '✅ Активные', totals.active ?? 0, 'работают прямо сейчас'],
        ['admins', '👥 Админы', totals.admins ?? 0, 'общий список доступа'],
        ['payments', '💳 Оплаты', totals.payments ?? 0, 'способы по всем семьям'],
        ['clones', '🪞 Клоны', totals.clones ?? 0, 'копии центральной админки'],
      ];
      metricsEl.innerHTML = cards.map(([, label, value, hint]) => `
        <article class="metric">
          <div class="label">${label}</div>
          <div class="value">${value}</div>
          <div class="hint">${hint}</div>
        </article>
      `).join('');
    }

    function renderStatus() {
      const totals = (state.bootstrap && state.bootstrap.totals) || {};
      const current = selectedFamily();
      const familyLabel = current ? current.label : 'Нет';
      const shopName = current ? familyShopName(current) : '—';
      const status = current && current.status === 'online' ? 'online' : 'offline';
      statusRowEl.innerHTML = `
        <span class="pill live">● <strong>${escapeHtml(status === 'online' ? 'ОНЛАЙН' : 'ОФФЛАЙН')}</strong> Панель</span>
        <span class="pill">🏷 <strong>${escapeHtml(familyLabel)}</strong></span>
        <span class="pill">🏪 <strong>${escapeHtml(shopName)}</strong></span>
        <span class="pill">🤖 <strong>${totals.bots ?? 0}</strong> ботов всего</span>
      `;
    }

    function renderFamilies() {
      const families = familiesFiltered();
      if (!families.length) {
        familyListEl.innerHTML = '<div class="empty-state">Ничего не найдено.</div>';
        return;
      }
      familyListEl.innerHTML = families.map((family) => {
        const active = family.key === state.selectedKey ? 'active' : '';
        const statusClass = family.status === 'online' ? 'good' : 'warn';
        const statusText = family.status === 'online' ? 'Онлайн' : 'Оффлайн';
        return `
          <button class="family-card ${active}" data-family="${escapeHtml(family.key)}" type="button">
            <div class="row">
              <div>
                <div class="family-name">${escapeHtml(familyDisplayName(family))}</div>
                <div class="family-shop">${escapeHtml(familyShopName(family))}</div>
              </div>
              <div class="card-actions">
                <span class="bot-status ${statusClass}">${statusText}</span>
                <span class="icon-btn" data-family-settings="${escapeHtml(family.key)}" role="button" tabindex="0" title="Настройки семьи" aria-label="Настройки семьи">⚙</span>
              </div>
            </div>
            <div class="chip-row">
              <span class="chip accent">🤖 ${family.bots_count ?? 0}</span>
              <span class="chip">✅ ${family.running_count ?? 0}</span>
              <span class="chip">👥 ${(family.admin_ids || []).length}</span>
              <span class="chip">💳 ${(family.payment_methods || []).length}</span>
              <span class="chip">📣 ${family.recipients_count ?? 0}</span>
            </div>
          </button>
        `;
      }).join('');
      familyListEl.querySelectorAll('[data-family]').forEach((btn) => {
        btn.addEventListener('click', () => {
          state.selectedKey = btn.dataset.family;
          openFamilyModal();
          renderAll();
        });
      });
      familyListEl.querySelectorAll('[data-family-settings]').forEach((btn) => {
        btn.addEventListener('click', async (event) => {
          event.stopPropagation();
          state.selectedKey = btn.dataset.familySettings;
          openFamilyModal();
          renderAll();
        });
      });
    }

    function botUsernameUrl(username) {
      if (!username) return '';
      return `https://t.me/${username.replace(/^@/, '')}`;
    }

    function renderSelected() {
      const family = selectedFamily();
      if (!family) {
        detailLabelEl.textContent = 'Выбранная семья';
        detailNameEl.textContent = 'Нет данных';
        detailShopEl.textContent = 'Сначала загрузим доступные семьи.';
        detailGridEl.innerHTML = '';
        botListEl.innerHTML = '<div class="empty-state">Данных нет.</div>';
        familyAdminsListEl.innerHTML = '';
        globalAdminsListEl.innerHTML = '';
        cloneTokenListEl.innerHTML = '';
        globalAdminsCountEl.textContent = '0';
        cloneCountEl.textContent = '0';
        botCountLabelEl.textContent = '0 ботов';
        broadcastRecipientsEl.textContent = '📣 0 получателей';
        broadcastTextEl.value = '';
        broadcastResultEl.textContent = '';
        detailApiBtn.href = '#';
        detailTelegramBtn.href = '#';
        return;
      }

      const template = family.template || {};
      const bots = family.bots || [];
      const admins = family.admin_ids || [];
      const payments = family.payment_methods || [];
      const firstBot = bots[0] || {};
      const botUrl = botUsernameUrl(firstBot.bot_username || family.bot_username || '');
      detailLabelEl.textContent = family.status === 'online' ? 'Семья онлайн' : 'Семья оффлайн';
      detailNameEl.textContent = familyDisplayName(family);
      detailShopEl.innerHTML = `
        <strong>${escapeHtml(familyShopName(family))}</strong><br>
        ${escapeHtml(template.start_text ? String(template.start_text).slice(0, 180) + (String(template.start_text).length > 180 ? '…' : '') : 'Без описания')}
      `;
      detailGridEl.innerHTML = [
        ['🤖 Боты', family.bots_count ?? 0, 'настроенные боты'],
        ['✅ Активные', family.running_count ?? 0, 'работают сейчас'],
        ['👥 Админы', admins.length, 'админы семьи'],
        ['💳 Оплаты', payments.length, 'способы оплаты'],
        ['📣 Получатели', family.recipients_count ?? 0, 'доступно для рассылки'],
      ].map(([label, value, hint]) => `
        <div class="mini-stat">
          <div class="k">${label}</div>
          <div class="v">${value}</div>
          <div class="s">${hint}</div>
        </div>
      `).join('');

      detailApiBtn.href = `${family.base_url || ''}/admin/family`;
      detailTelegramBtn.href = botUrl || '#';
      detailTelegramBtn.style.pointerEvents = botUrl ? 'auto' : 'none';
      detailTelegramBtn.style.opacity = botUrl ? '1' : '.45';

      botCountLabelEl.textContent = `${bots.length} ботов`;
      broadcastRecipientsEl.textContent = `📣 ${family.recipients_count ?? 0} получателей`;
      broadcastTextEl.value = '';
      broadcastResultEl.textContent = '';
      if (!bots.length) {
        botListEl.innerHTML = '<div class="empty-state">Ботов пока нет.</div>';
      } else {
        botListEl.innerHTML = bots.slice(0, 8).map((bot) => {
          const username = bot.bot_username ? `@${bot.bot_username}` : 'без username';
          const status = bot.is_paused ? 'warn' : 'good';
          const statusText = bot.is_paused ? 'Пауза' : 'Активен';
          return `
            <div class="bot-item">
              <div class="bot-main">
                <div class="name">${escapeHtml(bot.bot_name || bot.template?.shop_name || 'Bot')}</div>
                <div class="meta">${escapeHtml(username)} · ID ${escapeHtml(bot.bot_id || '-')}</div>
              </div>
              <span class="bot-status ${status}">${statusText}</span>
            </div>
          `;
        }).join('');
      }

      familyAdminsListEl.innerHTML = admins.length
        ? admins.map((adminId) => `
            <span class="admin-pill">
              <span>${escapeHtml(adminId)}</span>
              <button type="button" data-remove-family-admin="${escapeHtml(adminId)}" aria-label="Remove family admin">×</button>
            </span>
          `).join('')
        : '<div class="muted">У семьи пока нет админов.</div>';

      globalAdminsCountEl.textContent = String((state.bootstrap && state.bootstrap.settings && state.bootstrap.settings.global_admin_ids || []).length);
      globalAdminsListEl.innerHTML = (state.bootstrap && state.bootstrap.settings && state.bootstrap.settings.global_admin_ids || []).length
        ? (state.bootstrap.settings.global_admin_ids || []).map((adminId) => `
            <span class="admin-pill">
              <span>${escapeHtml(adminId)}</span>
              <button type="button" data-remove-admin="${escapeHtml(adminId)}" aria-label="Remove admin">×</button>
            </span>
          `).join('')
        : '<div class="muted">Глобальных админов пока нет.</div>';

      const cloneTokens = (state.bootstrap && state.bootstrap.settings && state.bootstrap.settings.clone_bot_tokens) || [];
      cloneCountEl.textContent = String(cloneTokens.length);
      cloneTokenListEl.innerHTML = cloneTokens.length
        ? cloneTokens.map((token) => `
            <span class="admin-pill"><span>${escapeHtml(token.slice(0, 10))}…${escapeHtml(token.slice(-6))}</span></span>
          `).join('')
        : '<div class="muted">Клонов пока нет.</div>';

      globalAdminsListEl.querySelectorAll('[data-remove-admin]').forEach((button) => {
        button.addEventListener('click', async () => {
          const adminId = button.getAttribute('data-remove-admin');
          await mutateGlobalAdmin('remove', adminId);
        });
      });

      familyAdminsListEl.querySelectorAll('[data-remove-family-admin]').forEach((button) => {
        button.addEventListener('click', async () => {
          const adminId = button.getAttribute('data-remove-family-admin');
          await mutateFamilyAdmin('remove', adminId);
        });
      });
    }

    function renderAll() {
      renderMetrics();
      renderStatus();
      renderFamilies();
      renderSelected();
    }

    async function fetchJson(url, options = {}) {
      const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options,
      });
      const text = await response.text();
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch (error) {
        data = text;
      }
      if (!response.ok) {
        throw new Error(typeof data === 'object' && data && data.detail ? data.detail : text || `HTTP ${response.status}`);
      }
      return data;
    }

    async function loadBootstrap() {
      const initData = telegram ? telegram.initData : '';
      const url = new URL('api/bootstrap', appBase);
      if (initData) {
        url.searchParams.set('init_data', initData);
      }
      state.bootstrap = await fetchJson(url);
      const families = state.bootstrap.families || [];
      if (families.length) {
        if (!families.some((family) => family.key === state.selectedKey)) {
          state.selectedKey = state.bootstrap.selected_key || families[0].key;
        }
      }
      renderAll();
      showToast('Панель загружена', 'good');
    }

    async function mutateGlobalAdmin(action, adminId) {
      try {
        const url = new URL('api/central/global-admins', appBase);
        if (telegram && telegram.initData) {
          url.searchParams.set('init_data', telegram.initData);
        }
        await fetchJson(url, {
          method: 'POST',
          body: JSON.stringify({ action, admin_id: Number(adminId) }),
        });
        showToast(action === 'add' ? 'Глобальный админ добавлен' : 'Глобальный админ удалён', 'good');
        await loadBootstrap();
      } catch (error) {
        showToast(error.message || 'Failed to update admin', 'bad');
      }
    }

    async function mutateFamilyAdmin(action, adminId) {
      const family = selectedFamily();
      if (!family) return;
      try {
        const url = new URL(`api/family/${family.key}`, appBase);
        if (telegram && telegram.initData) {
          url.searchParams.set('init_data', telegram.initData);
        }
        const admins = new Set((family.admin_ids || []).map((item) => Number(item)).filter((item) => Number.isFinite(item)));
        const adminIdNumber = Number(adminId);
        if (!Number.isFinite(adminIdNumber)) {
          throw new Error('admin_id must be an integer');
        }
        if (action === 'add') {
          admins.add(adminIdNumber);
        } else if (action === 'remove') {
          admins.delete(adminIdNumber);
        }
        await fetchJson(url, {
          method: 'PATCH',
          body: JSON.stringify({ admin_ids: Array.from(admins).sort((a, b) => a - b) }),
        });
        showToast(action === 'add' ? 'Админ семьи добавлен' : 'Админ семьи удалён', 'good');
        await loadBootstrap();
        openFamilyModal();
      } catch (error) {
        showToast(error.message || 'Не удалось обновить семью', 'bad');
      }
    }

    async function addGlobalAdmin() {
      const raw = globalAdminInput.value.trim();
      if (!raw) {
        showToast('Введите Telegram ID', 'bad');
        return;
      }
      if (!/^\\d+$/.test(raw)) {
        showToast('Telegram ID должен быть числом', 'bad');
        return;
      }
      await mutateGlobalAdmin('add', raw);
      globalAdminInput.value = '';
    }

    copySelectedBtn.addEventListener('click', async (event) => {
      event.preventDefault();
      const family = selectedFamily();
      if (!family) return;
      const text = `${family.label} · ${familyShopName(family)} · ботов: ${family.bots_count || 0}`;
      try {
        await navigator.clipboard.writeText(text);
        showToast('Сводка семьи скопирована', 'good');
      } catch (error) {
        showToast('Буфер обмена недоступен', 'bad');
      }
    });

    openFamilyBtn.addEventListener('click', () => {
      const family = selectedFamily();
      if (!family) return;
      const firstBot = (family.bots || [])[0] || {};
      const url = botUsernameUrl(firstBot.bot_username || '');
      if (url) {
        window.open(url, '_blank', 'noopener,noreferrer');
      } else {
        showToast('У семьи нет Telegram username', 'bad');
      }
    });

    modalCloseBtn.addEventListener('click', closeFamilyModal);
    familyModalBackdropEl.addEventListener('click', (event) => {
      if (event.target === familyModalBackdropEl) {
        closeFamilyModal();
      }
    });

    addFamilyAdminBtn.addEventListener('click', async () => {
      const raw = familyAdminInput.value.trim();
      if (!raw) {
        showToast('Введите Telegram ID', 'bad');
        return;
      }
      if (!/^\\d+$/.test(raw)) {
        showToast('Telegram ID должен быть числом', 'bad');
        return;
      }
      await mutateFamilyAdmin('add', raw);
      familyAdminInput.value = '';
    });
    refreshBtn.addEventListener('click', async () => {
      refreshBtn.disabled = true;
      try {
        await loadBootstrap();
      } catch (error) {
      showToast(error.message || 'Не удалось обновить панель', 'bad');
      } finally {
        refreshBtn.disabled = false;
      }
    });

    clearSearchBtn.addEventListener('click', () => {
      familySearchEl.value = '';
      state.search = '';
      renderFamilies();
    });

    familySearchEl.addEventListener('input', () => {
      state.search = familySearchEl.value;
      renderFamilies();
    });

    addGlobalAdminBtn.addEventListener('click', addGlobalAdmin);
    globalAdminInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        addGlobalAdmin();
      }
    });

    familyAdminInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        addFamilyAdminBtn.click();
      }
    });

    sendBroadcastBtn.addEventListener('click', async () => {
      const family = selectedFamily();
      if (!family) return;
      const text = broadcastTextEl.value.trim();
      if (!text) {
        showToast('Введите текст рассылки', 'bad');
        return;
      }
      const recipients = family.recipients_count ?? 0;
      if (!confirm(`Разослать рассылку ${recipients} получателям семейства «${familyDisplayName(family)}»? Это действие нельзя отменить.`)) {
        return;
      }
      sendBroadcastBtn.disabled = true;
      const originalLabel = sendBroadcastBtn.textContent;
      sendBroadcastBtn.textContent = '⏳ Отправка...';
      broadcastResultEl.textContent = '';
      try {
        const url = new URL(`api/family/${family.key}/broadcast`, appBase);
        if (telegram && telegram.initData) {
          url.searchParams.set('init_data', telegram.initData);
        }
        const result = await fetchJson(url, {
          method: 'POST',
          body: JSON.stringify({ text }),
        });
        const sent = result && result.sent_count != null ? result.sent_count : (result && result.recipients_count);
        const failed = result && result.failed_count != null ? result.failed_count : 0;
        broadcastResultEl.textContent = `✅ Отправлено: ${sent ?? '?'}, ошибок: ${failed}`;
        showToast('Рассылка завершена', 'good');
      } catch (error) {
        broadcastResultEl.textContent = `⚠ ${error.message || 'Ошибка рассылки'}`;
        showToast(error.message || 'Не удалось сделать рассылку', 'bad');
      } finally {
        sendBroadcastBtn.disabled = false;
        sendBroadcastBtn.textContent = originalLabel;
      }
    });

    loadBootstrap().catch((error) => {
      showToast(error.message || 'Не удалось загрузить панель', 'bad');
      statusRowEl.innerHTML = '<span class="pill">⚠ <strong>Ошибка</strong> загрузки</span>';
      familyListEl.innerHTML = `<div class="empty-state">${escapeHtml(error.message || 'Ошибка')}</div>`;
    });
  </script>
</body>
</html>
"""


async def handle_index(_: web.Request) -> web.Response:
    return web.Response(text=PAGE_HTML, content_type="text/html")


def create_app() -> web.Application:
    app = web.Application(client_max_size=2 * 1024 * 1024)
    app["dev_bypass"] = ALLOW_INSECURE
    app.router.add_get("/", handle_index)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/api/bootstrap", handle_bootstrap)
    app.router.add_get("/api/family/{family_key}", handle_family)
    app.router.add_patch("/api/family/{family_key}", handle_family)
    app.router.add_post("/api/family/{family_key}/broadcast", handle_family_broadcast)
    app.router.add_post("/api/central/global-admins", handle_global_admins)
    return app


def main() -> None:
    app = create_app()
    web.run_app(app, host=DEFAULT_WEBAPP_HOST, port=DEFAULT_WEBAPP_PORT)


if __name__ == "__main__":
    main()
