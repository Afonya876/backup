from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass
from functools import wraps
from html import escape
from pathlib import Path
from typing import Any

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, ErrorEvent, InlineKeyboardButton, InlineKeyboardMarkup, Message, MessageEntity, WebAppInfo
from dotenv import dotenv_values, load_dotenv


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = Path(__file__).resolve().with_name(".env")
SETTINGS_PATH = Path(__file__).resolve().with_name("central_admin_state.json")
DEFAULT_WEBAPP_URL = "https://144-31-53-210.sslip.io/central-admin/"


@dataclass(frozen=True, slots=True)
class FamilyService:
    key: str
    label: str
    env_path: Path
    base_url_env: str
    api_key_env: str


# Реестр семейных ботов. В gray_v2 он пуст — это чистый шаблон.
# Добавляйте сюда свои боты по образцу:
#     "mybot": FamilyService(
#         "mybot", "MyBot",
#         ROOT_DIR / "bots" / "MyBot" / ".env",
#         "MYBOT_API_BASE", "MYBOT_API_KEY",
#     ),
# и пропишите соответствующие *_API_BASE / *_API_KEY в .env.
SERVICES: dict[str, FamilyService] = {
    "kfc": FamilyService(
        "kfc",
        "monster-1",
        ROOT_DIR.parent / "KFC" / ".env",
        "KFC_API_BASE",
        "KFC_API_KEY",
    ),
    "kfc2": FamilyService(
        "kfc2",
        "monster-2 (UA)",
        ROOT_DIR.parent / "KFC2" / ".env",
        "KFC2_API_BASE",
        "KFC2_API_KEY",
    ),
    "vip1": FamilyService(
        "vip1",
        "VIP1",
        ROOT_DIR.parent / "KFC_vip1" / ".env",
        "VIP1_API_BASE",
        "VIP1_API_KEY",
    ),
    "centurypass6": FamilyService(
        "centurypass6",
        "CENTURYPASS6",
        ROOT_DIR.parent / "centurypass6" / ".env",
        "CENTURYPASS6_API_BASE",
        "CENTURYPASS6_API_KEY",
    ),
    "evila": FamilyService(
        "evila",
        "EVILA",
        ROOT_DIR.parent / "evila_bot" / ".env",
        "EVILA_API_BASE",
        "EVILA_API_KEY",
    ),
    "bgreenday": FamilyService(
        "bgreenday",
        "B_Green_Day (UA)",
        ROOT_DIR.parent / "B_Green_Day" / ".env",
        "BGREENDAY_API_BASE",
        "BGREENDAY_API_KEY",
    ),
    "flame4gngcxk": FamilyService(
        "flame4gngcxk",
        "Pirate Bay",
        ROOT_DIR.parent / "flame4gngcxk" / ".env",
        "FLAME4GNGCXK_API_BASE",
        "FLAME4GNGCXK_API_KEY",
    ),
    "ugtop20": FamilyService(
        "ugtop20",
        "UGTOP20",
        ROOT_DIR.parent / "ugtop20_probot" / ".env",
        "UGTOP20_API_BASE",
        "UGTOP20_API_KEY",
    ),
}

TEMPLATE_FIELD_LABELS = {
    "shop_name": "🏷 Название магазина",
    "operator_username": "👤 Юзер сапорта",
    "payment_support_username": "💳 Юзер оплаты",
    "operator_url": "🔗 Ссылка оператора",
    "work_url": "💼 Ссылка работа",
    "site_text": "📝 Текст сайта",
    "neon_price_url": "💸 Ссылка прайса",
    "vip_price_url": "💲 Ссылка Прайс",
    "reviews_url": "👍 Ссылка Отзывы",
    "info_url": "ℹ️ Ссылка Инфо",
    "giveaway_url": "🎁 Ссылка Розыгрыши",
    "site_url": "🌐 Ссылка Сайт-инфо",
    "chat_url": "👤 Ссылка Чат",
    "complaints_url": "😈 Ссылка Жалобы",
    "questions_url": "❓ Ссылка Вопросы",
    "payment_support_url": "🩺 Ссылка саппорт оплаты",
    "vacancy_rules_url": "📃 Ссылка условия вакансии",
    "vacancy_apply_url": "✅ Ссылка устроиться",
    "global24_pay_url": "♻️ Ссылка Global24",
    "contacts_text": "📞 Контакты",
    "exchangers_text": "💱 Текст обменников",
    "exchange_links_text": "💱 Текст обменников",
    "exchange_text": "💱 Текст обменников",
    "medicine_text": "⛑️ Текст медицины",
    "start_text": "✨ Стартовый текст",
    "work_button_text": "🧩 Кнопка Работа",
    "work_text": "📝 Текст Работа",
}
TEMPLATE_FIELD_LABEL_OVERRIDES_BY_FAMILY: dict[str, dict[str, str]] = {
    "bignewsanders": {
        "vip_price_url": "🕸 Ссылка Kraken",
        "exchangers_text": "💱 Текст обменников",
        "exchange_links_text": "💱 Текст обменников",
    },
    "kissmyacid": {
        "vip_price_url": "🕸 Ссылка Kraken",
        "exchangers_text": "💱 Текст обменников",
        "exchange_links_text": "💱 Текст обменников",
    },
    "samurai": {
        "vip_price_url": "🕸 Ссылка Kraken",
        "exchangers_text": "💱 Текст обменников",
        "exchange_links_text": "💱 Текст обменников",
    },
    "tds24": {
        "exchange_links_text": "💱 Текст обменников",
    },
    "solo": {
        "work_url": "💼 Ссылка дохода",
        "site_text": "📝 Текст сайта",
        "reviews_url": "⭐ Ссылка отзывов",
        "operator_url": "🛍 Ссылка оператора",
        "work_button_text": "💸 Текст кнопки дохода",
    },
}
HIDDEN_TEMPLATE_FIELDS_BY_FAMILY: dict[str, set[str]] = {
    "lepricon": {"work_button_text", "work_text"},
}
LEGACY_CARD_REQUISITES_PLACEHOLDER = "CARD_NUMBER_HERE"
LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER = "USDT_TRC20_WALLET_HERE"
LEGACY_LTC_REQUISITES_PLACEHOLDER = "LTC_WALLET_HERE"
_CARD_REQUISITES_PATTERN = re.compile(
    rf"(?<!\d)(?P<card>\d(?:[\s-]?\d){{11,18}}|{re.escape(LEGACY_CARD_REQUISITES_PLACEHOLDER)})(?!\d)",
    re.IGNORECASE,
)
_BTC_WALLET_REQUISITES_PATTERN = re.compile(
    r"(?<![A-Za-z0-9])(?P<wallet>bc1[ac-hj-np-z02-9]{20,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})(?=\s|$)",
    re.IGNORECASE,
)
_ETH_WALLET_REQUISITES_PATTERN = re.compile(
    r"(?<![A-Za-z0-9])(?P<wallet>0x[a-fA-F0-9]{40})(?=\s|$)",
    re.IGNORECASE,
)
_TRC20_WALLET_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>T[A-Za-z0-9]{{20,}}|{re.escape(LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER)})(?=\s|$)",
    re.IGNORECASE,
)
_LTC_WALLET_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>(?:ltc1[ac-hj-np-z02-9]{{10,}}|[LM3][a-km-zA-HJ-NP-Z1-9]{{26,33}}|{re.escape(LEGACY_LTC_REQUISITES_PLACEHOLDER)}))(?=\s|$)",
    re.IGNORECASE,
)
_BLIK_REQUISITES_PATTERN = re.compile(r"(?P<prefix>BLIK:\s*)(?P<value>\d{6,12})", re.IGNORECASE)
_GENERIC_REQUISITES_PLACEHOLDER_PATTERN = re.compile(r"\{requisites\}", re.IGNORECASE)
_TELEGRAM_USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{4,32}$")
TOKEN_RE = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{20,}$")


class AdminState(StatesGroup):
    waiting_value = State()


class ServiceError(RuntimeError):
    pass


ADMIN_IDS_CACHE_TTL = 60.0
ERROR_MESSAGE_MAX_LEN = 700
BOTS_PAGE_SIZE = 20
TELEGRAM_TEXT_LIMIT_SAFE = 3500
_admin_ids_cache: set[int] = set()
_admin_ids_cache_deadline = 0.0
_admin_ids_lock = asyncio.Lock()
_settings_lock = asyncio.Lock()

CUSTOM_EMOJI_ICONS: dict[str, tuple[str, str]] = {
    "nav": ("🧭", "6030687898141987254"),
    "settings": ("⚙️", "5904258298764334001"),
    "admins": ("👥", "6032609071373226027"),
    "person": ("👤", "6032994772321309200"),
    "family": ("🏷", "5888620056551625531"),
    "bots": ("🤖", "6030400221232501136"),
    "payments": ("💰", "5778421276024509124"),
    "catalog": ("🗂", "5766994197705921104"),
    "broadcast": ("📣", "6039450962865688331"),
    "add": ("➕", "6032924188828767321"),
    "edit": ("✏️", "6039779802741739617"),
    "delete": ("🗑", "6039522349517115015"),
    "back": ("⬅️", "6039539366177541657"),
    "forward": ("➡️", "5895383238473421210"),
    "start": ("▶️", "5773626993010546707"),
    "pause": ("🚫", "5938215362473496448"),
    "link": ("🔗", "6028171274939797252"),
    "pin": ("📍", "6030399199030284183"),
    "extra": ("💬", "6030784887093464891"),
    "success": ("✅", "5774022692642492953"),
    "inbox": ("📥", "6041730074376410123"),
    "clock": ("🕓", "5775896410780079073"),
    "lock": ("🔒", "6037249452824072506"),
    "note": ("📝", "5920046907782074235"),
    "store": ("🏪", "5920332557466997677"),
    "briefcase": ("💼", "5938492039971737551"),
    "map": ("🗺", "5904650558127478452"),
    "info": ("ℹ", "6028435952299413210"),
}

TEMPLATE_FIELD_ICON_BY_NAME: dict[str, str] = {
    "shop_name": "store",
    "operator_username": "person",
    "payment_support_username": "payments",
    "operator_url": "link",
    "work_url": "briefcase",
    "site_url": "link",
    "site_text": "note",
    "info_channel_url": "info",
    "neon_price_url": "payments",
    "vip_price_url": "payments",
    "reviews_url": "success",
    "info_url": "info",
    "giveaway_url": "link",
    "contacts_text": "person",
    "exchangers_text": "payments",
    "exchange_links_text": "payments",
    "start_text": "note",
    "work_button_text": "briefcase",
    "work_text": "note",
}


def parse_admin_ids(raw_value: str | None) -> set[int]:
    values: set[int] = set()
    if not raw_value:
        return values
    for chunk in raw_value.replace(" ", "").split(","):
        if not chunk:
            continue
        try:
            values.add(int(chunk))
        except ValueError:
            logger.warning("Skipping invalid admin id from env: %r", chunk)
    return values


def ce(name: str) -> str:
    emoji, custom_emoji_id = CUSTOM_EMOJI_ICONS[name]
    return f'<tg-emoji emoji-id="{custom_emoji_id}">{emoji}</tg-emoji>'


# Bot API 9.4+ button colors, assigned by semantic role (success=green, danger=red, primary=blue).
_BUTTON_STYLE_BY_EMOJI = {
    "add": "success",
    "family": "success",
    "delete": "danger",
    "edit": "primary",
    "payments": "primary",
    "admins": "primary",
    "bots": "primary",
    "catalog": "primary",
    "settings": "primary",
    "extra": "primary",
    "broadcast": "primary",
    "map": "primary",
}


def custom_button(
    text: str,
    *,
    callback_data: str | None = None,
    url: str | None = None,
    web_app: WebAppInfo | None = None,
    emoji_name: str | None = None,
    style: str | None = None,
) -> InlineKeyboardButton:
    payload: dict[str, Any] = {"text": text}
    if callback_data is not None:
        payload["callback_data"] = callback_data
    if url is not None:
        payload["url"] = url
    if web_app is not None:
        payload["web_app"] = web_app
    if emoji_name is not None:
        payload["icon_custom_emoji_id"] = CUSTOM_EMOJI_ICONS[emoji_name][1]
    resolved_style = style or _BUTTON_STYLE_BY_EMOJI.get(emoji_name or "")
    if resolved_style is not None and web_app is None:
        payload["style"] = resolved_style
    return InlineKeyboardButton(**payload)


def resolve_webapp_url() -> str:
    env = dotenv_values(ENV_PATH)
    raw = str(env.get("CENTRAL_WEBAPP_URL") or os.getenv("CENTRAL_WEBAPP_URL") or "").strip()
    if raw.startswith("https://"):
        return raw
    if raw:
        logger.warning("Ignoring non-HTTPS CENTRAL_WEBAPP_URL=%s", raw)
    return DEFAULT_WEBAPP_URL


def normalize_central_url(raw: str) -> str | None:
    value = (raw or "").strip()
    if not value:
        return None
    if value.casefold() in {"-", "нет", "none", "null"}:
        return ""  # clear the field
    if value.startswith("@"):
        handle = value[1:].strip()
        return f"https://t.me/{handle}" if handle else None
    if value.startswith(("http://", "https://")):
        return value
    if value.startswith(("t.me/", "telegram.me/")):
        return f"https://{value}"
    if re.fullmatch(r"[A-Za-z0-9_]{4,32}", value):
        return f"https://t.me/{value}"
    if "." in value and " " not in value:
        return f"https://{value}"
    return None


def strip_icon_prefix(label: str) -> str:
    parts = str(label).split(" ", 1)
    if len(parts) == 2 and any(not char.isalnum() for char in parts[0]):
        return parts[1]
    return str(label)


def resolve_template_field_button_text(family_key: str, field_name: str) -> str:
    return strip_icon_prefix(resolve_template_field_label(family_key, field_name))


def resolve_template_field_emoji_name(field_name: str) -> str | None:
    return TEMPLATE_FIELD_ICON_BY_NAME.get(field_name)


def fit_text_for_telegram(text: str, limit: int = TELEGRAM_TEXT_LIMIT_SAFE) -> str:
    if len(text) <= limit:
        return text
    suffix = "\n\n<i>Текст сокращён в админке, чтобы Telegram принял сообщение.</i>"
    available = max(limit - len(suffix), 0)
    shortened = text[:available].rstrip()
    return f"{shortened}{suffix}"


def normalize_clone_tokens(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    tokens: list[str] = []
    seen: set[str] = set()
    for value in values:
        token = str(value or "").strip()
        if TOKEN_RE.fullmatch(token) is None or token in seen:
            continue
        seen.add(token)
        tokens.append(token)
    return tokens


def normalize_central_settings(payload: Any) -> dict[str, Any]:
    data = payload if isinstance(payload, dict) else {}
    return {
        "global_admin_ids": sorted({admin_id for admin_id in data.get("global_admin_ids", []) if isinstance(admin_id, int)}),
        "clone_bot_tokens": normalize_clone_tokens(data.get("clone_bot_tokens", [])),
    }


async def load_central_settings() -> dict[str, Any]:
    async with _settings_lock:
        if not SETTINGS_PATH.exists():
            return normalize_central_settings(None)
        try:
            payload = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Could not read %s: %s", SETTINGS_PATH, exc)
            return normalize_central_settings(None)
        return normalize_central_settings(payload)


async def save_central_settings(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = normalize_central_settings(payload)
    async with _settings_lock:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(
            json.dumps(normalized, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return normalized


def invalidate_admin_ids_cache() -> None:
    global _admin_ids_cache, _admin_ids_cache_deadline
    _admin_ids_cache = set()
    _admin_ids_cache_deadline = 0.0


async def propagate_global_admin_id(admin_id: int, *, add: bool) -> list[str]:
    errors: list[str] = []
    for family_key, service in SERVICES.items():
        try:
            family = await fetch_family(family_key)
            admin_ids = sorted({item for item in family.get("admin_ids", []) if isinstance(item, int)})
            updated_admin_ids = sorted(set(admin_ids + [admin_id])) if add else [item for item in admin_ids if item != admin_id]
            if updated_admin_ids != admin_ids:
                await update_family(family_key, {"admin_ids": updated_admin_ids})
        except ServiceError as exc:
            errors.append(f"{service.label}: {exc}")
    return errors


async def ensure_global_admins_synced() -> None:
    startup_sync_enabled = os.getenv("CENTRAL_SYNC_GLOBAL_ADMINS_ON_START", "").strip().casefold()
    if startup_sync_enabled not in {"1", "true", "yes", "on"}:
        logger.warning("Startup global admin sync is disabled; skipping family PATCH on boot")
        return
    settings = await load_central_settings()
    for admin_id in settings["global_admin_ids"]:
        errors = await propagate_global_admin_id(admin_id, add=True)
        if errors:
            logger.warning("Could not sync global admin %s everywhere: %s", admin_id, "; ".join(errors))


def mask_bot_token(token: str) -> str:
    prefix, _, suffix = token.partition(":")
    if not suffix:
        return token[:6]
    if len(suffix) <= 10:
        return f"{prefix}:{suffix}"
    return f"{prefix}:{suffix[:4]}...{suffix[-4:]}"


async def restart_process(delay: float = 0.8) -> None:
    await asyncio.sleep(delay)
    logger.warning("Restarting central admin process to apply clone token changes")
    os.execv(sys.executable, [sys.executable, *sys.argv])


def resolve_service_env_path(service: FamilyService) -> Path | None:
    family_dir_name = service.env_path.parent.name
    candidates = [
        service.env_path,
        ROOT_DIR / family_dir_name / ".env",
        ROOT_DIR.parent / family_dir_name / ".env",
    ]
    seen: set[Path] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.exists():
            return candidate
    return None


def get_service_config(family_key: str) -> dict[str, str]:
    service = SERVICES[family_key]
    explicit_base_url = os.getenv(service.base_url_env)
    explicit_api_key = os.getenv(service.api_key_env)
    if explicit_base_url:
        return {
            "base_url": explicit_base_url.rstrip("/"),
            "api_key": explicit_api_key or os.getenv("CENTRAL_DEFAULT_API_KEY") or "change-me",
        }
    env_path = resolve_service_env_path(service)
    env = dotenv_values(env_path) if env_path is not None else {}
    return {
        "base_url": f"http://{env.get('API_HOST', '127.0.0.1')}:{env.get('API_PORT', '8000')}",
        "api_key": str(env.get("MASTER_API_KEY") or "change-me"),
    }


def resolve_local_family_root(family_key: str) -> Path | None:
    service = SERVICES[family_key]
    env_path = resolve_service_env_path(service)
    if env_path is None:
        return None
    root = env_path.parent
    return root if root.exists() else None


def resolve_local_family_data_path(family_key: str, filename: str) -> Path | None:
    root = resolve_local_family_root(family_key)
    if root is None:
        return None
    path = root / "data" / filename
    return path


def resolve_local_family_settings_path(family_key: str) -> Path | None:
    candidates = [
        resolve_local_family_data_path(family_key, "shared_settings.json"),
        resolve_local_family_data_path(family_key, "family.json"),
    ]
    for candidate in candidates:
        if candidate is not None and candidate.exists():
            return candidate
    return candidates[0] or candidates[1]


def resolve_local_family_bots_path(family_key: str) -> Path | None:
    candidates = [
        resolve_local_family_data_path(family_key, "bots.json"),
        resolve_local_family_data_path(family_key, "bots.local.json"),
    ]
    for candidate in candidates:
        if candidate is not None and candidate.exists():
            return candidate
    return candidates[0] or candidates[1]


def _safe_read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _safe_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(f"{path.suffix}.tmp")
    temp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp_path.replace(path)


def can_use_local_family_fallback(family_key: str) -> bool:
    return resolve_local_family_root(family_key) is not None


def load_local_family_payload(family_key: str) -> dict[str, Any]:
    family_path = resolve_local_family_settings_path(family_key)
    bots_path = resolve_local_family_bots_path(family_key)
    family = _safe_read_json(family_path, {}) if family_path is not None else {}
    bots = _safe_read_json(bots_path, []) if bots_path is not None else []
    if not isinstance(family, dict):
        family = {}
    if not isinstance(bots, list):
        bots = []
    return {
        "template": family.get("template", {}) if isinstance(family.get("template"), dict) else {},
        "admin_ids": family.get("admin_ids", []) if isinstance(family.get("admin_ids"), list) else [],
        "payment_methods": family.get("payment_methods", []) if isinstance(family.get("payment_methods"), list) else [],
        "bots_count": len(bots),
        "running_count": 0,
        "recipients_count": 0,
        "bots": [item for item in bots if isinstance(item, dict)],
    }


def save_local_family_payload(family_key: str, payload: dict[str, Any]) -> dict[str, Any]:
    family_path = resolve_local_family_settings_path(family_key)
    bots_path = resolve_local_family_bots_path(family_key)
    if family_path is None or bots_path is None:
        raise ServiceError(f"{SERVICES[family_key].label}: локальные файлы семейства не найдены")

    family = _safe_read_json(family_path, {})
    bots = _safe_read_json(bots_path, [])
    if not isinstance(family, dict):
        family = {}
    if not isinstance(bots, list):
        bots = []

    if "template" in payload and isinstance(payload["template"], dict):
        family["template"] = payload["template"]
        for bot in bots:
            if isinstance(bot, dict):
                bot["template"] = json.loads(json.dumps(payload["template"], ensure_ascii=False))
    if "admin_ids" in payload and isinstance(payload["admin_ids"], list):
        family["admin_ids"] = payload["admin_ids"]
        for bot in bots:
            if isinstance(bot, dict):
                bot["admin_ids"] = list(payload["admin_ids"])
    if "payment_methods" in payload and isinstance(payload["payment_methods"], list):
        family["payment_methods"] = payload["payment_methods"]
        for bot in bots:
            if isinstance(bot, dict):
                bot["payment_methods"] = json.loads(json.dumps(payload["payment_methods"], ensure_ascii=False))

    _safe_write_json(family_path, family)
    _safe_write_json(bots_path, bots)
    return load_local_family_payload(family_key)


def load_local_catalog_payload(family_key: str) -> dict[str, Any]:
    catalog_path = resolve_local_family_data_path(family_key, "catalog.json")
    cities = _safe_read_json(catalog_path, []) if catalog_path is not None else []
    if not isinstance(cities, list):
        cities = []
    return {"cities": cities}


def save_local_catalog_payload(family_key: str, cities: list[dict[str, Any]]) -> dict[str, Any]:
    catalog_path = resolve_local_family_data_path(family_key, "catalog.json")
    if catalog_path is None:
        raise ServiceError(f"{SERVICES[family_key].label}: локальный каталог семейства не найден")
    _safe_write_json(catalog_path, cities)
    return load_local_catalog_payload(family_key)


async def api_request(
    family_key: str,
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
    timeout_total: int = 20,
) -> Any:
    config = get_service_config(family_key)
    timeout = aiohttp.ClientTimeout(total=timeout_total)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.request(
                method,
                f"{config['base_url']}{path}",
                headers={"X-API-Key": config["api_key"]},
                json=json_body,
            ) as response:
                if response.status == 204:
                    return None
                raw_payload = await response.text()
                try:
                    payload = json.loads(raw_payload) if raw_payload else {}
                except json.JSONDecodeError as exc:
                    logger.error(
                        "Non-JSON response from %s %s%s: status=%s body=%r",
                        SERVICES[family_key].label,
                        method,
                        path,
                        response.status,
                        raw_payload[:500],
                    )
                    raise ServiceError(
                        f"{SERVICES[family_key].label}: API вернул некорректный ответ (status {response.status})"
                    ) from exc
                if response.status >= 400:
                    raise ServiceError(f"{SERVICES[family_key].label}: {payload.get('detail', payload)}")
                return payload
    except asyncio.TimeoutError as exc:
        raise ServiceError(f"{SERVICES[family_key].label}: API не ответил за {timeout_total}с") from exc
    except aiohttp.ClientError as exc:
        raise ServiceError(f"{SERVICES[family_key].label}: API недоступен ({exc})") from exc


async def fetch_family(family_key: str) -> dict[str, Any]:
    try:
        payload = await api_request(family_key, "GET", "/admin/family")
        return payload if isinstance(payload, dict) else {}
    except ServiceError:
        if can_use_local_family_fallback(family_key):
            logger.warning("Using local family fallback for %s", family_key)
            return load_local_family_payload(family_key)
        raise


async def update_family(family_key: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        await api_request(family_key, "PATCH", "/admin/family", json_body=payload)
        return await fetch_family(family_key)
    except ServiceError:
        if can_use_local_family_fallback(family_key):
            logger.warning("Using local family write fallback for %s", family_key)
            return save_local_family_payload(family_key, payload)
        raise


async def broadcast_family(family_key: str, text: str) -> dict[str, Any]:
    result = await api_request(
        family_key,
        "POST",
        "/admin/family/broadcast",
        json_body={"text": text},
        timeout_total=180,
    )
    return result if isinstance(result, dict) else {}


async def fetch_family_catalog(family_key: str) -> list[dict[str, Any]]:
    try:
        payload = await api_request(family_key, "GET", "/admin/family/catalog")
        if not isinstance(payload, dict):
            return []
        cities = payload.get("cities", [])
        return cities if isinstance(cities, list) else []
    except ServiceError:
        if can_use_local_family_fallback(family_key):
            logger.warning("Using local catalog fallback for %s", family_key)
            payload = load_local_catalog_payload(family_key)
            cities = payload.get("cities", [])
            return cities if isinstance(cities, list) else []
        raise


async def update_family_catalog(family_key: str, cities: list[dict[str, Any]]) -> list[dict[str, Any]]:
    try:
        payload = await api_request(family_key, "PUT", "/admin/family/catalog", json_body={"cities": cities})
        if not isinstance(payload, dict):
            return []
        result = payload.get("cities", [])
        return result if isinstance(result, list) else []
    except ServiceError:
        if can_use_local_family_fallback(family_key):
            logger.warning("Using local catalog write fallback for %s", family_key)
            payload = save_local_catalog_payload(family_key, cities)
            result = payload.get("cities", [])
            return result if isinstance(result, list) else []
        raise


async def create_family_bot(family_key: str, token: str) -> dict[str, Any]:
    result = await api_request(family_key, "POST", "/bots", json_body={"token": token})
    return result if isinstance(result, dict) else {}


async def fetch_family_bot(family_key: str, bot_id: int) -> dict[str, Any]:
    result = await api_request(family_key, "GET", f"/admin/bots/{bot_id}")
    return result if isinstance(result, dict) else {}


async def update_family_bot(family_key: str, bot_id: int, payload: dict[str, Any]) -> dict[str, Any]:
    result = await api_request(family_key, "PATCH", f"/admin/bots/{bot_id}", json_body=payload)
    return result if isinstance(result, dict) else {}


async def delete_family_bot(family_key: str, bot_id: int) -> None:
    await api_request(family_key, "DELETE", f"/admin/bots/{bot_id}")


async def refresh_admin_ids() -> set[int]:
    admin_ids = parse_admin_ids(os.getenv("CENTRAL_ADMIN_IDS"))
    settings = await load_central_settings()
    admin_ids.update(settings["global_admin_ids"])

    async def load_family_admins(family_key: str) -> set[int]:
        try:
            family = await fetch_family(family_key)
        except ServiceError as exc:
            logger.warning("Admin ids fetch failed for %s: %s", family_key, exc)
            return set()
        return {admin_id for admin_id in family.get("admin_ids", []) if isinstance(admin_id, int)}

    results = await asyncio.gather(*(load_family_admins(family_key) for family_key in SERVICES))
    for family_admin_ids in results:
        admin_ids.update(family_admin_ids)
    return admin_ids


async def resolve_admin_ids(force_refresh: bool = False) -> set[int]:
    global _admin_ids_cache, _admin_ids_cache_deadline

    now = time.monotonic()
    if not force_refresh and now < _admin_ids_cache_deadline and _admin_ids_cache:
        return set(_admin_ids_cache)

    async with _admin_ids_lock:
        now = time.monotonic()
        if not force_refresh and now < _admin_ids_cache_deadline and _admin_ids_cache:
            return set(_admin_ids_cache)
        admin_ids = await refresh_admin_ids()
        if admin_ids:
            _admin_ids_cache = set(admin_ids)
            _admin_ids_cache_deadline = time.monotonic() + ADMIN_IDS_CACHE_TTL
            return set(_admin_ids_cache)
        if _admin_ids_cache:
            logger.warning("Admin ids refresh returned empty set; using cached admins")
            _admin_ids_cache_deadline = time.monotonic() + ADMIN_IDS_CACHE_TTL
            return set(_admin_ids_cache)
        fallback_admin_ids = parse_admin_ids(os.getenv("CENTRAL_ADMIN_IDS"))
        _admin_ids_cache = set(fallback_admin_ids)
        _admin_ids_cache_deadline = time.monotonic() + ADMIN_IDS_CACHE_TTL
        return set(_admin_ids_cache)


def require_admin(func):
    @wraps(func)
    async def wrapper(event: Message | CallbackQuery, *args, **kwargs):
        user_id = event.from_user.id if event.from_user else None
        if user_id not in await resolve_admin_ids():
            if isinstance(event, Message):
                await event.answer("Доступ только для администраторов.")
            else:
                await event.answer("Доступ только для администраторов.", show_alert=True)
            return
        try:
            return await func(event, *args, **kwargs)
        except ServiceError as exc:
            logger.warning("Service error while handling %s: %s", func.__name__, exc)
            if isinstance(event, Message):
                await event.answer(escape(str(exc)))
            else:
                await event.answer(str(exc), show_alert=True)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected error while handling %s", func.__name__)
            message = build_exception_notice(exc, title="Ошибка общей админки")
            if isinstance(event, Message):
                await event.answer(message)
            else:
                try:
                    await event.answer(message, show_alert=True)
                except TelegramBadRequest:
                    if event.message is not None:
                        await event.message.answer(message)

    return wrapper


async def answer_or_edit(target: Message | CallbackQuery, text: str, reply_markup: InlineKeyboardMarkup) -> None:
    safe_text = text
    if isinstance(target, Message):
        try:
            await target.answer(safe_text, reply_markup=reply_markup, disable_web_page_preview=True)
        except TelegramBadRequest as exc:
            lowered = str(exc).casefold()
            if "message is too long" not in lowered and "message_too_long" not in lowered:
                raise
            await target.answer(fit_text_for_telegram(safe_text), reply_markup=reply_markup, disable_web_page_preview=True)
        except TelegramNetworkError:
            logger.warning("Telegram network error while answering message; retrying once")
            await asyncio.sleep(0.7)
            await target.answer(safe_text, reply_markup=reply_markup, disable_web_page_preview=True)
        return
    if target.message is None:
        logger.warning("Callback without message while trying to render UI")
        return
    try:
        await target.message.edit_text(safe_text, reply_markup=reply_markup, disable_web_page_preview=True)
    except TelegramBadRequest as exc:
        lowered = str(exc).casefold()
        try:
            fallback_text = fit_text_for_telegram(safe_text) if ("message is too long" in lowered or "message_too_long" in lowered) else safe_text
            await target.message.answer(fallback_text, reply_markup=reply_markup, disable_web_page_preview=True)
        except TelegramNetworkError:
            logger.warning("Telegram network error while sending fallback message; retrying once")
            await asyncio.sleep(0.7)
            await target.message.answer(fallback_text, reply_markup=reply_markup, disable_web_page_preview=True)
    except TelegramNetworkError:
        logger.warning("Telegram network error while editing message; retrying once")
        await asyncio.sleep(0.7)
        try:
            await target.message.edit_text(safe_text, reply_markup=reply_markup, disable_web_page_preview=True)
        except TelegramBadRequest as exc:
            fallback_text = fit_text_for_telegram(safe_text) if ("message is too long" in str(exc).casefold() or "message_too_long" in str(exc).casefold()) else safe_text
            await target.message.answer(fallback_text, reply_markup=reply_markup, disable_web_page_preview=True)


def build_main_menu() -> InlineKeyboardMarkup:
    rows = []
    webapp_url = resolve_webapp_url()
    if webapp_url:
        rows.append([custom_button("🌑 Mini App", web_app=WebAppInfo(url=webapp_url))])
    rows.append([custom_button("Настройки админки", callback_data="central_settings", emoji_name="settings")])
    rows.extend(
        [custom_button(service.label, callback_data=f"family:{key}", emoji_name="family")]
        for key, service in SERVICES.items()
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_main_text() -> str:
    return (
        f"<b>{ce('nav')} Центр управления</b>\n\n"
        f"{ce('settings')} Здесь собраны настройки общей админки и все семейства ботов.\n"
        "Выбери нужный раздел ниже."
    )


def build_central_settings_menu() -> InlineKeyboardMarkup:
    top_rows = []
    webapp_url = resolve_webapp_url()
    if webapp_url:
        top_rows.append([custom_button("🌑 Mini App", web_app=WebAppInfo(url=webapp_url))])
    return InlineKeyboardMarkup(
        inline_keyboard=top_rows
        + [
            [custom_button("Глобальные админы", callback_data="central_global_admins", emoji_name="admins")],
            [custom_button("Токены клонов админки", callback_data="central_clone_tokens", emoji_name="bots")],
            [custom_button("Назад", callback_data="main", emoji_name="back")],
        ]
    )


def build_central_settings_text(settings: dict[str, Any]) -> str:
    global_admin_ids = settings.get("global_admin_ids", [])
    clone_bot_tokens = settings.get("clone_bot_tokens", [])
    return "\n".join(
        [
            f"<b>{ce('settings')} Настройки общей админки</b>",
            "",
            f"{ce('admins')} Глобальных админов: {len(global_admin_ids)}",
            f"{ce('bots')} Клонов админки: {len(clone_bot_tokens)}",
            "",
            "Глобальные админы получают доступ к этой админке и автоматически добавляются во все семьи.",
            "Токены клонов поднимают дополнительные экземпляры этой же общей админки.",
        ]
    )


def build_central_global_admins_menu(admin_ids: list[int]) -> InlineKeyboardMarkup:
    rows = [[custom_button("Добавить глобального админа", callback_data="central_global_admin_add", emoji_name="add")]]
    rows.extend(
        [custom_button(f"Удалить {admin_id}", callback_data=f"central_global_admin_remove:{admin_id}", emoji_name="delete")]
        for admin_id in admin_ids
    )
    rows.append([custom_button("Назад", callback_data="central_settings", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_central_global_admins_text(admin_ids: list[int]) -> str:
    lines = [f"<b>{ce('admins')} Глобальные админы</b>", ""]
    if not admin_ids:
        lines.append(f"{ce('person')} Глобальных админов пока нет.")
    else:
        lines.extend(f"• <code>{admin_id}</code>" for admin_id in admin_ids)
    lines.extend(
        [
            "",
            "Эти ID считаются админами самой общей админки и одновременно применяются ко всем семьям.",
        ]
    )
    return "\n".join(lines)


def build_central_clone_tokens_menu(tokens: list[str]) -> InlineKeyboardMarkup:
    rows = [[custom_button("Добавить токен клона", callback_data="central_clone_token_add", emoji_name="add")]]
    for index, token in enumerate(tokens):
        rows.append(
            [
                custom_button(
                    text=f"Удалить {mask_bot_token(token)}",
                    callback_data=f"central_clone_token_remove:{index}",
                    emoji_name="delete",
                )
            ]
        )
    rows.append([custom_button("Назад", callback_data="central_settings", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_central_clone_tokens_text(tokens: list[str]) -> str:
    lines = [f"<b>{ce('bots')} Токены клонов общей админки</b>", ""]
    if not tokens:
        lines.append(f"{ce('bots')} Клонов пока нет.")
    else:
        lines.extend(f"• <code>{escape(mask_bot_token(token))}</code>" for token in tokens)
    lines.extend(
        [
            "",
            "После добавления или удаления токена общая админка перезапустится сама и поднимет новый набор ботов.",
        ]
    )
    return "\n".join(lines)


def resolve_template_field_label(family_key: str, field_name: str) -> str:
    family_overrides = TEMPLATE_FIELD_LABEL_OVERRIDES_BY_FAMILY.get(family_key, {})
    return family_overrides.get(field_name, TEMPLATE_FIELD_LABELS.get(field_name, field_name))


def resolve_template_field_storage_name(family_key: str, field_name: str) -> str:
    if field_name == "exchangers_text":
        return "exchange_links_text" if family_key == "tds24" else "exchangers_text"
    return field_name


def get_template_field_value(family_key: str, template: dict[str, Any], field_name: str) -> Any:
    storage_name = resolve_template_field_storage_name(family_key, field_name)
    value = template.get(storage_name)
    if value is None and storage_name != field_name:
        value = template.get(field_name)
    return value


def build_family_menu(family_key: str, family: dict[str, Any]) -> InlineKeyboardMarkup:
    template = family.get("template", {})
    hidden_fields = HIDDEN_TEMPLATE_FIELDS_BY_FAMILY.get(family_key, set())
    rows = [
        [custom_button("Добавить бота", callback_data=f"family_upload:{family_key}", emoji_name="add")],
        [custom_button("Оплата семьи", callback_data=f"family_payments:{family_key}", emoji_name="payments")],
        [custom_button("Каталог семьи", callback_data=f"family_catalog:{family_key}", emoji_name="catalog")]
        if family_key in {"bignewsanders", "kissmyacid", "samurai", "solo", "flame4gngcxk"}
        else None,
        [custom_button("Сообщение после оплаты", callback_data=f"family_payment_extra:{family_key}", emoji_name="extra")]
        if ("payment_extra_message_enabled" in template or "payment_extra_message_text" in template)
        else None,
        [custom_button("Ссылки кнопок", callback_data=f"family_links:{family_key}", emoji_name="edit")],
        [custom_button("Админы семьи", callback_data=f"family_admins:{family_key}", emoji_name="admins")],
        [custom_button("Рассылка", callback_data=f"family_broadcast:{family_key}", emoji_name="broadcast")],
        [custom_button("Боты семьи", callback_data=f"family_bots:{family_key}", emoji_name="bots")],
    ]
    rows = [row for row in rows if row is not None]
    for key in (
        "shop_name",
        "operator_username",
        "payment_support_username",
        "operator_url",
        "work_url",
        "site_url",
        "site_text",
        "info_channel_url",
        "work_button_text",
        "work_text",
        "neon_price_url",
        "vip_price_url",
        "reviews_url",
        "info_url",
        "giveaway_url",
        "start_text",
        "contacts_text",
        "exchange_text",
        "medicine_text",
        "exchange_links_text" if family_key == "tds24" else "exchangers_text",
    ):
        if key in hidden_fields:
            continue
        if get_template_field_value(family_key, template, key) is not None:
            rows.append(
                [
                    custom_button(
                        resolve_template_field_button_text(family_key, key),
                        callback_data=f"family_field:{family_key}:{key}",
                        emoji_name=resolve_template_field_emoji_name(key),
                    )
                ]
            )
    rows.append([custom_button("Назад", callback_data="main", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


CENTRAL_LINK_FIELDS = [
    "vip_price_url",
    "reviews_url",
    "work_url",
    "site_url",
    "chat_url",
    "complaints_url",
    "questions_url",
    "payment_support_url",
    "vacancy_rules_url",
    "vacancy_apply_url",
    "global24_pay_url",
]


def build_family_links_menu(family_key: str, template: dict[str, Any]) -> InlineKeyboardMarkup:
    hidden = HIDDEN_TEMPLATE_FIELDS_BY_FAMILY.get(family_key, set())
    rows = []
    for key in CENTRAL_LINK_FIELDS:
        if key in hidden:
            continue
        value = get_template_field_value(family_key, template, key)
        mark = "✅" if value else "▫️"
        rows.append(
            [
                custom_button(
                    f"{mark} {resolve_template_field_button_text(family_key, key)}",
                    callback_data=f"family_field:{family_key}:{key}",
                    emoji_name=resolve_template_field_emoji_name(key),
                )
            ]
        )
    rows.append([custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def resolve_family_shop_name(family_key: str, family: dict[str, Any]) -> str:
    template = family.get("template", {})
    raw_shop_name = str(template.get("shop_name") or "").strip()
    service_label = SERVICES[family_key].label
    if not raw_shop_name:
        return service_label
    if family_key == "piohano" and raw_shop_name.casefold() != service_label.casefold():
        return service_label
    return raw_shop_name


def build_family_text(family_key: str, family: dict[str, Any]) -> str:
    template = family.get("template", {})
    shop_name = resolve_family_shop_name(family_key, family)
    payment_methods = family.get("payment_methods", [])
    lines = [
        f"<b>{ce('family')} {escape(SERVICES[family_key].label)}</b>",
        "",
        f"{ce('bots')} Ботов в семье: {family.get('bots_count', 0)}",
        f"{ce('success')} Активных: {family.get('running_count', 0)}",
        f"{ce('admins')} Админов: {len(family.get('admin_ids', []))}",
        f"{ce('payments')} Способов оплаты: {len(payment_methods)}",
        f"{ce('inbox')} Получателей рассылки: {family.get('recipients_count', 0)}",
        f"{ce('store')} Магазин: {escape(shop_name)}",
    ]
    if "payment_extra_message_enabled" in template:
        status = "включено" if template.get("payment_extra_message_enabled") else "выключено"
        lines.append(f"{ce('success') if template.get('payment_extra_message_enabled') else ce('pause')} Сообщение после оплаты: {status}")
    if payment_methods:
        lines.append("")
        for method in payment_methods:
            label = escape(str(method.get("label") or "Без названия"))
            requisites = resolve_payment_requisites(method)
            requisites_text = escape(requisites) if requisites else "не заданы"
            lines.append(f"  • {label}: {requisites_text}")
    return "\n".join(lines)


def get_family_bots_page(family: dict[str, Any], page: int) -> tuple[list[dict[str, Any]], int, int]:
    bots = family.get("bots", [])
    if not isinstance(bots, list):
        return [], 0, 0
    total = len(bots)
    if total == 0:
        return [], 0, 0
    last_page = max((total - 1) // BOTS_PAGE_SIZE, 0)
    current_page = min(max(page, 0), last_page)
    start = current_page * BOTS_PAGE_SIZE
    end = start + BOTS_PAGE_SIZE
    return bots[start:end], current_page, total


def build_family_bots_text(family_key: str, family: dict[str, Any], page: int = 0) -> str:
    lines = [f"<b>{ce('bots')} Боты семейства {escape(SERVICES[family_key].label)}</b>", ""]
    bots_slice, current_page, total = get_family_bots_page(family, page)
    if total == 0:
        lines.append(f"{ce('bots')} Ботов пока нет.")
    else:
        start_index = current_page * BOTS_PAGE_SIZE + 1
        end_index = start_index + len(bots_slice) - 1
        lines.append(f"Показано: {start_index}-{end_index} из {total}")
        lines.append("")
        for bot in bots_slice:
            bot_name = str(bot.get("bot_name") or "без имени")
            bot_username = bot.get("bot_username")
            status = f"{ce('pause')} на паузе" if bot.get("is_paused") else f"{ce('success')} активен"
            if bot_username:
                lines.append(f"• @{escape(str(bot_username))} | {escape(bot_name)} | {status}")
            else:
                lines.append(f"• {escape(bot_name)} | {status}")
    lines.append("")
    lines.append("Изменения в разделе применяются ко всем ботам семьи сразу.")
    return "\n".join(lines)


def build_family_bots_menu(family_key: str, family: dict[str, Any], page: int = 0) -> InlineKeyboardMarkup:
    bots, current_page, total = get_family_bots_page(family, page)
    rows: list[list[InlineKeyboardButton]] = []
    for bot in bots:
        bot_id = bot.get("bot_id")
        if not isinstance(bot_id, int):
            continue
        bot_username = str(bot.get("bot_username") or "").strip()
        bot_name = str(bot.get("bot_name") or "без имени").strip()
        is_paused = bool(bot.get("is_paused"))
        title = f"@{bot_username}" if bot_username else bot_name
        toggle_text = "Запустить" if is_paused else "Пауза"
        toggle_emoji = "start" if is_paused else "pause"
        rows.append([custom_button(title[:64], callback_data=f"family_bot:{family_key}:{bot_id}:{current_page}", emoji_name="bots")])
        rows.append(
            [
                custom_button(toggle_text, callback_data=f"family_bot_pause:{family_key}:{bot_id}:{current_page}", emoji_name=toggle_emoji),
                custom_button("Удалить", callback_data=f"family_bot_delete:{family_key}:{bot_id}:{current_page}", emoji_name="delete"),
            ]
        )
    if total > BOTS_PAGE_SIZE:
        nav_row: list[InlineKeyboardButton] = []
        if current_page > 0:
            nav_row.append(custom_button("⬅️", callback_data=f"family_bots:{family_key}:{current_page - 1}", emoji_name="back"))
        nav_row.append(InlineKeyboardButton(text=f"{current_page + 1}/{max((total - 1) // BOTS_PAGE_SIZE + 1, 1)}", callback_data="noop"))
        if (current_page + 1) * BOTS_PAGE_SIZE < total:
            nav_row.append(custom_button("➡️", callback_data=f"family_bots:{family_key}:{current_page + 1}", emoji_name="forward"))
        if nav_row:
            rows.append(nav_row)
    rows.append([custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_back_family_menu(family_key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")]])


def build_back_to_city_menu(family_key: str, city_key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[custom_button("Назад", callback_data=f"family_catalog_city:{family_key}:{city_key}", emoji_name="back")]]
    )


def make_catalog_key(prefix: str) -> str:
    return f"{prefix}-{int(time.time() * 1000)}"


def build_family_catalog_text(cities: list[dict[str, Any]]) -> str:
    lines = [f"<b>{ce('catalog')} Города и районы</b>", ""]
    if not cities:
        lines.append(f"{ce('catalog')} Городов пока нет.")
        return "\n".join(lines)
    for city in cities:
        city_label = str(city.get("label") or "Без названия")
        districts = city.get("districts", [])
        districts_count = len(districts) if isinstance(districts, list) else 0
        lines.append(f"• {ce('map')} {escape(city_label)} | {ce('pin')} районов: {districts_count}")
    return "\n".join(lines)


def build_family_catalog_menu(family_key: str, cities: list[dict[str, Any]]) -> InlineKeyboardMarkup:
    rows = [
        [custom_button(str(city.get("label") or "Без названия")[:64], callback_data=f"family_catalog_city:{family_key}:{city.get('key')}", emoji_name="map")]
        for city in cities
        if city.get("key")
    ]
    rows.append([custom_button("Добавить город", callback_data=f"family_catalog_city_add:{family_key}", emoji_name="add")])
    rows.append([custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_catalog_city_text(city: dict[str, Any]) -> str:
    city_label = str(city.get("label") or "Без названия")
    districts = city.get("districts", [])
    lines = [f"<b>{ce('map')} {escape(city_label)}</b>", ""]
    if not isinstance(districts, list) or not districts:
        lines.append(f"{ce('pin')} Районов пока нет.")
    else:
        for index, district in enumerate(districts, start=1):
            lines.append(f"{index}. {ce('pin')} {escape(str(district))}")
    return "\n".join(lines)


def build_catalog_city_menu(family_key: str, city: dict[str, Any]) -> InlineKeyboardMarkup:
    city_key = str(city.get("key") or "")
    districts = city.get("districts", [])
    rows: list[list[InlineKeyboardButton]] = [
        [custom_button("Переименовать город", callback_data=f"family_catalog_city_rename:{family_key}:{city_key}", emoji_name="edit")],
        [custom_button("Добавить район", callback_data=f"family_catalog_district_add:{family_key}:{city_key}", emoji_name="add")],
    ]
    if isinstance(districts, list):
        for index, district in enumerate(districts):
            rows.append(
                [
                    InlineKeyboardButton(
                        text=str(district)[:48],
                        callback_data=f"family_catalog_district:{family_key}:{city_key}:{index}",
                        icon_custom_emoji_id=CUSTOM_EMOJI_ICONS["pin"][1],
                    ),
                    custom_button("Удалить", callback_data=f"family_catalog_district_delete:{family_key}:{city_key}:{index}", emoji_name="delete"),
                ]
            )
    rows.append([custom_button("Удалить город", callback_data=f"family_catalog_city_delete:{family_key}:{city_key}", emoji_name="delete")])
    rows.append([custom_button("Назад", callback_data=f"family_catalog:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_catalog_district_text(city_label: str, district_name: str) -> str:
    return "\n".join(
        [
            f"<b>{ce('pin')} Район</b>",
            "",
            f"{ce('map')} Город: {escape(city_label)}",
            f"{ce('pin')} Название: {escape(district_name)}",
        ]
    )


def build_catalog_district_menu(family_key: str, city_key: str, district_index: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [custom_button("Переименовать район", callback_data=f"family_catalog_district_rename:{family_key}:{city_key}:{district_index}", emoji_name="edit")],
            [custom_button("Удалить район", callback_data=f"family_catalog_district_delete:{family_key}:{city_key}:{district_index}", emoji_name="delete")],
            [custom_button("Назад", callback_data=f"family_catalog_city:{family_key}:{city_key}", emoji_name="back")],
        ]
    )


def build_family_admins_menu(family_key: str, admin_ids: list[int]) -> InlineKeyboardMarkup:
    rows = [[custom_button("Добавить админа", callback_data=f"family_admin_add:{family_key}", emoji_name="add")]]
    rows.extend(
        [custom_button(f"Удалить {admin_id}", callback_data=f"family_admin_remove:{family_key}:{admin_id}", emoji_name="delete")]
        for admin_id in admin_ids
    )
    rows.append([custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_family_admins_text(admin_ids: list[int]) -> str:
    lines = [f"<b>{ce('admins')} Общие админы семьи</b>", ""]
    if not admin_ids:
        lines.append(f"{ce('person')} Админов пока нет.")
    else:
        for admin_id in admin_ids:
            lines.append(f"• {ce('person')} <code>{admin_id}</code>")
    lines.extend(
        [
            "",
            "Все изменения здесь применяются сразу ко всем ботам этого семейства.",
        ]
    )
    return "\n".join(lines)


def build_family_payments_menu(family_key: str, methods: list[dict[str, Any]]) -> InlineKeyboardMarkup:
    rows = [
        [custom_button((method.get("label") or f"Метод {index + 1}")[:64], callback_data=f"family_payment:{family_key}:{index}", emoji_name="payments")]
        for index, method in enumerate(methods)
    ]
    rows.append([custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def extract_payment_requisites(details_text: str) -> str | None:
    for pattern in (
        _BTC_WALLET_REQUISITES_PATTERN,
        _ETH_WALLET_REQUISITES_PATTERN,
        _LTC_WALLET_REQUISITES_PATTERN,
        _TRC20_WALLET_REQUISITES_PATTERN,
    ):
        wallet_match = pattern.search(details_text or "")
        if wallet_match is not None:
            return wallet_match.group("wallet").strip()
    blik_match = _BLIK_REQUISITES_PATTERN.search(details_text or "")
    if blik_match is not None:
        return blik_match.group("value").strip()
    card_match = _CARD_REQUISITES_PATTERN.search(details_text or "")
    if card_match is not None:
        return re.sub(r"\s+", " ", card_match.group("card").replace("-", " ")).strip()
    for line in (details_text or "").splitlines():
        stripped = line.strip()
        lowered = stripped.casefold()
        if not stripped:
            continue
        if any(
            marker in lowered
            for marker in (
                "реквизиты для оплаты",
                "после оплаты",
                "ваш адресс пополнения",
                "ваш адрес пополнения",
                "пополнение blik",
                "инструкция по пополнению",
                "оплатить наличными",
            )
        ):
            continue
        return stripped
    plain_text = (details_text or "").strip()
    if _is_plain_requisites_text(plain_text):
        return plain_text
    return None


def _replace_requisites_line(details_text: str, replacement: str) -> str | None:
    lines = details_text.splitlines()
    if not lines:
        return None

    header_index = next(
        (
            index
            for index, line in enumerate(lines)
            if "реквизит" in line.casefold() or "адресс" in line.casefold() or "адрес" in line.casefold()
        ),
        None,
    )
    if header_index is None:
        return None

    for index in range(header_index + 1, len(lines)):
        if lines[index].strip():
            lines[index] = replacement
            return "\n".join(lines)

    lines.insert(header_index + 1, replacement)
    return "\n".join(lines)


def _inject_requisites_block(details_text: str, replacement: str) -> str | None:
    lines = details_text.splitlines()
    if not lines:
        return None

    first_nonempty_index = next((index for index, line in enumerate(lines) if line.strip()), None)
    if first_nonempty_index is None:
        return replacement

    insert_at = first_nonempty_index + 1
    if insert_at < len(lines) and not lines[insert_at].strip():
        lines[insert_at] = replacement
        if insert_at + 1 >= len(lines) or lines[insert_at + 1].strip():
            lines.insert(insert_at + 1, "")
        return "\n".join(lines)

    lines.insert(insert_at, "")
    lines.insert(insert_at + 1, replacement)
    lines.insert(insert_at + 2, "")
    return "\n".join(lines)


def resolve_payment_requisites(method: dict[str, Any]) -> str | None:
    raw_requisites = str(method.get("requisites") or "").strip()
    if raw_requisites:
        return raw_requisites
    return extract_payment_requisites(str(method.get("details_text") or ""))


def _is_plain_requisites_text(details_text: str) -> bool:
    stripped = details_text.strip()
    if not stripped or "\n" in stripped:
        return False
    lowered = stripped.casefold()
    return not any(
        marker in lowered
        for marker in (
            "реквизит",
            "после оплаты",
            "нажмите",
            "http://",
            "https://",
        )
    )


def replace_payment_requisites(method: dict[str, Any], new_requisites: str) -> None:
    replacement = new_requisites.strip()
    method["requisites"] = replacement

    details_text = str(method.get("details_text") or "")
    if not details_text or _is_plain_requisites_text(details_text):
        method["details_text"] = replacement
        return

    for pattern in (
        _GENERIC_REQUISITES_PLACEHOLDER_PATTERN,
        _BTC_WALLET_REQUISITES_PATTERN,
        _ETH_WALLET_REQUISITES_PATTERN,
        _TRC20_WALLET_REQUISITES_PATTERN,
        _LTC_WALLET_REQUISITES_PATTERN,
        _CARD_REQUISITES_PATTERN,
    ):
        updated_text, count = pattern.subn(replacement, details_text, count=1)
        if count > 0:
            method["details_text"] = updated_text
            return
    updated_text, count = _BLIK_REQUISITES_PATTERN.subn(
        lambda match: f"{match.group('prefix')}{replacement}",
        details_text,
        count=1,
    )
    if count > 0:
        method["details_text"] = updated_text
        return

    updated_text = _replace_requisites_line(details_text, replacement)
    if updated_text is not None:
        method["details_text"] = updated_text
        return

    updated_text = _inject_requisites_block(details_text, replacement)
    if updated_text is not None:
        method["details_text"] = updated_text
        return

    method["details_text"] = replacement


def render_payment_details_text(method: dict[str, Any]) -> str:
    details_text = str(method.get("details_text") or "").strip()
    if not details_text:
        return ""

    requisites = resolve_payment_requisites(method)
    if not requisites:
        return details_text

    for pattern in (
        _GENERIC_REQUISITES_PLACEHOLDER_PATTERN,
        _BTC_WALLET_REQUISITES_PATTERN,
        _ETH_WALLET_REQUISITES_PATTERN,
        _TRC20_WALLET_REQUISITES_PATTERN,
        _LTC_WALLET_REQUISITES_PATTERN,
        _CARD_REQUISITES_PATTERN,
    ):
        rendered_text, count = pattern.subn(requisites, details_text, count=1)
        if count > 0:
            return rendered_text
    return details_text


def build_family_payments_text(methods: list[dict[str, Any]]) -> str:
    lines = [f"<b>{ce('payments')} Общие способы оплаты семьи</b>", ""]
    if not methods:
        lines.append(f"{ce('payments')} Способы оплаты не настроены.")
    else:
        for method in methods:
            requisites_ready = bool(resolve_payment_requisites(method))
            requisites_text = f"{ce('success')} реквизиты заданы" if requisites_ready else f"{ce('pause')} реквизиты не заданы"
            parts = [escape(method.get("label") or "Без названия"), requisites_text]
            lines.append("• " + " | ".join(parts))
    return "\n".join(lines)


def build_payment_editor_menu(family_key: str, index: int, method: dict[str, Any]) -> InlineKeyboardMarkup:
    del method
    rows = [
        [custom_button("Изменить реквизиты", callback_data=f"family_payment_requisites:{family_key}:{index}", emoji_name="edit")],
        [custom_button("Назад", callback_data=f"family_payments:{family_key}", emoji_name="back")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_payment_editor_text(method: dict[str, Any], index: int) -> str:
    lines = [f"<b>{ce('edit')} Общий способ оплаты #{index + 1}</b>", "", f"{ce('family')} Название: {escape(method.get('label') or '-')}"]
    lines.append(f"{ce('briefcase')} Реквизиты: {escape(resolve_payment_requisites(method) or 'не указаны')}")
    lines.append("")
    lines.append(f"{ce('note')} Текущий текст шаблона:")
    lines.append(f"<pre>{escape(render_payment_details_text(method))}</pre>")
    return "\n".join(lines)


def build_family_payment_extra_menu(family_key: str, template: dict[str, Any]) -> InlineKeyboardMarkup:
    enabled = bool(template.get("payment_extra_message_enabled"))
    toggle_text = "Выключить сообщение" if enabled else "Включить сообщение"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [custom_button(toggle_text, callback_data=f"family_payment_extra_toggle:{family_key}", emoji_name="extra")],
            [custom_button("Изменить текст", callback_data=f"family_payment_extra_edit:{family_key}", emoji_name="edit")],
            [custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")],
        ]
    )


def build_family_payment_extra_text(template: dict[str, Any]) -> str:
    enabled = bool(template.get("payment_extra_message_enabled"))
    message_text = str(template.get("payment_extra_message_text") or "").strip()
    status_text = "включено" if enabled else "выключено"
    status_icon = "success" if enabled else "pause"
    return "\n".join(
        [
            f"<b>{ce('broadcast')} Доп. сообщение после выбора оплаты</b>",
            "",
            f"{ce(status_icon)} Статус: <b>{status_text}</b>",
            "",
            "Этот текст отправляется отдельным сообщением сразу после выбора способа оплаты во всех ботах семейства.",
            "",
            f"{ce('note')} Текущий текст:",
            f"<pre>{escape(message_text or 'пусто')}</pre>",
        ]
    )


def build_field_text(family_key: str, field_name: str, value: Any) -> str:
    raw_title = resolve_template_field_label(family_key, field_name)
    title = strip_icon_prefix(raw_title)
    title_prefix = ce(resolve_template_field_emoji_name(field_name)) + " " if resolve_template_field_emoji_name(field_name) else ""
    if field_name == "operator_username":
        normalized = str(value or "").strip().lstrip("@")
        display_value = f"@{normalized}" if normalized else ""
        return (
            f"<b>{title_prefix}{escape(title)}</b>\n\n"
            f"<pre>{escape(display_value)}</pre>\n\n"
            "Меняется только единый @user для текстов сапорта во всех ботах семьи."
        )
    if field_name == "payment_support_username":
        normalized = str(value or "").strip().lstrip("@")
        display_value = f"@{normalized}" if normalized else ""
        return (
            f"<b>{title_prefix}{escape(title)}</b>\n\n"
            f"<pre>{escape(display_value)}</pre>\n\n"
            "Меняется отдельный @user для карточного шаблона оплаты."
        )
    if field_name == "start_text":
        return (
            f"<b>{title_prefix}{escape(title)}</b>\n\n"
            f"<pre>{escape(str(value or ''))}</pre>\n\n"
            "Доступные переменные:\n"
            "<code>{user_name}</code>, <code>{first_name}</code>, <code>{user_id}</code>, "
            "<code>{balance}</code>, <code>{bot_username}</code>, <code>{bot_mention}</code>, "
            "<code>{shop_name}</code>, <code>{operator_username}</code>, <code>{operator_url}</code>, "
            "<code>{work_url}</code>, <code>{site_text}</code>, <code>{reviews_url}</code>, <code>{vip_price_url}</code>, "
            "<code>{work_button_text}</code>, <code>{contacts_text}</code>"
        )
    return f"<b>{title_prefix}{escape(title)}</b>\n\n<pre>{escape(str(value or ''))}</pre>"


def is_significant_exception(exc: Exception) -> bool:
    if isinstance(exc, TelegramBadRequest):
        return False
    if isinstance(exc, ServiceError):
        lowered = str(exc).casefold()
        return any(
            marker in lowered
            for marker in (
                "status 500",
                "api недоступен",
                "некорректный ответ",
                "timeout",
                "timed out",
            )
        )
    return True


def build_exception_notice(exc: Exception, *, title: str = "Значимая ошибка") -> str:
    details = str(exc).strip() or exc.__class__.__name__
    compact = f"{exc.__class__.__name__}: {details}"[:ERROR_MESSAGE_MAX_LEN]
    return f"<b>{escape(title)}</b>\n\n<code>{escape(compact)}</code>"


async def show_main(target: Message | CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await answer_or_edit(target, build_main_text(), build_main_menu())


async def show_central_settings(target: Message | CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    settings = await load_central_settings()
    await answer_or_edit(target, build_central_settings_text(settings), build_central_settings_menu())


async def show_central_global_admins(target: Message | CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    settings = await load_central_settings()
    await answer_or_edit(
        target,
        build_central_global_admins_text(settings["global_admin_ids"]),
        build_central_global_admins_menu(settings["global_admin_ids"]),
    )


async def show_central_clone_tokens(target: Message | CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    settings = await load_central_settings()
    await answer_or_edit(
        target,
        build_central_clone_tokens_text(settings["clone_bot_tokens"]),
        build_central_clone_tokens_menu(settings["clone_bot_tokens"]),
    )


async def show_family(target: Message | CallbackQuery, state: FSMContext, family_key: str) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    await answer_or_edit(target, build_family_text(family_key, family), build_family_menu(family_key, family))


async def show_family_bots(target: Message | CallbackQuery, state: FSMContext, family_key: str, page: int = 0) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    await answer_or_edit(target, build_family_bots_text(family_key, family, page), build_family_bots_menu(family_key, family, page))


def build_family_bot_text(family_key: str, bot: dict[str, Any]) -> str:
    username = str(bot.get("bot_username") or "").strip()
    name = str(bot.get("bot_name") or "без имени").strip()
    token = str(bot.get("token") or "").strip()
    status = f"{ce('pause')} На паузе" if bot.get("is_paused") else f"{ce('success')} Активен"
    lines = [f"<b>{ce('bots')} Бот семейства {escape(SERVICES[family_key].label)}</b>", ""]
    lines.append(f"{ce('person')} Username: {escape('@' + username if username else 'без username')}")
    lines.append(f"{ce('family')} Имя: {escape(name)}")
    lines.append(f"{ce('info')} ID: <code>{escape(str(bot.get('bot_id') or '-'))}</code>")
    lines.append(f"{ce('pause') if bot.get('is_paused') else ce('success')} Статус: {status}")
    if bot.get("created_at"):
        lines.append(f"{ce('clock')} Создан: <code>{escape(str(bot['created_at']))}</code>")
    if token:
        lines.append(f"{ce('lock')} Токен: <code>{escape(token)}</code>")
    return "\n".join(lines)


def build_family_bot_menu(family_key: str, bot: dict[str, Any], page: int = 0) -> InlineKeyboardMarkup:
    bot_id = int(bot["bot_id"])
    is_paused = bool(bot.get("is_paused"))
    toggle_text = "Запустить" if is_paused else "Поставить на паузу"
    toggle_emoji = "start" if is_paused else "pause"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [custom_button(toggle_text, callback_data=f"family_bot_pause:{family_key}:{bot_id}:{page}", emoji_name=toggle_emoji)],
            [custom_button("Удалить", callback_data=f"family_bot_delete:{family_key}:{bot_id}:{page}", emoji_name="delete")],
            [custom_button("Назад", callback_data=f"family_bots:{family_key}:{page}", emoji_name="back")],
        ]
    )


async def show_family_bot(target: Message | CallbackQuery, state: FSMContext, family_key: str, bot_id: int, page: int = 0) -> None:
    await state.clear()
    bot = await fetch_family_bot(family_key, bot_id)
    await answer_or_edit(target, build_family_bot_text(family_key, bot), build_family_bot_menu(family_key, bot, page))


async def show_family_admins(target: Message | CallbackQuery, state: FSMContext, family_key: str) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    await answer_or_edit(target, build_family_admins_text(family.get("admin_ids", [])), build_family_admins_menu(family_key, family.get("admin_ids", [])))


async def show_family_payments(target: Message | CallbackQuery, state: FSMContext, family_key: str) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    methods = family.get("payment_methods", [])
    await answer_or_edit(target, build_family_payments_text(methods), build_family_payments_menu(family_key, methods))


async def show_family_payment_editor(target: Message | CallbackQuery, state: FSMContext, family_key: str, index: int) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    methods = family.get("payment_methods", [])
    if not (0 <= index < len(methods)):
        await answer_or_edit(target, "Способ оплаты не найден.", build_back_family_menu(family_key))
        return
    await answer_or_edit(target, build_payment_editor_text(methods[index], index), build_payment_editor_menu(family_key, index, methods[index]))


async def show_family_payment_extra(target: Message | CallbackQuery, state: FSMContext, family_key: str) -> None:
    await state.clear()
    family = await fetch_family(family_key)
    template = dict(family.get("template", {}))
    await answer_or_edit(
        target,
        build_family_payment_extra_text(template),
        build_family_payment_extra_menu(family_key, template),
    )


async def show_family_catalog(target: Message | CallbackQuery, state: FSMContext, family_key: str) -> None:
    await state.clear()
    cities = await fetch_family_catalog(family_key)
    await answer_or_edit(target, build_family_catalog_text(cities), build_family_catalog_menu(family_key, cities))


def find_catalog_city(cities: list[dict[str, Any]], city_key: str) -> dict[str, Any] | None:
    return next((city for city in cities if str(city.get("key") or "") == city_key), None)


async def show_family_catalog_city(
    target: Message | CallbackQuery,
    state: FSMContext,
    family_key: str,
    city_key: str,
) -> None:
    await state.clear()
    cities = await fetch_family_catalog(family_key)
    city = find_catalog_city(cities, city_key)
    if city is None:
        await answer_or_edit(target, "Город не найден.", build_back_family_menu(family_key))
        return
    await answer_or_edit(target, build_catalog_city_text(city), build_catalog_city_menu(family_key, city))


async def show_family_catalog_district(
    target: Message | CallbackQuery,
    state: FSMContext,
    family_key: str,
    city_key: str,
    district_index: int,
) -> None:
    await state.clear()
    cities = await fetch_family_catalog(family_key)
    city = find_catalog_city(cities, city_key)
    if city is None:
        await answer_or_edit(target, "Город не найден.", build_back_family_menu(family_key))
        return
    districts = city.get("districts", [])
    if not isinstance(districts, list) or not (0 <= district_index < len(districts)):
        await answer_or_edit(target, "Район не найден.", build_back_to_city_menu(family_key, city_key))
        return
    await answer_or_edit(
        target,
        build_catalog_district_text(str(city.get("label") or "Без названия"), str(districts[district_index])),
        build_catalog_district_menu(family_key, city_key, district_index),
    )


async def show_family_field(target: Message | CallbackQuery, state: FSMContext, family_key: str, field_name: str) -> None:
    await state.clear()
    if field_name in HIDDEN_TEMPLATE_FIELDS_BY_FAMILY.get(family_key, set()):
        await answer_or_edit(target, "Это поле скрыто для данной семьи.", build_back_family_menu(family_key))
        return
    family = await fetch_family(family_key)
    value = get_template_field_value(family_key, family.get("template", {}), field_name)
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [custom_button("Изменить", callback_data=f"family_field_edit:{family_key}:{field_name}", emoji_name="edit")],
            [custom_button("Назад", callback_data=f"family:{family_key}", emoji_name="back")],
        ]
    )
    await answer_or_edit(target, build_field_text(family_key, field_name, value), markup)


def prompt_text(mode: str, family_key: str | None = None, field_name: str | None = None) -> str:
    if mode == "central_global_admin_add":
        return f"{ce('admins')} Пришлите Telegram ID глобального администратора. Он получит доступ к общей админке и будет добавлен во все семьи."
    if mode == "central_clone_token_add":
        return f"{ce('bots')} Пришлите токен Telegram-бота для клона общей админки. После сохранения админка перезапустится сама."
    if mode == "field":
        if field_name in {"operator_username", "payment_support_username"}:
            return (
                "Пришлите новый Telegram username для сапорта.\n"
                "Можно с <code>@</code> или без него, но только username без ссылок и лишнего текста."
            )
        if field_name in {"exchangers_text", "exchange_links_text"}:
            return (
                "Пришлите новый текст обменников.\n\n"
                "Можно вставлять много строк. Новый ввод полностью перезапишет текущий список.\n"
                "Пример:\n"
                "<code>www.bestchange.ru/mir-to-tether-trc20.html\nhttps://t.me/masterbit_bot\n@yagababa_robot</code>"
            )
        if field_name == "start_text":
            return (
                "Пришлите новый стартовый текст.\n\n"
                "Доступные переменные:\n"
                "<code>{user_name}</code>, <code>{first_name}</code>, <code>{user_id}</code>, "
                "<code>{balance}</code>, <code>{bot_username}</code>, <code>{bot_mention}</code>."
            )
        resolved_family_key = family_key or ""
        return f"{ce('edit')} Пришлите новое значение для поля «{resolve_template_field_label(resolved_family_key, field_name or '')}»."
    if mode == "admin_add":
        return f"{ce('admins')} Пришлите Telegram ID нового общего администратора."
    if mode == "payment_add":
        return "Пришлите название нового общего способа оплаты."
    if mode == "payment_label":
        return "Пришлите новое название."
    if mode == "payment_text":
        return "Пришлите новый текст."
    if mode == "payment_commission":
        return "Пришлите новую комиссию."
    if mode == "payment_requisites":
        return f"{ce('payments')} Пришлите новые реквизиты."
    if mode == "payment_extra_text":
        return f"{ce('extra')} Пришлите новый текст доп. сообщения после выбора оплаты."
    if mode == "catalog_city_add":
        return f"{ce('catalog')} Пришлите название нового города."
    if mode == "catalog_city_rename":
        return f"{ce('edit')} Пришлите новое название города."
    if mode == "catalog_district_add":
        return f"{ce('pin')} Пришлите название нового района."
    if mode == "catalog_district_rename":
        return f"{ce('edit')} Пришлите новое название района."
    if mode == "broadcast":
        return f"{ce('broadcast')} Пришлите текст рассылки для всех известных пользователей всех токенов выбранного семейства."
    if mode == "upload_tokens":
        return f"{ce('bots')} Пришлите один или несколько токенов, каждый с новой строки."
    return "Пришлите новое значение."


async def main() -> None:
    load_dotenv(ENV_PATH)
    token = os.getenv("CENTRAL_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("CENTRAL_BOT_TOKEN is not configured")

    bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    async def notify_significant_error(event: ErrorEvent) -> None:
        exc = event.exception
        if not isinstance(exc, Exception) or not is_significant_exception(exc):
            return

        chat_ids: set[int] = set()
        update = event.update
        message = getattr(update, "message", None)
        callback_query = getattr(update, "callback_query", None)

        if getattr(message, "chat", None) is not None:
            chat_ids.add(message.chat.id)
        if getattr(callback_query, "message", None) is not None and callback_query.message is not None:
            chat_ids.add(callback_query.message.chat.id)

        chat_ids.update(await resolve_admin_ids())
        if not chat_ids:
            return

        notice = build_exception_notice(exc)
        for chat_id in chat_ids:
            try:
                await bot.send_message(chat_id, notice, disable_web_page_preview=True)
            except Exception:  # noqa: BLE001
                logger.exception("Failed to deliver significant error to chat %s", chat_id)

    @dp.error()
    async def on_error(event: ErrorEvent) -> bool:
        logger.exception("Unhandled error in central admin", exc_info=event.exception)
        await notify_significant_error(event)
        return True

    @dp.message(CommandStart())
    @dp.message(Command("admin"))
    @require_admin
    async def on_start(message: Message, state: FSMContext) -> None:
        await show_main(message, state)

    @dp.message(Command("test"))
    @require_admin
    async def on_test(message: Message) -> None:
        await message.answer(
            "🙂",
            entities=[
                MessageEntity(
                    type="custom_emoji",
                    offset=0,
                    length=2,
                    custom_emoji_id="6039539366177541657",
                )
            ],
        )

    @dp.callback_query(F.data == "main")
    @require_admin
    async def on_main(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await show_main(callback, state)

    @dp.callback_query(F.data == "noop")
    @require_admin
    async def on_noop(callback: CallbackQuery) -> None:
        await callback.answer()

    @dp.callback_query(F.data == "central_settings")
    @require_admin
    async def on_central_settings(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await show_central_settings(callback, state)

    @dp.callback_query(F.data == "central_global_admins")
    @require_admin
    async def on_central_global_admins(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await show_central_global_admins(callback, state)

    @dp.callback_query(F.data == "central_clone_tokens")
    @require_admin
    async def on_central_clone_tokens(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await show_central_clone_tokens(callback, state)

    @dp.callback_query(F.data == "central_global_admin_add")
    @require_admin
    async def on_central_global_admin_add(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await state.set_state(AdminState.waiting_value)
        await state.update_data(mode="central_global_admin_add")
        await answer_or_edit(callback, prompt_text("central_global_admin_add"), build_central_global_admins_menu((await load_central_settings())["global_admin_ids"]))

    @dp.callback_query(F.data == "central_clone_token_add")
    @require_admin
    async def on_central_clone_token_add(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        await state.set_state(AdminState.waiting_value)
        await state.update_data(mode="central_clone_token_add")
        await answer_or_edit(callback, prompt_text("central_clone_token_add"), build_central_clone_tokens_menu((await load_central_settings())["clone_bot_tokens"]))

    @dp.callback_query(F.data.startswith("central_global_admin_remove:"))
    @require_admin
    async def on_central_global_admin_remove(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, admin_id_text = callback.data.split(":", 1)
        admin_id = int(admin_id_text)
        settings = await load_central_settings()
        settings["global_admin_ids"] = [item for item in settings["global_admin_ids"] if item != admin_id]
        await save_central_settings(settings)
        invalidate_admin_ids_cache()
        errors = await propagate_global_admin_id(admin_id, add=False)
        await show_central_global_admins(callback, state)
        if errors and callback.message is not None:
            await callback.message.answer(
                "Удалил админа из общей админки, но не все семейства ответили:\n"
                + "\n".join(errors[:10]),
                reply_markup=build_central_settings_menu(),
            )

    @dp.callback_query(F.data.startswith("central_clone_token_remove:"))
    @require_admin
    async def on_central_clone_token_remove(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, index_text = callback.data.split(":", 1)
        index = int(index_text)
        settings = await load_central_settings()
        tokens = list(settings["clone_bot_tokens"])
        if not (0 <= index < len(tokens)):
            await show_central_clone_tokens(callback, state)
            return
        removed_token = tokens.pop(index)
        settings["clone_bot_tokens"] = tokens
        await save_central_settings(settings)
        await show_central_clone_tokens(callback, state)
        if callback.message is not None:
            await callback.message.answer(
                "Токен клона удалён:\n"
                f"<code>{escape(mask_bot_token(removed_token))}</code>\n\n"
                "Перезапускаю общую админку, чтобы остановить этот клон.",
                reply_markup=build_central_settings_menu(),
            )
        asyncio.create_task(restart_process())

    @dp.callback_query(F.data.startswith("family:"))
    @require_admin
    async def on_family(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key = callback.data.split(":", 1)
        await show_family(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_bots:"))
    @require_admin
    async def on_family_bots(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        parts = callback.data.split(":")
        family_key = parts[1]
        page = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        await show_family_bots(callback, state, family_key, page)

    @dp.callback_query(F.data.startswith("family_bot:"))
    @require_admin
    async def on_family_bot(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        parts = callback.data.split(":")
        family_key = parts[1]
        bot_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
        await show_family_bot(callback, state, family_key, bot_id, page)

    @dp.callback_query(F.data.startswith("family_bot_pause:"))
    @require_admin
    async def on_family_bot_pause(callback: CallbackQuery, state: FSMContext) -> None:
        parts = callback.data.split(":")
        family_key = parts[1]
        bot_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
        bot = await fetch_family_bot(family_key, bot_id)
        updated = await update_family_bot(family_key, bot_id, {"is_paused": not bool(bot.get("is_paused"))})
        await callback.answer("Статус бота обновлен.")
        await show_family_bot(callback, state, family_key, int(updated.get("bot_id") or bot_id), page)

    @dp.callback_query(F.data.startswith("family_bot_delete:"))
    @require_admin
    async def on_family_bot_delete(callback: CallbackQuery, state: FSMContext) -> None:
        parts = callback.data.split(":")
        family_key = parts[1]
        bot_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
        bot = await fetch_family_bot(family_key, bot_id)
        token = str(bot.get("token") or "").strip()
        await delete_family_bot(family_key, bot_id)
        await callback.answer("Бот удален.")
        await show_family_bots(callback, state, family_key, page)
        if callback.message is not None and token:
            await callback.message.answer(f"Удален бот с токеном:\n<code>{escape(token)}</code>")

    @dp.callback_query(F.data.startswith("family_admins:"))
    @require_admin
    async def on_family_admins(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key = callback.data.split(":", 1)
        await show_family_admins(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_payments:"))
    @require_admin
    async def on_family_payments(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key = callback.data.split(":", 1)
        await show_family_payments(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_payment_extra:"))
    @require_admin
    async def on_family_payment_extra(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key = callback.data.split(":", 1)
        await show_family_payment_extra(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_catalog:"))
    @require_admin
    async def on_family_catalog(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key = callback.data.split(":", 1)
        await show_family_catalog(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_catalog_city:"))
    @require_admin
    async def on_family_catalog_city(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, city_key = callback.data.split(":", 2)
        await show_family_catalog_city(callback, state, family_key, city_key)

    @dp.callback_query(F.data.startswith("family_catalog_district:"))
    @require_admin
    async def on_family_catalog_district(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, city_key, district_index_text = callback.data.split(":", 3)
        await show_family_catalog_district(callback, state, family_key, city_key, int(district_index_text))

    @dp.callback_query(F.data.startswith("family_payment:"))
    @require_admin
    async def on_family_payment(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, index_text = callback.data.split(":", 2)
        await show_family_payment_editor(callback, state, family_key, int(index_text))

    @dp.callback_query(F.data.startswith("family_links:"))
    @require_admin
    async def on_family_links(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        family_key = callback.data.split(":", 1)[1]
        family = await fetch_family(family_key)
        await answer_or_edit(
            callback,
            "🔗 Ссылки кнопок главного меню.\nВыберите, что задать/изменить (присылайте полную ссылку https://… или @username):",
            build_family_links_menu(family_key, family.get("template", {})),
        )

    @dp.callback_query(F.data.startswith("family_field:"))
    @require_admin
    async def on_family_field(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, field_name = callback.data.split(":", 2)
        await show_family_field(callback, state, family_key, field_name)

    @dp.callback_query(F.data.startswith("family_field_edit:"))
    @dp.callback_query(F.data.startswith("family_admin_add:"))
    @dp.callback_query(F.data.startswith("family_upload:"))
    @dp.callback_query(F.data.startswith("family_broadcast:"))
    @dp.callback_query(F.data.startswith("family_payment_requisites:"))
    @dp.callback_query(F.data.startswith("family_payment_extra_edit:"))
    @dp.callback_query(F.data.startswith("family_catalog_city_add:"))
    @dp.callback_query(F.data.startswith("family_catalog_city_rename:"))
    @dp.callback_query(F.data.startswith("family_catalog_district_add:"))
    @dp.callback_query(F.data.startswith("family_catalog_district_rename:"))
    @require_admin
    async def on_waiting(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        parts = callback.data.split(":")
        action = parts[0]
        family_key = parts[1]
        data: dict[str, Any] = {"family_key": family_key}
        if action == "family_field_edit":
            if parts[2] in HIDDEN_TEMPLATE_FIELDS_BY_FAMILY.get(family_key, set()):
                await answer_or_edit(callback, "Это поле скрыто для данной семьи.", build_back_family_menu(family_key))
                return
            data["mode"] = "field"
            data["field_name"] = parts[2]
            text = prompt_text("field", family_key, parts[2])
        elif action == "family_admin_add":
            data["mode"] = "admin_add"
            text = prompt_text("admin_add")
        elif action == "family_upload":
            data["mode"] = "upload_tokens"
            text = prompt_text("upload_tokens")
        elif action == "family_broadcast":
            data["mode"] = "broadcast"
            text = prompt_text("broadcast")
        elif action == "family_payment_extra_edit":
            data["mode"] = "payment_extra_text"
            text = prompt_text("payment_extra_text")
        elif action == "family_catalog_city_add":
            data["mode"] = "catalog_city_add"
            text = prompt_text("catalog_city_add")
        elif action == "family_catalog_city_rename":
            data["mode"] = "catalog_city_rename"
            data["city_key"] = parts[2]
            text = prompt_text("catalog_city_rename")
        elif action == "family_catalog_district_add":
            data["mode"] = "catalog_district_add"
            data["city_key"] = parts[2]
            text = prompt_text("catalog_district_add")
        elif action == "family_catalog_district_rename":
            data["mode"] = "catalog_district_rename"
            data["city_key"] = parts[2]
            data["district_index"] = int(parts[3])
            text = prompt_text("catalog_district_rename")
        else:
            data["mode"] = "payment_requisites"
            data["payment_index"] = int(parts[2])
            text = prompt_text("payment_requisites")
        await state.set_state(AdminState.waiting_value)
        await state.update_data(**data)
        back_markup = build_back_family_menu(family_key)
        if data["mode"] == "catalog_city_rename" or data["mode"] == "catalog_district_add":
            back_markup = build_back_to_city_menu(family_key, str(data["city_key"]))
        elif data["mode"] == "catalog_district_rename":
            back_markup = build_catalog_district_menu(family_key, str(data["city_key"]), int(data["district_index"]))
        elif data["mode"] == "catalog_city_add":
            back_markup = InlineKeyboardMarkup(
                inline_keyboard=[[custom_button("Назад", callback_data=f"family_catalog:{family_key}", emoji_name="back")]]
            )
        await answer_or_edit(callback, text, back_markup)

    @dp.callback_query(F.data.startswith("family_payment_extra_toggle:"))
    @require_admin
    async def on_family_payment_extra_toggle(callback: CallbackQuery, state: FSMContext) -> None:
        _, family_key = callback.data.split(":", 1)
        family = await fetch_family(family_key)
        template = dict(family.get("template", {}))
        current_text = str(template.get("payment_extra_message_text") or "").strip()
        if not bool(template.get("payment_extra_message_enabled")) and not current_text:
            await callback.answer("Сначала задайте текст доп. сообщения.", show_alert=True)
            return
        template["payment_extra_message_enabled"] = not bool(template.get("payment_extra_message_enabled"))
        await update_family(family_key, {"template": template})
        await show_family_payment_extra(callback, state, family_key)
        await callback.answer()

    @dp.callback_query(F.data.startswith("family_admin_remove:"))
    @require_admin
    async def on_family_admin_remove(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, admin_id_text = callback.data.split(":", 2)
        family = await fetch_family(family_key)
        admin_ids = [item for item in family.get("admin_ids", []) if item != int(admin_id_text)]
        await update_family(family_key, {"admin_ids": admin_ids})
        await show_family_admins(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_payment_qr:"))
    @require_admin
    async def on_family_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, index_text = callback.data.split(":", 2)
        index = int(index_text)
        family = await fetch_family(family_key)
        methods = list(family.get("payment_methods", []))
        methods[index]["qr_enabled"] = not bool(methods[index].get("qr_enabled"))
        await update_family(family_key, {"payment_methods": methods})
        await show_family_payment_editor(callback, state, family_key, index)

    @dp.callback_query(F.data.startswith("family_catalog_city_delete:"))
    @require_admin
    async def on_family_catalog_city_delete(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, city_key = callback.data.split(":", 2)
        cities = await fetch_family_catalog(family_key)
        updated_cities = [city for city in cities if str(city.get("key") or "") != city_key]
        await update_family_catalog(family_key, updated_cities)
        await show_family_catalog(callback, state, family_key)

    @dp.callback_query(F.data.startswith("family_catalog_district_delete:"))
    @require_admin
    async def on_family_catalog_district_delete(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, city_key, district_index_text = callback.data.split(":", 3)
        district_index = int(district_index_text)
        cities = await fetch_family_catalog(family_key)
        city = find_catalog_city(cities, city_key)
        if city is None:
            await answer_or_edit(callback, "Город не найден.", build_back_family_menu(family_key))
            return
        districts = city.get("districts", [])
        if not isinstance(districts, list) or not (0 <= district_index < len(districts)):
            await answer_or_edit(callback, "Район не найден.", build_back_to_city_menu(family_key, city_key))
            return
        city["districts"] = [district for index, district in enumerate(districts) if index != district_index]
        await update_family_catalog(family_key, cities)
        await show_family_catalog_city(callback, state, family_key, city_key)

    @dp.callback_query(F.data.startswith("family_payment_delete:"))
    @require_admin
    async def on_family_payment_delete(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer()
        _, family_key, index_text = callback.data.split(":", 2)
        index = int(index_text)
        family = await fetch_family(family_key)
        methods = list(family.get("payment_methods", []))
        if 0 <= index < len(methods):
            methods.pop(index)
        await update_family(family_key, {"payment_methods": methods})
        await show_family_payments(callback, state, family_key)

    @dp.message(AdminState.waiting_value)
    @require_admin
    async def on_waiting_value(message: Message, state: FSMContext) -> None:
        raw_value = (message.text or "").strip()
        if not raw_value:
            await message.answer("✍️ Нужно прислать текст.")
            return
        data = await state.get_data()
        mode = data["mode"]

        if mode == "central_global_admin_add":
            if not raw_value.isdigit():
                settings = await load_central_settings()
                await message.answer(
                    "🆔 Нужен числовой Telegram ID.",
                    reply_markup=build_central_global_admins_menu(settings["global_admin_ids"]),
                )
                return
            admin_id = int(raw_value)
            settings = await load_central_settings()
            settings["global_admin_ids"] = sorted(set(settings["global_admin_ids"] + [admin_id]))
            await save_central_settings(settings)
            invalidate_admin_ids_cache()
            errors = await propagate_global_admin_id(admin_id, add=True)
            await show_central_global_admins(message, state)
            if errors:
                await message.answer(
                    "⚠️ Админ сохранён в общей админке, но не все семейства ответили:\n" + "\n".join(errors[:10]),
                    reply_markup=build_central_settings_menu(),
                )
            return

        if mode == "central_clone_token_add":
            token = raw_value
            settings = await load_central_settings()
            primary_token = os.getenv("CENTRAL_BOT_TOKEN", "").strip()
            if TOKEN_RE.fullmatch(token) is None:
                await message.answer(
                    f"{ce('lock')} Нужен валидный токен Telegram-бота в формате <code>123456:ABC...</code>.",
                    reply_markup=build_central_clone_tokens_menu(settings["clone_bot_tokens"]),
                )
                return
            if token == primary_token or token in settings["clone_bot_tokens"]:
                await message.answer(
                    "⚠️ Этот токен уже используется общей админкой.",
                    reply_markup=build_central_clone_tokens_menu(settings["clone_bot_tokens"]),
                )
                return
            settings["clone_bot_tokens"] = settings["clone_bot_tokens"] + [token]
            settings = await save_central_settings(settings)
            await show_central_clone_tokens(message, state)
            await message.answer(
                f"{ce('bots')} Токен клона сохранён.\n\nПерезапускаю общую админку, чтобы поднять нового админ-бота.",
                reply_markup=build_central_settings_menu(),
            )
            asyncio.create_task(restart_process())
            return

        family_key = data["family_key"]
        family = await fetch_family(family_key)

        if mode in {"catalog_city_add", "catalog_city_rename", "catalog_district_add", "catalog_district_rename"}:
            cities = await fetch_family_catalog(family_key)
            city_key = str(data.get("city_key") or "")
            city = find_catalog_city(cities, city_key) if city_key else None

            if mode == "catalog_city_add":
                cities.append(
                    {
                        "key": make_catalog_key("city"),
                        "label": raw_value,
                        "icon": "🏘",
                        "country_key": None,
                        "country_label": None,
                        "districts": [],
                        "district_selection_percent": 100,
                        "products": [],
                    }
                )
                await update_family_catalog(family_key, cities)
                await show_family_catalog(message, state, family_key)
                return

            if city is None:
                await message.answer("Город не найден.", reply_markup=build_back_family_menu(family_key))
                return

            if mode == "catalog_city_rename":
                city["label"] = raw_value
                await update_family_catalog(family_key, cities)
                await show_family_catalog_city(message, state, family_key, city_key)
                return

            districts = city.get("districts", [])
            if not isinstance(districts, list):
                city["districts"] = []
                districts = city["districts"]

            if mode == "catalog_district_add":
                districts.append(raw_value)
                await update_family_catalog(family_key, cities)
                await show_family_catalog_city(message, state, family_key, city_key)
                return

            district_index = int(data["district_index"])
            if not (0 <= district_index < len(districts)):
                await message.answer("Район не найден.", reply_markup=build_back_to_city_menu(family_key, city_key))
                return
            districts[district_index] = raw_value
            await update_family_catalog(family_key, cities)
            await show_family_catalog_district(message, state, family_key, city_key, district_index)
            return

        if mode == "field":
            template = dict(family.get("template", {}))
            field_name = data["field_name"]
            storage_name = resolve_template_field_storage_name(family_key, field_name)
            if field_name in {"operator_username", "payment_support_username"}:
                normalized_username = raw_value.lstrip("@")
                if _TELEGRAM_USERNAME_PATTERN.fullmatch(normalized_username) is None:
                    await message.answer(
                        "Нужен Telegram username в формате <code>@username</code> или <code>username</code>.",
                        reply_markup=build_back_family_menu(family_key),
                    )
                    return
                template[field_name] = normalized_username
                if field_name == "operator_username":
                    template["operator_url"] = f"https://t.me/{normalized_username}"
            elif field_name.endswith("_url"):
                normalized_url = normalize_central_url(raw_value)
                if normalized_url is None:
                    await message.answer(
                        "Нужна ссылка: полный URL (https://…), t.me-ссылка или @username. Отправь <code>-</code> чтобы очистить.",
                        reply_markup=build_back_family_menu(family_key),
                    )
                    return
                template[storage_name] = normalized_url or None
            else:
                template[storage_name] = raw_value
            await update_family(family_key, {"template": template})
            refreshed_family = await fetch_family(family_key)
            refreshed_template = dict(refreshed_family.get("template", {}))
            if field_name in {"operator_username", "payment_support_username"}:
                persisted_value = str(refreshed_template.get(field_name) or "").strip().lstrip("@")
                if persisted_value != normalized_username:
                    await message.answer(
                        "Не удалось подтвердить сохранение username через семейный API. Проверь ещё раз.",
                        reply_markup=build_back_family_menu(family_key),
                    )
                    return
            elif field_name.endswith("_url"):
                pass  # HttpUrl may normalize (trailing slash etc.); skip strict equality check
            else:
                persisted_value = str(get_template_field_value(family_key, refreshed_template, field_name) or "")
                if persisted_value != raw_value:
                    await message.answer(
                        "Поле не подтвердилось после записи через семейный API. Проверь ещё раз.",
                        reply_markup=build_back_family_menu(family_key),
                    )
                    return
            await show_family_field(message, state, family_key, field_name)
            return

        if mode == "admin_add":
            admin_ids = sorted(set([item for item in family.get("admin_ids", []) if isinstance(item, int)] + [int(raw_value)]))
            await update_family(family_key, {"admin_ids": admin_ids})
            await show_family_admins(message, state, family_key)
            return

        if mode == "payment_extra_text":
            template = dict(family.get("template", {}))
            if raw_value in {"-", "—", "–"}:
                template["payment_extra_message_text"] = ""
                template["payment_extra_message_enabled"] = False
            else:
                template["payment_extra_message_text"] = raw_value
            await update_family(family_key, {"template": template})
            await show_family_payment_extra(message, state, family_key)
            return

        if mode == "broadcast":
            progress_message = await message.answer(
                f"Запускаю рассылку по семейству {escape(SERVICES[family_key].label)}..."
            )
            result = await broadcast_family(family_key, raw_value)
            recipients_count = int(result.get("recipients_count", 0) or 0)
            if recipients_count == 0:
                summary = "\n".join(
                    [
                        "<b>Рассылка завершена</b>",
                        "",
                        f"Семейство: {escape(SERVICES[family_key].label)}",
                        "Получателей пока нет.",
                        "Никому не отправлено.",
                    ]
                )
            else:
                summary = "\n".join(
                    [
                        "<b>Рассылка завершена</b>",
                        "",
                        f"Семейство: {escape(SERVICES[family_key].label)}",
                        f"Токенов с получателями: {result.get('bots_count', 0)}",
                        f"Получателей: {recipients_count}",
                        f"Успешно: {result.get('sent_count', 0)}",
                        f"Ошибок: {result.get('failed_count', 0)}",
                    ]
                )
            await state.clear()
            try:
                await progress_message.edit_text(summary, reply_markup=build_back_family_menu(family_key))
            except TelegramBadRequest:
                await message.answer(summary, reply_markup=build_back_family_menu(family_key))
            return

        if mode == "upload_tokens":
            tokens = []
            for line in (message.text or "").splitlines():
                token = line.strip()
                if token:
                    tokens.append(token)
            if not tokens:
                await message.answer("Не нашёл ни одного токена.")
                return
            progress_message = await message.answer(
                f"Загружаю токены в семейство {escape(SERVICES[family_key].label)}..."
            )
            created_count = 0
            updated_count = 0
            failed_items: list[str] = []
            for token in tokens:
                try:
                    result = await create_family_bot(family_key, token)
                    if result.get("created"):
                        created_count += 1
                    else:
                        updated_count += 1
                except ServiceError as exc:
                    failed_items.append(f"{token[:12]}... | {escape(str(exc))}")
            lines = [
                "<b>Загрузка токенов завершена</b>",
                "",
                f"Семейство: {escape(SERVICES[family_key].label)}",
                f"Новых ботов: {created_count}",
                f"Обновлено: {updated_count}",
                f"Ошибок: {len(failed_items)}",
            ]
            if failed_items:
                lines.append("")
                lines.append("Ошибки:")
                lines.extend(failed_items[:10])
            await state.clear()
            summary = "\n".join(lines)
            try:
                await progress_message.edit_text(summary, reply_markup=build_back_family_menu(family_key))
            except TelegramBadRequest:
                await message.answer(summary, reply_markup=build_back_family_menu(family_key))
            return

        methods = list(family.get("payment_methods", []))
        index = int(data["payment_index"])
        if mode == "payment_requisites":
            replace_payment_requisites(methods[index], raw_value)
        await update_family(family_key, {"payment_methods": methods})
        await show_family_payment_editor(message, state, family_key, index)

    @dp.callback_query()
    @require_admin
    async def on_unknown_callback(callback: CallbackQuery, state: FSMContext) -> None:
        await callback.answer("Интерфейс устарел. Откройте /start заново.", show_alert=True)
        await show_main(callback, state)

    @dp.message()
    @require_admin
    async def on_fallback_message(message: Message, state: FSMContext) -> None:
        await show_main(message, state)

    await ensure_global_admins_synced()

    settings = await load_central_settings()
    bots = [bot]
    seen_tokens = {token}
    for current_token in settings["clone_bot_tokens"]:
        if current_token in seen_tokens:
            continue
        seen_tokens.add(current_token)
        bots.append(Bot(token=current_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML)))

    await dp.start_polling(*bots)


if __name__ == "__main__":
    asyncio.run(main())
