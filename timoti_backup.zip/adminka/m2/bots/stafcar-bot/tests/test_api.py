from __future__ import annotations

import shutil
from pathlib import Path

import httpx
import pytest

from app.config.settings import get_settings
from app.main import create_app


@pytest.mark.asyncio
async def test_stafcar_content_and_wallet_api(tmp_path, monkeypatch) -> None:
    source_config = Path(__file__).resolve().parents[1] / "config"
    config_copy = tmp_path / "config"
    shutil.copytree(source_config, config_copy)

    monkeypatch.setenv("APP_SECRET", "secret")
    monkeypatch.setenv("API_KEY", "stafcar-api-key")
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{tmp_path / 'stafcar.db'}")
    monkeypatch.setenv("PRIMARY_BOT_TOKEN", "")
    monkeypatch.setenv("PRIMARY_BOT_NAME", "Stafcar Test")
    monkeypatch.setenv("CONFIG_DIR", str(config_copy))
    get_settings.cache_clear()

    app = create_app()
    headers = {"X-API-Key": "stafcar-api-key"}

    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            response = await client.put(
                "/api/v1/config/content",
                headers=headers,
                json={
                    "welcome_message": "Нове привітання",
                },
            )
            assert response.status_code == 200
            payload = response.json()
            assert payload["welcome_message"] == "Нове привітання"

            response = await client.put(
                "/api/v1/wallets/paydom",
                headers=headers,
                json={"address": "PAYDOM_CARD_NEW"},
            )
            assert response.status_code == 200

            response = await client.get("/api/v1/wallets/paydom", headers=headers)
            assert response.status_code == 200
            wallet_payload = response.json()
            assert wallet_payload["address"] == "PAYDOM_CARD_NEW"

    get_settings.cache_clear()
