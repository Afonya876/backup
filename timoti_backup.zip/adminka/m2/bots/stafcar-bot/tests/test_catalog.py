from __future__ import annotations

from pathlib import Path

import pytest

from app.application.use_cases import CatalogService
from app.infrastructure.config_loader import ConfigStore


@pytest.mark.asyncio
async def test_stafcar_catalog_cities_products_and_districts() -> None:
    config_root = Path(__file__).resolve().parents[1] / "config"
    config_store = ConfigStore(config_root)
    await config_store.load()

    service = CatalogService(config_store)

    top_level = service.list_top_level_cities("ukraine")
    city_ids = {city.id for city in top_level}
    assert "pryluky" in city_ids
    assert "lubny" in city_ids
    assert "berezan" in city_ids

    products = [product.id for product in service.list_products_for_city("pryluky")]
    assert "shipment_nova_poshta" not in products
    assert products == ["alfa_pvp", "amph_local"]

    assert service.is_product_available("pryluky", "alfa_pvp") is True
    assert service.is_product_available("lubny", "amph_local") is True

    districts = service.list_districts_for_product("ukraine", "pryluky", "alfa_pvp")
    assert len(districts) == 3
