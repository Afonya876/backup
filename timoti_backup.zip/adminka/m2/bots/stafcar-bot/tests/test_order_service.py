from __future__ import annotations

from pathlib import Path

import pytest

from app.application.use_cases import CatalogService, OrderService
from app.infrastructure.config_loader import ConfigStore
from app.infrastructure.database import Database
from app.infrastructure.repositories.repositories import BotInstanceRepository, OrderRepository, UserRepository, WalletRepository
from app.infrastructure.security import TokenCipher


@pytest.mark.asyncio
async def test_stafcar_order_service_builds_base_payment_amount_and_ids() -> None:
    config_root = Path(__file__).resolve().parents[1] / "config"
    config_store = ConfigStore(config_root)
    await config_store.load()

    database = Database("sqlite+aiosqlite:///:memory:")
    await database.create_schema()

    async with database.session_factory() as session:
        bot_repository = BotInstanceRepository(session)
        bot_instance = await bot_repository.create(
            telegram_bot_id=123456789,
            name="Stafcar Test",
            username="stafcar_test_bot",
            token_encrypted=TokenCipher("secret").encrypt("123:token"),
            webhook_secret="secret",
            is_primary=True,
        )

        user_repository = UserRepository(session)
        user = await user_repository.get_or_create(telegram_user_id=700, bot_instance_id=bot_instance.id)
        user = await user_repository.save(
            user.id,
            language="ru",
            selection={
                "country_id": "ukraine",
                "city_id": "nova_poshta",
                "district_id": "shipment_nova_poshta",
                "product_id": "shipment_nova_poshta",
                "offer_id": "amph_100g",
            },
        )

        wallet_repository = WalletRepository(session)
        await wallet_repository.upsert("paydom", "PAYDOM_CARD")

        order_service = OrderService(
            config_store=config_store,
            catalog_service=CatalogService(config_store),
            wallet_repository=wallet_repository,
            order_repository=OrderRepository(session),
            user_repository=user_repository,
        )

        reservation = await order_service.create_reservation(user, bot_instance.id)
        user = await user_repository.get_or_create(telegram_user_id=700, bot_instance_id=bot_instance.id)
        order = await order_service.attach_payment(user, "paydom")

    await database.dispose()

    assert reservation.public_id == order.public_id
    assert order.wallet_snapshot == "PAYDOM_CARD"
    assert order.payment_details["payment_amount"] == "19000"
    assert order.payment_details["topup_id"]
    assert order.payment_details["request_id"]
