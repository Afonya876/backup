from app.infrastructure.captcha import CaptchaService


def test_stafcar_captcha_generate_and_validate() -> None:
    service = CaptchaService()

    challenge = service.generate()

    assert challenge.question
    assert service.validate(challenge.answer, challenge.answer)
    assert not service.validate(challenge.answer, "wrong")
