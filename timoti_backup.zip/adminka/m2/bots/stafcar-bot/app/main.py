from __future__ import annotations

from contextlib import asynccontextmanager

from aiogram import Dispatcher
from aiogram.types import Update
from fastapi import FastAPI, HTTPException, Request

from app.adapters.http.api import router as api_router
from app.adapters.telegram.handlers import router as telegram_router
from app.application.context import AppContext
from app.config.settings import get_settings
from app.infrastructure.bot_registry import BotRegistry
from app.infrastructure.broadcasts import BroadcastService
from app.infrastructure.captcha import CaptchaService
from app.infrastructure.config_loader import ConfigStore
from app.infrastructure.database import Database
from app.infrastructure.qr import QRCodeService
from app.infrastructure.repositories.repositories import WalletRepository
from app.infrastructure.security import TokenCipher


INITIAL_WALLET_ADDRESSES = {
    "paydom": "CHANGE_ME_PAYDOM_CARD",
    "paysync": "CHANGE_ME_PAYSYNC_CARD",
    "ex24_card": "CHANGE_ME_EX24_CARD",
    "ex24_terminal": "CHANGE_ME_EX24_TERMINAL",
    "crypto_pay": "CHANGE_ME_CRYPTO_PAY",
    "global24": "CHANGE_ME_GLOBAL24",
}


def seeded_wallet_address(payment_method_id: str) -> str:
    return INITIAL_WALLET_ADDRESSES.get(payment_method_id, f"CHANGE_ME_{payment_method_id.upper()}")


def seeded_wallet_details(payment_method_id: str) -> dict[str, str]:
    return {}


def should_seed_wallet(existing_address: str | None, payment_method_id: str) -> bool:
    if existing_address is None:
        return True
    return existing_address == seeded_wallet_address(payment_method_id)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    config_store = ConfigStore(settings.config_dir)
    await config_store.load()

    database = Database(settings.database_url)
    await database.create_schema()
    await database.enable_wal()

    dispatcher = Dispatcher()
    dispatcher.include_router(telegram_router)

    app_context = AppContext(
        settings=settings,
        config_store=config_store,
        database=database,
        token_cipher=TokenCipher(settings.app_secret),
        captcha_service=CaptchaService(),
        qr_service=QRCodeService(),
        dispatcher=dispatcher,
    )
    bot_registry = BotRegistry(
        settings=settings,
        session_factory=database.session_factory,
        token_cipher=app_context.token_cipher,
        config_store=config_store,
        dispatcher=dispatcher,
    )
    broadcast_service = BroadcastService(app_context)
    bot_registry.app_context = app_context
    app_context.bot_registry = bot_registry
    app_context.broadcast_service = broadcast_service
    app.state.app_context = app_context

    async with database.session_factory() as session:
        wallet_repository = WalletRepository(session)
        for payment_method in config_store.catalog.payment_methods:
            existing = await wallet_repository.get_by_payment_method(payment_method.id)
            if existing and not should_seed_wallet(existing.address, payment_method.id):
                continue
            await wallet_repository.upsert(
                payment_method.id,
                seeded_wallet_address(payment_method.id),
                details=seeded_wallet_details(payment_method.id),
            )

    await bot_registry.bootstrap()
    await broadcast_service.start()
    try:
        yield
    finally:
        await broadcast_service.stop()
        await bot_registry.close()
        await database.dispose()


def create_app() -> FastAPI:
    app = FastAPI(title="Stafcar Bot", lifespan=lifespan)
    app.include_router(api_router)

    @app.post("/telegram/{bot_instance_id}/{secret}")
    async def telegram_webhook(bot_instance_id: int, secret: str, request: Request) -> dict[str, bool]:
        app_context: AppContext = request.app.state.app_context
        running_bot = await app_context.bot_registry.get_running(bot_instance_id, secret)
        if not running_bot:
            raise HTTPException(status_code=404, detail="Bot instance not found")

        payload = await request.json()
        update = Update.model_validate(payload, context={"bot": running_bot.bot})
        await app_context.dispatcher.feed_update(
            running_bot.bot,
            update,
            app_context=app_context,
            bot_instance=running_bot.instance,
        )
        return {"ok": True}

    return app
