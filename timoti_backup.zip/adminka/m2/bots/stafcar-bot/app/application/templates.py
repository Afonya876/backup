from __future__ import annotations

from collections import UserDict
from typing import Any


class _SafeTemplateContext(UserDict[str, Any]):
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


class TemplateRenderer:
    def render(self, template: str, context: dict[str, Any] | None = None) -> str:
        return template.format_map(_SafeTemplateContext(context or {}))
