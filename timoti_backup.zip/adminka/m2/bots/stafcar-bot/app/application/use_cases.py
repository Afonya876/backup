from __future__ import annotations

import html
import secrets
import string
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from app.config.models import CatalogCity, CatalogCountry, CatalogDistrict, CatalogProduct, PaymentMethod, ProductOffer
from app.domain.entities import CatalogSelection, Order, User
from app.domain.enums import OrderStatus, UserState
from app.infrastructure.config_loader import ConfigStore
from app.infrastructure.repositories.repositories import OrderRepository, UserRepository, WalletRepository


KYIV_TZ = ZoneInfo("Europe/Kyiv")


def _find_by_id(items: list, item_id: str):
    for item in items:
        if item.id == item_id:
            return item
    raise ValueError(f"Unknown item id: {item_id}")


@dataclass(slots=True)
class OrderView:
    public_id: str
    product_name: str
    location: str
    price: float
    wallet_address: str
    status: str


class CatalogService:
    def __init__(self, config_store: ConfigStore) -> None:
        self.config_store = config_store

    def get_country(self, country_id: str) -> CatalogCountry:
        return _find_by_id(self.config_store.catalog.countries, country_id)

    def list_top_level_cities(self, country_id: str) -> list[CatalogCity]:
        return self.get_country(country_id).cities

    def get_city(self, country_id: str, city_id: str) -> CatalogCity:
        return _find_by_id(self.get_country(country_id).cities, city_id)

    def get_district(self, country_id: str, city_id: str, district_id: str) -> CatalogDistrict:
        return _find_by_id(self.get_city(country_id, city_id).districts, district_id)

    def list_districts_for_product(self, country_id: str, city_id: str, product_id: str) -> list[CatalogDistrict]:
        city = self.get_city(country_id, city_id)
        product = self.get_product(product_id)
        allowed_ids = product.district_availability.get(city_id)
        if not allowed_ids:
            return city.districts
        allowed = set(allowed_ids)
        return [district for district in city.districts if district.id in allowed]

    def get_district_for_product(self, country_id: str, city_id: str, product_id: str, district_id: str) -> CatalogDistrict:
        return _find_by_id(self.list_districts_for_product(country_id, city_id, product_id), district_id)

    def list_products_for_city(self, city_id: str) -> list[CatalogProduct]:
        return [
            product
            for product in self.config_store.catalog.products
            if product.availability.get(city_id, False)
        ]

    def is_product_available(self, city_id: str, product_id: str) -> bool:
        return self.get_product(product_id).availability.get(city_id, False)

    def get_product(self, product_id: str) -> CatalogProduct:
        return _find_by_id(self.config_store.catalog.products, product_id)

    def get_offer(self, product_id: str, offer_id: str) -> ProductOffer:
        return _find_by_id(self.get_product(product_id).offers, offer_id)

    def get_payment_method(self, payment_id: str) -> PaymentMethod:
        return _find_by_id(self.config_store.catalog.payment_methods, payment_id)

    def render_name(self, locale: str | None, value) -> str:
        return self.config_store.resolve_localized_value(locale, value)

    def format_price(self, value: float) -> str:
        if float(value).is_integer():
            return str(int(value))
        return f"{value:.2f}".rstrip("0").rstrip(".")

    def format_amount(self, value: float, precision: int) -> str:
        if precision <= 0:
            return str(int(round(value)))
        return f"{value:.{precision}f}".rstrip("0").rstrip(".")

    def build_product_name(self, locale: str | None, product_id: str) -> str:
        return self.render_name(locale, self.get_product(product_id).name)

    def build_offer_label(self, locale: str | None, product_id: str, offer_id: str) -> str:
        offer = self.get_offer(product_id, offer_id)
        if offer.display_label:
            return self.render_name(locale, offer.display_label)
        return offer.quantity_label or offer.id


class UserFlowService:
    def __init__(self, config_store: ConfigStore, catalog_service: CatalogService) -> None:
        self.config_store = config_store
        self.catalog_service = catalog_service

    def user_context(self, user: User, username: str) -> dict[str, object]:
        locale = user.language or self.config_store.app_config.default_locale
        return {
            "username": html.escape(username),
            "balance": self.catalog_service.format_price(user.balance_usd),
            "purchase_count": user.purchase_count,
            **self.config_store.app_config.external_links,
        }


class OrderService:
    def __init__(
        self,
        config_store: ConfigStore,
        catalog_service: CatalogService,
        wallet_repository: WalletRepository,
        order_repository: OrderRepository,
        user_repository: UserRepository,
    ) -> None:
        self.config_store = config_store
        self.catalog_service = catalog_service
        self.wallet_repository = wallet_repository
        self.order_repository = order_repository
        self.user_repository = user_repository

    def generate_public_id(self) -> str:
        return secrets.token_hex(12)

    def generate_request_id(self) -> str:
        alphabet = string.ascii_lowercase + string.digits
        return "".join(secrets.choice(alphabet) for _ in range(12))

    def generate_topup_id(self) -> str:
        return secrets.token_hex(12)

    def calculate_deadline(self, created_at: datetime | None = None) -> datetime:
        base = created_at or datetime.now(KYIV_TZ)
        return base + timedelta(hours=2)

    async def create_reservation(self, user: User, bot_instance_id: int) -> Order:
        selection = user.selection
        if not all([selection.country_id, selection.city_id, selection.district_id, selection.product_id, selection.offer_id]):
            raise ValueError("Incomplete selection for reservation")

        locale = user.language or self.config_store.app_config.default_locale
        city = self.catalog_service.get_city(selection.country_id, selection.city_id)
        district = self.catalog_service.get_district_for_product(
            selection.country_id,
            selection.city_id,
            selection.product_id,
            selection.district_id,
        )
        offer = self.catalog_service.get_offer(selection.product_id, selection.offer_id)
        order = await self.order_repository.create(
            public_id=self.generate_public_id(),
            user_id=user.id,
            bot_instance_id=bot_instance_id,
            product_id=selection.product_id,
            product_name=self.catalog_service.build_product_name(locale, selection.product_id),
            city_id=city.id,
            city_name=self.catalog_service.render_name(locale, city.name),
            district_id=district.id,
            district_name=self.catalog_service.render_name(locale, district.name),
            delivery_type_id=offer.id,
            delivery_type_name=offer.quantity_label or offer.id,
            payment_method_id="pending",
            payment_method_name="Не выбран",
            price=offer.base_price,
            wallet_snapshot="-",
            payment_details={
                "offer_label": self.catalog_service.build_offer_label(locale, selection.product_id, selection.offer_id),
                "payment_amount": self.catalog_service.format_price(offer.base_price),
            },
            deadline_at=self.calculate_deadline(),
            status=OrderStatus.PENDING,
        )
        await self.user_repository.save(
            user.id,
            state=UserState.CHOOSING_PAYMENT,
            selection=CatalogSelection(
                country_id=selection.country_id,
                city_id=selection.city_id,
                district_id=selection.district_id,
                product_id=selection.product_id,
                offer_id=selection.offer_id,
                order_public_id=order.public_id,
            ),
        )
        return order

    async def attach_payment(self, user: User, payment_method_id: str) -> Order:
        order_id = user.selection.order_public_id
        if not order_id:
            raise ValueError("Order is not created")

        wallet = await self.wallet_repository.get_by_payment_method(payment_method_id)
        if not wallet:
            raise ValueError(f"Wallet address is not configured for {payment_method_id}")

        payment_method = self.catalog_service.get_payment_method(payment_method_id)
        locale = user.language or self.config_store.app_config.default_locale
        base_price = self._order_price_from_selection(user)
        amount = self.catalog_service.format_amount(base_price, payment_method.amount_precision)

        payment_details = dict(wallet.details or {})
        payment_details.update(
            {
                "payment_amount": amount,
                "offer_label": self.catalog_service.build_offer_label(locale, user.selection.product_id or "", user.selection.offer_id or ""),
                "request_id": self.generate_request_id(),
                "topup_id": self.generate_topup_id(),
                "deadline_label": self._format_deadline(self.calculate_deadline()),
            }
        )
        order = await self.order_repository.update_payment(
            order_id,
            payment_method_id=payment_method.id,
            payment_method_name=self.config_store.t(locale, payment_method.label_key),
            wallet_snapshot=wallet.address,
            payment_details=payment_details,
        )
        await self.user_repository.save(
            user.id,
            state=UserState.IDLE,
            selection=CatalogSelection(country_id=user.selection.country_id),
        )
        return order

    def _order_price_from_selection(self, user: User) -> float:
        if not user.selection.product_id or not user.selection.offer_id:
            raise ValueError("Offer is not selected")
        offer = self.catalog_service.get_offer(user.selection.product_id, user.selection.offer_id)
        return offer.base_price

    async def cancel_order(self, order_id: str) -> Order:
        return await self.order_repository.save_status(order_id, OrderStatus.CANCELLED)

    def build_order_context(self, locale: str | None, order: Order) -> dict[str, str]:
        return {
            "order_number": str(order.id),
            "order_id": str(order.id),
            "request_id": str(order.payment_details.get("request_id") or ""),
            "topup_id": str(order.payment_details.get("topup_id") or order.public_id),
            "city": html.escape(order.city_name),
            "district": html.escape(order.district_name),
            "product_name": html.escape(order.product_name),
            "offer_label": html.escape(str(order.payment_details.get("offer_label") or order.delivery_type_name)),
            "payment_amount": str(order.payment_details.get("payment_amount") or ""),
            "wallet_address": html.escape(order.wallet_snapshot),
            "deadline_label": str(order.payment_details.get("deadline_label") or self._format_deadline(order.deadline_at)),
        }

    def build_order_status_text(self, order: Order) -> str:
        if order.status == OrderStatus.CANCELLED:
            return "Отменен"
        return "Ожидается оплата"

    def build_order_view(self, order: Order) -> OrderView:
        return OrderView(
            public_id=order.public_id,
            product_name=order.product_name,
            location=f"{order.city_name}, {order.district_name}",
            price=order.price,
            wallet_address=order.wallet_snapshot,
            status=self.build_order_status_text(order),
        )

    @staticmethod
    def _format_deadline(value: datetime) -> str:
        local = value.astimezone(KYIV_TZ)
        return local.strftime("%d-%m | %H : %M : %S")
