from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from aiogram import Dispatcher

from app.config.settings import Settings
from app.infrastructure.captcha import CaptchaService
from app.infrastructure.config_loader import ConfigStore
from app.infrastructure.database import Database
from app.infrastructure.qr import QRCodeService
from app.infrastructure.security import TokenCipher

if TYPE_CHECKING:
    from app.infrastructure.bot_registry import BotRegistry
    from app.infrastructure.broadcasts import BroadcastService


@dataclass(slots=True)
class AppContext:
    settings: Settings
    config_store: ConfigStore
    database: Database
    token_cipher: TokenCipher
    captcha_service: CaptchaService
    qr_service: QRCodeService
    dispatcher: Dispatcher
    bot_registry: "BotRegistry | None" = None
    broadcast_service: "BroadcastService | None" = None
