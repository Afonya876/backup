"""Transport adapters."""
