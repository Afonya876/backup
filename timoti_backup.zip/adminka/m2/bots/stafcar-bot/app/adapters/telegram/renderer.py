from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from aiogram.types import (
    BufferedInputFile,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

from app.config.models import ButtonConfig, MediaConfig, ScreenConfig
from app.infrastructure.config_loader import ConfigStore


@dataclass(slots=True)
class RenderedScreen:
    screen: ScreenConfig
    text: str
    parse_mode: str | None
    reply_markup: ReplyKeyboardMarkup | InlineKeyboardMarkup | None
    media: MediaConfig | None
    disable_web_page_preview: bool


def encode_ui_callback(
    button_or_action: ButtonConfig | str,
    target: str | None = None,
    payload: dict[str, Any] | None = None,
) -> str:
    if isinstance(button_or_action, ButtonConfig):
        action = button_or_action.action
        target = button_or_action.target
        payload = button_or_action.payload
    else:
        action = button_or_action
        payload = payload or {}

    payload_encoded = "-"
    if payload:
        payload_encoded = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8").rstrip("=")
    return f"ui:{action}:{target or '-'}:{payload_encoded}"


def decode_ui_callback(value: str) -> tuple[str, str | None, dict[str, Any]]:
    _, action, target, payload_encoded = value.split(":", 3)
    payload: dict[str, Any] = {}
    if payload_encoded != "-":
        padded = payload_encoded + "=" * (-len(payload_encoded) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8"))
    return action, None if target == "-" else target, payload


class ScreenRenderer:
    def __init__(self, config_store: ConfigStore) -> None:
        self.config_store = config_store

    def render(self, screen_id: str, locale: str | None, context: dict[str, Any] | None = None) -> RenderedScreen:
        screen = self.config_store.get_screen(screen_id)
        reply_markup = self._build_markup(screen, locale, context or {})
        text = self.config_store.t(locale, screen.message_key, context)
        return RenderedScreen(
            screen=screen,
            text=text,
            parse_mode=screen.parse_mode or self.config_store.app_config.parse_mode,
            reply_markup=reply_markup,
            media=screen.media,
            disable_web_page_preview=screen.disable_web_page_preview,
        )

    def resolve_reply_button(
        self,
        screen_id: str,
        locale: str | None,
        label: str,
        context: dict[str, Any] | None = None,
    ) -> ButtonConfig | None:
        screen = self.config_store.get_screen(screen_id)
        for button in self._visible_buttons(screen, context or {}):
            if self.config_store.t(locale, button.label_key) == label:
                return button
        return None

    def build_options_keyboard(self, rows: list[list[str]], placeholder: str | None = None) -> ReplyKeyboardMarkup:
        keyboard = [[KeyboardButton(text=label) for label in row] for row in rows]
        return ReplyKeyboardMarkup(
            keyboard=keyboard,
            resize_keyboard=True,
            is_persistent=True,
            input_field_placeholder=placeholder,
        )

    def build_inline_options_keyboard(self, rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text=label, callback_data=callback_data)
                    for label, callback_data in row
                ]
                for row in rows
            ]
        )

    def local_input_file(self, media: MediaConfig) -> FSInputFile | str:
        if media.is_remote:
            return media.source
        path = media.resolve_path(self.config_store.root_dir.parent)
        return FSInputFile(path)

    def buffered_file(self, filename: str, payload: bytes) -> BufferedInputFile:
        return BufferedInputFile(payload, filename=filename)

    def _build_markup(
        self,
        screen: ScreenConfig,
        locale: str | None,
        context: dict[str, Any],
    ) -> ReplyKeyboardMarkup | InlineKeyboardMarkup | None:
        visible_buttons = self._visible_buttons(screen, context)
        if not visible_buttons:
            return None

        grouped_rows: dict[int, list[ButtonConfig]] = {}
        for button in visible_buttons:
            grouped_rows.setdefault(button.row, []).append(button)

        if screen.keyboard_type == "reply":
            keyboard = [
                [KeyboardButton(text=self.config_store.t(locale, button.label_key)) for button in grouped_rows[row]]
                for row in sorted(grouped_rows)
            ]
            placeholder = (
                self.config_store.t(locale, screen.placeholder_key)
                if screen.placeholder_key
                else None
            )
            return ReplyKeyboardMarkup(
                keyboard=keyboard,
                resize_keyboard=True,
                is_persistent=True,
                input_field_placeholder=placeholder,
            )

        keyboard_rows = []
        for row in sorted(grouped_rows):
            inline_row = []
            for button in grouped_rows[row]:
                if button.action == "url" and button.url:
                    inline_row.append(
                        InlineKeyboardButton(
                            text=self.config_store.t(locale, button.label_key),
                            url=self.config_store.renderer.render(button.url, context),
                        )
                    )
                else:
                    inline_row.append(
                        InlineKeyboardButton(
                            text=self.config_store.t(locale, button.label_key),
                            callback_data=encode_ui_callback(button),
                        )
                    )
            keyboard_rows.append(inline_row)
        return InlineKeyboardMarkup(inline_keyboard=keyboard_rows)

    def _visible_buttons(self, screen: ScreenConfig, context: dict[str, Any]) -> list[ButtonConfig]:
        if not screen.buttons:
            return []
        visible = []
        for button in screen.buttons:
            if button.visible_if and not context.get(button.visible_if):
                continue
            visible.append(button)
        return visible
