from __future__ import annotations

from dataclasses import dataclass

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardMarkup, Message

from app.adapters.telegram.renderer import ScreenRenderer
from app.application.context import AppContext
from app.application.use_cases import CatalogService, OrderService, UserFlowService
from app.domain.entities import BotInstance, CatalogSelection, User
from app.domain.enums import UserState
from app.infrastructure.repositories.repositories import OrderRepository, UserRepository, WalletRepository


router = Router()


def flow_callback(action: str, value: str | None = None) -> str:
    return f"flow:{action}:{value or '-'}"


def parse_flow_callback(value: str) -> tuple[str, str | None]:
    _, action, payload = value.split(":", 2)
    return action, None if payload == "-" else payload


@dataclass(slots=True)
class RuntimeServices:
    user_repository: UserRepository
    order_repository: OrderRepository
    wallet_repository: WalletRepository
    catalog_service: CatalogService
    user_flow_service: UserFlowService
    order_service: OrderService
    screen_renderer: ScreenRenderer


def build_services(app_context: AppContext, session) -> RuntimeServices:
    user_repository = UserRepository(session)
    order_repository = OrderRepository(session)
    wallet_repository = WalletRepository(session)
    catalog_service = CatalogService(app_context.config_store)
    user_flow_service = UserFlowService(app_context.config_store, catalog_service)
    order_service = OrderService(
        app_context.config_store,
        catalog_service,
        wallet_repository,
        order_repository,
        user_repository,
    )
    return RuntimeServices(
        user_repository=user_repository,
        order_repository=order_repository,
        wallet_repository=wallet_repository,
        catalog_service=catalog_service,
        user_flow_service=user_flow_service,
        order_service=order_service,
        screen_renderer=ScreenRenderer(app_context.config_store),
    )


def build_inline_keyboard(rows: list[list[tuple[str, str]]], renderer: ScreenRenderer) -> InlineKeyboardMarkup:
    return renderer.build_inline_options_keyboard(rows)


def _city_label(services: RuntimeServices, locale: str, city_id: str) -> str:
    city = services.catalog_service.get_city("ukraine", city_id)
    return services.catalog_service.render_name(locale, city.name)


def menu_rows(locale: str, services: RuntimeServices) -> list[list[tuple[str, str]]]:
    t = services.screen_renderer.config_store.t
    rows: list[list[tuple[str, str]]] = [
        [
            (_city_label(services, locale, "pryluky"), flow_callback("city", "pryluky")),
            (_city_label(services, locale, "lubny"), flow_callback("city", "lubny")),
        ],
        [(t(locale, "buttons.shipping"), flow_callback("shipping"))],
        [(_city_label(services, locale, "pereiaslav"), flow_callback("city", "pereiaslav"))],
        [(_city_label(services, locale, "boryspil"), flow_callback("city", "boryspil"))],
        [(_city_label(services, locale, "baryshivka"), flow_callback("city", "baryshivka"))],
        [
            (_city_label(services, locale, "zolotonosha"), flow_callback("city", "zolotonosha")),
            (_city_label(services, locale, "yagotyn"), flow_callback("city", "yagotyn")),
        ],
        [(_city_label(services, locale, "berezan"), flow_callback("city", "berezan"))],
        [
            (t(locale, "buttons.enter_promo"), flow_callback("stub", "promo")),
            (t(locale, "buttons.purchases"), flow_callback("stub", "purchases")),
        ],
        [
            (t(locale, "buttons.jobs"), flow_callback("stub", "jobs")),
            (t(locale, "buttons.rules"), flow_callback("stub", "rules")),
        ],
        [
            (t(locale, "buttons.profile"), flow_callback("stub", "profile")),
            (t(locale, "buttons.site"), flow_callback("stub", "site")),
        ],
        [
            (t(locale, "buttons.topup"), flow_callback("stub", "topup")),
            (t(locale, "buttons.reviews"), flow_callback("stub", "reviews")),
        ],
        [(t(locale, "buttons.discounts"), flow_callback("stub", "discounts"))],
    ]
    return rows


async def show_main_menu(message: Message, services: RuntimeServices, user: User, username: str) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    await services.user_repository.save(
        user.id,
        state=UserState.CHOOSING_CITY,
        current_screen="main_menu",
        selection=CatalogSelection(country_id="ukraine"),
    )
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "screens.main_menu.message",
            services.user_flow_service.user_context(user, username),
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(menu_rows(locale, services), services.screen_renderer),
        disable_web_page_preview=True,
    )


async def show_shipping_hub(message: Message, services: RuntimeServices, user: User, username: str) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    await services.user_repository.save(
        user.id,
        state=UserState.CHOOSING_CITY,
        current_screen="shipping_menu",
        selection=CatalogSelection(country_id="ukraine", city_id="nova_poshta"),
    )
    rows = [
        [(services.catalog_service.render_name(locale, services.catalog_service.get_city("ukraine", "nova_poshta").name), flow_callback("city", "nova_poshta"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main"))],
    ]
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "screens.main_menu.message",
            services.user_flow_service.user_context(user, username),
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(rows, services.screen_renderer),
        disable_web_page_preview=True,
    )


async def show_product_prompt(message: Message, services: RuntimeServices, user: User) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    city = services.catalog_service.get_city(user.selection.country_id or "ukraine", user.selection.city_id or "")
    rows: list[list[tuple[str, str]]] = [
        [(services.catalog_service.render_name(locale, product.name), flow_callback("product", product.id))]
        for product in services.catalog_service.list_products_for_city(city.id)
    ]
    rows.append(
        [
            (services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main")),
            (services.screen_renderer.config_store.t(locale, "buttons.back"), flow_callback("back_main")),
        ]
    )
    await services.user_repository.save(user.id, state=UserState.CHOOSING_PRODUCT)
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "prompts.select_product",
            {"city": services.catalog_service.render_name(locale, city.name)},
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(rows, services.screen_renderer),
    )


async def show_offer_prompt(message: Message, services: RuntimeServices, user: User) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    city = services.catalog_service.get_city(user.selection.country_id or "ukraine", user.selection.city_id or "")
    product = services.catalog_service.get_product(user.selection.product_id or "")
    rows = [
        [(
            services.catalog_service.build_offer_label(locale, product.id, offer.id),
            flow_callback("offer", offer.id),
        )]
        for offer in product.offers
    ]
    rows.append(
        [
            (services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main")),
            (services.screen_renderer.config_store.t(locale, "buttons.back"), flow_callback("back_product")),
        ]
    )
    await services.user_repository.save(user.id, state=UserState.CHOOSING_OFFER)
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "prompts.select_offer",
            {
                "city": services.catalog_service.render_name(locale, city.name),
                "product_name": services.catalog_service.render_name(locale, product.name),
            },
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(rows, services.screen_renderer),
    )


async def show_district_prompt(message: Message, services: RuntimeServices, user: User) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    city = services.catalog_service.get_city(user.selection.country_id or "ukraine", user.selection.city_id or "")
    product = services.catalog_service.get_product(user.selection.product_id or "")
    offer = services.catalog_service.get_offer(product.id, user.selection.offer_id or "")
    rows = [
        [(services.catalog_service.render_name(locale, district.name), flow_callback("district", district.id))]
        for district in services.catalog_service.list_districts_for_product(
            user.selection.country_id or "ukraine",
            city.id,
            product.id,
        )
    ]
    rows.append(
        [
            (services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main")),
            (services.screen_renderer.config_store.t(locale, "buttons.back"), flow_callback("back_offer")),
        ]
    )
    await services.user_repository.save(user.id, state=UserState.CHOOSING_DISTRICT)
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "prompts.select_district",
            {
                "city": services.catalog_service.render_name(locale, city.name),
                "product_name": services.catalog_service.render_name(locale, product.name),
                "offer_label": services.catalog_service.build_offer_label(locale, product.id, offer.id),
            },
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(rows, services.screen_renderer),
    )


async def show_payment_prompt(message: Message, services: RuntimeServices, user: User, order: object) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    rows = [
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_paydom"), flow_callback("payment", "paydom"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_ex24_card"), flow_callback("payment", "ex24_card"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_ex24_terminal"), flow_callback("payment", "ex24_terminal"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_paysync"), flow_callback("payment", "paysync"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_crypto"), flow_callback("payment", "crypto_pay"))],
        [(services.screen_renderer.config_store.t(locale, "buttons.pay_global24"), flow_callback("payment", "global24"))],
        [
            (services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main")),
            (services.screen_renderer.config_store.t(locale, "buttons.back"), flow_callback("back_district")),
        ],
    ]
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "order.checkout",
            {
                "city": order.city_name,
                "product_name": order.product_name,
                "offer_label": order.payment_details.get("offer_label") or order.delivery_type_name,
                "district": order.district_name,
            },
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(rows, services.screen_renderer),
    )


async def send_payment_details(message: Message, services: RuntimeServices, user: User, order) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    context = services.order_service.build_order_context(locale, order)
    await message.answer(
        services.screen_renderer.config_store.t(locale, "order.payment_details", context),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
        reply_markup=build_inline_keyboard(
            [
                [(services.screen_renderer.config_store.t(locale, "buttons.check_payment"), flow_callback("stub", "check_payment"))],
                [(services.screen_renderer.config_store.t(locale, "buttons.main_menu"), flow_callback("back_main"))],
            ],
            services.screen_renderer,
        ),
    )
    await message.answer(
        services.screen_renderer.config_store.t(locale, "order.payment_short", context),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
    )


async def send_captcha(message: Message, services: RuntimeServices, app_context: AppContext, user: User) -> None:
    locale = user.language or services.screen_renderer.config_store.app_config.default_locale
    challenge = app_context.captcha_service.generate()
    await services.user_repository.save(
        user.id,
        captcha_passed=False,
        captcha_answer=challenge.answer,
        state=UserState.AWAITING_CAPTCHA,
    )
    await message.answer(
        services.screen_renderer.config_store.t(
            locale,
            "captcha.prompt",
            {"challenge": challenge.question},
        ),
        parse_mode=services.screen_renderer.config_store.app_config.parse_mode,
    )


@router.message(CommandStart())
async def command_start(message: Message, app_context: AppContext, bot_instance: BotInstance) -> None:
    if not message.from_user:
        return
    async with app_context.database.session_factory() as session:
        services = build_services(app_context, session)
        user = await services.user_repository.get_or_create(message.from_user.id, bot_instance.id)
        if not user.language:
            user = await services.user_repository.save(user.id, language="ru")
        if not user.captcha_passed:
            await send_captcha(message, services, app_context, user)
            return
        await show_main_menu(message, services, user, message.from_user.full_name)


@router.message(F.text)
async def handle_text_message(message: Message, app_context: AppContext, bot_instance: BotInstance) -> None:
    if not message.from_user:
        return
    async with app_context.database.session_factory() as session:
        services = build_services(app_context, session)
        user = await services.user_repository.get_or_create(message.from_user.id, bot_instance.id)
        if not user.language:
            user = await services.user_repository.save(user.id, language="ru")
        if not user.captcha_passed:
            if app_context.captcha_service.validate(user.captcha_answer, message.text):
                user = await services.user_repository.save(
                    user.id,
                    captcha_passed=True,
                    captcha_answer=None,
                    state=UserState.IDLE,
                )
                await message.answer(
                    app_context.config_store.t(user.language, "captcha.success"),
                    parse_mode=app_context.config_store.app_config.parse_mode,
                )
                await show_main_menu(message, services, user, message.from_user.full_name)
            else:
                await message.answer(
                    app_context.config_store.t(user.language, "captcha.failed"),
                    parse_mode=app_context.config_store.app_config.parse_mode,
                )
                await send_captcha(message, services, app_context, user)
            return
        await message.answer(app_context.config_store.t(user.language, "errors.use_buttons"))


@router.callback_query(F.data.startswith("flow:"))
async def handle_flow_callback(callback_query, app_context: AppContext, bot_instance: BotInstance) -> None:
    if not callback_query.message or not callback_query.from_user or not callback_query.data:
        return
    async with app_context.database.session_factory() as session:
        services = build_services(app_context, session)
        user = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
        if not user.language:
            user = await services.user_repository.save(user.id, language="ru")
        if not user.captcha_passed:
            await send_captcha(callback_query.message, services, app_context, user)
            await callback_query.answer()
            return
        action, value = parse_flow_callback(callback_query.data)

        if action == "back_main":
            await show_main_menu(callback_query.message, services, user, callback_query.from_user.full_name)
            await callback_query.answer()
            return

        if action == "shipping":
            await show_shipping_hub(callback_query.message, services, user, callback_query.from_user.full_name)
            await callback_query.answer()
            return

        if action == "stub":
            await callback_query.message.answer(app_context.config_store.t(user.language, f"stubs.{value}"))
            await callback_query.answer()
            return

        if action == "city" and value:
            if user.current_screen == "shipping_menu":
                await services.user_repository.save(
                    user.id,
                    selection=CatalogSelection(
                        country_id="ukraine",
                        city_id=value,
                    ),
                    state=UserState.CHOOSING_PRODUCT,
                    current_screen="shipping_menu",
                )
                updated = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
                await show_product_prompt(callback_query.message, services, updated)
            else:
                await services.user_repository.save(
                    user.id,
                    selection=CatalogSelection(country_id="ukraine", city_id=value),
                    state=UserState.CHOOSING_PRODUCT,
                    current_screen="main_menu",
                )
                updated = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
                await show_product_prompt(callback_query.message, services, updated)
            await callback_query.answer()
            return

        if action == "back_product":
            await show_product_prompt(callback_query.message, services, user)
            await callback_query.answer()
            return

        if action == "product" and value:
            await services.user_repository.save(
                user.id,
                selection=CatalogSelection(
                    country_id="ukraine",
                    city_id=user.selection.city_id,
                    product_id=value,
                ),
                state=UserState.CHOOSING_OFFER,
            )
            updated = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
            await show_offer_prompt(callback_query.message, services, updated)
            await callback_query.answer()
            return

        if action == "back_offer":
            await show_offer_prompt(callback_query.message, services, user)
            await callback_query.answer()
            return

        if action == "offer" and value:
            await services.user_repository.save(
                user.id,
                selection=CatalogSelection(
                    country_id="ukraine",
                    city_id=user.selection.city_id,
                    product_id=user.selection.product_id,
                    offer_id=value,
                ),
                state=UserState.CHOOSING_DISTRICT,
            )
            updated = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
            await show_district_prompt(callback_query.message, services, updated)
            await callback_query.answer()
            return

        if action == "back_district":
            await show_district_prompt(callback_query.message, services, user)
            await callback_query.answer()
            return

        if action == "district" and value:
            updated = await services.user_repository.save(
                user.id,
                selection=CatalogSelection(
                    country_id="ukraine",
                    city_id=user.selection.city_id,
                    product_id=user.selection.product_id,
                    offer_id=user.selection.offer_id,
                    district_id=value,
                ),
            )
            order = await services.order_service.create_reservation(updated, bot_instance.id)
            latest_user = await services.user_repository.get_or_create(callback_query.from_user.id, bot_instance.id)
            await show_payment_prompt(callback_query.message, services, latest_user, order)
            await callback_query.answer()
            return

        if action == "payment_stub":
            await callback_query.answer(app_context.config_store.t(user.language, "errors.payment_unavailable"), show_alert=True)
            return

        if action == "payment" and value:
            order = await services.order_service.attach_payment(user, value)
            await send_payment_details(callback_query.message, services, user, order)
            await callback_query.answer()
            return

        await callback_query.answer(app_context.config_store.t(user.language, "errors.use_buttons"), show_alert=True)
