"""Telegram adapter."""
