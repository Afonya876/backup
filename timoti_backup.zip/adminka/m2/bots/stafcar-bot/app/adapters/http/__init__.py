"""HTTP API adapter."""
