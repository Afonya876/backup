from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel

from app.application.context import AppContext
from app.infrastructure.bot_registry import BotProvisioningError, BotRemovalError, BotTokenValidationError
from app.infrastructure.repositories.repositories import ProxyRepository, WalletRepository
from app.infrastructure.security import constant_time_equal


router = APIRouter(prefix="/api/v1", tags=["api"])


class WalletUpdateRequest(BaseModel):
    address: str | None = None
    usd_rate: float | None = None


class BotCreateRequest(BaseModel):
    token: str
    name: str | None = None


class ContentSettingsUpdateRequest(BaseModel):
    locale: str | None = None
    welcome_message: str | None = None
    help_message: str | None = None
    vacancies_message: str | None = None
    rules_message: str | None = None
    instructions_message: str | None = None
    contacts_message: str | None = None


class BroadcastCreateRequest(BaseModel):
    message: str
    schedule_type: str
    interval_hours: int | None = None
    daily_time: str | None = None
    is_active: bool = True


class BroadcastUpdateRequest(BaseModel):
    message: str | None = None
    schedule_type: str | None = None
    interval_hours: int | None = None
    daily_time: str | None = None
    is_active: bool | None = None


async def get_app_context(request: Request) -> AppContext:
    return request.app.state.app_context


async def require_api_key(
    x_api_key: Annotated[str | None, Header(alias="X-API-Key")] = None,
    app_context: AppContext = Depends(get_app_context),
) -> None:
    if not x_api_key or not constant_time_equal(x_api_key, app_context.settings.api_key):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")


@router.get("/health")
async def health(app_context: AppContext = Depends(get_app_context)) -> dict[str, str]:
    return app_context.bot_registry.health_status()


@router.post("/config/reload", dependencies=[Depends(require_api_key)])
async def reload_config(app_context: AppContext = Depends(get_app_context)) -> dict[str, str]:
    await app_context.config_store.reload()
    return {"status": "reloaded"}


@router.get("/config/content", dependencies=[Depends(require_api_key)])
async def get_content_settings(
    locale: str | None = None,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | None]:
    active_locale = locale or app_context.config_store.app_config.default_locale
    try:
        return app_context.config_store.get_content_settings(active_locale)
    except FileNotFoundError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error


@router.put("/config/content", dependencies=[Depends(require_api_key)])
async def update_content_settings(
    payload: ContentSettingsUpdateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | None]:
    if (
        payload.welcome_message is None
        and payload.help_message is None
        and payload.vacancies_message is None
        and payload.rules_message is None
        and payload.instructions_message is None
        and payload.contacts_message is None
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one content field must be provided",
        )

    active_locale = payload.locale or app_context.config_store.app_config.default_locale
    updates: dict[str, str] = {}
    if payload.welcome_message is not None:
        updates["screens.main_menu.message"] = payload.welcome_message
    if payload.help_message is not None:
        updates["screens.instructions.message"] = payload.help_message
    if payload.vacancies_message is not None:
        updates["screens.jobs.message"] = payload.vacancies_message
    if payload.rules_message is not None:
        updates["screens.rules.message"] = payload.rules_message
    if payload.instructions_message is not None:
        updates["screens.instructions.message"] = payload.instructions_message
    if payload.contacts_message is not None:
        updates["screens.contacts.message"] = payload.contacts_message

    try:
        await app_context.config_store.update_locale_messages(active_locale, updates)
        return app_context.config_store.get_content_settings(active_locale)
    except FileNotFoundError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error


@router.get("/wallets", dependencies=[Depends(require_api_key)])
async def list_wallets(app_context: AppContext = Depends(get_app_context)) -> list[dict[str, str]]:
    async with app_context.database.session_factory() as session:
        repository = WalletRepository(session)
        wallets = await repository.list_all()
    return [
        {
            "payment_method_id": wallet.payment_method_id,
            "address": wallet.address,
            "updated_at": wallet.updated_at.isoformat(),
        }
        for wallet in wallets
    ]


@router.get("/wallets/{payment_method_id}", dependencies=[Depends(require_api_key)])
async def get_wallet_detail(
    payment_method_id: str,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | None]:
    async with app_context.database.session_factory() as session:
        repository = WalletRepository(session)
        wallet = await repository.get_by_payment_method(payment_method_id)
    if not wallet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Wallet not found")

    return {
        "payment_method_id": wallet.payment_method_id,
        "address": wallet.address,
        "usd_rate": str(wallet.details.get("usd_rate") or 1),
        "updated_at": wallet.updated_at.isoformat(),
    }


@router.put("/wallets/{payment_method_id}", dependencies=[Depends(require_api_key)])
async def update_wallet(
    payment_method_id: str,
    payload: WalletUpdateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | None]:
    async with app_context.database.session_factory() as session:
        repository = WalletRepository(session)
        current = await repository.get_by_payment_method(payment_method_id)
        if not current:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Wallet not found")
        details = dict(current.details or {})
        if payload.usd_rate is not None:
            details["usd_rate"] = payload.usd_rate
        wallet = await repository.upsert(
            payment_method_id,
            payload.address if payload.address is not None else current.address,
            details=details,
        )
    return {
        "payment_method_id": wallet.payment_method_id,
        "address": wallet.address,
        "usd_rate": str(wallet.details.get("usd_rate") or 1),
        "updated_at": wallet.updated_at.isoformat(),
    }


@router.get("/bots", dependencies=[Depends(require_api_key)])
async def list_bots(app_context: AppContext = Depends(get_app_context)) -> list[dict[str, str | int | bool | None]]:
    bots = await app_context.bot_registry.list_running()
    return [
        {
            "id": running.instance.id,
            "telegram_bot_id": running.instance.telegram_bot_id,
            "name": running.instance.name,
            "username": running.instance.username,
            "enabled": running.instance.enabled,
            "is_primary": running.instance.is_primary,
        }
        for running in bots
    ]


@router.post("/bots", dependencies=[Depends(require_api_key)])
async def add_bot(
    payload: BotCreateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | int | bool | None]:
    try:
        instance = await app_context.bot_registry.add_bot(token=payload.token, name=payload.name)
    except BotTokenValidationError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error
    except BotProvisioningError as error:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(error)) from error
    return {
        "id": instance.id,
        "telegram_bot_id": instance.telegram_bot_id,
        "name": instance.name,
        "username": instance.username,
        "enabled": instance.enabled,
        "is_primary": instance.is_primary,
    }


@router.delete("/bots/{bot_instance_id}", dependencies=[Depends(require_api_key)])
async def delete_bot(
    bot_instance_id: int,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str]:
    try:
        await app_context.bot_registry.remove_bot(bot_instance_id)
    except BotRemovalError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error
    return {"status": "deleted"}


@router.get("/broadcasts", dependencies=[Depends(require_api_key)])
async def list_broadcasts(app_context: AppContext = Depends(get_app_context)) -> list[dict[str, str | int | bool | None]]:
    broadcasts = await app_context.broadcast_service.list_broadcasts()
    return [
        {
            "id": broadcast.id,
            "message": broadcast.message,
            "schedule_type": broadcast.schedule_type,
            "interval_hours": broadcast.interval_hours,
            "daily_time": broadcast.daily_time,
            "is_active": broadcast.is_active,
            "next_run_at": broadcast.next_run_at.isoformat() if broadcast.next_run_at else None,
            "last_run_at": broadcast.last_run_at.isoformat() if broadcast.last_run_at else None,
            "last_finished_at": broadcast.last_finished_at.isoformat() if broadcast.last_finished_at else None,
            "last_recipient_count": broadcast.last_recipient_count,
            "last_error": broadcast.last_error,
            "created_at": broadcast.created_at.isoformat(),
            "updated_at": broadcast.updated_at.isoformat(),
        }
        for broadcast in broadcasts
    ]


@router.post("/broadcasts", dependencies=[Depends(require_api_key)])
async def create_broadcast(
    payload: BroadcastCreateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | int | bool | None]:
    try:
        broadcast = await app_context.broadcast_service.create_broadcast(
            message=payload.message,
            schedule_type=payload.schedule_type,
            interval_hours=payload.interval_hours,
            daily_time=payload.daily_time,
            is_active=payload.is_active,
        )
    except ValueError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error
    return {
        "id": broadcast.id,
        "message": broadcast.message,
        "schedule_type": broadcast.schedule_type,
        "interval_hours": broadcast.interval_hours,
        "daily_time": broadcast.daily_time,
        "is_active": broadcast.is_active,
        "next_run_at": broadcast.next_run_at.isoformat() if broadcast.next_run_at else None,
        "last_run_at": broadcast.last_run_at.isoformat() if broadcast.last_run_at else None,
        "last_finished_at": broadcast.last_finished_at.isoformat() if broadcast.last_finished_at else None,
        "last_recipient_count": broadcast.last_recipient_count,
        "last_error": broadcast.last_error,
        "created_at": broadcast.created_at.isoformat(),
        "updated_at": broadcast.updated_at.isoformat(),
    }


@router.put("/broadcasts/{broadcast_id}", dependencies=[Depends(require_api_key)])
async def update_broadcast(
    broadcast_id: int,
    payload: BroadcastUpdateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | int | bool | None]:
    try:
        broadcast = await app_context.broadcast_service.update_broadcast(
            broadcast_id,
            message=payload.message,
            schedule_type=payload.schedule_type,
            interval_hours=payload.interval_hours,
            daily_time=payload.daily_time,
            is_active=payload.is_active,
        )
    except ValueError as error:
        detail = str(error)
        status_code = status.HTTP_404_NOT_FOUND if "not found" in detail.lower() else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail) from error
    return {
        "id": broadcast.id,
        "message": broadcast.message,
        "schedule_type": broadcast.schedule_type,
        "interval_hours": broadcast.interval_hours,
        "daily_time": broadcast.daily_time,
        "is_active": broadcast.is_active,
        "next_run_at": broadcast.next_run_at.isoformat() if broadcast.next_run_at else None,
        "last_run_at": broadcast.last_run_at.isoformat() if broadcast.last_run_at else None,
        "last_finished_at": broadcast.last_finished_at.isoformat() if broadcast.last_finished_at else None,
        "last_recipient_count": broadcast.last_recipient_count,
        "last_error": broadcast.last_error,
        "created_at": broadcast.created_at.isoformat(),
        "updated_at": broadcast.updated_at.isoformat(),
    }


@router.post("/broadcasts/{broadcast_id}/run", dependencies=[Depends(require_api_key)])
async def run_broadcast(
    broadcast_id: int,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str | int | bool | None]:
    try:
        broadcast = await app_context.broadcast_service.run_now(broadcast_id)
    except ValueError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error
    return {
        "id": broadcast.id,
        "message": broadcast.message,
        "schedule_type": broadcast.schedule_type,
        "interval_hours": broadcast.interval_hours,
        "daily_time": broadcast.daily_time,
        "is_active": broadcast.is_active,
        "next_run_at": broadcast.next_run_at.isoformat() if broadcast.next_run_at else None,
        "last_run_at": broadcast.last_run_at.isoformat() if broadcast.last_run_at else None,
        "last_finished_at": broadcast.last_finished_at.isoformat() if broadcast.last_finished_at else None,
        "last_recipient_count": broadcast.last_recipient_count,
        "last_error": broadcast.last_error,
        "created_at": broadcast.created_at.isoformat(),
        "updated_at": broadcast.updated_at.isoformat(),
    }


@router.delete("/broadcasts/{broadcast_id}", dependencies=[Depends(require_api_key)])
async def delete_broadcast(
    broadcast_id: int,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str]:
    try:
        await app_context.broadcast_service.delete_broadcast(broadcast_id)
    except ValueError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error
    return {"status": "deleted"}


class ProxyCreateRequest(BaseModel):
    url: str


@router.get("/proxies", dependencies=[Depends(require_api_key)])
async def list_proxies(app_context: AppContext = Depends(get_app_context)) -> list[dict]:
    async with app_context.database.session_factory() as session:
        repo = ProxyRepository(session)
        proxies = await repo.list_all()
    return [
        {"id": p.id, "url": p.url, "is_active": p.is_active}
        for p in proxies
    ]


@router.post("/proxies", dependencies=[Depends(require_api_key)])
async def add_proxy(
    payload: ProxyCreateRequest,
    app_context: AppContext = Depends(get_app_context),
) -> dict:
    async with app_context.database.session_factory() as session:
        repo = ProxyRepository(session)
        proxy = await repo.add(payload.url)
    await app_context.bot_registry.redistribute_bots()
    return {"id": proxy.id, "url": proxy.url, "is_active": proxy.is_active}


@router.delete("/proxies/{proxy_id}", dependencies=[Depends(require_api_key)])
async def delete_proxy(
    proxy_id: int,
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, str]:
    async with app_context.database.session_factory() as session:
        repo = ProxyRepository(session)
        removed = await repo.remove(proxy_id)
    if not removed:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proxy not found")
    await app_context.bot_registry.redistribute_bots()
    return {"status": "deleted"}


@router.post("/proxies/redistribute", dependencies=[Depends(require_api_key)])
async def redistribute_proxies(
    app_context: AppContext = Depends(get_app_context),
) -> dict[str, int]:
    count = await app_context.bot_registry.redistribute_bots()
    return {"redistributed": count}

