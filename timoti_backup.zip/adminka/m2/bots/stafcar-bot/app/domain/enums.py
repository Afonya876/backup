from __future__ import annotations

from enum import Enum


class OrderStatus(str, Enum):
    PENDING = "pending"
    CANCELLED = "cancelled"


class UserState(str, Enum):
    IDLE = "idle"
    AWAITING_CAPTCHA = "awaiting_captcha"
    CHOOSING_LANGUAGE = "choosing_language"
    CHOOSING_CITY = "choosing_city"
    CHOOSING_SUBCITY = "choosing_subcity"
    CHOOSING_DISTRICT = "choosing_district"
    CHOOSING_PRODUCT = "choosing_product"
    VIEWING_PRODUCT = "viewing_product"
    CHOOSING_OFFER = "choosing_offer"
    CHOOSING_PAYMENT = "choosing_payment"
