from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from app.domain.enums import OrderStatus, UserState


@dataclass(slots=True)
class CatalogSelection:
    country_id: str | None = None
    parent_city_id: str | None = None
    city_id: str | None = None
    district_id: str | None = None
    product_id: str | None = None
    offer_id: str | None = None
    payment_method_id: str | None = None
    order_public_id: str | None = None


@dataclass(slots=True)
class User:
    id: int
    telegram_user_id: int
    bot_instance_id: int
    language: str | None
    balance_usd: float
    purchase_count: int
    captcha_passed: bool
    state: UserState
    current_screen: str | None
    selection: CatalogSelection = field(default_factory=CatalogSelection)
    captcha_answer: str | None = None


@dataclass(slots=True)
class Order:
    id: int
    public_id: str
    user_id: int
    bot_instance_id: int
    product_id: str
    product_name: str
    city_id: str
    city_name: str
    district_id: str
    district_name: str
    delivery_type_id: str
    delivery_type_name: str
    payment_method_id: str
    payment_method_name: str
    price: float
    wallet_snapshot: str
    deadline_at: datetime
    status: OrderStatus
    created_at: datetime
    payment_details: dict[str, str | None] = field(default_factory=dict)


@dataclass(slots=True)
class BotInstance:
    id: int
    telegram_bot_id: int
    name: str
    username: str | None
    token_encrypted: str
    enabled: bool
    webhook_secret: str
    is_primary: bool
    created_at: datetime


@dataclass(slots=True)
class WalletAddress:
    id: int
    payment_method_id: str
    address: str
    updated_at: datetime
    details: dict[str, str | None] = field(default_factory=dict)


@dataclass(slots=True)
class Broadcast:
    id: int
    message: str
    schedule_type: str
    interval_hours: int | None
    daily_time: str | None
    is_active: bool
    next_run_at: datetime | None
    last_run_at: datetime | None
    last_finished_at: datetime | None
    last_recipient_count: int
    last_error: str | None
    created_at: datetime
    updated_at: datetime



@dataclass(slots=True)
class Proxy:
    id: int
    url: str
    is_active: bool

