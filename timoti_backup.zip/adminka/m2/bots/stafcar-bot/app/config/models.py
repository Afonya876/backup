from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field


LocalizedValue = str | dict[str, str]


class AppConfig(BaseModel):
    default_locale: str = "ru"
    supported_locales: list[str] = Field(default_factory=lambda: ["ru"])
    parse_mode: str = "HTML"
    external_links: dict[str, str] = Field(default_factory=dict)
    webhook_timeout_seconds: int = 30


class MediaConfig(BaseModel):
    type: Literal["photo", "video", "animation"] = "photo"
    source: str
    caption_key: str | None = None

    @property
    def is_remote(self) -> bool:
        return self.source.startswith("http://") or self.source.startswith("https://")

    def resolve_path(self, base_dir: Path) -> Path:
        return base_dir / self.source


class ButtonConfig(BaseModel):
    label_key: str
    action: Literal[
        "navigate",
        "back_main",
        "url",
        "show_page",
        "select_value",
        "create_order",
        "refresh_order",
        "show_qr",
        "confirm_cancel",
        "cancel_yes",
        "show_orders",
    ]
    target: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    url: str | None = None
    visible_if: str | None = None
    row: int = 0


class ScreenConfig(BaseModel):
    screen_id: str
    message_key: str
    buttons: list[ButtonConfig] = Field(default_factory=list)
    media: MediaConfig | None = None
    keyboard_type: Literal["reply", "inline"] = "reply"
    parse_mode: str | None = None
    disable_web_page_preview: bool = False
    placeholder_key: str | None = None


class CatalogDistrict(BaseModel):
    id: str
    name: LocalizedValue


class CatalogCity(BaseModel):
    id: str
    name: LocalizedValue
    districts: list[CatalogDistrict] = Field(default_factory=list)
    children: list["CatalogCity"] = Field(default_factory=list)


class CatalogCountry(BaseModel):
    id: str
    name: LocalizedValue
    cities: list[CatalogCity] = Field(default_factory=list)


class CatalogProduct(BaseModel):
    id: str
    name: LocalizedValue
    description: LocalizedValue
    image_source: str | None = None
    availability: dict[str, bool] = Field(default_factory=dict)
    district_availability: dict[str, list[str]] = Field(default_factory=dict)
    offers: list["ProductOffer"] = Field(default_factory=list)


class ProductOffer(BaseModel):
    id: str
    delivery_type_name: LocalizedValue
    quantity_label: str | None = None
    base_price: float
    display_label: LocalizedValue | None = None


class PaymentMethod(BaseModel):
    id: str
    label_key: str
    fee_percent: float = 0.0
    qr_enabled: bool = True
    card_enabled: bool = True
    amount_precision: int = 6
    currency: str = "UAH"


class CatalogConfig(BaseModel):
    countries: list[CatalogCountry] = Field(default_factory=list)
    products: list[CatalogProduct] = Field(default_factory=list)
    payment_methods: list[PaymentMethod] = Field(default_factory=list)
