from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_env: str = Field(default="development", alias="APP_ENV")
    app_secret: str = Field(default="change-me", alias="APP_SECRET")
    api_key: str = Field(default="change-me", alias="API_KEY")
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@127.0.0.1:5432/candy_bot",
        alias="DATABASE_URL",
    )
    primary_bot_token: str = Field(default="", alias="PRIMARY_BOT_TOKEN")
    primary_bot_name: str = Field(default="Main Candy Bot", alias="PRIMARY_BOT_NAME")
    webhook_base_url: str = Field(default="", alias="WEBHOOK_BASE_URL")
    host: str = Field(default="0.0.0.0", alias="HOST")
    port: int = Field(default=8000, alias="PORT")
    config_dir: Path = Field(default=Path("config"), alias="CONFIG_DIR")

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
