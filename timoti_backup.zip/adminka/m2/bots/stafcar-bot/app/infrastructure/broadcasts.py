from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta

from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError, TelegramRetryAfter

from app.domain.entities import Broadcast
from app.infrastructure.repositories.repositories import BroadcastRepository, UserRepository


class BroadcastService:
    POLL_INTERVAL_SECONDS = 30
    SCHEDULE_TYPES = {"immediate", "interval", "daily"}

    def __init__(self, app_context) -> None:
        self.app_context = app_context
        self._task: asyncio.Task | None = None
        self._stopping = False

    async def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._loop(), name="broadcast-service")

    async def stop(self) -> None:
        self._stopping = True
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def create_broadcast(
        self,
        *,
        message: str,
        schedule_type: str,
        interval_hours: int | None = None,
        daily_time: str | None = None,
        is_active: bool = True,
    ) -> Broadcast:
        self._validate_schedule(schedule_type, interval_hours, daily_time)
        next_run_at = self._initial_next_run_at(
            schedule_type=schedule_type,
            interval_hours=interval_hours,
            daily_time=daily_time,
        )
        async with self.app_context.database.session_factory() as session:
            repository = BroadcastRepository(session)
            broadcast = await repository.create(
                message=message,
                schedule_type=schedule_type,
                interval_hours=interval_hours,
                daily_time=daily_time,
                is_active=is_active,
                next_run_at=next_run_at if is_active else None,
            )
        if schedule_type == "immediate" and is_active:
            await self.run_now(broadcast.id)
            async with self.app_context.database.session_factory() as session:
                refreshed = await BroadcastRepository(session).get(broadcast.id)
            return refreshed or broadcast
        return broadcast

    async def list_broadcasts(self) -> list[Broadcast]:
        async with self.app_context.database.session_factory() as session:
            return await BroadcastRepository(session).list_all()

    async def get_broadcast(self, broadcast_id: int) -> Broadcast | None:
        async with self.app_context.database.session_factory() as session:
            return await BroadcastRepository(session).get(broadcast_id)

    async def update_broadcast(
        self,
        broadcast_id: int,
        *,
        message: str | None = None,
        schedule_type: str | None = None,
        interval_hours: int | None = None,
        daily_time: str | None = None,
        is_active: bool | None = None,
    ) -> Broadcast:
        current = await self.get_broadcast(broadcast_id)
        if not current:
            raise ValueError(f"Broadcast {broadcast_id} not found")
        resolved_schedule = schedule_type or current.schedule_type
        resolved_interval = interval_hours if interval_hours is not None else current.interval_hours
        resolved_daily = daily_time if daily_time is not None else current.daily_time
        resolved_active = current.is_active if is_active is None else is_active
        self._validate_schedule(resolved_schedule, resolved_interval, resolved_daily)
        next_run_at = None
        if resolved_active:
            next_run_at = self._initial_next_run_at(
                schedule_type=resolved_schedule,
                interval_hours=resolved_interval,
                daily_time=resolved_daily,
            )
        async with self.app_context.database.session_factory() as session:
            return await BroadcastRepository(session).update(
                broadcast_id,
                message=message if message is not None else ...,
                schedule_type=resolved_schedule,
                interval_hours=resolved_interval,
                daily_time=resolved_daily,
                is_active=resolved_active,
                next_run_at=next_run_at,
            )

    async def delete_broadcast(self, broadcast_id: int) -> None:
        async with self.app_context.database.session_factory() as session:
            await BroadcastRepository(session).delete(broadcast_id)

    async def run_now(self, broadcast_id: int) -> Broadcast:
        broadcast = await self.get_broadcast(broadcast_id)
        if not broadcast:
            raise ValueError(f"Broadcast {broadcast_id} not found")
        return await self._execute_broadcast(broadcast)

    async def _loop(self) -> None:
        while not self._stopping:
            try:
                now = datetime.now(UTC)
                async with self.app_context.database.session_factory() as session:
                    due = await BroadcastRepository(session).list_due(now)
                for broadcast in due:
                    await self._execute_broadcast(broadcast)
            except asyncio.CancelledError:
                raise
            except Exception:
                await asyncio.sleep(5)
            await asyncio.sleep(self.POLL_INTERVAL_SECONDS)

    async def _execute_broadcast(self, broadcast: Broadcast) -> Broadcast:
        now = datetime.now(UTC)
        sent_count = 0
        last_error: str | None = None
        async with self.app_context.database.session_factory() as session:
            recipients = await UserRepository(session).list_recipient_map()
        running_bots = {running.instance.id: running.bot for running in await self.app_context.bot_registry.list_running()}
        for bot_instance_id, telegram_ids in recipients.items():
            bot = running_bots.get(bot_instance_id)
            if not bot:
                continue
            for telegram_id in telegram_ids:
                try:
                    await bot.send_message(telegram_id, broadcast.message)
                    sent_count += 1
                except TelegramRetryAfter as error:
                    await asyncio.sleep(error.retry_after)
                    try:
                        await bot.send_message(telegram_id, broadcast.message)
                        sent_count += 1
                    except TelegramAPIError as nested_error:
                        last_error = str(nested_error)
                except TelegramForbiddenError:
                    continue
                except TelegramAPIError as error:
                    last_error = str(error)
        next_run_at, is_active = self._resolve_next_run(broadcast, now)
        async with self.app_context.database.session_factory() as session:
            updated = await BroadcastRepository(session).update(
                broadcast.id,
                last_run_at=now,
                last_finished_at=datetime.now(UTC),
                last_recipient_count=sent_count,
                last_error=last_error,
                next_run_at=next_run_at,
                is_active=is_active,
            )
        return updated

    def _initial_next_run_at(
        self,
        *,
        schedule_type: str,
        interval_hours: int | None,
        daily_time: str | None,
    ) -> datetime | None:
        now = datetime.now(UTC)
        if schedule_type == "immediate":
            return now
        if schedule_type == "interval" and interval_hours:
            return now + timedelta(hours=interval_hours)
        if schedule_type == "daily" and daily_time:
            return self._next_daily_time(now, daily_time)
        return None

    def _resolve_next_run(self, broadcast: Broadcast, now: datetime) -> tuple[datetime | None, bool]:
        if broadcast.schedule_type == "immediate":
            return None, False
        if broadcast.schedule_type == "interval" and broadcast.interval_hours:
            return now + timedelta(hours=broadcast.interval_hours), True
        if broadcast.schedule_type == "daily" and broadcast.daily_time:
            return self._next_daily_time(now + timedelta(minutes=1), broadcast.daily_time), True
        return None, False

    def _next_daily_time(self, now: datetime, value: str) -> datetime:
        hour, minute = (int(chunk) for chunk in value.split(":", 1))
        candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    def _validate_schedule(self, schedule_type: str, interval_hours: int | None, daily_time: str | None) -> None:
        if schedule_type not in self.SCHEDULE_TYPES:
            raise ValueError("Unsupported schedule type")
        if schedule_type == "interval":
            if not interval_hours or interval_hours <= 0:
                raise ValueError("interval_hours must be greater than zero")
        if schedule_type == "daily":
            if not daily_time:
                raise ValueError("daily_time is required for daily schedule")
            try:
                hour, minute = (int(chunk) for chunk in daily_time.split(":", 1))
            except ValueError as error:
                raise ValueError("daily_time must be in HH:MM format") from error
            if not (0 <= hour <= 23 and 0 <= minute <= 59):
                raise ValueError("daily_time must be in HH:MM format")
