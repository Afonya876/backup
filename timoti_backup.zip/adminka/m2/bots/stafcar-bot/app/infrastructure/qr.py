from __future__ import annotations

import io

import qrcode


class QRCodeService:
    def generate(self, payload: str) -> bytes:
        image = qrcode.make(payload)
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()
