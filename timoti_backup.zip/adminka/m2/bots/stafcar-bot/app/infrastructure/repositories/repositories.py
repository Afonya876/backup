from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities import BotInstance, Broadcast, CatalogSelection, Order, User, WalletAddress, Proxy
from app.domain.enums import OrderStatus, UserState
from app.infrastructure.models import BotInstanceModel, BroadcastModel, OrderModel, ProxyModel, UserModel, WalletAddressModel


def _selection_from_payload(payload: dict | None) -> CatalogSelection:
    payload = payload or {}
    return CatalogSelection(
        country_id=payload.get("country_id"),
        parent_city_id=payload.get("parent_city_id"),
        city_id=payload.get("city_id"),
        district_id=payload.get("district_id"),
        product_id=payload.get("product_id"),
        offer_id=payload.get("offer_id"),
        payment_method_id=payload.get("payment_method_id"),
        order_public_id=payload.get("order_public_id"),
    )


def _selection_to_payload(selection: CatalogSelection | dict | None) -> dict:
    if selection is None:
        return {}
    if isinstance(selection, dict):
        return selection
    return asdict(selection)


def _to_user(model: UserModel) -> User:
    return User(
        id=model.id,
        telegram_user_id=model.telegram_user_id,
        bot_instance_id=model.bot_instance_id,
        language=model.language,
        balance_usd=float(model.balance_usd),
        purchase_count=model.purchase_count,
        captcha_passed=model.captcha_passed,
        state=UserState(model.state),
        current_screen=model.current_screen,
        selection=_selection_from_payload(model.selection_json),
        captcha_answer=model.captcha_answer,
    )


def _to_order(model: OrderModel) -> Order:
    return Order(
        id=model.id,
        public_id=model.public_id,
        user_id=model.user_id,
        bot_instance_id=model.bot_instance_id,
        product_id=model.product_id,
        product_name=model.product_name,
        city_id=model.city_id,
        city_name=model.city_name,
        district_id=model.district_id,
        district_name=model.district_name,
        delivery_type_id=model.delivery_type_id,
        delivery_type_name=model.delivery_type_name,
        payment_method_id=model.payment_method_id,
        payment_method_name=model.payment_method_name,
        price=model.price,
        wallet_snapshot=model.wallet_snapshot,
        payment_details=model.payment_details_json or {},
        deadline_at=model.deadline_at,
        status=OrderStatus(model.status),
        created_at=model.created_at,
    )


def _to_bot_instance(model: BotInstanceModel) -> BotInstance:
    return BotInstance(
        id=model.id,
        telegram_bot_id=model.telegram_bot_id,
        name=model.name,
        username=model.username,
        token_encrypted=model.token_encrypted,
        enabled=model.enabled,
        webhook_secret=model.webhook_secret,
        is_primary=model.is_primary,
        created_at=model.created_at,
    )


def _to_wallet(model: WalletAddressModel) -> WalletAddress:
    return WalletAddress(
        id=model.id,
        payment_method_id=model.payment_method_id,
        address=model.address,
        details=model.details_json or {},
        updated_at=model.updated_at,
    )


def _to_broadcast(model: BroadcastModel) -> Broadcast:
    return Broadcast(
        id=model.id,
        message=model.message,
        schedule_type=model.schedule_type,
        interval_hours=model.interval_hours,
        daily_time=model.daily_time,
        is_active=model.is_active,
        next_run_at=model.next_run_at,
        last_run_at=model.last_run_at,
        last_finished_at=model.last_finished_at,
        last_recipient_count=model.last_recipient_count,
        last_error=model.last_error,
        created_at=model.created_at,
        updated_at=model.updated_at,
    )


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_or_create(self, telegram_user_id: int, bot_instance_id: int) -> User:
        query = select(UserModel).where(
            UserModel.telegram_user_id == telegram_user_id,
            UserModel.bot_instance_id == bot_instance_id,
        )
        model = await self.session.scalar(query)
        if not model:
            model = UserModel(
                telegram_user_id=telegram_user_id,
                bot_instance_id=bot_instance_id,
                selection_json={},
            )
            self.session.add(model)
            await self.session.commit()
            await self.session.refresh(model)
        return _to_user(model)

    async def save(
        self,
        user_id: int,
        *,
        language: str | None | object = ...,
        balance_usd: float | None | object = ...,
        purchase_count: int | object = ...,
        captcha_passed: bool | object = ...,
        state: UserState | str | object = ...,
        current_screen: str | None | object = ...,
        selection: CatalogSelection | dict | None | object = ...,
        captcha_answer: str | None | object = ...,
    ) -> User:
        model = await self.session.get(UserModel, user_id)
        if not model:
            raise ValueError(f"User {user_id} not found")

        if language is not ...:
            model.language = language
        if balance_usd is not ...:
            model.balance_usd = Decimal(str(balance_usd))
        if purchase_count is not ...:
            model.purchase_count = purchase_count
        if captcha_passed is not ...:
            model.captcha_passed = captcha_passed
        if state is not ...:
            model.state = state.value if isinstance(state, UserState) else state
        if current_screen is not ...:
            model.current_screen = current_screen
        if selection is not ...:
            model.selection_json = _selection_to_payload(selection)
        if captcha_answer is not ...:
            model.captcha_answer = captcha_answer

        await self.session.commit()
        await self.session.refresh(model)
        return _to_user(model)

    async def list_recipient_map(self) -> dict[int, list[int]]:
        rows = (
            await self.session.execute(
                select(UserModel.bot_instance_id, UserModel.telegram_user_id)
                .where(UserModel.telegram_user_id.is_not(None))
            )
        ).all()
        recipients: dict[int, list[int]] = {}
        for bot_instance_id, telegram_user_id in rows:
            recipients.setdefault(int(bot_instance_id), []).append(int(telegram_user_id))
        return recipients


class OrderRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self,
        *,
        public_id: str,
        user_id: int,
        bot_instance_id: int,
        product_id: str,
        product_name: str,
        city_id: str,
        city_name: str,
        district_id: str,
        district_name: str,
        delivery_type_id: str,
        delivery_type_name: str,
        payment_method_id: str,
        payment_method_name: str,
        price: float,
        wallet_snapshot: str,
        payment_details: dict[str, str | None] | None,
        deadline_at: datetime,
        status: OrderStatus = OrderStatus.PENDING,
    ) -> Order:
        model = OrderModel(
            public_id=public_id,
            user_id=user_id,
            bot_instance_id=bot_instance_id,
            product_id=product_id,
            product_name=product_name,
            city_id=city_id,
            city_name=city_name,
            district_id=district_id,
            district_name=district_name,
            delivery_type_id=delivery_type_id,
            delivery_type_name=delivery_type_name,
            payment_method_id=payment_method_id,
            payment_method_name=payment_method_name,
            price=price,
            wallet_snapshot=wallet_snapshot,
            payment_details_json=payment_details or {},
            deadline_at=deadline_at,
            status=status.value,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return _to_order(model)

    async def list_by_user(self, user_id: int, limit: int = 10) -> list[Order]:
        query = (
            select(OrderModel)
            .where(OrderModel.user_id == user_id)
            .order_by(OrderModel.created_at.desc())
            .limit(limit)
        )
        rows = (await self.session.scalars(query)).all()
        return [_to_order(row) for row in rows]

    async def get_for_user(self, public_id: str, user_id: int) -> Order | None:
        query = select(OrderModel).where(
            OrderModel.public_id == public_id,
            OrderModel.user_id == user_id,
        )
        model = await self.session.scalar(query)
        return _to_order(model) if model else None

    async def save_status(self, public_id: str, status: OrderStatus) -> Order:
        query = select(OrderModel).where(OrderModel.public_id == public_id)
        model = await self.session.scalar(query)
        if not model:
            raise ValueError(f"Order {public_id} not found")
        model.status = status.value
        await self.session.commit()
        await self.session.refresh(model)
        return _to_order(model)

    async def update_payment(
        self,
        public_id: str,
        *,
        payment_method_id: str,
        payment_method_name: str,
        wallet_snapshot: str,
        payment_details: dict[str, str | None] | None,
    ) -> Order:
        query = select(OrderModel).where(OrderModel.public_id == public_id)
        model = await self.session.scalar(query)
        if not model:
            raise ValueError(f"Order {public_id} not found")

        model.payment_method_id = payment_method_id
        model.payment_method_name = payment_method_name
        model.wallet_snapshot = wallet_snapshot
        model.payment_details_json = payment_details or {}
        await self.session.commit()
        await self.session.refresh(model)
        return _to_order(model)


class BotInstanceRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_enabled(self) -> list[BotInstance]:
        query = select(BotInstanceModel).where(BotInstanceModel.enabled.is_(True))
        rows = (await self.session.scalars(query)).all()
        return [_to_bot_instance(row) for row in rows]

    async def get(self, bot_instance_id: int) -> BotInstance | None:
        model = await self.session.get(BotInstanceModel, bot_instance_id)
        return _to_bot_instance(model) if model else None

    async def get_primary(self) -> BotInstance | None:
        query = select(BotInstanceModel).where(BotInstanceModel.is_primary.is_(True))
        model = await self.session.scalar(query)
        return _to_bot_instance(model) if model else None

    async def get_by_telegram_bot_id(self, telegram_bot_id: int) -> BotInstance | None:
        query = select(BotInstanceModel).where(BotInstanceModel.telegram_bot_id == telegram_bot_id)
        model = await self.session.scalar(query)
        return _to_bot_instance(model) if model else None

    async def create(
        self,
        *,
        telegram_bot_id: int,
        name: str,
        username: str | None,
        token_encrypted: str,
        webhook_secret: str,
        is_primary: bool = False,
    ) -> BotInstance:
        model = BotInstanceModel(
            telegram_bot_id=telegram_bot_id,
            name=name,
            username=username,
            token_encrypted=token_encrypted,
            webhook_secret=webhook_secret,
            is_primary=is_primary,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return _to_bot_instance(model)

    async def update(
        self,
        bot_instance_id: int,
        *,
        name: str | object = ...,
        username: str | None | object = ...,
        token_encrypted: str | object = ...,
        enabled: bool | object = ...,
        webhook_secret: str | object = ...,
        is_primary: bool | object = ...,
    ) -> BotInstance:
        model = await self.session.get(BotInstanceModel, bot_instance_id)
        if not model:
            raise ValueError(f"Bot instance {bot_instance_id} not found")

        if name is not ...:
            model.name = name
        if username is not ...:
            model.username = username
        if token_encrypted is not ...:
            model.token_encrypted = token_encrypted
        if enabled is not ...:
            model.enabled = enabled
        if webhook_secret is not ...:
            model.webhook_secret = webhook_secret
        if is_primary is not ...:
            model.is_primary = is_primary

        await self.session.commit()
        await self.session.refresh(model)
        return _to_bot_instance(model)


class WalletRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_all(self) -> list[WalletAddress]:
        rows = (await self.session.scalars(select(WalletAddressModel))).all()
        return [_to_wallet(row) for row in rows]

    async def get_by_payment_method(self, payment_method_id: str) -> WalletAddress | None:
        query = select(WalletAddressModel).where(WalletAddressModel.payment_method_id == payment_method_id)
        model = await self.session.scalar(query)
        return _to_wallet(model) if model else None

    async def upsert(
        self,
        payment_method_id: str,
        address: str,
        *,
        details: dict[str, str | None] | None = None,
    ) -> WalletAddress:
        query = select(WalletAddressModel).where(WalletAddressModel.payment_method_id == payment_method_id)
        model = await self.session.scalar(query)
        if model:
            model.address = address
            if details is not None:
                model.details_json = details
        else:
            model = WalletAddressModel(
                payment_method_id=payment_method_id,
                address=address,
                details_json=details or {},
            )
            self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return _to_wallet(model)


class BroadcastRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_all(self) -> list[Broadcast]:
        rows = (
            await self.session.scalars(
                select(BroadcastModel).order_by(BroadcastModel.created_at.desc(), BroadcastModel.id.desc())
            )
        ).all()
        return [_to_broadcast(row) for row in rows]

    async def list_due(self, now: datetime) -> list[Broadcast]:
        rows = (
            await self.session.scalars(
                select(BroadcastModel)
                .where(
                    BroadcastModel.is_active.is_(True),
                    BroadcastModel.next_run_at.is_not(None),
                    BroadcastModel.next_run_at <= now,
                )
                .order_by(BroadcastModel.next_run_at.asc(), BroadcastModel.id.asc())
            )
        ).all()
        return [_to_broadcast(row) for row in rows]

    async def get(self, broadcast_id: int) -> Broadcast | None:
        model = await self.session.get(BroadcastModel, broadcast_id)
        return _to_broadcast(model) if model else None

    async def create(
        self,
        *,
        message: str,
        schedule_type: str,
        interval_hours: int | None,
        daily_time: str | None,
        is_active: bool,
        next_run_at: datetime | None,
    ) -> Broadcast:
        model = BroadcastModel(
            message=message,
            schedule_type=schedule_type,
            interval_hours=interval_hours,
            daily_time=daily_time,
            is_active=is_active,
            next_run_at=next_run_at,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return _to_broadcast(model)

    async def update(
        self,
        broadcast_id: int,
        *,
        message: str | object = ...,
        schedule_type: str | object = ...,
        interval_hours: int | None | object = ...,
        daily_time: str | None | object = ...,
        is_active: bool | object = ...,
        next_run_at: datetime | None | object = ...,
        last_run_at: datetime | None | object = ...,
        last_finished_at: datetime | None | object = ...,
        last_recipient_count: int | object = ...,
        last_error: str | None | object = ...,
    ) -> Broadcast:
        model = await self.session.get(BroadcastModel, broadcast_id)
        if not model:
            raise ValueError(f"Broadcast {broadcast_id} not found")

        if message is not ...:
            model.message = message
        if schedule_type is not ...:
            model.schedule_type = schedule_type
        if interval_hours is not ...:
            model.interval_hours = interval_hours
        if daily_time is not ...:
            model.daily_time = daily_time
        if is_active is not ...:
            model.is_active = is_active
        if next_run_at is not ...:
            model.next_run_at = next_run_at
        if last_run_at is not ...:
            model.last_run_at = last_run_at
        if last_finished_at is not ...:
            model.last_finished_at = last_finished_at
        if last_recipient_count is not ...:
            model.last_recipient_count = last_recipient_count
        if last_error is not ...:
            model.last_error = last_error

        await self.session.commit()
        await self.session.refresh(model)
        return _to_broadcast(model)

    async def delete(self, broadcast_id: int) -> None:
        model = await self.session.get(BroadcastModel, broadcast_id)
        if not model:
            raise ValueError(f"Broadcast {broadcast_id} not found")
        await self.session.delete(model)
        await self.session.commit()


def _to_proxy(model: ProxyModel) -> "Proxy":
    from app.domain.entities import Proxy
    return Proxy(id=model.id, url=model.url, is_active=model.is_active)


class ProxyRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_all(self) -> list:
        rows = (await self.session.scalars(select(ProxyModel).order_by(ProxyModel.id))).all()
        return [_to_proxy(row) for row in rows]

    async def list_active(self) -> list:
        rows = (
            await self.session.scalars(
                select(ProxyModel).where(ProxyModel.is_active.is_(True)).order_by(ProxyModel.id)
            )
        ).all()
        return [_to_proxy(row) for row in rows]

    async def add(self, url: str) -> object:
        model = ProxyModel(url=url, is_active=True)
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return _to_proxy(model)

    async def remove(self, proxy_id: int) -> bool:
        model = await self.session.get(ProxyModel, proxy_id)
        if not model:
            return False
        await self.session.delete(model)
        await self.session.commit()
        return True
