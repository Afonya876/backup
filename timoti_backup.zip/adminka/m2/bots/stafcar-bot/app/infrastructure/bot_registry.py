from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

from aiogram import Bot, Dispatcher
from aiogram.types import Update
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.exceptions import TelegramAPIError, TelegramNetworkError, TelegramUnauthorizedError
from aiogram.utils.token import TokenValidationError
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.application.context import AppContext
from app.config.settings import Settings
from app.domain.entities import BotInstance
from app.infrastructure.config_loader import ConfigStore
from app.infrastructure.repositories.repositories import BotInstanceRepository, ProxyRepository
from app.infrastructure.security import TokenCipher, constant_time_equal, create_secret


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class RunningBot:
    instance: BotInstance
    bot: Bot
    polling_task: asyncio.Task | None = None
    monitor_task: asyncio.Task | None = None


TELEGRAM_LANGUAGE_ALIASES = {
    "ua": "uk",
    "kz": "kk",
    "md": "ro",
}


class BotTokenValidationError(ValueError):
    pass


class BotProvisioningError(RuntimeError):
    pass


class BotRemovalError(RuntimeError):
    pass


class BotRegistry:
    def __init__(
        self,
        *,
        settings: Settings,
        session_factory: async_sessionmaker,
        token_cipher: TokenCipher,
        config_store: ConfigStore,
        dispatcher: Dispatcher,
    ) -> None:
        self.settings = settings
        self.session_factory = session_factory
        self.token_cipher = token_cipher
        self.config_store = config_store
        self.dispatcher = dispatcher
        self.app_context: AppContext | None = None
        self._running_bots: dict[int, RunningBot] = {}
        self._health_issues: dict[str, str] = {}

    async def bootstrap(self) -> None:
        try:
            await self._ensure_primary_bot()
        except (BotTokenValidationError, BotProvisioningError):
            self._set_service_issue(
                "primary-token",
                f"Основной токен {self.settings.primary_bot_name} недоступен или удалён. "
                "Замените его в админке.",
            )
            logger.warning("Primary bot token is unavailable; continuing without bootstrap bot", exc_info=True)
        async with self.session_factory() as session:
            repository = BotInstanceRepository(session)
            for instance in await repository.list_enabled():
                await self._start_bot(instance)


    async def _get_proxy_for_instance(self, instance_id: int) -> str | None:
        async with self.session_factory() as session:
            repo = ProxyRepository(session)
            proxies = await repo.list_active()
        pool_size = 1 + len(proxies)
        slot = instance_id % pool_size
        if slot == 0:
            return None
        return proxies[slot - 1].url

    async def redistribute_bots(self) -> int:
        running_ids = list(self._running_bots.keys())
        instances: list[BotInstance] = []
        for bid in running_ids:
            running = self._running_bots.get(bid)
            if running:
                instances.append(running.instance)
                await self._stop_bot(bid)
        count = 0
        for instance in instances:
            await self._start_bot(instance)
            count += 1
        return count

    async def close(self) -> None:
        for running_bot in self._running_bots.values():
            if running_bot.polling_task:
                running_bot.polling_task.cancel()
            if running_bot.monitor_task:
                running_bot.monitor_task.cancel()
        for running_bot in self._running_bots.values():
            if running_bot.polling_task:
                try:
                    await running_bot.polling_task
                except asyncio.CancelledError:
                    pass
            if running_bot.monitor_task:
                try:
                    await running_bot.monitor_task
                except asyncio.CancelledError:
                    pass
            await running_bot.bot.session.close()
        self._running_bots.clear()
        self._health_issues.clear()

    def health_status(self) -> dict[str, str]:
        if not self._health_issues:
            return {"status": "ok"}
        warning = "; ".join(dict.fromkeys(self._health_issues.values()))
        return {"status": "degraded", "warning": warning}

    async def add_bot(self, *, token: str, name: str | None = None, is_primary: bool = False) -> BotInstance:
        try:
            bot = Bot(token=token, default=DefaultBotProperties(parse_mode=self.config_store.app_config.parse_mode))
        except TokenValidationError as error:
            raise BotTokenValidationError("Invalid bot token format") from error
        try:
            me = await bot.get_me()
            try:
                await self._clone_primary_profile(bot, token, is_primary=is_primary)
            except (TelegramAPIError, BotProvisioningError):
                logger.warning(
                    "Failed to clone primary bot profile; continuing without copying profile",
                    exc_info=True,
                )
        except TelegramUnauthorizedError as error:
            raise BotTokenValidationError("Invalid bot token") from error
        except TelegramNetworkError as error:
            raise BotProvisioningError("Telegram API request failed") from error
        finally:
            await bot.session.close()
        resolved_name = (name or "").strip() or me.full_name or me.username or f"Bot {me.id}"

        async with self.session_factory() as session:
            repository = BotInstanceRepository(session)
            existing = await repository.get_by_telegram_bot_id(me.id)
            if existing:
                existing = await repository.update(
                    existing.id,
                    name=resolved_name,
                    username=me.username,
                    token_encrypted=self.token_cipher.encrypt(token),
                    enabled=True,
                )
                if existing.id not in self._running_bots:
                    await self._start_bot(existing)
                else:
                    self._running_bots[existing.id].instance = existing
                return existing

            instance = await repository.create(
                telegram_bot_id=me.id,
                name=resolved_name,
                username=me.username,
                token_encrypted=self.token_cipher.encrypt(token),
                webhook_secret=create_secret(),
                is_primary=is_primary,
            )

        await self._start_bot(instance)
        return instance

    def _set_service_issue(self, key: str, message: str) -> None:
        self._health_issues[key] = message

    def _clear_service_issue(self, key: str) -> None:
        self._health_issues.pop(key, None)

    def _bot_issue_key(self, instance: BotInstance) -> str:
        return f"bot:{instance.id}"

    def _bot_issue_message(self, instance: BotInstance) -> str:
        label = instance.name or instance.username or str(instance.telegram_bot_id)
        if instance.is_primary:
            return (
                f"Основной токен бота {label} недоступен или удалён. "
                "Замените его в админке."
            )
        return f"Токен бота {label} недоступен или удалён."

    async def _clone_primary_profile(
        self,
        target_bot: Bot,
        target_token: str,
        *,
        is_primary: bool,
    ) -> None:
        primary_token = (self.settings.primary_bot_token or "").strip()
        if is_primary or not primary_token or primary_token == target_token:
            return

        try:
            source_bot = Bot(
                token=primary_token,
                default=DefaultBotProperties(parse_mode=self.config_store.app_config.parse_mode),
            )
        except TokenValidationError:
            import logging
            logging.getLogger(__name__).warning("Primary bot token has invalid format; skipping profile clone")
            return
        language_codes = [None, *self._profile_language_codes()]

        try:
            for language_code in language_codes:
                description = await source_bot.get_my_description(language_code=language_code)
                await target_bot.set_my_description(
                    description=description.description or None,
                    language_code=language_code,
                )

                short_description = await source_bot.get_my_short_description(language_code=language_code)
                await target_bot.set_my_short_description(
                    short_description=short_description.short_description or None,
                    language_code=language_code,
                )

                commands = await source_bot.get_my_commands(language_code=language_code)
                await target_bot.set_my_commands(
                    commands=commands,
                    language_code=language_code,
                )

            menu_button = await source_bot.get_chat_menu_button()
            await target_bot.set_chat_menu_button(menu_button=menu_button)
        except TelegramAPIError:
            logger.warning(
                "Failed to clone primary bot profile; continuing without copying profile",
                exc_info=True,
            )
            return
        finally:
            await source_bot.session.close()

    def _profile_language_codes(self) -> list[str]:
        codes: list[str] = []
        seen: set[str] = set()
        for locale in self.config_store.locales:
            language_code = TELEGRAM_LANGUAGE_ALIASES.get(locale, locale)
            if language_code in seen:
                continue
            seen.add(language_code)
            codes.append(language_code)
        return sorted(codes)

    async def get_running(self, bot_instance_id: int, secret: str) -> RunningBot | None:
        running_bot = self._running_bots.get(bot_instance_id)
        if not running_bot:
            return None
        if not constant_time_equal(running_bot.instance.webhook_secret, secret):
            return None
        return running_bot

    async def list_running(self) -> list[RunningBot]:
        return list(self._running_bots.values())

    async def remove_bot(self, bot_instance_id: int) -> BotInstance:
        async with self.session_factory() as session:
            repository = BotInstanceRepository(session)
            instance = await repository.get(bot_instance_id)
            if not instance:
                raise BotRemovalError("Bot instance not found")
            if instance.is_primary:
                raise BotRemovalError("Primary bot cannot be removed")
            instance = await repository.update(bot_instance_id, enabled=False)

        await self._stop_bot(bot_instance_id)
        return instance


    async def _ensure_primary_bot(self) -> None:
        if not self.settings.primary_bot_token:
            return

        async with self.session_factory() as session:
            repository = BotInstanceRepository(session)
            primary = await repository.get_primary()
        if primary:
            return

        try:
            await self.add_bot(
                token=self.settings.primary_bot_token,
                name=self.settings.primary_bot_name,
                is_primary=True,
            )
        except Exception:
            import logging
            logging.getLogger(__name__).warning(
                "Primary bot token is invalid or Telegram unreachable; skipping primary bot setup",
                exc_info=True,
            )

    async def _start_bot(self, instance: BotInstance) -> None:
        if instance.id in self._running_bots:
            return

        token = self.token_cipher.decrypt(instance.token_encrypted)
        bot = Bot(token=token, default=DefaultBotProperties(parse_mode=self.config_store.app_config.parse_mode))
        monitor_task = asyncio.create_task(self._monitor_bot(instance, bot))
        try:
            if self.settings.webhook_base_url:
                webhook_url = self._build_webhook_url(instance)
                await bot.set_webhook(
                    url=webhook_url,
                    allowed_updates=self.dispatcher.resolve_used_update_types(),
                )
                self._clear_service_issue(self._bot_issue_key(instance))
                self._running_bots[instance.id] = RunningBot(
                    instance=instance,
                    bot=bot,
                    monitor_task=monitor_task,
                )
                return

            await bot.delete_webhook(drop_pending_updates=False)
            polling_task = asyncio.create_task(self._poll_bot(instance, bot))
            self._clear_service_issue(self._bot_issue_key(instance))
            self._running_bots[instance.id] = RunningBot(
                instance=instance,
                bot=bot,
                polling_task=polling_task,
                monitor_task=monitor_task,
            )
        except TelegramUnauthorizedError:
            monitor_task.cancel()
            try:
                await monitor_task
            except asyncio.CancelledError:
                pass
            await bot.session.close()
            self._set_service_issue(self._bot_issue_key(instance), self._bot_issue_message(instance))
            logger.warning(
                "Telegram token for bot instance %s is unauthorized; bot will stay offline",
                instance.id,
                exc_info=True,
            )

    async def _stop_bot(self, bot_instance_id: int) -> None:
        running_bot = self._running_bots.pop(bot_instance_id, None)
        if not running_bot:
            return

        if running_bot.polling_task:
            running_bot.polling_task.cancel()
            try:
                await running_bot.polling_task
            except asyncio.CancelledError:
                pass
        if running_bot.monitor_task:
            running_bot.monitor_task.cancel()
            try:
                await running_bot.monitor_task
            except asyncio.CancelledError:
                pass
        if not running_bot.polling_task:
            try:
                await running_bot.bot.delete_webhook(drop_pending_updates=True)
            except TelegramAPIError:
                pass

        await running_bot.bot.session.close()
        self._clear_service_issue(self._bot_issue_key(running_bot.instance))

    def _build_webhook_url(self, instance: BotInstance) -> str:
        return f"{self.settings.webhook_base_url.rstrip('/')}/telegram/{instance.id}/{instance.webhook_secret}"

    async def _monitor_bot(self, instance: BotInstance, bot: Bot) -> None:
        interval_seconds = max(self.config_store.app_config.webhook_timeout_seconds, 60)
        try:
            while True:
                try:
                    await bot.get_me()
                except TelegramUnauthorizedError:
                    self._set_service_issue(self._bot_issue_key(instance), self._bot_issue_message(instance))
                    logger.warning(
                        "Telegram token for bot instance %s became unauthorized during monitoring",
                        instance.id,
                        exc_info=True,
                    )
                    return
                except TelegramNetworkError:
                    logger.warning("Network error while monitoring bot instance %s", instance.id, exc_info=True)
                except TelegramAPIError:
                    logger.warning("Telegram API error while monitoring bot instance %s", instance.id, exc_info=True)
                await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            raise

    async def _poll_bot(self, instance: BotInstance, bot: Bot) -> None:
        if not self.app_context:
            raise RuntimeError("BotRegistry.app_context must be set before polling starts")

        allowed_updates = self.dispatcher.resolve_used_update_types()
        offset = 0
        while True:
            try:
                updates = await bot.get_updates(
                    offset=offset,
                    timeout=self.config_store.app_config.webhook_timeout_seconds,
                    allowed_updates=allowed_updates,
                )
                for update in updates:
                    offset = max(offset, update.update_id + 1)
                    await self._feed_polled_update(bot, instance, update)
            except asyncio.CancelledError:
                raise
            except TelegramUnauthorizedError:
                self._set_service_issue(self._bot_issue_key(instance), self._bot_issue_message(instance))
                logger.warning(
                    "Telegram token for bot instance %s became unauthorized during polling",
                    instance.id,
                    exc_info=True,
                )
                return
            except Exception:
                logger.exception("Polling failed for bot instance %s", instance.id)
                await asyncio.sleep(5)

    async def _feed_polled_update(self, bot: Bot, instance: BotInstance, update: Update) -> None:
        if not self.app_context:
            raise RuntimeError("BotRegistry.app_context must be set before polling starts")
        await self.dispatcher.feed_update(
            bot,
            update,
            app_context=self.app_context,
            bot_instance=instance,
        )
