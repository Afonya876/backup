from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.application.templates import TemplateRenderer
from app.config.models import AppConfig, CatalogConfig, LocalizedValue, ScreenConfig


class ConfigStore:
    def __init__(self, root_dir: Path) -> None:
        self.root_dir = root_dir
        self.renderer = TemplateRenderer()
        self.app_config = AppConfig()
        self.catalog = CatalogConfig()
        self.locales: dict[str, dict[str, str]] = {}
        self.screens: dict[str, ScreenConfig] = {}

    async def load(self) -> None:
        self.app_config = AppConfig.model_validate_json(self._read_text(self.root_dir / "app.json"))
        self.locales = self._load_locales(self.root_dir / "locales")
        self.screens = self._load_screens(self.root_dir / "screens")
        self.catalog = self._load_catalog(self.root_dir / "catalog")

    async def reload(self) -> None:
        await self.load()

    async def update_locale_messages(self, locale: str, updates: dict[str, str]) -> dict[str, str]:
        path = self.root_dir / "locales" / f"{locale}.json"
        if not path.exists():
            raise FileNotFoundError(f"Locale file {locale}.json not found")
        payload = json.loads(self._read_text(path))
        payload.update(updates)
        self._write_json(path, payload)
        await self.reload()
        return self.locales[locale]

    def get_content_settings(self, locale: str) -> dict[str, str | None]:
        messages = self.locales.get(locale)
        if messages is None:
            raise FileNotFoundError(f"Locale file {locale}.json not found")
        return {
            "locale": locale,
            "welcome_message": messages.get("screens.main_menu.message"),
            "help_message": messages.get("screens.instructions.message"),
            "vacancies_message": messages.get("screens.jobs.message"),
            "rules_message": messages.get("screens.rules.message"),
            "instructions_message": messages.get("screens.instructions.message"),
            "contacts_message": messages.get("screens.contacts.message"),
        }

    def t(self, locale: str | None, key: str, context: dict[str, Any] | None = None) -> str:
        active_locale = locale or self.app_config.default_locale
        messages = self.locales.get(active_locale) or {}
        fallback_messages = self.locales.get(self.app_config.default_locale) or {}
        template = messages.get(key) or fallback_messages.get(key) or key
        return self.renderer.render(template, context)

    def resolve_localized_value(self, locale: str | None, value: LocalizedValue) -> str:
        if isinstance(value, str):
            return value
        active_locale = locale or self.app_config.default_locale
        return value.get(active_locale) or value.get(self.app_config.default_locale) or next(iter(value.values()))

    def get_screen(self, screen_id: str) -> ScreenConfig:
        return self.screens[screen_id]

    def _read_text(self, path: Path) -> str:
        return path.read_text(encoding="utf-8")

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def _load_locales(self, directory: Path) -> dict[str, dict[str, str]]:
        return {
            path.stem: json.loads(self._read_text(path))
            for path in sorted(directory.glob("*.json"))
        }

    def _load_screens(self, directory: Path) -> dict[str, ScreenConfig]:
        screens: dict[str, ScreenConfig] = {}
        for path in sorted(directory.glob("*.json")):
            payload = json.loads(self._read_text(path))
            for raw_screen in payload.get("screens", []):
                screen = ScreenConfig.model_validate(raw_screen)
                screens[screen.screen_id] = screen
        return screens

    def _load_catalog(self, directory: Path) -> CatalogConfig:
        return CatalogConfig.model_validate_json(self._read_text(directory / "catalog.json"))
