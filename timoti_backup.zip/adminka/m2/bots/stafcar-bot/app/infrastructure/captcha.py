from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass(slots=True)
class CaptchaChallenge:
    question: str
    answer: str


class CaptchaService:
    def __init__(self, min_value: int = 1, max_value: int = 20) -> None:
        self.min_value = min_value
        self.max_value = max_value

    def generate(self) -> CaptchaChallenge:
        left = random.randint(self.min_value, self.max_value)
        right = random.randint(self.min_value, self.max_value)
        return CaptchaChallenge(question=f"{left} + {right}", answer=str(left + right))

    def validate(self, expected: str | None, provided: str) -> bool:
        if not expected:
            return False
        try:
            return int(expected) == int(provided.strip())
        except ValueError:
            return False
