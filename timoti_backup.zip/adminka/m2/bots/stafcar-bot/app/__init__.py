"""Candy Bot application package."""
