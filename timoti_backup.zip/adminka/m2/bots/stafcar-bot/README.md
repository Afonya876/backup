# Stafcar Bot

Telegram-бот магазина `Stafcar` на `aiogram 3 + FastAPI + JSON config` с отдельным admin API и поддержкой нескольких bot-token'ов.

## Быстрый старт

```bash
cd Stafcar_bot
python3 -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
cp .env.example .env
uvicorn app.main:create_app --factory --host 0.0.0.0 --port 8014
```

## Что настраивается

- `config/catalog/catalog.json`: города, районы, товары, фасовки и доступность по локациям
- `config/locales/ru.json`: приветствие и подписи кнопок
- `api/v1/config/content`: редактирование приветствия через admin-бота
- `api/v1/wallets/{payment_method_id}`: смена реквизитов карты

## Команды пользователя

- `/start`: запуск сценария покупки
