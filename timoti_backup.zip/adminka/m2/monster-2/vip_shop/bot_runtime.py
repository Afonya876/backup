from __future__ import annotations

import asyncio
import io
import logging
import random
import re
import string
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from html import escape
from pathlib import Path
from typing import Protocol
from urllib.parse import urlparse

import aiohttp
import qrcode
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from pydantic import HttpUrl, TypeAdapter, ValidationError

from vip_shop.config import (
    BotSpec,
    BotSummary,
    CityConfig,
    CreateBotRequest,
    ExchangerLink,
    PaymentMethodConfig,
    ProductConfig,
    ProductOption,
    Settings,
    normalize_payment_details_template,
    normalize_template,
    save_catalog_cities,
)
from vip_shop.payment_admin_ui import (
    build_payment_method_editor_text,
    build_payments_admin_text,
    payment_admin_menu,
    payment_method_editor_menu,
)
from vip_shop.storage import AnalyticsRegistry, CaptchaRegistry, UserRegistry
from vip_shop.template import (
    MEDICAL_HELP_TEXT,
    ORDER_CANCEL_CONFIRMATION_TEXT,
    PAYMENT_EXIT_CONFIRMATION_TEXT,
    PAYMENT_HELP_TEXT,
    PAYMENT_METHOD_CHANGED_TEXT,
    PIN_TEXT,
    _build_order_display_fields,
    admin_cancel_menu,
    admin_menu,
    bots_menu,
    bots_upload_menu,
    build_admin_text,
    build_catalog_cities_text,
    build_catalog_city_text,
    build_catalog_product_text,
    build_bot_info_alert,
    build_bot_list_menu,
    build_bots_list_text,
    build_bots_text,
    build_bots_upload_text,
    build_city_not_found_text,
    build_city_searching_text,
    build_city_suggestions_text,
    build_city_text,
    build_district_text,
    build_delivery_method_text,
    build_option_text,
    build_registration_prompt_text,
    build_order_payment_details_text,
    build_order_payment_followup_text,
    build_order_payment_methods_text,
    build_order_payment_waiting_text,
    build_start_text,
    catalog_cities_menu,
    catalog_city_menu,
    catalog_product_menu,
    city_not_found_menu,
    city_suggestions_menu,
    delivery_menu,
    delivery_category_menu,
    delivery_category_items_menu,
    find_delivery_category_index,
    build_delivery_text,
    registration_menu,
    build_topup_payment_text,
    build_topup_request_text,
    city_menu,
    district_menu,
    existing_unpaid_order_menu,
    find_city_menu_page,
    find_delivery_menu_page,
    find_start_menu_page,
    main_menu,
    option_menu,
    order_cancel_confirmation_menu,
    order_payment_detail_menu,
    payment_action_menu,
    payment_exit_confirmation_menu,
    payment_waiting_back_menu,
    payment_waiting_menu,
    payment_methods_menu,
    promo_menu,
    purchases_menu,
    render_payment_details_text,
    render_payment_details_html,
    resolve_payment_requisites,
    rules_menu,
    simple_back_menu,
    format_payment_method_title,
    ORDER_TYPES,
    build_order_type_text,
    order_type_menu,
    build_order_summary_text,
    order_summary_menu,
    build_main_city_text,
    main_city_menu,
    build_links_admin_text,
    links_admin_menu,
    LINK_FIELDS,
    is_crypto_method,
    method_coin,
    build_crypto_payment_text,
    crypto_payment_menu,
    order_cancel_only_menu,
    build_exchangers_admin_text,
    exchangers_admin_menu,
    _format_decimal_amount,
    extract_uah_price,
    t,
    SUPPORTED_LANGUAGES,
    build_language_prompt_text,
    build_language_menu,
    build_login_confirm_text,
    login_confirm_menu,
    build_enter_login_text,
)
from vip_shop.city_match import resolve_city
from vip_shop.crypto_rates import convert_uah_to_crypto

logger = logging.getLogger(__name__)

PersistSpec = Callable[[BotSpec], Awaitable[None]]
ListBotsAction = Callable[[], Awaitable[list[BotSummary]]]
RemoveBotAction = Callable[[int], Awaitable[bool]]
ToggleBotPauseAction = Callable[[int], Awaitable[BotSpec | None]]
SyncPaymentMethodsAction = Callable[[list[PaymentMethodConfig]], Awaitable[None]]
SyncStartTextAction = Callable[[str], Awaitable[None]]
SyncAdminIdsAction = Callable[[list[int]], Awaitable[None]]
SyncTemplateAction = Callable[[object], Awaitable[None]]
HTTP_URL_ADAPTER = TypeAdapter(HttpUrl)
TELEGRAM_HOSTS = {"t.me", "www.t.me", "telegram.me", "www.telegram.me"}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{5,32}$")
TOKEN_RE = re.compile(r"\b\d{5,}:[A-Za-z0-9_-]{20,}\b")
TELEGRAM_FILE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{20,}$")
BOTS_PAGE_SIZE = 8
EXPIRED_CALLBACK_ERROR_FRAGMENTS = (
    "query is too old",
    "response timeout expired",
    "query id is invalid",
)
INVALID_FILE_ID_ERROR_FRAGMENTS = (
    "wrong file identifier",
    "wrong remote file identifier",
    "failed to get http url content",
    "wrong type of the web page content",
)
START_PAGE_STATE_KEY = "start_page"
CITY_PAGE_STATE_KEY = "city_page"
DELIVERY_PAGE_STATE_KEY = "delivery_page"


class RegisterResultLike(Protocol):
    spec: BotSpec
    created: bool


RegisterBotAction = Callable[[CreateBotRequest], Awaitable[RegisterResultLike]]


class RegistrationState(StatesGroup):
    entering_nickname = State()
    waiting_for_city = State()


LOGIN_RE = re.compile(r"^[A-Za-z0-9_]{6,32}$")
SYSTEM_LOGIN_BLOCKLIST = {
    "admin", "administrator", "root", "support", "operator", "telegram", "bot",
    "system", "null", "none", "user", "users", "test", "moderator", "mod",
    "owner", "staff", "help", "info", "service", "manager", "superuser", "sudo",
    "anonymous", "guest", "default", "official",
}


def generate_login() -> str:
    return "".join(random.choice(string.ascii_lowercase) for _ in range(7))


class PromoState(StatesGroup):
    waiting_for_code = State()


class TopupState(StatesGroup):
    waiting_for_method = State()
    waiting_for_amount = State()
    waiting_for_payment = State()


class AdminState(StatesGroup):
    waiting_for_start_text = State()
    waiting_for_contacts_text = State()
    waiting_for_operator = State()
    waiting_for_link = State()
    waiting_for_exchanger_label = State()
    waiting_for_exchanger_url = State()
    waiting_for_payment_label = State()
    waiting_for_payment_commission = State()
    waiting_for_payment_text = State()
    waiting_for_payment_requisites = State()
    waiting_for_new_payment_label = State()
    waiting_for_new_payment_text = State()
    waiting_for_admin_id = State()
    waiting_for_bot_tokens = State()
    waiting_for_catalog_product_name = State()
    waiting_for_catalog_product_first_option = State()
    waiting_for_catalog_option_label = State()


@dataclass(slots=True)
class OrderSelection:
    city_key: str
    product_index: int
    option_index: int
    district_index: int
    order_id: int | None = None


@dataclass(slots=True)
class TopupSelection:
    order_id: int
    topup_id: int
    amount_uah: int
    deadline_text: str


@dataclass(slots=True)
class PendingOrderRecord:
    user_id: int
    chat_id: int
    order: OrderSelection
    expires_at: datetime
    method_index: int | None = None


@dataclass(slots=True)
class BotRuntime:
    spec: BotSpec
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task[None]


PAYMENT_GUARD_KEY = "active_payment_guard"
CAPTCHA_MAX_ATTEMPTS = 5
PAYMENT_DEADLINE_MINUTES = 60
PAYMENT_EXTENSION_MINUTES = 30
PAYMENT_EXPIRED_TEXT = "Время оплаты вышло."
PAYMENT_EXTENDED_TEXT = "Время оплаты продлено на 30 минут."
EXISTING_PENDING_ORDER_TEXT = (
    "У Вас уже есть неоплаченый заказ № {order_id}.\n"
    "Прежде чем делать новый заказ, оплатите текущий или отмените его!"
)


def parse_bot_callback_payload(callback_data: str | None) -> tuple[int, int] | None:
    if not callback_data:
        return None
    try:
        _prefix, bot_id_text, page_text = callback_data.rsplit(":", maxsplit=2)
        return int(bot_id_text), int(page_text)
    except ValueError:
        logger.warning("Invalid bot callback payload: %r", callback_data)
        return None


def create_dispatcher(
    bot: Bot,
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
) -> Dispatcher:
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    router = Router()
    spec.template = normalize_template(spec.template)
    captcha_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_captcha_{spec.bot_id or 'unknown'}.json"
    )
    captcha_registry = CaptchaRegistry(captcha_storage_path)
    analytics_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_analytics_{spec.bot_id or 'unknown'}.json"
    )
    analytics = AnalyticsRegistry(analytics_storage_path)
    users_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_users_{spec.bot_id or 'unknown'}.json"
    )
    users = UserRegistry(users_storage_path)
    pending_orders: dict[int, PendingOrderRecord] = {}
    pending_order_timeout_tasks: dict[int, asyncio.Task[None]] = {}

    def now_local() -> datetime:
        return datetime.now().astimezone()

    def format_payment_deadline(deadline: datetime) -> str:
        return deadline.astimezone().strftime("%d-%m | %H : %M : %S")

    def is_same_order(left: OrderSelection, right: OrderSelection) -> bool:
        if (
            left.city_key == right.city_key
            and left.product_index == right.product_index
            and left.option_index == right.option_index
            and left.district_index == right.district_index
        ):
            return True
        return left.order_id is not None and right.order_id is not None and left.order_id == right.order_id

    def get_target_user_id(target: Message | CallbackQuery) -> int | None:
        if isinstance(target, CallbackQuery):
            return target.from_user.id if target.from_user else None
        return target.from_user.id if target.from_user else None

    def get_target_chat_id(target: Message | CallbackQuery) -> int | None:
        message = target.message if isinstance(target, CallbackQuery) else target
        return message.chat.id if message is not None else None

    async def get_lang(target: Message | CallbackQuery | int | None) -> str:
        user_id = target if isinstance(target, int) else get_target_user_id(target) if target is not None else None
        if user_id is None:
            return "ru"
        record = await users.get(user_id)
        language = record.get("language")
        return language if language in SUPPORTED_LANGUAGES else "ru"

    async def show_language_menu(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        await show_text_screen(target, build_language_prompt_text(), build_language_menu())

    def get_target_user_name(target: Message | CallbackQuery) -> str | None:
        user = target.from_user
        return user.first_name if user else None

    async def render_main_menu(target: Message | CallbackQuery, city: CityConfig, lang: str):
        user_id = get_target_user_id(target)
        record = await users.get(user_id) if user_id is not None else {}
        purchases = int(record.get("purchases", 0) or 0)
        total_sum = int(record.get("purchases_sum", 0) or 0)
        text = build_main_city_text(
            spec.template,
            city,
            lang=lang,
            name=get_target_user_name(target),
            user_id=user_id,
            purchases=purchases,
            total_sum=total_sum,
        )
        markup = main_city_menu(spec.template, city.key, lang)
        return text, markup

    async def show_main_menu(target: Message | CallbackQuery, state: FSMContext, city_key: str) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        lang = await get_lang(target)
        await state.update_data(last_city=city.key)
        text, markup = await render_main_menu(target, city, lang)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    def cancel_pending_order_timeout(user_id: int | None) -> None:
        if user_id is None:
            return
        task = pending_order_timeout_tasks.pop(user_id, None)
        if task is not None:
            task.cancel()

    def get_active_pending_order(user_id: int | None) -> PendingOrderRecord | None:
        if user_id is None:
            return None
        record = pending_orders.get(user_id)
        if record is None:
            return None
        if record.expires_at > now_local():
            return record
        pending_orders.pop(user_id, None)
        cancel_pending_order_timeout(user_id)
        return None

    async def clear_pending_order(user_id: int | None) -> None:
        if user_id is None:
            return
        pending_orders.pop(user_id, None)
        cancel_pending_order_timeout(user_id)

    def schedule_pending_order_timeout(user_id: int) -> None:
        cancel_pending_order_timeout(user_id)

        async def worker() -> None:
            try:
                while True:
                    record = pending_orders.get(user_id)
                    if record is None:
                        return
                    delay_seconds = (record.expires_at - now_local()).total_seconds()
                    if delay_seconds > 0:
                        await asyncio.sleep(delay_seconds)
                    record = pending_orders.get(user_id)
                    if record is None:
                        return
                    if record.expires_at > now_local():
                        continue
                    pending_orders.pop(user_id, None)
                    pending_order_timeout_tasks.pop(user_id, None)
                    try:
                        await bot.send_message(
                            record.chat_id,
                            f"{PAYMENT_EXPIRED_TEXT}\nЗаказ № {record.order.order_id}.",
                        )
                    except Exception as exc:
                        logger.warning(
                            "Could not send payment expiration message for order %s: %s",
                            record.order.order_id,
                            exc,
                        )
                    return
            except asyncio.CancelledError:
                return

        pending_order_timeout_tasks[user_id] = asyncio.create_task(worker())

    async def upsert_pending_order(
        user_id: int | None,
        chat_id: int | None,
        order: OrderSelection,
        *,
        method_index: int | None = None,
        reset_deadline: bool = False,
    ) -> PendingOrderRecord | None:
        if user_id is None or chat_id is None:
            return None
        current = get_active_pending_order(user_id)
        if current is not None and is_same_order(current.order, order):
            expires_at = (
                now_local() + timedelta(minutes=PAYMENT_DEADLINE_MINUTES)
                if reset_deadline
                else current.expires_at
            )
            next_method_index = method_index if method_index is not None else current.method_index
        else:
            expires_at = now_local() + timedelta(minutes=PAYMENT_DEADLINE_MINUTES)
            next_method_index = method_index
        record = PendingOrderRecord(
            user_id=user_id,
            chat_id=chat_id,
            order=order,
            expires_at=expires_at,
            method_index=next_method_index,
        )
        pending_orders[user_id] = record
        schedule_pending_order_timeout(user_id)
        return record

    async def extend_pending_order(user_id: int | None) -> PendingOrderRecord | None:
        record = get_active_pending_order(user_id)
        if record is None:
            return None
        record.expires_at = record.expires_at + timedelta(minutes=PAYMENT_EXTENSION_MINUTES)
        pending_orders[user_id] = record
        schedule_pending_order_timeout(user_id)
        return record

    def build_existing_pending_order_text(record: PendingOrderRecord) -> str:
        return EXISTING_PENDING_ORDER_TEXT.format(order_id=record.order.order_id or create_order_id())

    async def show_existing_pending_order_warning(message: Message, record: PendingOrderRecord) -> None:
        await message.answer(
            build_existing_pending_order_text(record),
            reply_markup=existing_unpaid_order_menu(
                "pendingorder:pay",
                "ordercancel:confirmed",
                "pendingorder:status",
            ),
        )

    async def resolve_pending_order_for_callback(
        callback: CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        *,
        allow_restore: bool = False,
    ) -> PendingOrderRecord | None:
        user_id = callback.from_user.id if callback.from_user else None
        chat_id = callback.message.chat.id if callback.message is not None else None
        record = get_active_pending_order(user_id)
        if record is None and allow_restore:
            return await upsert_pending_order(user_id, chat_id, order, reset_deadline=True)
        if record is None:
            await clear_payment_guard(state)
            if callback.message is not None:
                await callback.message.answer(PAYMENT_EXPIRED_TEXT)
            return None
        if not is_same_order(record.order, order):
            if callback.message is not None:
                await show_existing_pending_order_warning(callback.message, record)
            return None
        return record

    def is_admin(user_id: int | None) -> bool:
        return user_id is not None and user_id in spec.admin_ids

    def has_photo_message(message: Message) -> bool:
        return bool(message.photo)

    def is_expired_callback_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in EXPIRED_CALLBACK_ERROR_FRAGMENTS)

    def is_invalid_file_id_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in INVALID_FILE_ID_ERROR_FRAGMENTS)

    async def download_photo_from_url(url: str) -> BufferedInputFile | None:
        try:
            timeout = aiohttp.ClientTimeout(total=4)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        logger.warning("Could not download product photo %s: HTTP %s", url, response.status)
                        return None
                    content = await response.read()
                    if not content:
                        logger.warning("Downloaded empty product photo from %s", url)
                        return None
                    parsed = urlparse(url)
                    filename = Path(parsed.path).name or "product.jpg"
                    return BufferedInputFile(content, filename=filename)
        except Exception as exc:
            logger.warning("Could not download product photo %s: %s", url, exc)
            return None

    async def safe_answer_callback(
        callback: CallbackQuery,
        text: str | None = None,
        *,
        show_alert: bool = False,
    ) -> bool:
        try:
            await callback.answer(text, show_alert=show_alert)
            return True
        except TelegramBadRequest as exc:
            if not is_expired_callback_error(exc):
                raise
            logger.info("Callback answer expired for %r: %s", callback.data, exc)
            return False

    async def replace_with_text_message(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        await message.answer(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete previous message %s", message.message_id)

    async def show_text_screen(
        target: Message | CallbackQuery,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        if isinstance(target, Message):
            await target.answer(
                text,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview,
            )
            return
        if has_photo_message(target.message):
            await replace_with_text_message(
                target.message,
                text,
                reply_markup,
                disable_web_page_preview=disable_web_page_preview,
            )
            return
        await target.message.edit_text(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )

    async def edit_message_copy(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        if has_photo_message(message):
            await message.edit_caption(caption=text, reply_markup=reply_markup)
            return
        await message.edit_text(text, reply_markup=reply_markup)

    async def send_product_photo_message(message: Message, product: ProductConfig) -> None:
        photo_source = resolve_product_photo(product, settings)
        if photo_source is None:
            return
        try:
            if isinstance(photo_source, FSInputFile):
                await message.answer_photo(photo_source)
                return
            if isinstance(photo_source, str) and photo_source.startswith(("http://", "https://")):
                downloaded = await download_photo_from_url(photo_source)
                if downloaded is not None:
                    await message.answer_photo(downloaded)
                    return
            await message.answer_photo(photo_source)
        except Exception as exc:
            logger.warning("Could not send product photo for %s: %s", product.label, exc)

    def build_captcha_markup(options: list[int]) -> InlineKeyboardMarkup:
        rows: list[list[InlineKeyboardButton]] = []
        current_row: list[InlineKeyboardButton] = []
        for option in options:
            current_row.append(
                InlineKeyboardButton(text=str(option), callback_data=f"captcha:{option}")
            )
            if len(current_row) == 4:
                rows.append(current_row)
                current_row = []
        if current_row:
            rows.append(current_row)
        return InlineKeyboardMarkup(inline_keyboard=rows)

    def build_captcha_progress_text(captcha_id: int, attempt_number: int) -> str:
        return f"# {captcha_id} Просмотр капчи {attempt_number} из {CAPTCHA_MAX_ATTEMPTS}."

    def build_captcha_question_text(a: int, b: int) -> str:
        return f"Решите пример: {a} - {b} = ?"

    def next_day_start_iso() -> str:
        now = datetime.now().astimezone()
        next_day = (now + timedelta(days=1)).date()
        blocked_until = datetime.combine(next_day, datetime.min.time(), tzinfo=now.tzinfo)
        return blocked_until.isoformat()

    async def get_captcha_record(user_id: int) -> dict[str, object]:
        record = await captcha_registry.get_user(user_id)
        blocked_until_raw = record.get("blocked_until")
        if isinstance(blocked_until_raw, str):
            try:
                blocked_until = datetime.fromisoformat(blocked_until_raw)
            except ValueError:
                blocked_until = None
            if blocked_until is not None and blocked_until <= datetime.now().astimezone():
                record["blocked_until"] = None
                record["failed_attempts"] = 0
                await captcha_registry.update_user(user_id, lambda _: record)
        return record

    async def is_captcha_passed(user_id: int | None) -> bool:
        # Captcha is disabled: registration starts straight at the city prompt.
        return True

    async def is_user_blocked(user_id: int | None) -> tuple[bool, str | None]:
        if user_id is None:
            return False, None
        record = await get_captcha_record(user_id)
        blocked_until_raw = record.get("blocked_until")
        if not isinstance(blocked_until_raw, str) or not blocked_until_raw:
            return False, None
        try:
            blocked_until = datetime.fromisoformat(blocked_until_raw)
        except ValueError:
            return False, None
        if blocked_until <= datetime.now().astimezone():
            return False, None
        return True, blocked_until.strftime("%d.%m %H:%M")

    async def ensure_captcha_challenge(user_id: int, *, force_new: bool = False) -> dict[str, object]:
        def updater(current: dict[str, object]) -> dict[str, object]:
            if current.get("passed"):
                return current
            has_active_captcha = (
                current.get("captcha_a") is not None
                and current.get("captcha_b") is not None
                and current.get("captcha_correct") is not None
                and isinstance(current.get("captcha_options"), list)
                and bool(current.get("captcha_options"))
            )
            if has_active_captcha and not force_new:
                return current
            a = random.randint(10, 20)
            b = random.randint(1, min(9, a - 1))
            correct = a - b
            options = {correct}
            while len(options) < 4:
                delta = random.randint(-4, 4)
                candidate = correct + delta
                if candidate > 0:
                    options.add(candidate)
            shuffled = list(options)
            random.shuffle(shuffled)
            current.update(
                failed_attempts=int(current.get("failed_attempts", 0)),
                captcha_id=random.randint(10000, 99999),
                captcha_a=a,
                captcha_b=b,
                captcha_correct=correct,
                captcha_options=shuffled,
                captcha_message_id=current.get("captcha_message_id"),
                blocked_until=current.get("blocked_until"),
                passed=bool(current.get("passed")),
            )
            return current

        return await captcha_registry.update_user(user_id, updater)

    async def send_captcha_prompt(message: Message, user_id: int) -> None:
        record = await ensure_captcha_challenge(user_id, force_new=True)
        attempt_number = min(int(record.get("failed_attempts", 0)) + 1, CAPTCHA_MAX_ATTEMPTS)
        await message.answer(build_captcha_progress_text(int(record["captcha_id"]), attempt_number))
        captcha_message = await message.answer(
            build_captcha_question_text(int(record["captcha_a"]), int(record["captcha_b"])),
            reply_markup=build_captcha_markup([int(item) for item in record.get("captcha_options", [])]),
        )
        await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "captcha_message_id": captcha_message.message_id,
            },
        )

    async def ensure_captcha_access(message: Message, state: FSMContext) -> bool:
        # Captcha is disabled.
        return True

    async def ensure_captcha_callback_access(callback: CallbackQuery, state: FSMContext) -> bool:
        # Captcha is disabled.
        return True

    async def show_registration_prompt(target: Message | CallbackQuery, state: FSMContext) -> None:
        lang = await get_lang(target)
        await state.clear()
        await state.set_state(RegistrationState.waiting_for_city)
        text = build_registration_prompt_text(lang)
        markup = registration_menu(lang)
        if isinstance(target, Message):
            msg = await target.answer(text, reply_markup=markup, disable_web_page_preview=True)
        else:
            try:
                await target.message.edit_text(text, reply_markup=markup, disable_web_page_preview=True)
                msg = target.message
            except Exception:
                msg = await target.message.answer(text, reply_markup=markup, disable_web_page_preview=True)
        await state.update_data(reg_prompt_msg_id=msg.message_id, reg_prompt_chat_id=msg.chat.id)

    async def show_enter_login(target: Message | CallbackQuery, state: FSMContext, lang: str) -> None:
        await state.set_state(RegistrationState.entering_nickname)
        text = build_enter_login_text(lang)
        if isinstance(target, Message):
            msg = await target.answer(text)
        else:
            try:
                await target.message.edit_text(text)
                msg = target.message
            except Exception:
                msg = await target.message.answer(text)
        await state.update_data(login_prompt_msg_id=msg.message_id, login_prompt_chat_id=msg.chat.id)

    async def show_main_screen(target: Message | CallbackQuery, state: FSMContext) -> None:
        # The city list and captcha were removed: "main" is the registration prompt.
        await show_registration_prompt(target, state)

    async def show_main_screen_page(target: Message | CallbackQuery, state: FSMContext, page: int) -> None:
        await show_registration_prompt(target, state)

    async def show_city_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        *,
        page: int | None = None,
    ) -> None:
        data = await state.get_data()
        raw_page = data.get(CITY_PAGE_STATE_KEY, 0) if page is None else page
        current_page = raw_page if isinstance(raw_page, int) else 0
        city = get_city(settings, city_key)
        lang = await get_lang(target)
        markup, current_page, total_pages = city_menu(city, page=current_page)
        text = build_city_text(city, page=current_page, total_pages=total_pages, lang=lang)
        await state.update_data(last_city=city.key, city_page=current_page)
        await show_text_screen(target, text, markup)

    async def show_city_screen_page(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        page: int,
    ) -> None:
        data = await state.get_data()
        await state.set_data({**data, "last_city": city_key, CITY_PAGE_STATE_KEY: max(0, page)})
        await show_city_screen(target, state, city_key, page=page)

    async def show_delivery_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        *,
        page: int | None = None,
    ) -> None:
        # Доставка теперь по категориям: показываем список веществ (категорий).
        data = await state.get_data()
        raw_page = data.get(DELIVERY_PAGE_STATE_KEY, 0) if page is None else page
        current_page = raw_page if isinstance(raw_page, int) else 0
        city = get_city(settings, city_key)
        lang = await get_lang(target)
        markup, current_page, _total_pages = delivery_category_menu(city, page=current_page)
        await state.update_data(last_city=city.key, delivery_page=current_page)
        await show_text_screen(target, build_delivery_text(city, lang), markup)

    async def show_delivery_screen_page(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        page: int,
    ) -> None:
        data = await state.get_data()
        await state.set_data({**data, "last_city": city_key, DELIVERY_PAGE_STATE_KEY: max(0, page)})
        await show_delivery_screen(target, state, city_key, page=page)

    async def show_delivery_category_items(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        cat_idx: int,
        page: int = 0,
    ) -> None:
        city = get_city(settings, city_key)
        lang = await get_lang(target)
        markup, _page, _total = delivery_category_items_menu(city, cat_idx, page=page)
        await state.update_data(last_city=city.key)
        await show_text_screen(target, build_delivery_text(city, lang), markup)

    async def set_payment_guard(
        state: FSMContext,
        stay_callback: str,
        *,
        exit_prompt_shown: bool = False,
    ) -> None:
        data = await state.get_data()
        await state.update_data(
            **{
                **data,
                PAYMENT_GUARD_KEY: {
                    "stay_callback": stay_callback,
                    "exit_prompt_shown": exit_prompt_shown,
                },
            }
        )

    async def clear_payment_guard(state: FSMContext) -> None:
        data = await state.get_data()
        if PAYMENT_GUARD_KEY not in data:
            return
        data.pop(PAYMENT_GUARD_KEY, None)
        await state.set_data(data)

    async def get_payment_guard_stay_callback(state: FSMContext) -> str | None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return None
        stay_callback = guard.get("stay_callback")
        return stay_callback if isinstance(stay_callback, str) and stay_callback else None

    async def is_payment_exit_prompt_shown(state: FSMContext) -> bool:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        return isinstance(guard, dict) and bool(guard.get("exit_prompt_shown"))

    async def mark_payment_exit_prompt(state: FSMContext, shown: bool) -> None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return
        guard["exit_prompt_shown"] = shown
        data[PAYMENT_GUARD_KEY] = guard
        await state.set_data(data)

    async def show_order_payment_detail_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        method_index: int,
        *,
        changed_method_notice: bool = False,
    ) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        district = get_district(city, order.district_index)
        method = get_payment_method(spec, method_index)
        current_order_id = order.order_id or create_order_id()
        stay_callback = f"payment:order:{order_prefix(order)}:{method_index}"
        record = await upsert_pending_order(
            get_target_user_id(target),
            get_target_chat_id(target),
            order,
            method_index=method_index,
        )
        deadline_text = format_payment_deadline(record.expires_at) if record is not None else format_payment_deadline(now_local() + timedelta(minutes=PAYMENT_DEADLINE_MINUTES))

        await set_payment_guard(state, stay_callback)
        message = target if isinstance(target, Message) else target.message

        # Crypto: show the QR as an image + "Оплатите X COIN на адрес ..." + exchanger buttons.
        if is_crypto_method(method):
            coin = method_coin(method) or "USDT"
            address = resolve_payment_requisites(method) or "не указан"
            uah_text = (_build_order_display_fields(product, option)[2] or extract_uah_price(option.label))
            crypto_amount = _compute_crypto_amount(uah_text, coin)
            caption = build_crypto_payment_text(coin, address, crypto_amount, uah_text)
            if changed_method_notice:
                caption = f"{PAYMENT_METHOD_CHANGED_TEXT}\n\n{caption}"
            markup = crypto_payment_menu(
                spec.template.exchangers,
                f"cancel:order:{order_prefix(order)}",
            )
            try:
                await message.answer_photo(generate_qr_file(method), caption=caption, reply_markup=markup)
            except Exception as exc:
                logger.warning("Could not send crypto QR for %s: %s", method.label, exc)
                await message.answer(caption, reply_markup=markup)
            if isinstance(target, CallbackQuery):
                try:
                    await target.message.delete()
                except Exception:
                    logger.debug("Could not delete prior payment message")
            return

        payment_text = build_order_payment_details_text(
            current_order_id,
            city,
            product,
            option,
            district,
            method,
            deadline_text,
            support_url=str(spec.template.payment_support_url) if spec.template.payment_support_url else None,
        )
        if changed_method_notice:
            payment_text = f"{PAYMENT_METHOD_CHANGED_TEXT}\n\n{payment_text}"
        cancel_markup = order_cancel_only_menu(f"cancel:order:{order_prefix(order)}")

        if isinstance(target, Message):
            await target.answer(payment_text, reply_markup=cancel_markup)
            return
        await edit_message_copy(target.message, payment_text, reply_markup=cancel_markup)

    async def show_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_admin_text(spec)
        markup = admin_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payments_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_payments_admin_text(spec)
        markup = payment_admin_menu(spec)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payment_method_editor(
        target: Message | CallbackQuery,
        state: FSMContext,
        method_index: int,
    ) -> None:
        await state.clear()
        method = get_payment_method(spec, method_index)
        text = build_payment_method_editor_text(method)
        markup = payment_method_editor_menu(method_index, method)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def persist_catalog() -> None:
        save_catalog_cities(settings.catalog_path, settings.cities)

    def next_product_key(city: CityConfig) -> str:
        index = len(city.products) + 1
        while any(product.key == f"product_{index}" for product in city.products):
            index += 1
        return f"product_{index}"

    def next_option_key(product: ProductConfig) -> str:
        index = len(product.options) + 1
        while any(option.key == f"option_{index}" for option in product.options):
            index += 1
        return f"option_{index}"

    async def show_catalog_cities(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_catalog_cities_text(settings.cities)
        markup = catalog_cities_menu(settings.cities)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_city(target: Message | CallbackQuery, state: FSMContext, city_key: str) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        text = build_catalog_city_text(city)
        markup = catalog_city_menu(city)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_product(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        product_index: int,
    ) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        product = get_product(city, product_index)
        text = build_catalog_product_text(city, product)
        markup = catalog_product_menu(city_key, product_index)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        bots = await list_bots()
        text = build_bots_text(len(bots))
        markup = bots_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_upload(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(AdminState.waiting_for_bot_tokens)
        text = build_bots_upload_text()
        markup = bots_upload_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_list(target: Message | CallbackQuery, state: FSMContext, page: int = 0) -> None:
        await state.clear()
        bots = await list_bots()
        total_pages = max(1, (len(bots) + BOTS_PAGE_SIZE - 1) // BOTS_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        visible_bots = bots[page * BOTS_PAGE_SIZE : (page + 1) * BOTS_PAGE_SIZE]
        text = build_bots_list_text(visible_bots, page, BOTS_PAGE_SIZE)
        markup = build_bot_list_menu(visible_bots, page, total_pages, spec.bot_id)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def process_uploaded_tokens(message: Message, raw_text: str) -> None:
        tokens = extract_bot_tokens(raw_text)
        if not tokens:
            await message.answer(
                "Не нашел ни одного Telegram-токена. Пришли токен текстом или `.txt` файл.",
                reply_markup=bots_upload_menu(),
            )
            return

        created_count = 0
        updated_count = 0
        skipped_count = 0
        lines: list[str] = []

        for token in tokens:
            if token == spec.token:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: пропущен, это текущий бот")
                continue
            payload = CreateBotRequest(
                token=token,
                template=spec.template.model_copy(deep=True),
                payment_methods=[method.model_copy(deep=True) for method in spec.payment_methods],
                admin_ids=list(spec.admin_ids),
            )
            try:
                result = await register_bot(payload)
            except Exception as exc:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: ошибка, {escape(short_error(exc))}")
                continue
            if result.created:
                created_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: создан и запущен")
            else:
                updated_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: обновлен и перезапущен")

        summary = [
            "<b>Загрузка завершена</b>",
            "",
            f"Создано: {created_count}",
            f"Обновлено: {updated_count}",
            f"Пропущено/ошибок: {skipped_count}",
        ]
        if lines:
            summary.extend(["", *lines[:20]])
            if len(lines) > 20:
                summary.append(f"... и еще {len(lines) - 20}")
        await message.answer("\n".join(summary), reply_markup=bots_upload_menu())

    async def show_payment_selector(
        target: Message | CallbackQuery,
        order: OrderSelection | None,
        topup: TopupSelection | None = None,
    ) -> None:
        if not spec.payment_methods:
            text = "Способы оплаты пока не настроены."
            if isinstance(target, Message):
                await target.answer(text, reply_markup=simple_back_menu())
            else:
                await edit_message_copy(target.message, text, simple_back_menu())
            return

        if topup is not None:
            text = build_topup_request_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
            )
            markup = payment_methods_menu(
                None,
                spec.payment_methods,
                cancel_callback="cancel:topup",
                amount_text=f"{topup.amount_uah} грн.",
                back_callback="nav:main",
            )
        elif order is None:
            text = settings.payment_text
            markup = payment_methods_menu(
                None,
                spec.payment_methods,
                cancel_callback="cancel:generic",
                back_callback="nav:main",
            )
        else:
            if order.order_id is None:
                order = OrderSelection(
                    city_key=order.city_key,
                    product_index=order.product_index,
                    option_index=order.option_index,
                    district_index=order.district_index,
                    order_id=create_order_id(),
                )
            await upsert_pending_order(
                get_target_user_id(target),
                get_target_chat_id(target),
                order,
            )
            city = get_city(settings, order.city_key)
            product = get_product(city, order.product_index)
            option = get_option(product, order.option_index)
            district = get_district(city, order.district_index)
            _, _, price_text = _build_order_display_fields(product, option)
            text = build_order_payment_methods_text(order.order_id, city, product, option, district)
            markup = payment_methods_menu(
                order_prefix(order),
                spec.payment_methods,
                cancel_callback=f"cancel:{order_prefix(order)}",
                cancel_text="Отменить заказ",
                amount_text=price_text,
                back_callback=f"variant:{order.city_key}:{order.product_index}:{order.option_index}",
            )

        if isinstance(target, Message):
            await target.answer(text, reply_markup=markup)
            return
        await edit_message_copy(target.message, text, markup)

    async def show_topup_method_selector(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(TopupState.waiting_for_method)
        text = "Выберите платежную систему"
        markup = payment_methods_menu(
            None,
            spec.payment_methods,
            cancel_callback="cancel:topup",
            back_callback="nav:main",
        )
        if isinstance(target, Message):
            await target.answer(text, reply_markup=markup)
            return
        await edit_message_copy(target.message, text, markup)

    async def start_order_checkout(
        callback: CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        *,
        announce_creation: bool,
        order_type: str | None = None,
    ) -> None:
        if not spec.payment_methods:
            await state.clear()
            if announce_creation:
                await edit_message_copy(callback.message, "Способы оплаты пока не настроены.")
            else:
                await edit_message_copy(callback.message, "Способы оплаты пока не настроены.")
            return
        if order.order_id is None:
            order = OrderSelection(
                city_key=order.city_key,
                product_index=order.product_index,
                option_index=order.option_index,
                district_index=order.district_index,
                order_id=create_order_id(),
            )
        existing = get_active_pending_order(callback.from_user.id if callback.from_user else None)
        if existing is not None:
            await state.clear()
            await show_existing_pending_order_warning(callback.message, existing)
            return
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        district = get_district(city, order.district_index)
        _, _, price_text = _build_order_display_fields(product, option)
        await state.clear()
        await state.update_data(last_city=city.key)
        await upsert_pending_order(
            callback.from_user.id if callback.from_user else None,
            callback.message.chat.id if callback.message is not None else None,
            order,
        )
        payment_markup = payment_methods_menu(
            order_prefix(order),
            spec.payment_methods,
            cancel_callback=f"cancel:{order_prefix(order)}",
            cancel_text="Отменить заказ",
            amount_text=price_text,
            back_callback=f"variant:{order.city_key}:{order.product_index}:{order.option_index}",
        )
        lang = await get_lang(callback)
        methods_text = build_order_payment_methods_text(order.order_id, city, product, option, district)
        if order_type:
            methods_text = f"Тип: {escape(order_type)}\n{methods_text}"
        methods_text = f"{methods_text}\n\n📌 {t(lang, 'operator_after_pay')}"
        if (product.key or "").startswith("dlv_"):
            operator = (spec.template.operator_username or "").strip().lstrip("@")
            if operator:
                methods_text = f"{methods_text}\n✍️ По доставке свяжитесь с оператором: @{escape(operator)}"
        await edit_message_copy(callback.message, methods_text, reply_markup=payment_markup)

    async def send_qr_if_needed(message: Message, method: PaymentMethodConfig) -> None:
        if not method.qr_enabled:
            return
        await send_payment_qr(message, method)

    async def send_payment_qr(message: Message, method: PaymentMethodConfig) -> None:
        try:
            await message.answer_photo(generate_qr_file(method))
        except Exception as exc:
            logger.warning("Could not send QR for %s: %s", method.label, exc)

    async def notify_admins_about_payment(
        payer_message: Message,
        method: PaymentMethodConfig,
        summary_text: str | None,
    ) -> None:
        # Payment notifications to admins are intentionally disabled.
        return

    async def show_order_payment_waiting_screen(
        message: Message,
        order: OrderSelection,
        method_index: int,
        *,
        as_new_message: bool = False,
    ) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        district = get_district(city, order.district_index)
        record = await upsert_pending_order(
            message.from_user.id if message.from_user else None,
            message.chat.id,
            order,
            method_index=method_index,
        )
        deadline_text = format_payment_deadline(record.expires_at) if record is not None else format_payment_deadline(now_local() + timedelta(minutes=PAYMENT_DEADLINE_MINUTES))
        waiting_text = build_order_payment_waiting_text(
            order.order_id or create_order_id(),
            city,
            product,
            option,
            district,
            deadline_text,
        )
        waiting_markup = payment_waiting_menu(
            f"paymenthelp:{order_prefix(order)}:{method_index}",
            f"cancel:{order_prefix(order)}",
            f"paymentextend:{order_prefix(order)}:{method_index}",
            f"paymentrefresh:{order_prefix(order)}:{method_index}",
            f"payment:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index}",
            main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index}",
        )
        if as_new_message:
            await message.answer(waiting_text, reply_markup=waiting_markup)
            return
        await edit_message_copy(message, waiting_text, reply_markup=waiting_markup)

    @router.message(CommandStart())
    async def on_start(message: Message, state: FSMContext) -> None:
        user_id = message.from_user.id if message.from_user else None
        record = await users.get(user_id) if user_id is not None else {}
        if record.get("registered"):
            await show_registration_prompt(message, state)
            return
        await show_language_menu(message, state)

    @router.callback_query(F.data.startswith("lang:"))
    async def on_language_select(callback: CallbackQuery, state: FSMContext) -> None:
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        lang = callback.data.split(":", maxsplit=1)[1]
        if lang not in SUPPORTED_LANGUAGES:
            lang = "ru"
        await users.update(user_id, language=lang, pending_login=None)
        await safe_answer_callback(callback)
        await show_enter_login(callback, state, lang)

    @router.callback_query(F.data == "login:yes")
    async def on_login_yes(callback: CallbackQuery, state: FSMContext) -> None:
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        record = await users.get(user_id)
        login = str(record.get("pending_login") or "").strip() or generate_login()
        await users.update(user_id, login=login, registered=True, pending_login=None)
        await safe_answer_callback(callback)
        await show_registration_prompt(callback, state)

    @router.callback_query(F.data == "login:no")
    async def on_login_no(callback: CallbackQuery, state: FSMContext) -> None:
        lang = await get_lang(callback)
        await safe_answer_callback(callback)
        await show_enter_login(callback, state, lang)

    @router.message(RegistrationState.entering_nickname)
    async def on_nickname(message: Message, state: FSMContext) -> None:
        user_id = message.from_user.id if message.from_user else None
        lang = await get_lang(user_id)
        nickname = (message.text or "").strip()
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete nickname message")
        if user_id is None:
            return
        if len(nickname) <= 5:
            await message.answer(t(lang, "login_short"))
            return
        if not LOGIN_RE.fullmatch(nickname):
            await message.answer(t(lang, "login_bad"))
            return
        if nickname.casefold() in SYSTEM_LOGIN_BLOCKLIST or await users.login_exists(nickname):
            await message.answer(t(lang, "login_system"))
            return
        await users.update(user_id, pending_login=nickname)
        # Delete the "enter login" prompt after the nickname is accepted.
        data = await state.get_data()
        prompt_mid = data.get("login_prompt_msg_id")
        prompt_cid = data.get("login_prompt_chat_id")
        if prompt_mid and prompt_cid:
            try:
                await bot.delete_message(prompt_cid, prompt_mid)
            except Exception:
                logger.debug("Could not delete login prompt message")
            await state.update_data(login_prompt_msg_id=None, login_prompt_chat_id=None)
        await message.answer(build_login_confirm_text(lang, nickname), reply_markup=login_confirm_menu(lang))

    @router.callback_query(F.data == "reg:ok")
    async def on_registration_ok(callback: CallbackQuery, state: FSMContext) -> None:
        await state.set_state(RegistrationState.waiting_for_city)
        await safe_answer_callback(callback)

    @router.callback_query(F.data == "reg:retry")
    async def on_registration_retry(callback: CallbackQuery, state: FSMContext) -> None:
        await safe_answer_callback(callback)
        await show_registration_prompt(callback, state)

    @router.callback_query(F.data.startswith("regcity:"))
    async def on_registration_city_pick(callback: CallbackQuery, state: FSMContext) -> None:
        city_key = callback.data.split(":", maxsplit=1)[1]
        try:
            city = get_city(settings, city_key)
        except StopIteration:
            await safe_answer_callback(callback, "Город не найден.", show_alert=True)
            return
        await safe_answer_callback(callback)
        await show_main_menu(callback, state, city.key)

    @router.callback_query(F.data.startswith("shop:ready:"))
    async def on_shop_ready(callback: CallbackQuery, state: FSMContext) -> None:
        city_key = callback.data.split(":", maxsplit=2)[2]
        await safe_answer_callback(callback)
        await state.clear()
        await show_city_screen(callback, state, city_key, page=0)

    @router.callback_query(F.data.startswith("shop:order:"))
    async def on_shop_order(callback: CallbackQuery, state: FSMContext) -> None:
        city_key = callback.data.split(":", maxsplit=2)[2]
        await safe_answer_callback(callback)
        await state.clear()
        try:
            city = get_city(settings, city_key)
        except StopIteration:
            await show_registration_prompt(callback, state)
            return
        await state.update_data(last_city=city.key)
        if not any(is_delivery_product_index(city, i) for i in range(len(city.products))):
            # No delivery catalog for this family: fall back to ready products.
            await show_city_screen(callback, state, city.key, page=0)
            return
        await show_delivery_screen(callback, state, city.key, page=0)

    @router.callback_query(F.data == "shop:unset")
    async def on_shop_unset(callback: CallbackQuery, state: FSMContext) -> None:
        lang = await get_lang(callback)
        await safe_answer_callback(callback, t(lang, "not_configured"), show_alert=True)

    @router.callback_query(F.data == "nav:change_city")
    async def on_change_city(callback: CallbackQuery, state: FSMContext) -> None:
        await safe_answer_callback(callback)
        await show_registration_prompt(callback, state)

    @router.callback_query(F.data.startswith("nav:citymenu:"))
    async def on_nav_citymenu(callback: CallbackQuery, state: FSMContext) -> None:
        city_key = callback.data.split(":", maxsplit=2)[2]
        try:
            get_city(settings, city_key)
        except StopIteration:
            await safe_answer_callback(callback)
            await show_registration_prompt(callback, state)
            return
        await safe_answer_callback(callback)
        await show_main_menu(callback, state, city_key)

    @router.message(RegistrationState.waiting_for_city)
    async def on_registration_city(message: Message, state: FSMContext) -> None:
        lang = await get_lang(message.from_user.id if message.from_user else None)
        raw_city = (message.text or "").strip()
        data = await state.get_data()
        panel_cid = data.get("reg_prompt_chat_id")
        panel_mid = data.get("reg_prompt_msg_id")
        # Delete the city name the user typed, as requested.
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete user city message %s", message.message_id)
        if not raw_city:
            return

        async def edit_panel(text: str, markup=None) -> bool:
            if not (panel_cid and panel_mid):
                return False
            try:
                await bot.edit_message_text(
                    text,
                    chat_id=panel_cid,
                    message_id=panel_mid,
                    reply_markup=markup,
                    disable_web_page_preview=True,
                )
                return True
            except Exception:
                return False

        # Edit the existing registration/city message into the "searching" state,
        # or fall back to a fresh message if the panel is gone.
        searching_text = build_city_searching_text(raw_city, lang)
        if not await edit_panel(searching_text):
            sent = await message.answer(searching_text, disable_web_page_preview=True)
            panel_cid, panel_mid = sent.chat.id, sent.message_id

        resolution = await resolve_city(settings, raw_city)
        if resolution.kind == "found" and resolution.city is not None:
            city = resolution.city
            await state.clear()
            await state.update_data(last_city=city.key)
            text, markup = await render_main_menu(message, city, lang)
        elif resolution.kind == "suggest" and resolution.suggestions:
            text = build_city_suggestions_text(spec.template, lang)
            markup = city_suggestions_menu(resolution.suggestions, lang)
        else:
            text = build_city_not_found_text(spec.template, lang)
            markup = city_not_found_menu(lang)

        if not await edit_panel(text, markup):
            await message.answer(text, reply_markup=markup, disable_web_page_preview=True)

    @router.callback_query(F.data.startswith("captcha:"))
    async def on_captcha_answer(callback: CallbackQuery, state: FSMContext) -> None:
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return

        blocked, blocked_until_text = await is_user_blocked(user_id)
        if blocked:
            await safe_answer_callback(callback)
            await edit_message_copy(
                callback.message,
                "Вы исчерпали 5 из 5 попыток и заблокированы до следующего дня.\n"
                f"Попробуйте снова после {blocked_until_text}.",
            )
            return

        record = await get_captcha_record(user_id)
        if not record or record.get("captcha_correct") is None:
            await safe_answer_callback(callback)
            if callback.message is not None:
                await callback.message.answer("Капча обновлена. Ниже новый пример.")
                await send_captcha_prompt(callback.message, user_id)
            return
        active_message_id = int(record.get("captcha_message_id", 0) or 0)
        callback_message_id = callback.message.message_id if callback.message else 0
        if active_message_id and callback_message_id != active_message_id:
            await safe_answer_callback(callback)
            if callback.message is not None:
                await callback.message.answer("Эта капча устарела. Используйте последнюю ниже.")
            return
        correct_answer = int(record.get("captcha_correct", -1))
        selected_answer = int(callback.data.rsplit(":", maxsplit=1)[1])
        if selected_answer == correct_answer:
            await captcha_registry.update_user(
                user_id,
                lambda current: {
                    **current,
                    "passed": True,
                    "failed_attempts": 0,
                    "blocked_until": None,
                    "captcha_id": None,
                    "captcha_a": None,
                    "captcha_b": None,
                    "captcha_correct": None,
                    "captcha_options": [],
                    "captcha_message_id": None,
                },
            )
            await safe_answer_callback(callback)
            await state.clear()
            await edit_message_copy(
                callback.message,
                "Капча успешно пройдена! Чтобы начать работу, введите команду /start",
            )
            return

        updated = await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "failed_attempts": int(current.get("failed_attempts", 0)) + 1,
            },
        )
        failed_attempts = int(updated.get("failed_attempts", 0))
        if failed_attempts >= CAPTCHA_MAX_ATTEMPTS:
            blocked_until_iso = next_day_start_iso()
            await captcha_registry.update_user(
                user_id,
                lambda current: {
                    **current,
                    "blocked_until": blocked_until_iso,
                    "captcha_id": None,
                    "captcha_a": None,
                    "captcha_b": None,
                    "captcha_correct": None,
                    "captcha_options": [],
                    "captcha_message_id": None,
                },
            )
            blocked_until = datetime.fromisoformat(blocked_until_iso).strftime("%d.%m %H:%M")
            await safe_answer_callback(callback)
            await edit_message_copy(
                callback.message,
                "Капча не пройдена. Попытки: 5/5.\n"
                f"Вы заблокированы до следующего дня, до {blocked_until}.",
            )
            return

        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            f"Неверно. Попытка {failed_attempts}/{CAPTCHA_MAX_ATTEMPTS}. Ниже новая капча.",
        )
        await send_captcha_prompt(callback.message, user_id)

    @router.message(Command("admin"))
    async def on_admin(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_admin_panel(message, state)

    @router.message(Command("stats"))
    async def on_stats(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await analytics.stats()
        await message.answer(
            "<b>Аналитика</b>\n"
            f"Всего пользователей: {data['total']}\n"
            f"👤 Люди (написали/нажали что-то кроме /start): {data['humans']}\n"
            f"🤖 Боты (только /start): {data['bots']}"
        )

    @router.message(Command("catalog"))
    async def on_catalog(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_catalog_cities(message, state)

    @router.callback_query(F.data == "admin:panel")
    async def on_admin_panel(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:close")
    async def on_admin_close(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text("Админка закрыта.")

    @router.callback_query(F.data == "admin:payments")
    async def on_admin_payments(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_payments_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:catalog")
    async def on_admin_catalog(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_catalog_cities(callback, state)

    @router.callback_query(F.data.startswith("admin:catalog_city:"))
    async def on_admin_catalog_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        await safe_answer_callback(callback)
        await show_catalog_city(callback, state, city_key)

    @router.callback_query(F.data.startswith("admin:catalog_product:"))
    async def on_admin_catalog_product(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, product_index_text = callback.data.split(":")
        await safe_answer_callback(callback)
        await show_catalog_product(callback, state, city_key, int(product_index_text))

    @router.callback_query(F.data.startswith("admin:catalog_add_product:"))
    async def on_admin_catalog_add_product(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_catalog_product_name)
        await state.update_data(catalog_city_key=city_key)
        await callback.message.edit_text(
            f"Город: <b>{escape(city.label)}</b>\n\nПришли название нового товара одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_add_option:"))
    async def on_admin_catalog_add_option(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_catalog_option_label)
        await state.update_data(catalog_city_key=city_key, catalog_product_index=product_index)
        await callback.message.edit_text(
            f"Товар: <b>{escape(product.button_label or product.label)}</b>\n\n"
            "Пришли новую фасовку одним сообщением. Пример: <code>0.2г за 280 ₴ -30%</code>",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_method:"))
    async def on_admin_payment_method(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_payment_method_editor(callback, state, method_index)

    @router.callback_query(F.data == "admin:payment_add")
    async def on_admin_payment_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(
            callback,
            "Доступны только USDT TRC20 и LTC. Добавление других способов отключено.",
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:payment_label:"))
    async def on_admin_payment_label(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(
            callback,
            "Название метода зафиксировано. Меняйте только комиссию и кошелек.",
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:payment_edit:"))
    async def on_admin_payment_edit(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(
            callback,
            "Шаблон текста зафиксирован. Меняйте только кошелек в реквизитах.",
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:payment_commission:"))
    async def on_admin_payment_commission(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        current_commission = (method.commission_text or "").strip() or "не указана"
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_commission)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущая комиссия метода <b>{escape(format_payment_method_title(method))}</b>: "
            f"<b>{escape(current_commission)}</b>\n\n"
            "Пришли новую комиссию одним сообщением. Например: <code>-5%</code>\n"
            "Чтобы убрать комиссию, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_requisites:"))
    async def on_admin_payment_requisites(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        current_requisites = resolve_payment_requisites(method) or "не указаны"
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_requisites)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущий кошелек метода <b>{escape(format_payment_method_title(method))}</b>: "
            f"<b>{escape(current_requisites)}</b>\n\n"
            "Пришли новый кошелек одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_qr:"))
    async def on_admin_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        method.qr_enabled = not method.qr_enabled
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(callback, state, method_index)
        await safe_answer_callback(callback, "QR обновлен.")

    @router.callback_query(F.data.startswith("admin:payment_delete:"))
    async def on_admin_payment_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(
            callback,
            "Удаление способов оплаты отключено. Доступны только USDT TRC20 и LTC.",
            show_alert=True,
        )

    @router.callback_query(F.data == "admin:bots")
    async def on_bots(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_panel(callback, state)

    @router.callback_query(F.data == "admin:bots_upload")
    async def on_bots_upload(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_upload(callback, state)

    @router.callback_query(F.data.startswith("admin:bots_page:"))
    async def on_bots_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        page = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_bots_list(callback, state, page)

    @router.callback_query(F.data.startswith("admin:bot_toggle_pause:"))
    async def on_bot_toggle_pause(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, _page = payload
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await safe_answer_callback(
            callback,
            build_bot_info_alert(bot_summary, bot_id == spec.bot_id),
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:bot_pause_switch:"))
    async def on_bot_pause_switch(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if bot_id == spec.bot_id:
            await safe_answer_callback(callback, "Текущего бота нельзя приостановить из его собственной админки.", show_alert=True)
            return
        updated_spec = await toggle_bot_pause_by_id(bot_id)
        if updated_spec is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await show_bots_list(callback, state, page)
        if updated_spec.is_paused:
            await safe_answer_callback(callback, "🟠 Бот приостановлен.")
            return
        await safe_answer_callback(callback, "Бот снова запущен.")

    @router.callback_query(F.data.startswith("admin:bot_delete:"))
    async def on_bot_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if spec.bot_id == bot_id:
            await safe_answer_callback(callback, "Нельзя удалить текущего бота из его собственной админки.", show_alert=True)
            return
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот уже удален или не найден.", show_alert=True)
            return
        await safe_answer_callback(callback, "Удаляю бота и останавливаю токен...")
        removed = await remove_bot_by_id(bot_id)
        if not removed:
            await show_bots_list(callback, state, page)
            if callback.message is not None:
                await callback.message.answer("Бот уже удален или не найден.")
            return
        await show_bots_list(callback, state, page)
        if callback.message is not None:
            await callback.message.answer(
                "Бот удален и остановлен.\n"
                f"Токен удаленного бота:\n<code>{escape(bot_summary.token)}</code>"
            )

    @router.callback_query(F.data == "admin:set_start_text")
    async def on_set_start_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_start_text)
        await callback.message.edit_text(
            "Текущий стартовый текст:\n\n"
            f"<pre>{escape(spec.template.start_text)}</pre>\n\n"
            "Пришли новый стартовый текст одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_contacts_text")
    async def on_set_contacts_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_contacts_text)
        await callback.message.edit_text(
            "Текущий текст контактов:\n\n"
            f"<pre>{escape(spec.template.contacts_text)}</pre>\n\n"
            "Пришли новый текст контактов одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_operator")
    async def on_set_operator(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_operator)
        current = (spec.template.operator_username or "").strip().lstrip("@")
        current_text = f"@{escape(current)}" if current else "не задан"
        await callback.message.edit_text(
            f"Текущий оператор: <b>{current_text}</b>\n\n"
            "Пришли новый @username оператора одним сообщением.\n"
            "Он используется в сообщении, когда город не распознан.",
            reply_markup=admin_cancel_menu(),
        )

    async def show_exchangers_admin(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_exchangers_admin_text(spec.template.exchangers)
        markup = exchangers_admin_menu(spec.template.exchangers)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_links_admin(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        await show_text_screen(
            target,
            build_links_admin_text(spec.template),
            links_admin_menu(),
            disable_web_page_preview=True,
        )

    @router.callback_query(F.data == "admin:links")
    async def on_admin_links(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_links_admin(callback, state)

    @router.callback_query(F.data.startswith("admin:set_link:"))
    async def on_admin_set_link(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        key = callback.data.rsplit(":", maxsplit=1)[1]
        field = next((f for f in LINK_FIELDS if f[0] == key), None)
        if field is None:
            await safe_answer_callback(callback, "Неизвестная кнопка.", show_alert=True)
            return
        _key, label, attr = field
        current = getattr(spec.template, attr, None)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_link)
        await state.update_data(link_attr=attr, link_label=label)
        await callback.message.edit_text(
            f"Текущая ссылка для <b>{escape(label)}</b>: {escape(str(current)) if current else '—'}\n\n"
            "Пришли новую ссылку (URL или @username). Отправь <code>-</code> чтобы очистить.",
            reply_markup=admin_cancel_menu(),
            disable_web_page_preview=True,
        )

    @router.message(AdminState.waiting_for_link)
    async def on_link_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        attr = str(data.get("link_attr") or "")
        if not attr:
            await show_admin_panel(message, state)
            return
        raw_value = (message.text or "").strip()
        try:
            url = validate_url_input(raw_value, allow_telegram_handle=True)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        setattr(spec.template, attr, url)
        await sync_template_for_all(spec.template)
        await show_links_admin(message, state)

    @router.callback_query(F.data == "admin:exchangers")
    async def on_admin_exchangers(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_exchangers_admin(callback, state)

    @router.callback_query(F.data == "admin:exchanger_add")
    async def on_admin_exchanger_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_exchanger_label)
        await callback.message.edit_text(
            "Пришли название кнопки-обменника одним сообщением.\nНапример: <b>Обменник 4</b>",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:exchanger_delete:"))
    async def on_admin_exchanger_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        try:
            index = int(callback.data.rsplit(":", maxsplit=1)[1])
        except ValueError:
            await safe_answer_callback(callback, "Некорректная кнопка.", show_alert=True)
            return
        if 0 <= index < len(spec.template.exchangers):
            removed = spec.template.exchangers.pop(index)
            await sync_template_for_all(spec.template)
            await safe_answer_callback(callback, f"Удалён: {removed.label}")
        else:
            await safe_answer_callback(callback, "Обменник не найден.", show_alert=True)
        await show_exchangers_admin(callback, state)

    @router.message(AdminState.waiting_for_exchanger_label)
    async def on_exchanger_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        label = (message.text or "").strip()
        if not label:
            await message.answer("Название не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        await state.set_state(AdminState.waiting_for_exchanger_url)
        await state.update_data(exchanger_label=label[:64])
        await message.answer(
            f"Название: <b>{escape(label[:64])}</b>\n\n"
            "Теперь пришли ссылку обменника (URL или @username бота).",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_exchanger_url)
    async def on_exchanger_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        raw_url = (message.text or "").strip()
        try:
            url = validate_url_input(raw_url, allow_telegram_handle=True)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        if url is None:
            await message.answer("Нужна ссылка. Пришли URL или @username.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        label = str(data.get("exchanger_label") or "Обменник")
        spec.template.exchangers.append(ExchangerLink(label=label, url=str(url)))
        await sync_template_for_all(spec.template)
        await show_exchangers_admin(message, state)

    @router.callback_query(F.data == "admin:add_admin")
    async def on_add_admin(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_admin_id)
        await callback.message.edit_text(
            "Пришли Telegram ID нового админа одним числом.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_catalog_product_name)
    async def on_catalog_product_name(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        product_name = (message.text or "").strip()
        if not product_name:
            await message.answer("Название товара не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        city = get_city(settings, city_key)
        await state.set_state(AdminState.waiting_for_catalog_product_first_option)
        await state.update_data(catalog_product_name=product_name)
        await message.answer(
            f"Город: <b>{escape(city.label)}</b>\n"
            f"Товар: <b>{escape(product_name)}</b>\n\n"
            "Теперь пришли первую фасовку одним сообщением. Пример: <code>0.2г за 280 ₴ -30%</code>",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_catalog_product_first_option)
    async def on_catalog_product_first_option(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        option_label = (message.text or "").strip()
        if not option_label:
            await message.answer("Фасовка не должна быть пустой.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        product_name = str(data["catalog_product_name"])
        city = get_city(settings, city_key)
        product = ProductConfig(
            key=next_product_key(city),
            label=product_name,
            button_label=product_name,
            options=[ProductOption(key="option_1", label=option_label)],
            description=None,
            photo_id=None,
            photo_url=None,
            photo_path="",
        )
        city.products.append(product)
        await persist_catalog()
        await show_catalog_city(message, state, city_key)

    @router.message(AdminState.waiting_for_catalog_option_label)
    async def on_catalog_option_label(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        option_label = (message.text or "").strip()
        if not option_label:
            await message.answer("Фасовка не должна быть пустой.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        product_index = int(data["catalog_product_index"])
        city = get_city(settings, city_key)
        product = get_product(city, product_index)
        product.options.append(ProductOption(key=next_option_key(product), label=option_label))
        await persist_catalog()
        await show_catalog_product(message, state, city_key, product_index)

    @router.message(AdminState.waiting_for_start_text)
    async def on_start_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Стартовый текст не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.start_text = new_text
        await sync_start_text_for_all(new_text)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_contacts_text)
    async def on_contacts_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст контактов не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.contacts_text = new_text
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_operator)
    async def on_operator_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_operator = (message.text or "").strip().lstrip("@")
        if not USERNAME_RE.fullmatch(new_operator):
            await message.answer(
                "Нужен корректный @username оператора (5-32 символа: латиница, цифры, _).",
                reply_markup=admin_cancel_menu(),
            )
            return
        spec.template.operator_username = new_operator
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_payment_label)
    async def on_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await state.clear()
        await message.answer(
            "Название метода зафиксировано. Меняйте только комиссию и кошелек.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_payment_text)
    async def on_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await state.clear()
        await message.answer(
            "Редактирование шаблона отключено. Меняйте только кошелек в реквизитах.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_payment_commission)
    async def on_payment_commission_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        method = get_payment_method(spec, method_index)
        raw_value = (message.text or "").strip()
        method.commission_text = None if raw_value.casefold() in {"-", "—", "–", "нет", "none", "null"} else raw_value
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_requisites)
    async def on_payment_requisites_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        method = get_payment_method(spec, method_index)
        new_requisites = (message.text or "").strip()
        if not new_requisites:
            await message.answer("Кошелек не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        updated_method = PaymentMethodConfig.model_validate(
            {
                **method.model_dump(mode="python"),
                "requisites": new_requisites,
                "details_text": normalize_payment_details_template(method.details_text, new_requisites),
            }
        )
        spec.payment_methods[method_index] = updated_method
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_new_payment_label)
    async def on_new_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await state.clear()
        await message.answer(
            "Добавление новых способов оплаты отключено. Доступны только USDT TRC20 и LTC.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_new_payment_text)
    async def on_new_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await state.clear()
        await message.answer(
            "Добавление новых способов оплаты отключено. Доступны только USDT TRC20 и LTC.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_admin_id)
    async def on_admin_id_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        value = (message.text or "").strip()
        if not value.isdigit():
            await message.answer("Нужен числовой Telegram ID.", reply_markup=admin_cancel_menu())
            return
        admin_id = int(value)
        if admin_id not in spec.admin_ids:
            spec.admin_ids.append(admin_id)
            spec.admin_ids.sort()
            await sync_admin_ids_for_all(spec.admin_ids)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_bot_tokens, F.document)
    async def on_bot_tokens_document(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            raw_text = await read_document_text(message)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=bots_upload_menu())
            return
        await process_uploaded_tokens(message, raw_text)

    @router.message(AdminState.waiting_for_bot_tokens)
    async def on_bot_tokens_text(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        raw_text = message.text or message.caption or ""
        await process_uploaded_tokens(message, raw_text)

    @router.callback_query(F.data.startswith("city:"))
    async def on_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        city_key = callback.data.split(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        start_page = find_start_menu_page(settings, city.key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(start_page=start_page)
        target: Message | CallbackQuery = callback.message if callback.message is not None else callback
        await show_city_screen(target, state, city.key, page=0)

    @router.callback_query(F.data.startswith("nav:start_page:"))
    async def on_start_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            page = int(callback.data.rsplit(":", maxsplit=1)[1])
        except ValueError:
            page = 0
        await show_main_screen_page(callback, state, page)

    @router.callback_query(F.data.startswith("nav:city_page:"))
    async def on_city_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            _, _, city_key, page_text = callback.data.split(":", maxsplit=3)
            page = int(page_text)
        except ValueError:
            city_key = callback.data.split(":")[2]
            page = 0
        await show_city_screen_page(callback, state, city_key, page)

    @router.callback_query(F.data.startswith("nav:delivery_page:"))
    async def on_delivery_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            _, _, city_key, page_text = callback.data.split(":", maxsplit=3)
            page = int(page_text)
        except ValueError:
            city_key = callback.data.split(":")[2]
            page = 0
        await show_delivery_screen_page(callback, state, city_key, page)

    @router.callback_query(F.data.startswith("nav:dcat_page:"))
    async def on_delivery_category_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            _, _, city_key, page_text = callback.data.split(":", maxsplit=3)
            page = int(page_text)
        except ValueError:
            city_key = callback.data.split(":")[2]
            page = 0
        await show_delivery_screen_page(callback, state, city_key, page)

    @router.callback_query(F.data.startswith("dcat:"))
    async def on_delivery_category(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            _, city_key, cat_text = callback.data.split(":", maxsplit=2)
            cat_idx = int(cat_text)
        except ValueError:
            return
        await show_delivery_category_items(callback, state, city_key, cat_idx, page=0)

    @router.callback_query(F.data.startswith("nav:dcatitem:"))
    async def on_delivery_category_item_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            _, _, city_key, cat_text, page_text = callback.data.split(":", maxsplit=4)
            cat_idx = int(cat_text)
            page = int(page_text)
        except ValueError:
            return
        await show_delivery_category_items(callback, state, city_key, cat_idx, page=page)

    @router.callback_query(F.data.startswith("item:"))
    async def on_item(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        is_delivery = is_delivery_product_index(city, product_index)
        data = await state.get_data()
        if is_delivery:
            # Доставка: назад к списку весов внутри категории.
            cat_idx = find_delivery_category_index(city, product)
            list_page = 0
            back_callback = f"dcat:{city.key}:{cat_idx}"
        else:
            raw_page = data.get(CITY_PAGE_STATE_KEY, 0)
            list_page = raw_page if isinstance(raw_page, int) else find_city_menu_page(city, product_index)
            back_callback = f"nav:city_page:{city.key}:{list_page}"
        await safe_answer_callback(callback)
        if len(product.options) == 1:
            option_index = 0
            option = product.options[option_index]
            visible_districts = select_visible_districts(city)
            prompt_text = build_district_text(city, product, option)
            await state.update_data(
                last_city=city.key,
                **({} if is_delivery else {CITY_PAGE_STATE_KEY: list_page}),
                last_product=product_index,
                last_option=option_index,
            )
            asyncio.create_task(send_product_photo_message(callback.message, product))
            await callback.message.answer(
                prompt_text,
                reply_markup=district_menu(
                    city,
                    product_index,
                    option_index,
                    visible_districts,
                    back_callback=back_callback,
                ),
            )
            return
        await state.update_data(
            last_city=city.key,
            **({} if is_delivery else {CITY_PAGE_STATE_KEY: list_page}),
            last_product=product_index,
        )
        await show_text_screen(
            callback,
            build_option_text(city, product),
            reply_markup=option_menu(city, product_index, product),
        )

    @router.callback_query(F.data.startswith("variant:"))
    async def on_variant(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        option_index = int(option_index_text)
        product = get_product(city, product_index)
        option = get_option(product, option_index)
        visible_districts = select_visible_districts(city)
        prompt_text = build_district_text(city, product, option)
        await safe_answer_callback(callback)
        await state.update_data(
            last_city=city.key,
            last_product=product_index,
            last_option=option_index,
        )
        asyncio.create_task(send_product_photo_message(callback.message, product))
        await callback.message.answer(
            prompt_text,
            reply_markup=district_menu(
                city,
                product_index,
                option_index,
                visible_districts,
                back_callback=f"item:{city.key}:{product_index}",
            ),
        )

    @router.callback_query(F.data.startswith("district:"))
    async def on_district(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index)
        await safe_answer_callback(callback)
        logger.debug("Selected district %s for %s", district, order)
        if (product.key or "").startswith("dlv_"):
            # Delivery: no Прикоп/Магнит — straight to order summary + operator link.
            option = get_option(product, order.option_index)
            operator_url = (
                str(spec.template.operator_url)
                if spec.template.operator_url
                else (f"https://t.me/{spec.template.operator_username}" if spec.template.operator_username else None)
            )
            await edit_message_copy(
                callback.message,
                build_order_summary_text(order.order_id or create_order_id(), city, product, option, district),
                order_summary_menu(f"checkout:-1:{order_prefix(order)}", "nav:main", operator_url=operator_url),
            )
            return
        # Stash: after the district, ask for the order "type" (random subset of Прикоп/Магнит).
        type_count = random.randint(1, len(ORDER_TYPES))
        visible_types = sorted(random.sample(range(len(ORDER_TYPES)), k=type_count))
        await edit_message_copy(
            callback.message,
            build_order_type_text(),
            order_type_menu(visible_types, order_prefix(order)),
        )

    @router.callback_query(F.data.startswith("ordertype:"))
    async def on_order_type(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        try:
            type_index = int(parts[1])
        except (IndexError, ValueError):
            type_index = 0
        order = parse_order_callback_values(parts[2:])
        if not 0 <= type_index < len(ORDER_TYPES):
            type_index = 0
        await safe_answer_callback(callback)
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        district = get_district(city, order.district_index)
        await edit_message_copy(
            callback.message,
            build_order_summary_text(order.order_id or create_order_id(), city, product, option, district),
            reply_markup=order_summary_menu(
                f"checkout:{type_index}:{order_prefix(order)}",
                "nav:main",
            ),
        )

    @router.callback_query(F.data.startswith("checkout:"))
    async def on_checkout(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        try:
            type_index = int(parts[1])
        except (IndexError, ValueError):
            type_index = 0
        order = parse_order_callback_values(parts[2:])
        # type_index == -1 (delivery) -> no Прикоп/Магнит type
        order_type = ORDER_TYPES[type_index] if 0 <= type_index < len(ORDER_TYPES) else None
        await safe_answer_callback(callback)
        await start_order_checkout(callback, state, order, announce_creation=True, order_type=order_type)

    @router.callback_query(F.data.startswith("confirm:"))
    async def on_confirm_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        await safe_answer_callback(callback)
        await start_order_checkout(callback, state, order, announce_creation=False)

    @router.callback_query(F.data == "action:promo")
    async def on_promo(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await callback.message.edit_text("Введите свой код", reply_markup=promo_menu())

    @router.callback_query(F.data == "action:secret_phrase")
    async def on_secret_phrase(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await callback.message.edit_text("Введите секретную фразу", reply_markup=promo_menu())

    @router.message(PromoState.waiting_for_code)
    async def on_promo_code(message: Message, state: FSMContext) -> None:
        code = (message.text or "").strip()
        await state.clear()
        await message.answer(
            f"Промокод: <b>{escape(code)}</b>\n\n{settings.promo_applied_text}",
            reply_markup=simple_back_menu(),
        )

    @router.callback_query(F.data == "action:purchases")
    async def on_purchases(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text("Ваши покупки:", reply_markup=purchases_menu())

    @router.callback_query(F.data == "action:rules")
    async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text(settings.rules_text, reply_markup=rules_menu())

    @router.callback_query(F.data == "action:topup")
    async def on_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_topup_method_selector(callback, state)

    @router.message(TopupState.waiting_for_amount)
    async def on_topup_amount(message: Message, state: FSMContext) -> None:
        try:
            amount_uah = parse_topup_amount(message.text or "")
        except ValueError:
            await message.answer("Введите сумму числом в гривнах.", reply_markup=simple_back_menu())
            return
        topup = create_topup_selection(amount_uah)
        data = await state.get_data()
        selected_method_index = data.get("selected_topup_method_index")
        if not isinstance(selected_method_index, int):
            await state.clear()
            await show_topup_method_selector(message, state)
            return
        await state.set_state(TopupState.waiting_for_payment)
        await state.update_data(
            topup=serialize_topup_selection(topup),
            selected_topup_method_index=selected_method_index,
        )
        method = get_payment_method(spec, selected_method_index)
        await message.answer(
            build_topup_payment_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
                method,
            ),
            reply_markup=payment_action_menu(
                f"paid:generic:{selected_method_index}",
                "paymenu:generic",
                "cancel:topup",
                f"qr:generic:{selected_method_index}" if method.qr_enabled else None,
            ),
        )

    @router.callback_query(F.data == "paymenu:generic")
    async def on_paymenu_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        if topup is None:
            await show_topup_method_selector(callback, state)
            return
        await state.set_state(TopupState.waiting_for_payment)
        await show_payment_selector(callback, None, topup)

    @router.callback_query(F.data.startswith("paymenu:order:"))
    async def on_paymenu_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await safe_answer_callback(callback)
        await state.clear()
        await show_payment_selector(callback, order)

    @router.callback_query(F.data.startswith("payment:generic:"))
    async def on_payment_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        current_state = await state.get_state()
        if topup is None and current_state == TopupState.waiting_for_method.state:
            await state.set_state(TopupState.waiting_for_amount)
            await state.update_data(selected_topup_method_index=method_index)
            await callback.message.edit_text("Введите сумму", reply_markup=simple_back_menu())
            return
        if topup is None:
            await state.clear()
            text = f"<b>{escape(format_payment_method_title(method))}</b>\n\n{render_payment_details_html(method)}"
        else:
            await state.set_state(TopupState.waiting_for_payment)
            text = build_topup_payment_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
                method,
            )
        await callback.message.edit_text(
            text,
            reply_markup=payment_action_menu(
                f"paid:generic:{method_index}",
                "paymenu:generic",
                "cancel:generic" if topup is None else "cancel:topup",
                f"qr:generic:{method_index}" if method.qr_enabled else None,
            ),
        )

    @router.callback_query(F.data.startswith("payment:order:"))
    async def on_payment_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        await state.clear()
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text))

    @router.callback_query(F.data.startswith("paymentretry:order:"))
    async def on_payment_retry_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        await state.clear()
        await show_order_payment_detail_screen(
            callback,
            state,
            order,
            int(method_index_text),
            changed_method_notice=True,
        )

    @router.callback_query(F.data.startswith("qr:generic:"))
    async def on_qr_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("qr:order:"))
    async def on_qr_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("paid:generic:"))
    async def on_paid_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        topup = await load_topup_selection(state)
        await safe_answer_callback(callback)
        summary_text = None
        if topup is not None:
            summary_text = build_topup_request_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
            )
            await state.clear()
            await edit_message_copy(
                callback.message,
                PIN_TEXT,
                reply_markup=simple_back_menu(),
            )
        await notify_admins_about_payment(callback.message, method, summary_text)

    @router.callback_query(F.data.startswith("paid:order:"))
    async def on_paid_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        method = get_payment_method(spec, int(method_index_text))
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        await upsert_pending_order(
            callback.from_user.id if callback.from_user else None,
            callback.message.chat.id if callback.message is not None else None,
            order,
            method_index=int(method_index_text),
        )
        await set_payment_guard(state, f"payment:order:{order_prefix(order)}:{method_index_text}")
        await show_order_payment_waiting_screen(
            callback.message,
            order,
            int(method_index_text),
            as_new_message=True,
        )
        await notify_admins_about_payment(callback.message, method, build_order_summary(settings, order))

    @router.callback_query(F.data == "cancel:generic")
    async def on_cancel_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await edit_message_copy(callback.message, "Оплата отменена.")

    @router.callback_query(F.data == "cancel:topup")
    async def on_cancel_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await edit_message_copy(callback.message, "Пополнение отменено.")

    @router.callback_query(F.data.startswith("cancel:order:"))
    async def on_cancel_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        parts = callback.data.split(":")
        order = parse_order_callback_values(parts[2:])
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        method_index = 0
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if isinstance(guard, dict):
            stay_callback = guard.get("stay_callback")
            if isinstance(stay_callback, str):
                method_index = int(stay_callback.split(":")[-1])
        await edit_message_copy(
            callback.message,
            ORDER_CANCEL_CONFIRMATION_TEXT.replace("Заказ", f"Заказ № {order.order_id or create_order_id()}"),
            reply_markup=order_cancel_confirmation_menu(
                f"paymentretry:order:{order_prefix(order)}:{method_index}",
                "ordercancel:confirmed",
            ),
        )

    @router.callback_query(F.data.startswith("paymentexit:detail:"))
    async def on_payment_exit_detail(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                f"payment:order:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentexit:waiting:"))
    async def on_payment_exit_waiting(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                f"payment:order:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymenthelp:order:"))
    async def on_payment_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        await set_payment_guard(state, f"payment:order:{order_prefix(order)}:{method_index_text}")
        await callback.message.answer(
            PAYMENT_HELP_TEXT,
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index_text}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentextend:order:"))
    async def on_payment_extend(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        extended_record = await extend_pending_order(callback.from_user.id if callback.from_user else None)
        if extended_record is None:
            await clear_payment_guard(state)
            await callback.message.answer(PAYMENT_EXPIRED_TEXT)
            return
        await set_payment_guard(state, f"payment:order:{order_prefix(order)}:{method_index_text}")
        await callback.message.answer(
            f"{PAYMENT_EXTENDED_TEXT}\nНовый срок оплаты: {format_payment_deadline(extended_record.expires_at)}",
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index_text}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentrefresh:order:"))
    async def on_payment_refresh(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        if await resolve_pending_order_for_callback(callback, state, order) is None:
            return
        await set_payment_guard(state, f"payment:order:{order_prefix(order)}:{method_index_text}")
        await show_order_payment_waiting_screen(
            callback.message,
            order,
            int(method_index_text),
            as_new_message=True,
        )

    @router.callback_query(F.data == "pendingorder:pay")
    async def on_pending_order_pay(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        record = get_active_pending_order(callback.from_user.id if callback.from_user else None)
        if record is None:
            await clear_payment_guard(state)
            await callback.message.answer(PAYMENT_EXPIRED_TEXT)
            await show_main_screen(callback.message, state)
            return
        if record.method_index is None:
            await state.clear()
            await show_payment_selector(callback.message, record.order)
            return
        await state.clear()
        await show_order_payment_detail_screen(
            callback.message,
            state,
            record.order,
            record.method_index,
        )

    @router.callback_query(F.data == "pendingorder:status")
    async def on_pending_order_status(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        record = get_active_pending_order(callback.from_user.id if callback.from_user else None)
        if record is None:
            await clear_payment_guard(state)
            await callback.message.answer(PAYMENT_EXPIRED_TEXT)
            await show_main_screen(callback.message, state)
            return
        if record.method_index is None:
            await state.clear()
            await show_payment_selector(callback.message, record.order)
            return
        await set_payment_guard(state, f"payment:order:{order_prefix(record.order)}:{record.method_index}")
        await show_order_payment_waiting_screen(
            callback.message,
            record.order,
            record.method_index,
            as_new_message=True,
        )

    @router.callback_query(F.data == "action:instructions")
    async def on_instructions(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text(settings.instructions_text, reply_markup=simple_back_menu())

    @router.callback_query(F.data.in_({"action:medical_help", "action:overdose"}))
    async def on_medical_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text(MEDICAL_HELP_TEXT, reply_markup=simple_back_menu())

    @router.callback_query(F.data == "action:operator")
    async def on_operator(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (spec.template.contacts_text or "").strip()
        if not text:
            text = f"Оператор: @{escape(spec.template.operator_username)}"
            if spec.template.operator_url:
                text += f"\nСсылка: {spec.template.operator_url}"
        await callback.message.edit_text(text, reply_markup=simple_back_menu())

    @router.callback_query(F.data == "action:price")
    async def on_price(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = "Раздел VIP Price пока не настроен."
        if spec.template.vip_price_url:
            text = f"VIP Price: {spec.template.vip_price_url}"
        await callback.message.edit_text(text, reply_markup=simple_back_menu())

    @router.callback_query(F.data == "action:work")
    async def on_work(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = "Раздел РАБОТА пока не настроен."
        if spec.template.work_url:
            text = f"РАБОТА: {spec.template.work_url}"
        await callback.message.edit_text(text, reply_markup=simple_back_menu())

    @router.callback_query(F.data == "action:reviews")
    async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = "Отзывы пока не настроены."
        if spec.template.reviews_url:
            text = f"Отзывы: {spec.template.reviews_url}"
        await callback.message.edit_text(text, reply_markup=simple_back_menu())

    @router.callback_query(F.data == "nav:last_city")
    async def on_back_to_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        data = await state.get_data()
        last_city_key = data.get("last_city")
        if not last_city_key:
            await show_main_screen(callback, state)
            return
        raw_page = data.get(CITY_PAGE_STATE_KEY, 0)
        page = raw_page if isinstance(raw_page, int) else 0
        await show_city_screen(callback, state, str(last_city_key), page=page)

    @router.callback_query(F.data == "nav:main")
    async def on_main(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        stay_callback = await get_payment_guard_stay_callback(state)
        if stay_callback is not None:
            if get_active_pending_order(callback.from_user.id if callback.from_user else None) is None:
                await clear_payment_guard(state)
                await show_main_screen(callback, state)
                return
            await mark_payment_exit_prompt(state, True)
            await edit_message_copy(
                callback.message,
                PAYMENT_EXIT_CONFIRMATION_TEXT,
                reply_markup=payment_exit_confirmation_menu(
                    stay_callback,
                    leave_callback="nav:main:confirmed",
                ),
            )
            return
        await show_main_screen(callback, state)

    @router.callback_query(F.data == "nav:main:confirmed")
    async def on_main_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await clear_payment_guard(state)
        await show_main_screen(callback, state)

    @router.callback_query(F.data == "ordercancel:confirmed")
    async def on_order_cancel_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_captcha_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await clear_payment_guard(state)
        await clear_pending_order(callback.from_user.id if callback.from_user else None)
        await show_main_screen(callback.message, state)

    @router.message()
    async def on_fallback_message(message: Message, state: FSMContext) -> None:
        # Unregistered users go to language selection; registered ones to the city prompt.
        user_id = message.from_user.id if message.from_user else None
        record = await users.get(user_id) if user_id is not None else {}
        if record.get("registered"):
            await show_registration_prompt(message, state)
        else:
            await show_language_menu(message, state)

    async def analytics_message_mw(handler, event, data):
        user = data.get("event_from_user")
        if user is not None:
            text = (getattr(event, "text", None) or "").strip()
            only_start = text == "/start" or text.startswith("/start ")
            try:
                await analytics.record(
                    user.id,
                    human=not only_start,
                    timestamp=now_local().isoformat(),
                    username=user.username,
                    full_name=user.full_name,
                    note=None if only_start else f"typed: {text[:40]}",
                )
            except Exception:
                logger.debug("analytics record failed", exc_info=True)
        return await handler(event, data)

    async def analytics_callback_mw(handler, event, data):
        user = data.get("event_from_user")
        if user is not None:
            try:
                await analytics.record(
                    user.id,
                    human=True,
                    timestamp=now_local().isoformat(),
                    username=user.username,
                    full_name=user.full_name,
                    note="button",
                )
            except Exception:
                logger.debug("analytics record failed", exc_info=True)
        return await handler(event, data)

    dp.message.outer_middleware(analytics_message_mw)
    dp.callback_query.outer_middleware(analytics_callback_mw)

    dp.include_router(router)
    return dp


def get_city(settings: Settings, city_key: str) -> CityConfig:
    return next(city for city in settings.cities if city.key == city_key)


def get_product(city: CityConfig, product_index: int) -> ProductConfig:
    return city.products[product_index]


def get_option(product: ProductConfig, option_index: int) -> ProductOption:
    return product.options[option_index]


DELIVERY_DISTRICT_INDEX = 9000
# Способы доставки (вместо района для dlv_-товаров): выбор Такси / Почта / Горячий.
DELIVERY_METHODS: list[tuple[int, str]] = [
    (9001, "🚕 Такси"),
    (9002, "📦 Почта"),
    (9003, "🔥 Горячий"),
]
DELIVERY_METHOD_LABELS = {index: label for index, label in DELIVERY_METHODS}


def get_district(city: CityConfig, district_index: int) -> str:
    if district_index == DELIVERY_DISTRICT_INDEX:
        return "Доставка"
    if district_index in DELIVERY_METHOD_LABELS:
        return DELIVERY_METHOD_LABELS[district_index]
    return city.districts[district_index]


def is_delivery_product_index(city: CityConfig, product_index: int) -> bool:
    try:
        return (city.products[product_index].key or "").startswith("dlv_")
    except (IndexError, AttributeError):
        return False


def select_visible_districts(city: CityConfig) -> list[tuple[int, str]]:
    districts = list(enumerate(city.districts))
    if not districts:
        return []
    if len(districts) <= 1 or city.district_selection_percent >= 100:
        return districts
    visible_count = (len(districts) * city.district_selection_percent) // 100
    visible_count = max(1, min(visible_count, len(districts) - 1))
    selected_positions = sorted(random.sample(range(len(districts)), k=visible_count))
    return [districts[position] for position in selected_positions]


def get_payment_method(spec: BotSpec, method_index: int) -> PaymentMethodConfig:
    return spec.payment_methods[method_index]


def build_payment_method_key(spec: BotSpec, label: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    if not base:
        base = "custom_payment"
    existing_keys = {method.key for method in spec.payment_methods}
    candidate = base
    suffix = 2
    while candidate in existing_keys:
        candidate = f"{base}_{suffix}"
        suffix += 1
    return candidate


def create_order_id() -> int:
    return random.randint(1_000_000, 9_999_999)


def parse_order_callback_values(values: list[str]) -> OrderSelection:
    if values and values[0] == "order":
        values = values[1:]
    if len(values) not in {4, 5}:
        raise ValueError("Invalid order callback payload.")
    return OrderSelection(
        city_key=values[0],
        product_index=int(values[1]),
        option_index=int(values[2]),
        district_index=int(values[3]),
        order_id=int(values[4]) if len(values) == 5 else None,
    )


def order_prefix(order: OrderSelection) -> str:
    parts = [
        order.city_key,
        str(order.product_index),
        str(order.option_index),
        str(order.district_index),
    ]
    if order.order_id is not None:
        parts.append(str(order.order_id))
    return f"order:{':'.join(parts)}"


def build_order_summary(settings: Settings, order: OrderSelection) -> str:
    city = get_city(settings, order.city_key)
    product = get_product(city, order.product_index)
    option = get_option(product, order.option_index)
    district = get_district(city, order.district_index)
    return (
        f"Город: {city.icon} {escape(city.label)}\n"
        f"Товар: {escape(product.label)}\n"
        f"Количество: {escape(option.label)}\n"
        f"Район: {escape(district)}"
    )


def parse_topup_amount(raw_value: str) -> int:
    normalized = (
        raw_value.strip()
        .lower()
        .replace("грн", "")
        .replace("uah", "")
        .replace("₴", "")
        .replace(" ", "")
    )
    if not normalized.isdigit():
        raise ValueError("Top-up amount must be numeric.")
    amount_uah = int(normalized)
    if amount_uah <= 0:
        raise ValueError("Top-up amount must be positive.")
    return amount_uah


def create_topup_selection(amount_uah: int) -> TopupSelection:
    deadline = datetime.now().astimezone() + timedelta(hours=1)
    return TopupSelection(
        order_id=random.randint(10_000_000, 99_999_999),
        topup_id=random.randint(10_000_000, 99_999_999),
        amount_uah=amount_uah,
        deadline_text=deadline.strftime("%d-%m | %H : %M : %S"),
    )


def serialize_topup_selection(topup: TopupSelection) -> dict[str, int | str]:
    return {
        "order_id": topup.order_id,
        "topup_id": topup.topup_id,
        "amount_uah": topup.amount_uah,
        "deadline_text": topup.deadline_text,
    }


async def load_topup_selection(state: FSMContext) -> TopupSelection | None:
    data = await state.get_data()
    payload = data.get("topup")
    if not isinstance(payload, dict):
        return None
    try:
        return TopupSelection(
            order_id=int(payload["order_id"]),
            topup_id=int(payload["topup_id"]),
            amount_uah=int(payload["amount_uah"]),
            deadline_text=str(payload["deadline_text"]),
        )
    except (KeyError, TypeError, ValueError):
        return None


def _compute_crypto_amount(uah_text: str | None, coin: str) -> str | None:
    if not uah_text:
        return None
    digits = re.sub(r"[^\d.,]", "", uah_text).replace(",", ".")
    if not digits:
        return None
    try:
        uah_value = Decimal(digits)
    except InvalidOperation:
        return None
    converted = convert_uah_to_crypto(uah_value, coin)
    if converted is None:
        return None
    return _format_decimal_amount(converted)


def generate_qr_file(method: PaymentMethodConfig) -> BufferedInputFile:
    qr_payload = resolve_payment_requisites(method) or render_payment_details_text(method)
    image = qrcode.make(qr_payload)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return BufferedInputFile(buffer.getvalue(), filename=f"{method.key}.png")


def resolve_configured_photo_url(label: str, settings: Settings) -> str | None:
    marker = label.casefold()
    for rule in settings.product_photo_rules:
        pattern = rule.name_contains.strip().casefold()
        if pattern and pattern in marker:
            return str(rule.photo_url)
    return None


def resolve_product_photo(product: ProductConfig, settings: Settings) -> str | FSInputFile | None:
    photo_id = (product.photo_id or "").strip()
    if photo_id:
        return photo_id

    photo_url = (product.photo_url or "").strip()
    if photo_url:
        return photo_url

    photo_path = (product.photo_path or "").strip()
    if photo_path.startswith("keyword:"):
        keyword_photo = resolve_configured_photo_url(photo_path.partition(":")[2].strip(), settings)
        if keyword_photo:
            return keyword_photo

    configured_photo = resolve_configured_photo_url(product.label, settings)
    if configured_photo:
        return configured_photo

    if not photo_path:
        return None
    if TELEGRAM_FILE_ID_RE.fullmatch(photo_path) and "/" not in photo_path and "\\" not in photo_path:
        return photo_path

    path = Path(photo_path)
    if not path.is_absolute():
        path = Path(settings.catalog_path).resolve().parent / path
    if not path.exists():
        return None
    return FSInputFile(path)


def validate_url_input(raw_value: str, allow_telegram_handle: bool = False) -> HttpUrl | None:
    value = raw_value.strip()
    if not value:
        raise ValueError("Пустое значение. Пришли ссылку или отправь - чтобы очистить.")
    if value.casefold() in {"-", "none", "null", "нет"}:
        return None
    if allow_telegram_handle and value.startswith("@"):
        value = f"https://t.me/{value[1:]}"
    elif allow_telegram_handle and USERNAME_RE.fullmatch(value):
        value = f"https://t.me/{value}"
    elif value.startswith("t.me/") or value.startswith("telegram.me/"):
        value = f"https://{value}"
    elif "://" not in value and "." in value:
        value = f"https://{value}"
    try:
        return HTTP_URL_ADAPTER.validate_python(value)
    except ValidationError as exc:
        raise ValueError("Некорректная ссылка. Пришли полный URL.") from exc


def extract_telegram_username(url: HttpUrl | None) -> str | None:
    if url is None:
        return None
    parsed = urlparse(str(url))
    if parsed.netloc not in TELEGRAM_HOSTS:
        return None
    candidate = parsed.path.strip("/").split("/", maxsplit=1)[0]
    if USERNAME_RE.fullmatch(candidate):
        return candidate
    return None


def extract_bot_tokens(raw_text: str) -> list[str]:
    tokens = TOKEN_RE.findall(raw_text)
    unique_tokens: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique_tokens.append(token)
    return unique_tokens


def mask_token(token: str) -> str:
    if len(token) <= 16:
        return token
    return f"{token[:10]}...{token[-4:]}"


def short_error(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return text[:160]


async def read_document_text(message: Message) -> str:
    if message.document is None:
        raise ValueError("Файл не найден.")
    buffer = io.BytesIO()
    await message.bot.download(message.document, destination=buffer)
    data = buffer.getvalue()
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("Не удалось прочитать файл. Используй обычный `.txt` с токенами.")


async def start_runtime(
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
) -> BotRuntime:
    bot = Bot(
        token=spec.token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    try:
        # Some bots may still have a webhook configured from previous deployments.
        # Polling will fail immediately in that case, so clear the webhook first.
        await bot.delete_webhook(drop_pending_updates=False)
        dp = create_dispatcher(
            bot,
            settings,
            spec,
            persist_spec,
            register_bot,
            list_bots,
            remove_bot_by_id,
            toggle_bot_pause_by_id,
            sync_payment_methods_for_all,
            sync_start_text_for_all,
            sync_admin_ids_for_all,
            sync_template_for_all,
        )
        task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
        logger.info("Started bot @%s", spec.bot_username)
        return BotRuntime(spec=spec, dispatcher=dp, bot=bot, task=task)
    except Exception:
        await bot.session.close()
        raise


async def stop_runtime(runtime: BotRuntime) -> None:
    runtime.task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    await runtime.bot.session.close()
