from __future__ import annotations

import asyncio
import json
import time
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from threading import Lock
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


WHITEBIT_TICKER_URL = "https://whitebit.com/api/v4/public/ticker"
USER_AGENT = "kfc/1.0"
REFRESH_INTERVAL_SECONDS = 3600.0
USDT_UAH_MARKET = "USDT_UAH"
LTC_USDT_MARKET = "LTC_USDT"
CRYPTO_AMOUNT_PRECISION = Decimal("0.00000001")
FIAT_AMOUNT_PRECISION = Decimal("0.01")

# UAH prices of coins (UAH per 1 coin), used to convert hryvnia order sums to crypto.
COINGECKO_URL = (
    "https://api.coingecko.com/api/v3/simple/price"
    "?ids=bitcoin,litecoin,tether&vs_currencies=uah"
)
_COIN_IDS = {"BTC": "bitcoin", "LTC": "litecoin", "USDT": "tether"}

_cache_lock = Lock()
_cached_rates: dict[str, Decimal] = {}
_cached_at = 0.0
_coin_uah_rates: dict[str, Decimal] = {}


def refresh_crypto_uah_rates() -> dict[str, Decimal]:
    request = Request(COINGECKO_URL, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=6) as response:
            payload = json.load(response)
        updated: dict[str, Decimal] = {}
        for coin, coin_id in _COIN_IDS.items():
            entry = payload.get(coin_id)
            if not isinstance(entry, dict):
                continue
            rate = Decimal(str(entry.get("uah") or "0"))
            if rate > 0:
                updated[coin] = rate
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, InvalidOperation, json.JSONDecodeError):
        return dict(_coin_uah_rates)
    if updated:
        with _cache_lock:
            _coin_uah_rates.update(updated)
    return dict(_coin_uah_rates)


def convert_uah_to_crypto(amount_uah: Decimal, coin: str) -> Decimal | None:
    coin = coin.strip().upper()
    with _cache_lock:
        rate = _coin_uah_rates.get(coin)
    if rate is None or rate <= 0:
        return None
    precision = FIAT_AMOUNT_PRECISION if coin == "USDT" else CRYPTO_AMOUNT_PRECISION
    try:
        return (amount_uah / rate).quantize(precision, rounding=ROUND_CEILING)
    except (InvalidOperation, ZeroDivisionError):
        return None


def _read_cached_rate(market: str, max_age_seconds: float | None = None) -> Decimal | None:
    now = time.monotonic()
    with _cache_lock:
        rate = _cached_rates.get(market)
        if rate is None:
            return None
        if max_age_seconds is not None and now - _cached_at > max_age_seconds:
            return None
        return rate


def _write_cached_rates(rates: dict[str, Decimal]) -> None:
    global _cached_at
    with _cache_lock:
        _cached_rates.update(rates)
        _cached_at = time.monotonic()


def refresh_market_rates() -> dict[str, Decimal]:
    request = Request(WHITEBIT_TICKER_URL, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=5) as response:
            payload = json.load(response)
        updated_rates: dict[str, Decimal] = {}
        for market in (USDT_UAH_MARKET, LTC_USDT_MARKET):
            market_data = payload.get(market)
            if not isinstance(market_data, dict):
                continue
            rate = Decimal(str(market_data.get("last_price") or "0"))
            if rate > 0:
                updated_rates[market] = rate
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, InvalidOperation, json.JSONDecodeError):
        return dict(_cached_rates)

    if updated_rates:
        _write_cached_rates(updated_rates)
    return dict(_cached_rates)


def get_usdt_uah_rate() -> Decimal | None:
    return _read_cached_rate(USDT_UAH_MARKET)


def get_ltc_usdt_rate() -> Decimal | None:
    return _read_cached_rate(LTC_USDT_MARKET)


def _normalize_currency(raw_currency: str) -> str:
    marker = raw_currency.strip().casefold()
    if marker in {"usd", "$"}:
        return "USD"
    if marker in {"usdt", "usdt trc20"}:
        return "USDT"
    if marker in {"uah", "грн", "₴"}:
        return "UAH"
    if marker == "ltc":
        return "LTC"
    return raw_currency.strip().upper()


def convert_amount(amount: Decimal, source_currency: str, target_currency: str) -> Decimal | None:
    source = _normalize_currency(source_currency)
    target = _normalize_currency(target_currency)

    if source == target:
        precision = CRYPTO_AMOUNT_PRECISION if target == "LTC" else FIAT_AMOUNT_PRECISION
        return amount.quantize(precision, rounding=ROUND_CEILING)

    # Treat USD as a 1:1 display alias for USDT in the current catalog.
    if source == "USD":
        source = "USDT"
    if target == "USD":
        target = "USDT"
    if source == target:
        precision = CRYPTO_AMOUNT_PRECISION if target == "LTC" else FIAT_AMOUNT_PRECISION
        return amount.quantize(precision, rounding=ROUND_CEILING)

    if source == "UAH" and target == "USDT":
        rate = get_usdt_uah_rate()
        if rate is None or rate <= 0:
            return None
        return (amount / rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "USDT" and target == "UAH":
        rate = get_usdt_uah_rate()
        if rate is None or rate <= 0:
            return None
        return (amount * rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "USDT" and target == "LTC":
        rate = get_ltc_usdt_rate()
        if rate is None or rate <= 0:
            return None
        return (amount / rate).quantize(CRYPTO_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "LTC" and target == "USDT":
        rate = get_ltc_usdt_rate()
        if rate is None or rate <= 0:
            return None
        return (amount * rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if target in {"USDT", "LTC"}:
        usdt_amount = convert_amount(amount, source, "USDT")
        if usdt_amount is None:
            return None
        if target == "USDT":
            return usdt_amount
        return convert_amount(usdt_amount, "USDT", "LTC")

    if source in {"USDT", "LTC"} and target == "UAH":
        usdt_amount = convert_amount(amount, source, "USDT")
        if usdt_amount is None:
            return None
        return convert_amount(usdt_amount, "USDT", "UAH")

    return None


async def refresh_market_rates_periodically() -> None:
    while True:
        await asyncio.sleep(REFRESH_INTERVAL_SECONDS)
        await asyncio.to_thread(refresh_market_rates)
        await asyncio.to_thread(refresh_crypto_uah_rates)
