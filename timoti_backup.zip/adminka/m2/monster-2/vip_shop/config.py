from __future__ import annotations

import json
import os
import random
import re
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field, HttpUrl, ValidationError, model_validator


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_PATH = PROJECT_ROOT / "data" / "bots.json"
DEFAULT_CATALOG_PATH = PROJECT_ROOT / "data" / "catalog.json"
DEFAULT_PRODUCT_PHOTO_RULES_PATH = PROJECT_ROOT / "data" / "product_photo_rules.json"
DOTENV_PATH = PROJECT_ROOT / ".env"
DEFAULT_PRODUCT_PHOTO = PROJECT_ROOT / "СКРИНЫ ИНТЕРФЕЙСА" / "start.png"
DEFAULT_RANDOM_PRODUCT_PHOTO_DIR = PROJECT_ROOT / "RandomFoto"
DEFAULT_START_TEXT_PATH = PROJECT_ROOT / "СКРИНЫ ИНТЕРФЕЙСА" / "start.txt"
DEFAULT_GENERIC_DISTRICTS = [
    "Заполните районы",
]
# monster-2 — украинское семейство. Источник правды — data/catalog.json.
DEFAULT_SCREENSHOT_CITY_ORDER: list[str] = []


def _city_lookup_key(raw_label: str) -> str:
    return " ".join(raw_label.split()).strip().casefold()


CITY_DISTRICT_OVERRIDES = {
    _city_lookup_key("Киев"): [
        "Печерск",
        "Оболонь",
        "Троещина",
        "Позняки",
        "Соломенка",
        "Подол",
        "Нивки",
        "Теремки",
        "Шулявка",
        "Академгородок",
    ],
    _city_lookup_key("Борисполь"): [
        "Центр",
        "Соцгородок",
        "Розвилка",
        "УМБ-17",
    ],
    _city_lookup_key("Боярка"): [
        "Центр",
        "Новая Боярка",
        "Старая Боярка",
    ],
    _city_lookup_key("Бровары"): [
        "Центр",
        "Торгмаш",
        "Массив",
        "Старый центр",
        "Пекарня",
        "Промузел",
    ],
    _city_lookup_key("Буча"): [
        "Центр",
        "Лесная Буча",
        "Яблунька",
        "Склозаводской",
    ],
    _city_lookup_key("Вишневое"): [
        "Центр",
        "Южный",
        "Северный",
        "Железнодорожный",
    ],
    _city_lookup_key("Вышгород"): [
        "Центр",
        "Шолуденка",
        "Набережная",
        "Карат",
    ],
    _city_lookup_key("Ворзель"): [
        "Центр",
        "Курортная зона",
        "Ворзель-Парк",
    ],
    _city_lookup_key("Гостомель"): [
        "Центр",
        "Балановка",
        "Стеклозавод",
    ],
    _city_lookup_key("Горенка"): [
        "Центр",
        "Озерная",
        "Лесная",
    ],
    _city_lookup_key("Дымер"): [
        "Центр",
        "Старый Дымер",
        "Выезд на Вышгород",
    ],
    _city_lookup_key("Ирпень"): [
        "Центр",
        "Синергия",
        "Романовка",
        "Машторф",
        "БКЗ",
        "СМУ",
    ],
    _city_lookup_key("Стоянка"): [
        "Стоянка-1",
        "Стоянка-2",
        "Центр",
    ],
    _city_lookup_key("Фастов"): [
        "Центр",
        "Завокзалье",
        "Заречье",
        "Потиевка",
    ],
    _city_lookup_key("Николаев"): [
        "Центр",
        "Намыв",
        "Лиски",
        "Соляные",
        "Терновка",
        "Корабельный",
    ],
    _city_lookup_key("Днепр"): [
        "Тополь",
        "СОЛНЕЧНЫЙ McDonalds",
        "ТЦ Караван (левый Берег)",
        "Парк Глобы",
        "NEO PLAZA",
        "ул Титова",
        "ТОПОЛЬ ТРЦ TERRA",
        "ПРОСПЕКТ ПЕТРОВСКОГО",
        "ул. Рабочая",
        "12 КВАРТАЛ",
        "Центр ( вокзал )",
        "Новокодакский (ПАРУС)",
    ],
    _city_lookup_key("Харьков"): [
        "Центр",
        "Салтовка",
        "Алексеевка",
        "Павлово Поле",
        "Новые Дома",
        "Одесская",
        "Холодная Гора",
        "Гагарина",
    ],
    _city_lookup_key("Костополь"): [
        "Центр",
        "Заречье",
        "Новостройки",
    ],
    _city_lookup_key("Каменское (Днепр обл)"): [
        "Соцгород",
        "Черемушки",
        "Левый берег",
        "БАМ",
        "Днепрострой",
        "Романково",
    ],
    _city_lookup_key("Новая Одесса"): [
        "Центр",
        "Северный",
        "Южный",
    ],
    _city_lookup_key("Баштанка (Нико обл.)"): [
        "Центр",
        "Заводской",
        "Южный",
    ],
    _city_lookup_key("Коростышев"): [
        "Центр",
        "Заречье",
        "Новый район",
    ],
    _city_lookup_key("Винница"): [
        "Центр",
        "Вишенка",
        "Замостье",
        "Урожай",
        "Славянка",
        "Старый город",
        "Тяжилов",
        "Подолье",
    ],
    _city_lookup_key("Белая церковь"): [
        "Центр",
        "Леваневского",
        "Пионерская",
        "ДНС",
        "Заречье",
        "Гаек",
    ],
    _city_lookup_key("Чернигов"): [
        "Центр",
        "Масаны",
        "Рокоссовского",
        "Шерстянка",
        "Бобровица",
        "Красный Хутор",
    ],
    _city_lookup_key("Васильков"): [
        "Центр",
        "Массив",
        "Военный городок",
    ],
    _city_lookup_key("Кропивницкий"): [
        "Центр",
        "Попова",
        "Жадова",
        "Ковалевка",
        "Новониколаевка",
        "Балашовка",
    ],
    _city_lookup_key("Немиров"): [
        "Центр",
        "Замостье",
        "Новый район",
    ],
    _city_lookup_key("ГНИВАНЬ"): [
        "Центр",
        "Селище",
        "Варшавка",
    ],
    _city_lookup_key("Казатин"): [
        "Центр",
        "Железнодорожный",
        "ПРБ",
        "Белополье",
    ],
    _city_lookup_key("Львов"): [
        "Центр",
        "Сыхов",
        "Лычаков",
        "Франковский",
        "Левандовка",
        "Замарстынов",
        "Рясне",
        "Подзамче",
        "Погулянка",
        "Научная",
    ],
}


def get_city_districts(city_label: str, fallback: list[str] | None = None) -> list[str]:
    if fallback is not None:
        return list(fallback)
    return list(DEFAULT_GENERIC_DISTRICTS)


def load_default_start_text() -> str:
    try:
        text = DEFAULT_START_TEXT_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        text = ""
    if text:
        return text
    return "Добро пожаловать.\n\nВыберите свой город из списка ниже."


DEFAULT_START_TEXT = load_default_start_text()

PAYMENT_REQUISITES_PLACEHOLDER = "{requisites}"
LEGACY_CARD_REQUISITES_PLACEHOLDER = "CARD_NUMBER_HERE"
LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER = "USDT_TRC20_WALLET_HERE"
LEGACY_LTC_REQUISITES_PLACEHOLDER = "LTC_WALLET_HERE"
_CARD_REQUISITES_PATTERN = re.compile(
    rf"(?<!\d)(?P<card>\d(?:[\s-]?\d){{11,18}}|{re.escape(LEGACY_CARD_REQUISITES_PLACEHOLDER)})(?!\d)",
    re.IGNORECASE,
)
_TRC20_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>T[A-Za-z0-9]{{20,}}|{re.escape(LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER)})(?=\s|$)",
    re.IGNORECASE,
)
_LTC_REQUISITES_PATTERN = re.compile(
    rf"(?<![A-Za-z0-9])(?P<wallet>(?:ltc1[ac-hj-np-z02-9]{{10,}}|[LM3][a-km-zA-HJ-NP-Z1-9]{{26,33}}|{re.escape(LEGACY_LTC_REQUISITES_PLACEHOLDER)}))(?=\s|$)",
    re.IGNORECASE,
)
_LEGACY_REQUISITES_HINT_PATTERN = re.compile(
    rf"^\s*Замените\s+(?:{re.escape(LEGACY_CARD_REQUISITES_PLACEHOLDER)}|"
    rf"{re.escape(LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER)}|"
    rf"{re.escape(LEGACY_LTC_REQUISITES_PLACEHOLDER)})\b.*$",
    re.IGNORECASE,
)


def _normalize_requisites_value(raw_value: object | None) -> str | None:
    if raw_value is None:
        return None
    value = str(raw_value).strip()
    if not value:
        return None
    uppercase_value = value.upper()
    if uppercase_value == LEGACY_CARD_REQUISITES_PLACEHOLDER:
        return LEGACY_CARD_REQUISITES_PLACEHOLDER
    if uppercase_value == LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER:
        return LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER
    if uppercase_value == LEGACY_LTC_REQUISITES_PLACEHOLDER:
        return LEGACY_LTC_REQUISITES_PLACEHOLDER
    if _CARD_REQUISITES_PATTERN.fullmatch(value) is not None:
        return re.sub(r"\s+", " ", value.replace("-", " ")).strip()
    return value


def extract_payment_requisites(details_text: str) -> str | None:
    for pattern in (_TRC20_REQUISITES_PATTERN, _LTC_REQUISITES_PATTERN):
        wallet_match = pattern.search(details_text)
        if wallet_match is not None:
            return _normalize_requisites_value(wallet_match.group("wallet"))
    card_match = _CARD_REQUISITES_PATTERN.search(details_text)
    if card_match is not None:
        return _normalize_requisites_value(card_match.group("card"))
    return None


def normalize_payment_details_template(details_text: str, requisites: str | None = None) -> str:
    del requisites
    text = (details_text or "").strip()
    if not text:
        return ""

    cleaned_lines: list[str] = []
    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if _LEGACY_REQUISITES_HINT_PATTERN.fullmatch(stripped):
            continue

        normalized_line = raw_line.rstrip()
        if PAYMENT_REQUISITES_PLACEHOLDER not in normalized_line:
            for pattern in (_TRC20_REQUISITES_PATTERN, _LTC_REQUISITES_PATTERN, _CARD_REQUISITES_PATTERN):
                normalized_line, replacements = pattern.subn(PAYMENT_REQUISITES_PLACEHOLDER, normalized_line, count=1)
                if replacements:
                    break
        normalized_line = re.sub(
            rf"(?<![A-Za-z0-9])[lL]{re.escape(PAYMENT_REQUISITES_PLACEHOLDER)}(?=\s|$)",
            PAYMENT_REQUISITES_PLACEHOLDER,
            normalized_line,
        )
        cleaned_lines.append(normalized_line)

    while cleaned_lines and not cleaned_lines[-1].strip():
        cleaned_lines.pop()
    return "\n".join(cleaned_lines).strip()


class ProductOption(BaseModel):
    key: str
    label: str


class ProductConfig(BaseModel):
    key: str
    label: str
    options: list[ProductOption]
    button_label: str | None = None
    description: str | None = None
    photo_id: str | None = None
    photo_url: str | None = None
    photo_path: str | None = None
    percent: int = Field(default=100, ge=1, le=100)


class CityConfig(BaseModel):
    key: str
    label: str
    icon: str
    districts: list[str]
    district_selection_percent: int = Field(default=100, ge=1, le=100)
    products: list[ProductConfig]


def select_visible_products(city: "CityConfig") -> list[tuple[int, "ProductConfig"]]:
    # Each product row rolls its own probability (percent) independently — unlike
    # select_visible_districts (bot_runtime.py), there is no single shared percent
    # to size a fixed subset by. Index is preserved so `item:{city.key}:{index}`
    # callbacks still resolve to the right entry in city.products after filtering.
    indexed = list(enumerate(city.products))
    visible = [(i, p) for i, p in indexed if p.percent >= 100 or random.random() * 100 < p.percent]
    return visible or indexed


class PaymentMethodConfig(BaseModel):
    key: str
    label: str
    commission_text: str | None = None
    requisites: str | None = None
    details_text: str
    qr_enabled: bool = False

    @model_validator(mode="before")
    @classmethod
    def _normalize_payload(cls, value: object) -> object:
        if isinstance(value, BaseModel):
            payload = value.model_dump(mode="python")
        elif isinstance(value, dict):
            payload = dict(value)
        else:
            return value

        details_text = str(payload.get("details_text") or "").strip()
        requisites = _normalize_requisites_value(payload.get("requisites"))
        if details_text:
            if requisites is None:
                requisites = extract_payment_requisites(details_text)
            payload["details_text"] = normalize_payment_details_template(details_text, requisites)
        payload["requisites"] = requisites
        return payload


class ProductPhotoRule(BaseModel):
    name_contains: str
    photo_url: HttpUrl
    description: str | None = None


class ExchangerLink(BaseModel):
    label: str
    url: str


def default_exchangers() -> list["ExchangerLink"]:
    # No stock links: exchangers are added by the admin via /admin → Обменники.
    return []


class TemplateOverrides(BaseModel):
    shop_name: str = "monster-2"
    operator_username: str = "kfc_support"
    operator_url: HttpUrl | None = None
    work_url: HttpUrl | None = None
    vip_price_url: HttpUrl | None = None
    reviews_url: HttpUrl | None = None
    site_url: HttpUrl | None = None
    chat_url: HttpUrl | None = None
    complaints_url: HttpUrl | None = None
    questions_url: HttpUrl | None = None
    payment_support_url: HttpUrl | None = None
    contacts_text: str = "Контакты магазина monster-2"
    start_text: str = DEFAULT_START_TEXT
    exchangers: list[ExchangerLink] = Field(default_factory=default_exchangers)


class BotSpec(BaseModel):
    token: str = Field(min_length=20)
    template: TemplateOverrides = Field(default_factory=TemplateOverrides)
    payment_methods: list[PaymentMethodConfig] = Field(default_factory=list)
    admin_ids: list[int] = Field(default_factory=list)
    is_paused: bool = False
    bot_id: int | None = None
    bot_username: str | None = None
    bot_name: str | None = None
    created_at: str | None = None


class CreateBotRequest(BaseModel):
    token: str = Field(min_length=20)
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None


class BotSummary(BaseModel):
    bot_id: int
    bot_username: str | None = None
    bot_name: str | None = None
    token: str
    created_at: str | None = None
    is_running: bool
    is_paused: bool = False
    admin_ids: list[int] = Field(default_factory=list)
    template: TemplateOverrides


class FamilyState(BaseModel):
    template: TemplateOverrides = Field(default_factory=TemplateOverrides)
    payment_methods: list[PaymentMethodConfig] = Field(default_factory=list)
    admin_ids: list[int] = Field(default_factory=list)


class Settings(BaseModel):
    api_host: str = "127.0.0.1"
    api_port: int = 18746
    master_api_key: str = "change-me"
    data_path: Path = Path("data/bots.json")
    catalog_path: Path = Path("data/catalog.json")
    product_photo_rules_path: Path = DEFAULT_PRODUCT_PHOTO_RULES_PATH
    default_admin_ids: list[int] = Field(default_factory=list)
    default_product_photo: Path = DEFAULT_PRODUCT_PHOTO
    random_product_photo_dir: Path = DEFAULT_RANDOM_PRODUCT_PHOTO_DIR
    product_photo_rules: list[ProductPhotoRule] = Field(default_factory=list)
    default_payment_methods: list[PaymentMethodConfig]
    cities: list[CityConfig]
    rules_text: str
    instructions_text: str
    payment_text: str
    purchase_stub_text: str
    promo_applied_text: str
    # Codex Sale (provider id: codexsale) — OpenAI-compatible API for city matching.
    ai_enabled: bool = True
    ai_api_key: str = ""
    ai_base_endpoint: str = "https://codex.sale/v1"
    ai_models_endpoint: str = "https://codex.sale/v1/models"
    ai_chat_endpoint: str = "https://codex.sale/v1/chat/completions"
    ai_model: str = "gpt-5.4-mini"


def flat_product(
    key: str,
    label: str,
    *,
    description: str | None = None,
    photo_id: str = "",
    photo_url: str = "",
    photo_path: str = "",
) -> ProductConfig:
    return ProductConfig(
        key=key,
        label=label,
        options=[ProductOption(key="default", label=label)],
        description=description,
        photo_id=photo_id,
        photo_url=photo_url,
        photo_path=photo_path,
    )


# Preserve the legacy catalog for autogenerated cities that inherit the fallback assortment.
LEGACY_DEFAULT_PRODUCTS = [
    ProductConfig(
        key="alpha_pvp_white_crystal_moon",
        label="Alfa PvP🌖 White crystal moon🌖🧂",
        options=[
            ProductOption(key="1g_630", label="Alfa PvP 🧂 1г за 630 ₴"),
            ProductOption(key="2g_1100", label="Alfa PvP 🧂 2г за 1100 ₴"),
            ProductOption(key="5g_2400", label="Alfa PvP 🧂 5г за 2400 ₴"),
        ],
        photo_path="",
    ),
    ProductConfig(
        key="alpha_pvp_red_heart",
        label="Alpha PvP ❤️Red Heart❤️🧂",
        options=[
            ProductOption(key="1g_630", label="Alfa PvP ❤️ 1г за 630 ₴"),
            ProductOption(key="2g_1100", label="Alfa PvP ❤️ 2г за 1100 ₴"),
            ProductOption(key="3g_1500", label="Alfa PvP ❤️ 3г за 1500 ₴"),
        ],
        photo_path="",
    ),
    ProductConfig(
        key="mefedron_vhq",
        label="Мефедрон 💎 VHQ 💎",
        options=[
            ProductOption(key="1g_650", label="Меф 1гр💎 за 650 ₴"),
            ProductOption(key="2g_1100", label="Меф 2гр💎 за 1100 ₴"),
        ],
        photo_path="",
    ),
    ProductConfig(
        key="amfetamin_sulfat",
        label="Amfetamin Sulfat ☃️White Dust☃️",
        options=[
            ProductOption(key="1g_477", label="Amfetamin ☃️ 1г ☃️ за 477 ₴"),
            ProductOption(key="2g_850", label="Amfetamin ☃️ 2г ☃️ за 850 ₴"),
        ],
        photo_path="",
    ),
    ProductConfig(
        key="rose_gold_indica",
        label="🍂Rose Gold Strain - InDiCa🍂",
        options=[
            ProductOption(
                key="1g_467",
                label="ШиШкИ Rose Gold Strain - InDiCa - 1gr за 467 ₴",
            ),
            ProductOption(
                key="2g_800",
                label="ШиШкИ Rose Gold Strain - InDiCa - 2gr за 800 ₴",
            ),
        ],
        photo_path="",
    ),
    ProductConfig(
        key="morocco_hassan",
        label="🍪Morocco Hassan🍪",
        options=[
            ProductOption(key="1g_552", label="Гашиш 1гр за 552 ₴"),
        ],
        photo_path="",
    ),
]


KYIV_DISTRICTS = get_city_districts("Киев")


# Kyiv uses a simplified generated catalog with 10 lots.
KYIV_PRODUCTS = [
    flat_product(key=f"lot_{index}", label=f"lot_{index}")
    for index in range(1, 11)
]


BORYSPIL_DISTRICTS = get_city_districts("Борисполь")


# Boryspil uses a simplified generated catalog with 5 lots.
BORYSPIL_PRODUCTS = [
    flat_product(key=f"lot_{index}", label=f"lot_{index} - 10")
    for index in range(1, 6)
]


BROVARY_DISTRICTS = get_city_districts("Бровары")


# Brovary uses a simplified generated catalog with 6 lots.
BROVARY_PRODUCTS = [
    flat_product(key=f"lot_{index}", label=f"lot_{index} - 10")
    for index in range(1, 7)
]


BOYARKA_DISTRICTS = get_city_districts("Боярка")


# Boyarka uses a simplified generated catalog with 9 lots.
BOYARKA_PRODUCTS = [
    flat_product(key=f"lot_{index}", label=f"lot_{index} - 10")
    for index in range(1, 10)
]


# Lviv uses flat product buttons from the provided catalog screenshot.
LVIV_PRODUCTS = [
    flat_product(key="sale_apvp_hq_5g_1300", label="РАСПРОДАЖА! - A-PVP HQ - 5 г. 1300грн."),
    flat_product(key="mix_1g_300", label="Микс - 1 г. 300грн."),
    flat_product(key="a_pvp_hq_025g_252", label="A-PVP HQ - 0.25 г. 252грн."),
    flat_product(key="mix_2g_500", label="Микс - 2 г. 500грн."),
    flat_product(key="salt_hq_100_05g_315", label="Соль HQ 100% - 0.5 г. 315грн."),
    flat_product(key="mix_3g_660", label="Микс - 3 г. 660грн."),
    flat_product(key="salt_all_colors_1g_500", label="Соль все цвета: 1 г. 500грн."),
    flat_product(key="mix_5g_930", label="Микс - 5 г. 930грн."),
    flat_product(key="salt_all_colors_2g_810", label="Соль все цвета: 2 г. 810грн."),
    flat_product(key="salt_all_colors_5g_1620", label="Соль все цвета: 5 г. 1620грн."),
    flat_product(key="salt_all_colors_10g_2565", label="Соль все цвета: 10 г. 2565грн."),
    flat_product(key="amf_fosfat_sulfat_hq_1g_450", label="АМФ Фосфат/сульфат HQ - 1 г. 450грн."),
    flat_product(key="a_pvp_20g_4500", label="A-PVP - 20 г. 4500грн."),
    flat_product(key="a_pvp_30g_6300", label="A-PVP - 30 г. 6300грн."),
]


NEMIROV_PRODUCTS = [
    flat_product(key="salt_hq_100_025g_280", label="Соль HQ 100% - 0.25 г. 280грн."),
    flat_product(key="salt_hq_100_05g_350", label="Соль HQ 100% - 0.5 г. 350грн."),
    flat_product(key="salt_all_colors_1g_555", label="Соль все цвета: 1 г. 555грн."),
    flat_product(key="salt_all_colors_2g_900", label="Соль все цвета: 2 г. 900грн."),
    flat_product(key="salt_all_colors_3g_1250", label="Соль все цвета: 3 г. 1250грн."),
    flat_product(key="salt_all_colors_5g_1800", label="Соль все цвета: 5 г. 1800грн."),
    flat_product(key="shishki_indor_hq_1g_380", label="Шишки Индор HQ: 1 грамм 380грн."),
    flat_product(key="a_pvp_20g_5000", label="A-PVP - 20 г. 5000грн."),
]


GNIVAN_PRODUCTS = [
    ProductConfig(
        key="shish_1g",
        label="Шиш",
        options=[ProductOption(key="1g_380", label="1 грамм 380грн.")],
        button_label="Шиш - 1 грамм 380грн.",
        photo_path="",
    ),
    ProductConfig(
        key="shish_indor_hq_2g",
        label="Шиш Индор HQ",
        options=[ProductOption(key="2g_630", label="2 г. 630грн.")],
        button_label="Шиш Индор HQ - 2 г. 630грн.",
        photo_path="",
    ),
    ProductConfig(
        key="shish_indor_hq_3g",
        label="Шиш Индор HQ",
        options=[ProductOption(key="3g_855", label="3 г. 855грн.")],
        button_label="Шиш Индор HQ - 3 г. 855грн.",
        photo_path="",
    ),
    ProductConfig(
        key="shish_indor_hq_5g",
        label="Шиш Индор HQ",
        options=[ProductOption(key="5g_1530", label="5 г. 1530грн.")],
        button_label="Шиш Индор HQ - 5 г. 1530грн.",
        photo_path="",
    ),
    ProductConfig(
        key="a_pvp_hq_025g",
        label="A-PVP HQ",
        options=[ProductOption(key="0_25g_280", label="0.25 г. 280грн.")],
        button_label="A-PVP HQ - 0.25 г. 280грн.",
        photo_path="",
    ),
    ProductConfig(
        key="salt_hq_100_05g",
        label="Соль HQ 100%",
        options=[ProductOption(key="0_5g_350", label="0.5 г. 350грн.")],
        button_label="Соль HQ 100% - 0.5 г. 350грн.",
        photo_path="",
    ),
    ProductConfig(
        key="salt_all_colors_1g",
        label="Соль все цвета",
        options=[ProductOption(key="1g_555", label="1 г. 555грн.")],
        button_label="Соль все цвета: 1 г. 555грн.",
        photo_path="",
    ),
    ProductConfig(
        key="salt_all_colors_2g",
        label="Соль все цвета",
        options=[ProductOption(key="2g_900", label="2 г. 900грн.")],
        button_label="Соль все цвета: 2 г. 900грн.",
        photo_path="",
    ),
    ProductConfig(
        key="salt_all_colors_3g",
        label="Соль все цвета",
        options=[ProductOption(key="3g_1250", label="3 г. 1250грн.")],
        button_label="Соль все цвета: 3 г. 1250грн.",
        photo_path="",
    ),
    ProductConfig(
        key="a_pvp_20g",
        label="A-PVP",
        options=[ProductOption(key="20g_5000", label="20 г. 5000грн.")],
        button_label="A-PVP - 20 г. 5000грн.",
        photo_path="",
    ),
    ProductConfig(
        key="a_pvp_30g",
        label="A-PVP",
        options=[ProductOption(key="30g_7000", label="30 г. 7000грн.")],
        button_label="A-PVP - 30 г. 7000грн.",
        photo_path="",
    ),
]

KAZATIN_PRODUCTS = [
    flat_product(key="salt_all_colors_2g_900", label="Соль все цвета: 2 г. 900грн."),
    flat_product(key="salt_all_colors_3g_1250", label="Соль все цвета: 3 г. 1250грн."),
    flat_product(key="salt_all_colors_5g_1800", label="Соль все цвета: 5 г. 1800грн."),
    flat_product(key="salt_all_colors_10g_2850", label="Соль все цвета: 10 г. 2850грн."),
    flat_product(key="shishki_indor_hq_1g_380", label="Шишки Индор HQ: 1 грамм 380грн."),
    flat_product(key="shishki_indor_hq_2g_630", label="Шишки Индор HQ: 2 г. 630грн."),
    flat_product(key="salt_hq_100_025g_280", label="Соль HQ 100% - 0.25 г. 280грн."),
    flat_product(key="salt_hq_100_05g_350", label="Соль HQ 100% - 0.5 г. 350грн."),
    flat_product(key="salt_all_colors_1g_555", label="Соль все цвета: 1 г. 555грн."),
]


DEFAULT_CITIES = [
    CityConfig(
        key="kyiv",
        label="Киев",
        icon="🌇",
        districts=list(KYIV_DISTRICTS),
        district_selection_percent=75,
        products=[
            ProductConfig(
                key="alpha_pvp_white_crystal_moon",
                label="Alfa PvP🌖 White crystal moon🌖🧂",
                options=[
                    ProductOption(key="1g_630", label="Alfa PvP 🧂 1г за 630 ₴"),
                    ProductOption(key="2g_1100", label="Alfa PvP 🧂 2г за 1100 ₴"),
                    ProductOption(key="5g_2400", label="Alfa PvP 🧂 5г за 2400 ₴"),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="alpha_pvp_red_heart",
                label="Alpha PvP ❤️Red Heart❤️🧂",
                options=[
                    ProductOption(key="1g_630", label="Alfa PvP ❤️ 1г за 630 ₴"),
                    ProductOption(key="2g_1100", label="Alfa PvP ❤️ 2г за 1100 ₴"),
                    ProductOption(key="3g_1500", label="Alfa PvP ❤️ 3г за 1500 ₴"),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="mefedron_vhq",
                label="Мефедрон 💎 VHQ 💎",
                options=[
                    ProductOption(key="1g_650", label="Меф 1гр💎 за 650 ₴"),
                    ProductOption(key="2g_1100", label="Меф 2гр💎 за 1100 ₴"),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="amfetamin_sulfat",
                label="Amfetamin Sulfat ☁️White Dust☁️",
                options=[
                    ProductOption(key="1g_477", label="Amfetamin ☁️ 1г ☁️ за 477 ₴"),
                    ProductOption(key="2g_850", label="Amfetamin ☁️ 2г ☁️ за 850 ₴"),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="rose_gold_indica",
                label="🍀Rose Gold Strain - InDiCa🍀",
                options=[
                    ProductOption(
                        key="1g_467",
                        label="ШиШкИ Rose Gold Strain - InDiCa - 1gr за 467 ₴",
                    ),
                    ProductOption(
                        key="2g_800",
                        label="ШиШкИ Rose Gold Strain - InDiCa - 2gr за 800 ₴",
                    ),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="morocco_hassan",
                label="🍪Morocco Hassan🍪",
                options=[
                    ProductOption(key="1g_552", label="Гашиш 1гр за 552 ₴"),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="nikolaev",
        label="Николаев",
        icon="📍",
        districts=get_city_districts("Николаев"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="shishki_1g_380",
                label="Шишки",
                options=[ProductOption(key="1g_380", label="1 г. 380грн.")],
                button_label="Шишки - 1 г. 380грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g_280",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_280", label="0.25 г. 280грн.")],
                button_label="A-PVP HQ - 0.25 г. 280грн.",
                photo_path="",
            ),
            ProductConfig(
                key="shishki_2g_630",
                label="Шишки",
                options=[ProductOption(key="2g_630", label="2 г. 630грн.")],
                button_label="Шишки - 2 г. 630грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_100g_15500",
                label="A-PVP",
                options=[ProductOption(key="100g_15500", label="100 г. 15500грн.")],
                button_label="A-PVP - 100 г. 15500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="shishki_3g_855",
                label="Шишки",
                options=[ProductOption(key="3g_855", label="3 г. 855грн.")],
                button_label="Шишки - 3 г. 855грн.",
                photo_path="",
            ),
            ProductConfig(
                key="shishki_5g_1530",
                label="Шишки",
                options=[ProductOption(key="5g_1530", label="5 г. 1530грн.")],
                button_label="Шишки - 5 г. 1530грн.",
                photo_path="",
            ),
            ProductConfig(
                key="shishki_10g_2520",
                label="Шишки",
                options=[ProductOption(key="10g_2520", label="10 г. 2520грн.")],
                button_label="Шишки - 10 г. 2520грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_05g_365",
                label="A-PVP",
                options=[ProductOption(key="0_5g_365", label="0.5 г. 365грн.")],
                button_label="A-PVP - 0.5 г. 365грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_1g_575",
                label="A-PVP",
                options=[ProductOption(key="1g_575", label="1 г. 575грн.")],
                button_label="A-PVP - 1 г. 575грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_2g_980",
                label="A-PVP",
                options=[ProductOption(key="2g_980", label="2 г. 980грн.")],
                button_label="A-PVP - 2 г. 980грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_3g_1350",
                label="A-PVP",
                options=[ProductOption(key="3g_1350", label="3 г. 1350грн.")],
                button_label="A-PVP - 3 г. 1350грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_5g_1860",
                label="A-PVP",
                options=[ProductOption(key="5g_1860", label="5 г. 1860грн.")],
                button_label="A-PVP - 5 г. 1860грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_10g_2860",
                label="A-PVP",
                options=[ProductOption(key="10g_2860", label="10 г. 2860грн.")],
                button_label="A-PVP - 10 г. 2860грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="dnepr",
        label="Днепр",
        icon="📍",
        districts=get_city_districts("Днепр"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="a_pvp_50g_9000",
                label="A-PVP",
                options=[ProductOption(key="50g_9000", label="50 г. 9000грн.")],
                button_label="A-PVP - 50 г. 9000грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_3g_1125",
                label="A-PVP",
                options=[ProductOption(key="3g_1125", label="3 г. 1125грн.")],
                button_label="A-PVP - 3 г. 1125грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_5g_1620",
                label="A-PVP",
                options=[ProductOption(key="5g_1620", label="5 г. 1620грн.")],
                button_label="A-PVP - 5 г. 1620грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_10g_2565",
                label="A-PVP",
                options=[ProductOption(key="10g_2565", label="10 г. 2565грн.")],
                button_label="A-PVP - 10 г. 2565грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g_252",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_252", label="0.25 г. 252грн.")],
                button_label="A-PVP HQ - 0.25 г. 252грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_20g_4500",
                label="A-PVP",
                options=[ProductOption(key="20g_4500", label="20 г. 4500грн.")],
                button_label="A-PVP - 20 г. 4500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_30g_6300",
                label="A-PVP",
                options=[ProductOption(key="30g_6300", label="30 г. 6300грн.")],
                button_label="A-PVP - 30 г. 6300грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_05g_315",
                label="A-PVP",
                options=[ProductOption(key="0_5g_315", label="0.5 г. 315грн.")],
                button_label="A-PVP - 0.5 г. 315грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_1g_500",
                label="A-PVP",
                options=[ProductOption(key="1g_500", label="1 г. 500грн.")],
                button_label="A-PVP - 1 г. 500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_2g_810",
                label="A-PVP",
                options=[ProductOption(key="2g_810", label="2 г. 810грн.")],
                button_label="A-PVP - 2 г. 810грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="kharkiv",
        label="Харьков",
        icon="📍",
        districts=get_city_districts("Харьков"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="a_pvp_20g_5500",
                label="A-PVP - 20 г. 5500грн.",
                options=[
                    ProductOption(key="a_pvp_20g_5500", label="A-PVP - 20 г. 5500грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_30g_7700",
                label="A-PVP HQ - 30 г. 7700грн.",
                options=[
                    ProductOption(key="a_pvp_hq_30g_7700", label="A-PVP HQ - 30 г. 7700грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_0_5g_415",
                label="A-PVP - 0,5 г. 415грн.",
                options=[
                    ProductOption(key="a_pvp_0_5g_415", label="A-PVP - 0,5 г. 415грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_1g_615",
                label="A-PVP - 1 г. 615грн.",
                options=[
                    ProductOption(key="a_pvp_1g_615", label="A-PVP - 1 г. 615грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_2g_1060",
                label="A-PVP - 2 г. 1060грн.",
                options=[
                    ProductOption(key="a_pvp_2g_1060", label="A-PVP - 2 г. 1060грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_3g_1450",
                label="A-PVP - 3 г. 1450грн.",
                options=[
                    ProductOption(key="a_pvp_3g_1450", label="A-PVP - 3 г. 1450грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_5g_2000",
                label="A-PVP - 5 г. 2000грн.",
                options=[
                    ProductOption(key="a_pvp_5g_2000", label="A-PVP - 5 г. 2000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_10g_3150",
                label="A-PVP - 10 г. 3150грн.",
                options=[
                    ProductOption(key="a_pvp_10g_3150", label="A-PVP - 10 г. 3150грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_0_25g_280",
                label="A-PVP HQ - 0.25 г. 280грн.",
                options=[
                    ProductOption(key="a_pvp_hq_0_25g_280", label="A-PVP HQ - 0.25 г. 280грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="odesa",
        label="Одесса",
        icon="🌊",
        districts=[
            "🔷 7 Небо",
            "🔷 Аркадия",
            "🔷 Малиновский",
            "🔷 Черемушки",
            "🔷 Таирова",
            "🔷 Фонтан",
            "🔷 Центр",
            "🔷 Молдаванка",
            "🔷 Слободка",
            "🔷 Пересыпь",
            "🔷 Котовского",
            "🔷 Лузановка",
            "🔷 Совиньон",
            "🔷 Черноморка",
            "🔷 Радужный",
            "🔷 Жемчужный квартал",
        ],
        district_selection_percent=75,
        products=[
            ProductConfig(
                key="a_pvp_200g",
                label="A-PVP - 200 г. 26000грн.",
                options=[
                    ProductOption(key="200g_26000", label="A-PVP - 200 г. 26000грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_50g",
                label="A-PVP - 50 г. 10000грн.",
                options=[
                    ProductOption(key="50g_10000", label="A-PVP - 50 г. 10000грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_3g",
                label="A-PVP - 3 г. 1250грн.",
                options=[
                    ProductOption(key="3g_1250", label="A-PVP - 3 г. 1250грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_10g",
                label="A-PVP - 10 г. 2800грн.",
                options=[
                    ProductOption(key="10g_2800", label="A-PVP - 10 г. 2800грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_5g",
                label="A-PVP - 5 г. 1800грн.",
                options=[
                    ProductOption(key="5g_1800", label="A-PVP - 5 г. 1800грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP - 20 г. 5000грн.",
                options=[
                    ProductOption(key="20g_5000", label="A-PVP - 20 г. 5000грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="sol_hq_025g",
                label="Соль HQ 100% - 0.25 г. 270грн.",
                options=[
                    ProductOption(key="025g_270", label="Соль HQ 100% - 0.25 г. 270грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP - 30 г. 7000грн.",
                options=[
                    ProductOption(key="30g_7000", label="A-PVP - 30 г. 7000грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="shishki_10g",
                label="Шишки - 10 г. 2450грн.",
                options=[
                    ProductOption(key="10g_2450", label="Шишки - 10 г. 2450грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="sale_shish_indor_hq_5g",
                label="РАСПРОДАЖА! - Шиш Индор HQ - 5 г. 1000грн.",
                options=[
                    ProductOption(
                        key="5g_1000",
                        label="РАСПРОДАЖА! - Шиш Индор HQ - 5 г. 1000грн.",
                    ),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_05g",
                label="A-PVP - 0.5 г. 350грн.",
                options=[
                    ProductOption(key="05g_350", label="A-PVP - 0.5 г. 350грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_100g",
                label="A-PVP - 100 г. 15500грн.",
                options=[
                    ProductOption(key="100g_15500", label="A-PVP - 100 г. 15500грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_1g",
                label="A-PVP - 1 г. 550грн.",
                options=[
                    ProductOption(key="1g_550", label="A-PVP - 1 г. 550грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
            ProductConfig(
                key="a_pvp_2g",
                label="A-PVP - 2 г. 880грн.",
                options=[
                    ProductOption(key="2g_880", label="A-PVP - 2 г. 880грн."),
                ],
                photo_path="СКРИНЫ ИНТЕРФЕЙСА/Одеса.png",
            ),
        ],
    ),
    CityConfig(
        key="kostopol",
        label="Костополь",
        icon="📍",
        districts=get_city_districts("Костополь"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100%",
                options=[ProductOption(key="0_5g_315", label="0.5 г. 315грн.")],
                button_label="Соль HQ 100% - 0.5 г. 315грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета",
                options=[ProductOption(key="1g_500", label="1 г. 500грн.")],
                button_label="Соль все цвета: 1 г. 500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета",
                options=[ProductOption(key="2g_810", label="2 г. 810грн.")],
                button_label="Соль все цвета: 2 г. 810грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета",
                options=[ProductOption(key="3g_1215", label="3 г. 1215грн.")],
                button_label="Соль все цвета: 3 г. 1215грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета",
                options=[ProductOption(key="5g_1620", label="5 г. 1620грн.")],
                button_label="Соль все цвета: 5 г. 1620грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета",
                options=[ProductOption(key="10g_2565", label="10 г. 2565грн.")],
                button_label="Соль все цвета: 10 г. 2565грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP",
                options=[ProductOption(key="20g_4500", label="20 г. 4500грн.")],
                button_label="A-PVP - 20 г. 4500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP",
                options=[ProductOption(key="30g_5600", label="30 г. 5600грн.")],
                button_label="A-PVP - 30 г. 5600грн.",
                photo_path="",
            ),
            ProductConfig(
                key="sale_a_pvp_hq_025g",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_95", label="0.25 г. 95грн.")],
                button_label="РАСПРОДАЖА! - A-PVP HQ - 0.25 г. 95грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_250", label="0.25 г. 250грн.")],
                button_label="A-PVP HQ - 0.25 г. 250грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="vyshgorod",
        label="Вышгород",
        icon="📍",
        districts=get_city_districts("Вышгород"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP",
                options=[ProductOption(key="30g_7000", label="30 г. 7000грн.")],
                button_label="A-PVP - 30 г. 7000грн.",
                photo_path="",
            ),
            ProductConfig(
                key="sale_shish_1g",
                label="Шиш",
                options=[ProductOption(key="1g_240", label="1 грамм 240грн.")],
                button_label="РАСПРОДАЖА! - Шиш - 1 грамм 240грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100%",
                options=[ProductOption(key="0_5g_350", label="0.5 г. 350грн.")],
                button_label="Соль HQ 100% - 0.5 г. 350грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета",
                options=[ProductOption(key="1g_555", label="1 г. 555грн.")],
                button_label="Соль все цвета: 1 г. 555грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета",
                options=[ProductOption(key="2g_900", label="2 г. 900грн.")],
                button_label="Соль все цвета: 2 г. 900грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета",
                options=[ProductOption(key="3g_1250", label="3 г. 1250грн.")],
                button_label="Соль все цвета: 3 г. 1250грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета",
                options=[ProductOption(key="5g_1800", label="5 г. 1800грн.")],
                button_label="Соль все цвета: 5 г. 1800грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета",
                options=[ProductOption(key="10g_2850", label="10 г. 2850грн.")],
                button_label="Соль все цвета: 10 г. 2850грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP",
                options=[ProductOption(key="20g_5000", label="20 г. 5000грн.")],
                button_label="A-PVP - 20 г. 5000грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="kamenskoe",
        label="Каменское (Днепр обл)",
        icon="📍",
        districts=get_city_districts("Каменское (Днепр обл)"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 280грн.",
                options=[
                    ProductOption(key="0_5g_280", label="Соль HQ 100% - 0.5 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 444грн.",
                options=[
                    ProductOption(key="1g_444", label="Соль все цвета: 1 г. 444грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета: 2 г. 720грн.",
                options=[
                    ProductOption(key="2g_720", label="Соль все цвета: 2 г. 720грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета: 3 г. 1000грн.",
                options=[
                    ProductOption(key="3g_1000", label="Соль все цвета: 3 г. 1000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_1g",
                label="Шишки Индор HQ: 1 грамм 304грн.",
                options=[
                    ProductOption(key="1g_304", label="Шишки Индор HQ: 1 грамм 304грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_2g",
                label="Шишки Индор HQ: 2 г. 504грн.",
                options=[
                    ProductOption(key="2g_504", label="Шишки Индор HQ: 2 г. 504грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_3g",
                label="Шишки Индор HQ: 3 г. 684грн.",
                options=[
                    ProductOption(key="3g_684", label="Шишки Индор HQ: 3 г. 684грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_5g",
                label="Шишки Индор HQ: 5 г. 1224грн.",
                options=[
                    ProductOption(key="5g_1224", label="Шишки Индор HQ: 5 г. 1224грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_10g",
                label="Шишки Индор HQ: 10 г. 2015грн.",
                options=[
                    ProductOption(key="10g_2015", label="Шишки Индор HQ: 10 г. 2015грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ - 0.25 г. 224грн.",
                options=[
                    ProductOption(key="0_25g_224", label="A-PVP HQ - 0.25 г. 224грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="boyarka",
        label="Боярка",
        icon="📍",
        districts=list(BOYARKA_DISTRICTS),
        district_selection_percent=100,
        products=list(BOYARKA_PRODUCTS),
    ),
    CityConfig(
        key="novaya_odessa",
        label="Новая Одесса",
        icon="📍",
        districts=get_city_districts("Новая Одесса"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP - 20 г. 5000грн.",
                options=[
                    ProductOption(key="20g_5000", label="A-PVP - 20 г. 5000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_2g",
                label="Шишки Индор HQ: 2 г. 630грн.",
                options=[
                    ProductOption(key="2g_630", label="Шишки Индор HQ: 2 г. 630грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_3g",
                label="Шишки Индор HQ: 3 г. 855грн.",
                options=[
                    ProductOption(key="3g_855", label="Шишки Индор HQ: 3 г. 855грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_5g",
                label="Шишки Индор HQ: 5 г. 1530грн.",
                options=[
                    ProductOption(key="5g_1530", label="Шишки Индор HQ: 5 г. 1530грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP - 30 г. 7000грн.",
                options=[
                    ProductOption(key="30g_7000", label="A-PVP - 30 г. 7000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ - 0.25 г. 280грн.",
                options=[
                    ProductOption(key="0_25g_280", label="A-PVP HQ - 0.25 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 365грн.",
                options=[
                    ProductOption(key="0_5g_365", label="Соль HQ 100% - 0.5 г. 365грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 575грн.",
                options=[
                    ProductOption(key="1g_575", label="Соль все цвета: 1 г. 575грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета: 5 г. 1860грн.",
                options=[
                    ProductOption(key="5g_1860", label="Соль все цвета: 5 г. 1860грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета: 10 г. 2860грн.",
                options=[
                    ProductOption(key="10g_2860", label="Соль все цвета: 10 г. 2860грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="bashtanka_niko_obl",
        label="Баштанка (Нико обл.)",
        icon="📍",
        districts=get_city_districts("Баштанка (Нико обл.)"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ - 0.25 г. 280грн.",
                options=[
                    ProductOption(key="0_25g_280", label="A-PVP HQ - 0.25 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 350грн.",
                options=[
                    ProductOption(key="0_5g_350", label="Соль HQ 100% - 0.5 г. 350грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="korostyshev",
        label="Коростышев",
        icon="📍",
        districts=get_city_districts("Коростышев"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="salt_hq_100_025g",
                label="Соль HQ 100% - 0.25 г. 225грн.",
                options=[
                    ProductOption(key="0_25g_225", label="Соль HQ 100% - 0.25 г. 225грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 445грн.",
                options=[
                    ProductOption(key="1g_445", label="Соль все цвета: 1 г. 445грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета: 2 г. 720грн.",
                options=[
                    ProductOption(key="2g_720", label="Соль все цвета: 2 г. 720грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета: 3 г. 1000грн.",
                options=[
                    ProductOption(key="3g_1000", label="Соль все цвета: 3 г. 1000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета: 5 г. 1440грн.",
                options=[
                    ProductOption(key="5g_1440", label="Соль все цвета: 5 г. 1440грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета: 10 г. 2280грн.",
                options=[
                    ProductOption(key="10g_2280", label="Соль все цвета: 10 г. 2280грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="vinnitsa",
        label="Винница",
        icon="📍",
        districts=get_city_districts("Винница"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="shishki_indor_hq_2g",
                label="Шишки Индор HQ: 2 г. 630грн.",
                options=[
                    ProductOption(key="2g_630", label="Шишки Индор HQ: 2 г. 630грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_3g",
                label="Шишки Индор HQ: 3 г. 855грн.",
                options=[
                    ProductOption(key="3g_855", label="Шишки Индор HQ: 3 г. 855грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ - 0.25 г. 280грн.",
                options=[
                    ProductOption(key="0_25g_280", label="A-PVP HQ - 0.25 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_5g",
                label="Шишки Индор HQ: 5 г. 1530грн.",
                options=[
                    ProductOption(key="5g_1530", label="Шишки Индор HQ: 5 г. 1530грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 350грн.",
                options=[
                    ProductOption(key="0_5g_350", label="Соль HQ 100% - 0.5 г. 350грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_10g",
                label="Шишки Индор HQ: 10 г. 2520грн.",
                options=[
                    ProductOption(key="10g_2520", label="Шишки Индор HQ: 10 г. 2520грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 555грн.",
                options=[
                    ProductOption(key="1g_555", label="Соль все цвета: 1 г. 555грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP - 30 г. 7000грн.",
                options=[
                    ProductOption(key="30g_7000", label="A-PVP - 30 г. 7000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета: 2 г. 900грн.",
                options=[
                    ProductOption(key="2g_900", label="Соль все цвета: 2 г. 900грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="mefedron_hq_05g",
                label="Мефедрон HQ - 0.5 390грн.",
                options=[
                    ProductOption(key="0_5g_390", label="Мефедрон HQ - 0.5 390грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета: 3 г. 1250грн.",
                options=[
                    ProductOption(key="3g_1250", label="Соль все цвета: 3 г. 1250грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="mefedron_hq_1g",
                label="Мефедрон HQ - 1 г. 600грн.",
                options=[
                    ProductOption(key="1g_600", label="Мефедрон HQ - 1 г. 600грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета: 5 г. 1800грн.",
                options=[
                    ProductOption(key="5g_1800", label="Соль все цвета: 5 г. 1800грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета: 10 г. 2850грн.",
                options=[
                    ProductOption(key="10g_2850", label="Соль все цвета: 10 г. 2850грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP - 20 г. 5000грн.",
                options=[
                    ProductOption(key="20g_5000", label="A-PVP - 20 г. 5000грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_1g",
                label="Шишки Индор HQ: 1 грамм 380грн.",
                options=[
                    ProductOption(key="1g_380", label="Шишки Индор HQ: 1 грамм 380грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="belaya_tserkov",
        label="Белая церковь",
        icon="📍",
        districts=get_city_districts("Белая церковь"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="shishki_indor_hq_1g",
                label="Шишки Индор HQ: 1 грамм 380грн.",
                options=[
                    ProductOption(key="1g_380", label="Шишки Индор HQ: 1 грамм 380грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="shishki_indor_hq_2g",
                label="Шишки Индор HQ: 2 г. 630грн.",
                options=[
                    ProductOption(key="2g_630", label="Шишки Индор HQ: 2 г. 630грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_025g",
                label="Соль HQ 100% - 0.25 г. 280грн.",
                options=[
                    ProductOption(key="0_25g_280", label="Соль HQ 100% - 0.25 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 350грн.",
                options=[
                    ProductOption(key="0_5g_350", label="Соль HQ 100% - 0.5 г. 350грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 555грн.",
                options=[
                    ProductOption(key="1g_555", label="Соль все цвета: 1 г. 555грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета: 2 г. 900грн.",
                options=[
                    ProductOption(key="2g_900", label="Соль все цвета: 2 г. 900грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета: 3 г. 1250грн.",
                options=[
                    ProductOption(key="3g_1250", label="Соль все цвета: 3 г. 1250грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="chernigov",
        label="Чернигов",
        icon="📍",
        districts=get_city_districts("Чернигов"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета",
                options=[ProductOption(key="2g_980", label="2 г. 980грн.")],
                button_label="Соль все цвета: 2 г. 980грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета",
                options=[ProductOption(key="3g_1300", label="3 г. 1300грн.")],
                button_label="Соль все цвета: 3 г. 1300грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета",
                options=[ProductOption(key="5g_1860", label="5 г. 1860грн.")],
                button_label="Соль все цвета: 5 г. 1860грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_20g",
                label="A-PVP",
                options=[ProductOption(key="20g_5000", label="20 г. 5000грн.")],
                button_label="A-PVP - 20 г. 5000грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_30g",
                label="A-PVP",
                options=[ProductOption(key="30g_7000", label="30 г. 7000грн.")],
                button_label="A-PVP - 30 г. 7000грн.",
                photo_path="",
            ),
            ProductConfig(
                key="sale_a_pvp_hq_025g",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_120", label="0.25 г. 120грн.")],
                button_label="РАСПРОДАЖА! - A-PVP HQ - 0.25 г. 120грн.",
                photo_path="",
            ),
            ProductConfig(
                key="mix_1g",
                label="Микс",
                options=[ProductOption(key="1g_300", label="1 г. 300грн.")],
                button_label="Микс - 1 г. 300грн.",
                photo_path="",
            ),
            ProductConfig(
                key="mix_2g",
                label="Микс",
                options=[ProductOption(key="2g_500", label="2 г. 500грн.")],
                button_label="Микс - 2 г. 500грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_280", label="0.25 г. 280грн.")],
                button_label="A-PVP HQ - 0.25 г. 280грн.",
                photo_path="",
            ),
            ProductConfig(
                key="mix_3g",
                label="Микс",
                options=[ProductOption(key="3g_660", label="3 г. 660грн.")],
                button_label="Микс - 3 г. 660грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100%",
                options=[ProductOption(key="0_5g_365", label="0.5 г. 365грн.")],
                button_label="Соль HQ 100% - 0.5 г. 365грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета",
                options=[ProductOption(key="1g_575", label="1 г. 575грн.")],
                button_label="Соль все цвета: 1 г. 575грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="vasilkov",
        label="Васильков",
        icon="📍",
        districts=get_city_districts("Васильков"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="sale_a_pvp_hq_2g",
                label="A-PVP HQ",
                options=[ProductOption(key="2g_650", label="2 г. 650грн.")],
                button_label="РАСПРОДАЖА! - A-PVP HQ - 2 г. 650грн.",
                photo_path="",
            ),
            ProductConfig(
                key="sale_a_pvp_hq_1g",
                label="A-PVP HQ",
                options=[ProductOption(key="1g_350", label="1 г. 350грн.")],
                button_label="РАСПРОДАЖА! - A-PVP HQ - 1 г. 350грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="fastov",
        label="Фастов",
        icon="📍",
        districts=get_city_districts("Фастов"),
        products=[
            ProductConfig(
                key="broken_buds_1g",
                label="Битые шишки - 1 г 300грн.",
                options=[
                    ProductOption(key="1g_300", label="Битые шишки - 1 г 300грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="indoor_hq_2g",
                label="Шишки Индор HQ: 2 г. 630грн.",
                options=[
                    ProductOption(key="2g_630", label="Шишки Индор HQ: 2 г. 630грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="broken_buds_2g",
                label="Битые шишки - 2г 450грн.",
                options=[
                    ProductOption(key="2g_450", label="Битые шишки - 2г 450грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_apvp_hq_05g",
                label="РАСПРОДАЖА! - A-PVP HQ - 0.5 г. 180грн.",
                options=[
                    ProductOption(key="05g_180", label="РАСПРОДАЖА! - A-PVP HQ - 0.5 г. 180грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_apvp_hq_1g",
                label="РАСПРОДАЖА! - A-PVP HQ - 1 г. 280грн.",
                options=[
                    ProductOption(key="1g_280", label="РАСПРОДАЖА! - A-PVP HQ - 1 г. 280грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_mefedron_hq_1g",
                label="РАСПРОДАЖА! - Мефедрон HQ - 1 г. 300грн.",
                options=[
                    ProductOption(key="1g_300", label="РАСПРОДАЖА! - Мефедрон HQ - 1 г. 300грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100% - 0.5 г. 315грн.",
                options=[
                    ProductOption(key="05g_315", label="Соль HQ 100% - 0.5 г. 315грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_apvp_hq_2g",
                label="РАСПРОДАЖА! - A-PVP HQ - 2 г. 450грн.",
                options=[
                    ProductOption(key="2g_450", label="РАСПРОДАЖА! - A-PVP HQ - 2 г. 450грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета: 1 г. 500грн.",
                options=[
                    ProductOption(key="1g_500", label="Соль все цвета: 1 г. 500грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_apvp_hq_3g",
                label="РАСПРОДАЖА! - A-PVP HQ - 3 г. 650грн.",
                options=[
                    ProductOption(key="3g_650", label="РАСПРОДАЖА! - A-PVP HQ - 3 г. 650грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета: 2 г. 810грн.",
                options=[
                    ProductOption(key="2g_810", label="Соль все цвета: 2 г. 810грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="sale_apvp_hq_5g",
                label="РАСПРОДАЖА! - A-PVP HQ - 5 г. 900грн.",
                options=[
                    ProductOption(key="5g_900", label="РАСПРОДАЖА! - A-PVP HQ - 5 г. 900грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета: 3 г. 1125грн.",
                options=[
                    ProductOption(key="3g_1125", label="Соль все цвета: 3 г. 1125грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="apvp_20g",
                label="A-PVP - 20 г. 4500грн.",
                options=[
                    ProductOption(key="20g_4500", label="A-PVP - 20 г. 4500грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета: 5 г. 1620грн.",
                options=[
                    ProductOption(key="5g_1620", label="Соль все цвета: 5 г. 1620грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="apvp_30g",
                label="A-PVP - 30 г. 6300грн.",
                options=[
                    ProductOption(key="30g_6300", label="A-PVP - 30 г. 6300грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета: 10 г. 2565грн.",
                options=[
                    ProductOption(key="10g_2565", label="Соль все цвета: 10 г. 2565грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="broken_buds_3g",
                label="Битые шишки - 3 г 600грн.",
                options=[
                    ProductOption(key="3g_600", label="Битые шишки - 3 г 600грн."),
                ],
                photo_path="",
            ),
            ProductConfig(
                key="indoor_hq_1g",
                label="Шишки Индор HQ: 1 грамм 380грн.",
                options=[
                    ProductOption(key="1g_380", label="Шишки Индор HQ: 1 грамм 380грн."),
                ],
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="brovary",
        label="Бровары",
        icon="📍",
        districts=list(BROVARY_DISTRICTS),
        district_selection_percent=100,
        products=list(BROVARY_PRODUCTS),
    ),
    CityConfig(
        key="kropyvnytskyi",
        label="Кропивницкий",
        icon="📍",
        districts=get_city_districts("Кропивницкий"),
        district_selection_percent=100,
        products=[
            ProductConfig(
                key="salt_all_colors_3g",
                label="Соль все цвета",
                options=[ProductOption(key="3g_1250", label="3 г. 1250грн.")],
                button_label="Соль все цвета: 3 г. 1250грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_5g",
                label="Соль все цвета",
                options=[ProductOption(key="5g_1800", label="5 г. 1800грн.")],
                button_label="Соль все цвета: 5 г. 1800грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_10g",
                label="Соль все цвета",
                options=[ProductOption(key="10g_2850", label="10 г. 2850грн.")],
                button_label="Соль все цвета: 10 г. 2850грн.",
                photo_path="",
            ),
            ProductConfig(
                key="a_pvp_hq_025g",
                label="A-PVP HQ",
                options=[ProductOption(key="0_25g_280", label="0.25 г. 280грн.")],
                button_label="A-PVP HQ - 0.25 г. 280грн.",
                photo_path="",
            ),
            ProductConfig(
                key="mix_1g",
                label="Микс",
                options=[ProductOption(key="1g_300", label="1 г. 300грн.")],
                button_label="Микс - 1 г. 300грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_hq_100_05g",
                label="Соль HQ 100%",
                options=[ProductOption(key="0_5g_350", label="0.5 г. 350грн.")],
                button_label="Соль HQ 100% - 0.5 г. 350грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_1g",
                label="Соль все цвета",
                options=[ProductOption(key="1g_555", label="1 г. 555грн.")],
                button_label="Соль все цвета: 1 г. 555грн.",
                photo_path="",
            ),
            ProductConfig(
                key="salt_all_colors_2g",
                label="Соль все цвета",
                options=[ProductOption(key="2g_900", label="2 г. 900грн.")],
                button_label="Соль все цвета: 2 г. 900грн.",
                photo_path="",
            ),
        ],
    ),
    CityConfig(
        key="city_24",
        label="Немиров",
        icon="📍",
        districts=get_city_districts("Немиров"),
        district_selection_percent=100,
        products=[product.model_copy(deep=True) for product in NEMIROV_PRODUCTS],
    ),
    CityConfig(
        key="city_27",
        label="ГНИВАНЬ",
        icon="📍",
        districts=get_city_districts("ГНИВАНЬ"),
        district_selection_percent=100,
        products=[product.model_copy(deep=True) for product in GNIVAN_PRODUCTS],
    ),
    CityConfig(
        key="city_28",
        label="Казатин",
        icon="📍",
        districts=get_city_districts("Казатин"),
        district_selection_percent=100,
        products=[product.model_copy(deep=True) for product in KAZATIN_PRODUCTS],
    ),
    CityConfig(
        key="lviv",
        label="Львов",
        icon="📍",
        districts=get_city_districts("Львов"),
        district_selection_percent=100,
        products=[product.model_copy(deep=True) for product in LVIV_PRODUCTS],
    ),
]

RULES_TEXT = """/start - вернуться к выбору города
-------------------------------
Помощь: @kfc_support
📭 Админ: почта, горячие, опт
💎 Саппорт: покупки в боте, ненаходы
-------------------------------
Правила&Советы от команды KFC ❤️

Как правильно искать клад

1. Подойдя к месту заклада, выбери ракурс обзора места, как на фото курьера
2. Выбирай видимые ориентиры, на фото адреса и найди их на местности.
3. Сделайте соотношение пропорции расстояния от ориентира на местности, до отметки клада на фото.
4. Рекомендуем искать только в светлое время суток и без спешки!
Только после этих трёх пунктов - начинайте поиски.

💎 Условия выдачи перезаклада

⚠️ Возврат денег по оплаченным покупкам не предусмотрен!
✅ Гарантия доверия - 5 УСПЕШНЫХ покупок!
✅ Заявка подана не позже 8 часов с момента покупки
✅ Вы искали точно по метке

Отправьте саппорту: @kfc_support

- описание проблемы
- заказ с бота или сайта
- видео запись процесса съёма клада
- фото места до и после поиска с того же ракурса, что и фото курьера
- Ожидайте ответа оператора без флуда и мата

⛔️ причины отказа в рассмотрении заявки

🔻 Мат, негатив о шопе или его сотрудниках
🔻 Настойчивый флуд в ЛС оператору
🔻 Дача заведомо ложной информации (пример - постановочное видео)
🔻 Отсутствие фото/видео поиска
🔻 Частые ненаходы с 1 акка

Перезаклад не даётся на:

🔻 1-3 покупку (4-5 на усмотрение оператора)
🔻 Заявки позже 8 часов с момента покупки
🔻 Свежий клад (менее 24 часа)
🔻 Перезаклад
🔻 бонус, приз, пробу
🔻 более 1 ненахода подряд"""

INSTRUCTIONS_TEXT = """1. Выберите город.
2. Откройте нужный товар.
3. Выберите количество.
4. Выберите район.
5. Подтвердите заказ и переходите к оплате."""

PAYMENT_TEXT = """Выберите способ оплаты:"""

PURCHASE_STUB_TEXT = """После подтверждения заказа бот покажет карточку товара и переведет к оплате."""

PROMO_APPLIED_TEXT = """Промокод сохранен в шаблоне.

Проверка и начисление скидки пока не подключены."""


DEFAULT_PAYMENT_METHODS = [
    PaymentMethodConfig(
        key="card_sbp",
        label="Карта СПБ",
        requisites=LEGACY_CARD_REQUISITES_PLACEHOLDER,
        details_text=f"Реквизиты для оплаты (Карта / СБП):\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=False,
    ),
    PaymentMethodConfig(
        key="btc",
        label="BTC",
        requisites="BTC_WALLET_HERE",
        details_text=f"Реквизиты для оплаты в BTC:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
    PaymentMethodConfig(
        key="ltc",
        label="LTC",
        requisites=LEGACY_LTC_REQUISITES_PLACEHOLDER,
        details_text=f"Реквизиты для оплаты в LTC:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
    PaymentMethodConfig(
        key="usdt_trc20",
        label="USDT TRC20",
        requisites=LEGACY_USDT_TRC20_REQUISITES_PLACEHOLDER,
        details_text=f"Реквизиты для оплаты в USDT TRC20:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
    PaymentMethodConfig(
        key="usdt_bep20",
        label="USDT BEP20",
        requisites="USDT_BEP20_WALLET_HERE",
        details_text=f"Реквизиты для оплаты в USDT BEP20:\n{PAYMENT_REQUISITES_PLACEHOLDER}\n\nПосле оплаты нажмите кнопку «Я оплатил».",
        qr_enabled=True,
    ),
]


def normalize_template(template: object | None) -> TemplateOverrides:
    if template is None:
        return TemplateOverrides()
    if isinstance(template, BaseModel):
        payload = template.model_dump(mode="python")
    elif isinstance(template, dict):
        payload = dict(template)
    else:
        payload = {}
    return TemplateOverrides.model_validate(payload)


def normalize_city_label(raw_label: str) -> str:
    return " ".join(raw_label.split()).strip()


def city_label_marker(raw_label: str) -> str:
    marker = normalize_city_label(raw_label)
    return marker.casefold()


def unique_city_labels(labels: list[str]) -> list[str]:
    unique_labels: list[str] = []
    seen: set[str] = set()
    for raw_label in labels:
        label = normalize_city_label(raw_label)
        marker = city_label_marker(label)
        if not label or marker in seen:
            continue
        seen.add(marker)
        unique_labels.append(label)
    return unique_labels


def extract_city_labels(start_text: str) -> list[str]:
    labels: list[str] = []
    seen: set[str] = set()
    for raw_line in start_text.splitlines():
        line = raw_line.strip()
        if not line.startswith("✅"):
            continue
        label = line.removeprefix("✅").strip()
        if not label or label.casefold().startswith("и другие города"):
            continue
        normalized_label = normalize_city_label(label)
        marker = city_label_marker(normalized_label)
        if marker in seen:
            continue
        seen.add(marker)
        labels.append(normalized_label)
    return labels


def build_screenshot_city_labels() -> list[str]:
    return unique_city_labels(DEFAULT_SCREENSHOT_CITY_ORDER)


def clone_products(products: list[ProductConfig]) -> list[ProductConfig]:
    return [product.model_copy(deep=True) for product in products]


def clone_cities(cities: list[CityConfig]) -> list[CityConfig]:
    return [city.model_copy(deep=True) for city in cities]


def dedupe_cities_by_label(cities: list[CityConfig]) -> list[CityConfig]:
    deduped: list[CityConfig] = []
    city_indexes: dict[str, int] = {}
    for city in cities:
        marker = city_label_marker(city.label)
        existing_index = city_indexes.get(marker)
        if existing_index is None:
            city_indexes[marker] = len(deduped)
            deduped.append(city.model_copy(deep=True))
            continue

        merged_city = deduped[existing_index]
        if has_placeholder_districts(merged_city.districts) and not has_placeholder_districts(city.districts):
            merged_city.districts = list(city.districts)
        if len(city.products) > len(merged_city.products):
            merged_city.products = clone_products(city.products)
        deduped[existing_index] = merged_city
    return deduped


def has_placeholder_districts(districts: list[str]) -> bool:
    normalized = [district.strip().casefold() for district in districts if district.strip()]
    if not normalized:
        return True
    placeholder_markers = {
        "заполните районы этого города",
        "заполните районы",
    }
    return all(marker in placeholder_markers for marker in normalized)


def build_start_screen_cities() -> list[CityConfig]:
    city_labels = build_screenshot_city_labels()
    if not city_labels:
        city_labels = extract_city_labels(DEFAULT_START_TEXT)
    if not city_labels:
        return []

    cities: list[CityConfig] = []

    for index, city_label in enumerate(city_labels, start=1):
        cities.append(
            CityConfig(
                key=f"city_{index}",
                label=city_label,
                icon="📍",
                districts=get_city_districts(city_label),
                district_selection_percent=100,
                products=[],
            )
        )
    return cities


def sync_catalog_cities(
    existing_cities: list[CityConfig],
    fallback_cities: list[CityConfig],
) -> list[CityConfig]:
    existing_by_key = {city.key: city for city in existing_cities}
    existing_by_label = {city_label_marker(city.label): city for city in existing_cities}
    merged: list[CityConfig] = []
    used_keys: set[str] = set()
    used_labels: set[str] = set()

    for fallback_city in fallback_cities:
        current_city = existing_by_key.get(fallback_city.key)
        if current_city is None:
            current_city = existing_by_label.get(city_label_marker(fallback_city.label))
        if current_city is None:
            merged.append(fallback_city.model_copy(deep=True))
            used_keys.add(fallback_city.key)
            continue

        merged_city = current_city.model_copy(deep=True)
        merged_city.key = fallback_city.key
        merged_city.label = fallback_city.label
        if has_placeholder_districts(merged_city.districts):
            merged_city.districts = list(fallback_city.districts)
        merged.append(merged_city)
        used_keys.add(merged_city.key)
        used_labels.add(city_label_marker(merged_city.label))

    for city in existing_cities:
        if city.key in used_keys or city_label_marker(city.label) in used_labels:
            continue
        merged.append(city.model_copy(deep=True))
    return merged


def cities_payload(cities: list[CityConfig]) -> list[dict[str, object]]:
    return [city.model_dump(mode="json") for city in cities]


def build_visible_start_cities(cities: list[CityConfig]) -> list[CityConfig]:
    ordered_labels = build_screenshot_city_labels()
    if not ordered_labels:
        ordered_labels = extract_city_labels(DEFAULT_START_TEXT)
    if not ordered_labels:
        return clone_cities(cities)

    cities_by_marker = {city_label_marker(city.label): city for city in cities}
    visible_cities: list[CityConfig] = []
    for label in ordered_labels:
        city = cities_by_marker.get(city_label_marker(label))
        if city is None:
            continue
        start_city = city.model_copy(deep=True)
        start_city.label = label
        visible_cities.append(start_city)
    return visible_cities or clone_cities(cities)


def save_catalog_cities(path: Path, cities: list[CityConfig]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = [city.model_dump(mode="json") for city in cities]
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_catalog_cities(path: Path, fallback_cities: list[CityConfig] | None = None) -> list[CityConfig]:
    fallback = clone_cities(fallback_cities or build_start_screen_cities())
    if not path.exists():
        save_catalog_cities(path, fallback)
        return fallback
    try:
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read catalog from {path}") from exc
    if not isinstance(raw_data, list):
        raise RuntimeError(f"Catalog file {path} must contain a list of cities.")
    try:
        existing_cities = [CityConfig.model_validate(item) for item in raw_data]
    except ValidationError as exc:
        raise RuntimeError(f"Invalid catalog data in {path}") from exc
    existing_cities = dedupe_cities_by_label(existing_cities)
    synced_cities = sync_catalog_cities(existing_cities, fallback)
    if cities_payload(synced_cities) != cities_payload(existing_cities):
        save_catalog_cities(path, synced_cities)
    return synced_cities


def parse_admin_ids(raw_value: str | None) -> list[int]:
    if not raw_value:
        return []
    admin_ids: list[int] = []
    for chunk in raw_value.split(","):
        value = chunk.strip()
        if not value:
            continue
        admin_ids.append(int(value))
    return admin_ids


def load_product_photo_rules(path: Path) -> list[ProductPhotoRule]:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[]\n", encoding="utf-8")
        return []
    try:
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read product photo rules from {path}") from exc
    if not isinstance(raw_data, list):
        raise RuntimeError(f"Product photo rules file {path} must contain a list.")
    try:
        return [ProductPhotoRule.model_validate(item) for item in raw_data]
    except ValidationError as exc:
        raise RuntimeError(f"Invalid product photo rules data in {path}") from exc


def apply_product_rules_to_cities(
    cities: list[CityConfig],
    rules: list[ProductPhotoRule],
) -> list[CityConfig]:
    if not rules:
        return cities
    updated_cities: list[CityConfig] = []
    for city in cities:
        updated_city = city.model_copy(deep=True)
        for product in updated_city.products:
            marker = product.label.casefold()
            for rule in rules:
                pattern = rule.name_contains.strip().casefold()
                if not pattern or pattern not in marker:
                    continue
                if not (product.description or "").strip() and (rule.description or "").strip():
                    product.description = rule.description
                if not (product.photo_url or "").strip() and not (product.photo_path or "").strip():
                    product.photo_url = str(rule.photo_url)
                break
        updated_cities.append(updated_city)
    return updated_cities


def resolve_path(raw_value: str | None, default_path: Path) -> Path:
    if not raw_value:
        return default_path
    path = Path(raw_value).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    load_dotenv(DOTENV_PATH)
    catalog_path = resolve_path(os.getenv("CATALOG_DATA_PATH"), DEFAULT_CATALOG_PATH)
    product_photo_rules_path = resolve_path(
        os.getenv("PRODUCT_PHOTO_RULES_PATH"),
        DEFAULT_PRODUCT_PHOTO_RULES_PATH,
    )
    product_photo_rules = load_product_photo_rules(product_photo_rules_path)
    cities = load_catalog_cities(catalog_path, build_start_screen_cities())
    cities = apply_product_rules_to_cities(cities, product_photo_rules)
    return Settings(
        api_host=os.getenv("API_HOST", "127.0.0.1"),
        api_port=int(os.getenv("API_PORT", "18746")),
        master_api_key=os.getenv("MASTER_API_KEY", "change-me"),
        data_path=resolve_path(os.getenv("BOTS_DATA_PATH"), DEFAULT_DATA_PATH),
        catalog_path=catalog_path,
        product_photo_rules_path=product_photo_rules_path,
        default_admin_ids=parse_admin_ids(os.getenv("DEFAULT_ADMIN_IDS")),
        default_product_photo=resolve_path(os.getenv("DEFAULT_PRODUCT_PHOTO"), DEFAULT_PRODUCT_PHOTO),
        random_product_photo_dir=resolve_path(
            os.getenv("RANDOM_PRODUCT_PHOTO_DIR"),
            DEFAULT_RANDOM_PRODUCT_PHOTO_DIR,
        ),
        product_photo_rules=product_photo_rules,
        default_payment_methods=[method.model_copy(deep=True) for method in DEFAULT_PAYMENT_METHODS],
        cities=cities,
        rules_text=RULES_TEXT,
        instructions_text=INSTRUCTIONS_TEXT,
        payment_text=PAYMENT_TEXT,
        purchase_stub_text=PURCHASE_STUB_TEXT,
        promo_applied_text=PROMO_APPLIED_TEXT,
        ai_enabled=os.getenv("AI_ENABLED", "1").strip().casefold() not in {"0", "false", "no", "off"},
        ai_api_key=os.getenv("AI_API_KEY", "sk-clb-72KgKtjTYTTwpCvNscBGz8O_doGAQhaesVIMOMJe-J0"),
        ai_base_endpoint=os.getenv("AI_BASE_ENDPOINT", "https://codex.sale/v1"),
        ai_models_endpoint=os.getenv("AI_MODELS_ENDPOINT", "https://codex.sale/v1/models"),
        ai_chat_endpoint=os.getenv("AI_CHAT_ENDPOINT", "https://codex.sale/v1/chat/completions"),
        ai_model=os.getenv("AI_MODEL", "gpt-5.4-mini"),
    )
