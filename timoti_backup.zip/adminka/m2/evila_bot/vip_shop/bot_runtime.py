from __future__ import annotations

from dataclasses import dataclass

import asyncio

import json
import logging
import random
from decimal import Decimal
import qrcode
import io
import string
from html import escape
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
)
from aiogram.types import FSInputFile

from vip_shop.config import Settings, get_settings, load_family_state, FamilyState, TemplateOverrides
from vip_shop.crypto_rates import convert_pln_to_crypto, refresh_pln_rate, refresh_market_rates
from vip_shop.captcha import generate_captcha_image, generate_captcha_text

logger = logging.getLogger(__name__)

router = Router()


class CaptchaState(StatesGroup):
    waiting = State()


_CAPTCHA_FILE: Path | None = None


def _get_captcha_path() -> Path:
    global _CAPTCHA_FILE
    if _CAPTCHA_FILE is None:
        settings = get_settings()
        _CAPTCHA_FILE = settings.data_path.with_name("evila_captcha.json")
    return _CAPTCHA_FILE


def _load_captcha_data() -> dict:
    path = _get_captcha_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_captcha_data(data: dict) -> None:
    path = _get_captcha_path()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _is_captcha_passed(user_id: int) -> bool:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return bool(user.get("passed"))


def _set_captcha_passed(user_id: int) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = True
    data[str(user_id)]["captcha_text"] = None
    _save_captcha_data(data)


def _set_captcha_challenge(user_id: int, text: str) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = False
    data[str(user_id)]["captcha_text"] = text
    _save_captcha_data(data)


def _get_captcha_text(user_id: int) -> str | None:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return user.get("captcha_text")

_template_cache: FamilyState | None = None


def _get_template() -> TemplateOverrides:
    """Load template from bots.json (with simple caching)."""
    global _template_cache
    settings = get_settings()
    state = load_family_state(settings.data_path)
    return state.template


def _main_menu_markup() -> InlineKeyboardMarkup:
    tpl = _get_template()
    support_url = str(tpl.operator_url) if tpl.operator_url else f"https://t.me/{tpl.operator_username}"
    chat_url = str(tpl.chat_url) if tpl.chat_url else "https://t.me/+j5ZmqUwuH1VkMGM0"
    operator_url = f"https://t.me/{tpl.operator_username}" if tpl.operator_username else "https://t.me/Evil_Co_operator"
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🗺 Выбрать город", callback_data="MAIN_MENU_REQUEST_CALLBACK"),
            InlineKeyboardButton(text="🖥️ Пополнить счет", callback_data="MAIN_MENU_LK_CALLBACK"),
        ],
        [InlineKeyboardButton(text="🎁Бонусы", callback_data="MAIN_MENU_BONUS_CALLBACK")],
        [
            InlineKeyboardButton(text="📃 Правила", callback_data="MAIN_MENU_RULES_CALLBACK"),
            InlineKeyboardButton(text="🧾 Поддержка", url=support_url),
        ],
        [
            InlineKeyboardButton(text="🛒 ВИТРИНА", callback_data="MAIN_MENU_NEWLIST_CALLBACK"),
            InlineKeyboardButton(text="ℹ️ Информация", callback_data="MAIN_MENU_INFO_CALLBACK"),
        ],
        [InlineKeyboardButton(text="EVIL CHAT GEORGIA", url=chat_url)],
        [InlineKeyboardButton(text="EVIL SUPPORT", url=operator_url)],
        [InlineKeyboardButton(text="⭐ Отзывы", callback_data="MAIN_REVIEWS_CALLBACK")],
        [InlineKeyboardButton(text="🤖 Подключить своего бота", callback_data="CREATE_PRIVATE_BOT_CALLBACK")],
        [InlineKeyboardButton(text="🔑 Код для сайта", callback_data="MAIN_MENU_WEB_AUTH_CODE")],
    ])


def _main_menu_text(user_id: int = 0, bot_username: str = "Evila_devila_bot") -> str:
    return (
        "🎉 Добро пожаловать в наш магазин! 🛍️\n\n"
        "🌟 Здесь вы найдете широкий ассортимент товаров для всех случаев жизни! "
        "Чтобы начать покупки, необходимо сначала пополнить ваш счет. "
        "После пополнения вы сможете использовать баланс для покупки любого товара, "
        "который будет выдан вам автоматически. 🎁\n\n"
        "💳 Пополнение счета простое и безопасное. Все транзакции проходят в защищенном режиме, "
        "чтобы вы могли чувствовать себя уверенно и комфортно.\n\n"
        "🤔 Если у вас возникнут вопросы, не стесняйтесь обращаться к нашим операторам. "
        "Мы здесь, чтобы помочь вам! 🙋‍♂️🙋\n\n"
        "🚀 Готовы начать? Приступим к покупкам и наслаждайтесь удобством и разнообразием нашего ассортимента!\n\n"
        "💬 Ждем ваших заказов и желаем приятных покупок! 🎉\n\n\n"
        "Рейтинг магазина: ⭐ 3.9/5 (64 шт.)\n\n"
        "Твой баланс: 0 USD \n"
        "Покупок: 0\n"
        "Персональная скидка: 0 %\n\n"
        "Приглашены: 0\n"
        "Бонусов получено: 0 USD\n\n"
        f"Пригласить друга и получить бонус: https://t.me/{bot_username}?start={user_id}\n\n"
        "При совершении покупки клиентом, которого вы пригласили - бонус будет автоматически "
        "зачислен на Ваш баланс. Вы получите уведомление о зачислении."
    )


async def edit_or_send(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    try:
        return await message.edit_text(text, reply_markup=markup)
    except TelegramBadRequest:
        pass
    if message.photo:
        try:
            await message.delete()
            return await message.answer(text, reply_markup=markup)
        except TelegramBadRequest:
            pass
    return await message.answer(text, reply_markup=markup)


async def send_new(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    return await message.answer(text, reply_markup=markup)


def _back_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])


def _option_price_display(option_key: str) -> str:
    parts = option_key.split("_")
    if len(parts) == 2:
        return f"{parts[0].upper()} - {parts[1]} $"
    return option_key


_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _resolve_product_photo(product) -> FSInputFile | None:
    if not product.photo_path:
        return None
    photo_path = Path(product.photo_path)
    if not photo_path.is_absolute():
        photo_path = _PROJECT_ROOT / photo_path
    if photo_path.exists():
        return FSInputFile(str(photo_path))
    return None


async def _edit_to_photo_or_send(
    message: Message,
    text: str,
    markup: InlineKeyboardMarkup | None,
    photo: FSInputFile | None,
) -> Message:
    if photo is None:
        return await edit_or_send(message, text, markup)
    try:
        media = InputMediaPhoto(media=photo, caption=text)
        return await message.edit_media(media, reply_markup=markup)
    except TelegramBadRequest:
        pass
    try:
        await message.delete()
    except TelegramBadRequest:
        pass
    return await message.answer_photo(photo, caption=text, reply_markup=markup)


async def safe_answer(callback: CallbackQuery, text: str = "", show_alert: bool = False) -> None:
    try:
        await callback.answer(text, show_alert=show_alert)
    except TelegramBadRequest:
        pass


@router.message(CommandStart())
async def on_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    user_id = message.from_user.id if message.from_user else 0
    
    if not _is_captcha_passed(user_id):
        captcha_text = generate_captcha_text()
        _set_captcha_challenge(user_id, captcha_text)
        image_bytes = generate_captcha_image(captcha_text)
        await message.answer_photo(
            BufferedInputFile(image_bytes, filename="captcha.png"),
            caption="🔒 Введите текст с картинки для доступа к боту:"
        )
        await state.set_state(CaptchaState.waiting)
        return
    
    bot_username = (await message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    await message.answer(text, reply_markup=_main_menu_markup())


@router.message(CaptchaState.waiting)
async def on_captcha_input(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id if message.from_user else 0
    user_input = (message.text or "").strip().upper()
    correct_text = _get_captcha_text(user_id)
    
    if correct_text and user_input == correct_text.upper():
        _set_captcha_passed(user_id)
        await state.clear()
        bot_username = (await message.bot.get_me()).username
        text = _main_menu_text(user_id, bot_username=bot_username)
        await message.answer("✅ Капча пройдена!", reply_markup=_main_menu_markup())
        await message.answer(text, reply_markup=_main_menu_markup())
    else:
        captcha_text = generate_captcha_text()
        _set_captcha_challenge(user_id, captcha_text)
        image_bytes = generate_captcha_image(captcha_text)
        await message.answer_photo(
            BufferedInputFile(image_bytes, filename="captcha.png"),
            caption="❌ Неверно. Попробуйте ещё раз:"
        )


@router.callback_query(F.data == "MAIN_MENU_REQUEST_CALLBACK")
async def on_choose_city(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    rows = []
    for city in settings.cities:
        rows.append([InlineKeyboardButton(text=city.label, callback_data=f"city:{city.key}")])
    rows.append([InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    await edit_or_send(callback.message, "Выбери город:", markup)


@router.callback_query(F.data.startswith("city:"))
async def on_city_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    city_key = callback.data.split(":", 1)[1]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, "Город не найден.", _back_markup())
        return
    rows = []
    for product in city.products:
        rows.append([InlineKeyboardButton(text=product.label, callback_data=f"product:{city_key}:{product.key}")])
    rows.append([InlineKeyboardButton(text="< Назад", callback_data="MAIN_MENU_REQUEST_CALLBACK")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    await edit_or_send(callback.message, "Отличный выбор!\nА теперь выбери нужный товар:", markup)


@router.callback_query(F.data.startswith("product:"))
async def on_product_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key = parts[1], parts[2]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, "Город не найден.", _back_markup())
        return
    product = next((p for p in city.products if p.key == product_key), None)
    if not product:
        await edit_or_send(callback.message, "Товар не найден.", _back_markup())
        return
    rows = []
    for option in product.options:
        rows.append([InlineKeyboardButton(text=option.label, callback_data=f"option:{city_key}:{product_key}:{option.key}")])
    rows.append([InlineKeyboardButton(text="< Назад", callback_data=f"city:{city_key}")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = f"Отличный выбор!\nА теперь выбери вариант товара {product.label}:"
    photo = _resolve_product_photo(product)
    await _edit_to_photo_or_send(callback.message, text, markup, photo)


@router.callback_query(F.data.startswith("option:"))
async def on_option_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = None
    option = None
    if city:
        product = next((p for p in city.products if p.key == product_key), None)
    if product:
        option = next((o for o in product.options if o.key == option_key), None)
    option_districts = option.districts if option and option.districts else None
    product_districts = product.districts if product else None
    active_districts = option_districts or product_districts or city.districts
    district_rows = []
    for i, district in enumerate(active_districts):
        district_rows.append([InlineKeyboardButton(
            text=district, callback_data=f"district:{city_key}:{product_key}:{option_key}:{i}"
        )])
    district_rows.append([InlineKeyboardButton(text="< Назад", callback_data=f"product:{city_key}:{product_key}")])
    markup = InlineKeyboardMarkup(inline_keyboard=district_rows)
    text = "Отличный выбор!\nА теперь выбери район:"
    if callback.message.photo:
        try:
            await callback.message.delete()
            await callback.message.answer(text, reply_markup=markup)
            return
        except TelegramBadRequest:
            pass
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("district:"))
async def on_district_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    district_idx = int(parts[4])
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = None
    option = None
    if city:
        product = next((p for p in city.products if p.key == product_key), None)
    if product:
        option = next((o for o in product.options if o.key == option_key), None)
    option_districts = option.districts if option and option.districts else None
    product_districts = product.districts if product else None
    active_districts = option_districts or product_districts or (city.districts if city else [])
    district = active_districts[district_idx] if 0 <= district_idx < len(active_districts) else "Неизвестно"
    price_display = _option_price_display(option.key) if option else "N/A"
    price_value = price_display.split(" - ")[1] if " - " in price_display else price_display
    # Extract numeric price from option key (e.g., "2g_170" -> 170)
    price_num = 85  # default
    if option and option.key:
        try:
            parts = option.key.split('_')
            if len(parts) >= 2:
                price_num = int(parts[-1])
        except:
            pass
    await state.update_data(selected_price=price_num)
    text = (
        f"{product.label} {option.label} ({city.label}, {district})\n\n\n\n"
        f"Цена: {price_value}\n\n"
        f"У вас нет персональной скидки! Покупайте в магазине и получайте скидку для постоянных клиентов\n"
        f"    \n"
        f"Твой баланс: 0 $"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Купить!", callback_data="BUY_NOW_CALLBACK")],
        [InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    photo = _resolve_product_photo(product)
    await _edit_to_photo_or_send(callback.message, text, markup, photo)


@router.callback_query(F.data == "MAIN_MENU_LK_CALLBACK")
async def on_payin(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    # Save selected_price before clearing state
    data = await state.get_data()
    selected_price = data.get("selected_price", 85)
    await state.clear()
    # Restore selected_price after clearing
    await state.update_data(selected_price=selected_price)
    user_balance = 0
    required_amount = selected_price
    if user_balance >= required_amount:
        text = "У вас достаточно баланса для покупки."
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="< Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
        ])
    else:
        text = (
            f"У вас недостаточно баланса! Выберите способ пополнения счета на сумму {required_amount} $:\n\n"
            f"📊 Статистика выдачи реквизитов (1 ч.):\n\n"
            f"🟢 BTC: 100.0%\n"
            f"🟢 LTC: 100.0%"
        )
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ LTC", callback_data="PAYMENT_ltc", style="success"),
                InlineKeyboardButton(text="✅ BTC", callback_data="PAYMENT_btc", style="success"),
            ],
            [InlineKeyboardButton(text="✅ USDT TRC20", callback_data="PAYMENT_usdt", style="success")],
            [InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
        ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_ltc")
async def on_payment_ltc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="LTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_ltc = convert_pln_to_crypto(amount_pln, "LTC")
    if amount_ltc is None:
        amount_ltc = Decimal("0.01")
    await state.update_data(amount_usd=amount_usd, amount_ltc=str(amount_ltc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: LTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_ltc} LTC</code>\n"
        f"☝️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только LTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👌 Подтвердить", callback_data="PAYMENT_confirm_ltc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_btc")
async def on_payment_btc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="BTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_btc = convert_pln_to_crypto(amount_pln, "BTC")
    if amount_btc is None:
        amount_btc = Decimal("0.001")
    await state.update_data(amount_usd=amount_usd, amount_btc=str(amount_btc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: BTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_btc} BTC</code>\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только BTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_btc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_usdt")
async def on_payment_usdt(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="USDT")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    # USDT is 1:1 with USD, so convert PLN to USDT
    amount_usdt = amount_pln * Decimal("0.2564")  # Approx PLN to USDT rate
    await state.update_data(amount_usd=amount_usd, amount_usdt=str(amount_usdt.quantize(Decimal("0.01"))))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: USDT TRC20\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount_usdt.quantize(Decimal('0.01'))} USDT\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только USDT (TRC20) на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_usdt")],
        [InlineKeyboardButton(text=" Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_confirm_"))
async def on_payment_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    request_id = data.get("request_id", 0)
    amount = data.get(f"amount_{coin.lower()}", "0.01")
    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh" if coin == "LTC" else "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    if coin.upper() == "USDT":
        wallet = "USDT_TRC20_WALLET_HERE"
    coin_marker = coin.lower()
    for pm in family_state.payment_methods:
        pm_key = pm.key.lower()
        # match by exact key OR by prefix (e.g. usdt_trc20 matches coin=USDT)
        if pm_key == coin_marker or pm_key.startswith(coin_marker + "_") or pm_key.startswith(coin_marker + "-"):
            if pm.requisites and "HERE" not in pm.requisites:
                wallet = pm.requisites
            break
    await state.update_data(wallet=wallet)
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: {coin}\n"
        f"На баланс: {data.get('amount_usd', 85)} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount} {coin}\n\n"
        f"Реквизиты для оплаты:\n"
        f"<code>{escape(wallet)}</code>\n"
        f"☝️ ☝️\n\n\n"
        f"Заявка подтверждена\n"
        f"Ожидайте генерации адреса {coin}. Время для оплаты - 60 минут.\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только {coin} на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"Для вас сгенерирован уникальный адрес для пополнения.\n"
        f"Отправьте {coin} на указанный адрес.\n\n"
        f"Вы можете отправить любую сумму — баланс будет пересчитан автоматически.\n"
        f"Рекомендуем отправить чуть больше указанной суммы, чтобы начисленного баланса точно хватило на покупку.\n\n"
        f"После 1 подтверждения в сети средства будут зачислены автоматически."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📱 LTC QRCODE 1", callback_data="PAYMENT_qr1")],
        [InlineKeyboardButton(text="📱 LTC QRCODE 2", callback_data="PAYMENT_qr2")],
        [InlineKeyboardButton(text="👍 Оплачено!", callback_data="PAYMENT_paid")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_message")
async def on_payment_message(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = "Вы можете написать оператору технической поддержки: @EvilSUPPORT_AU"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
        [InlineKeyboardButton(text="< Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_paid")
async def on_payment_paid(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = "Ваша заявка принята на проверку. Ожидайте подтверждения от оператора.\n\nКонтакты оператора: @EvilSUPPORT_AU"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
        [InlineKeyboardButton(text="< Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_cancel")
async def on_payment_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = "Оплата отменена."
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="< Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_qr"))
async def on_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    wallet = data.get("wallet", "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh")
    
    # Generate QR code
    try:
        if coin == "LTC":
            qr_data = f"litecoin:{wallet}"
        elif coin == "BTC":
            qr_data = f"bitcoin:{wallet}"
        else:
            qr_data = wallet
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        bio = io.BytesIO()
        img.save(bio, format='PNG')
        bio.seek(0)
        qr_photo = BufferedInputFile(bio.read(), filename="qr_code.png")
        
        await callback.message.answer_photo(qr_photo, caption=f"QR код для {coin}:\n<code>{escape(wallet)}</code>")
    except Exception as e:
        logger.warning(f"Could not generate QR: {e}")
        await callback.message.answer(f"Не удалось сгенерировать QR код. Адрес: <code>{escape(wallet)}</code>")


@router.callback_query(F.data == "MAIN_MENU_BONUS_CALLBACK")
async def on_bonus(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = (
        "Условия получения бонусов:\n    \n"
        "Мы готовы делиться с тобой прибылью с каждой продажи! "
        "Просто разошли эту ссылку своим друзьям и с каждой их покупки "
        "ты будешь получать до 5%!\n\n"
        f"👉 https://t.me/{bot_username}?start={user_id} 👈\n\n"
        "Считай сам - твои друзья совершат пару покупок, а для тебя будет уже "
        "хорошая скидка! А ведь ты можешь рассылать ссылку в любые чаты, "
        "где люди будут готовы совершить покупки! И тогда счет пойдет уже на десятки ;)"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_RULES_CALLBACK")
async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Всех приветствуем в разделе где можно узнать правила подачи заявления о ненаходе\n\n"
        "Сразу приступим к тому как делать не нужно: \n\n"
        "-Не нужно спамить, умолять оператора выдать пз, угрожать и тд\n"
        "-Не нужно писать со всех возможных аккаунтов, это расценивается как попытка обмана\n\n"
        "Как правильно сообщить о ненаходе: \n\n"
        "-При подходе к месту снимаем видео (разрывать яму не нужно)\n"
        "-Ищем клад в глубине 3-4см и в радиусе 5см от точки\n"
        "-Если клада нет - делаем два фото с ракурса как у курьера\n\n"
        "Предоставление данных оператору в случае ненахода:\n\n"
        "-Ссылка на клад\n"
        "-Фото с места и видео ДО НАЧАЛА ПОИСКОВ\n"
        "-Ваш ник в боте  или номер заказа (его можно посмотреть в профиле или выполнив команду /start\n\n"
        "⚠️⚠️ ЕСЛИ АДРЕС НЕ СООТВЕТСТВУЕТ ФОТО/КОРДИНАТАМ ⚠️⚠️\n\n"
        " предоставьте, пожалуйста, 4 фотографии местности с отметкой координат. "
        "Координаты на Ваших фото должны совпадать с координатами в заказе, "
        "желательно в таком же ракурсе как у курьера. "
        "Для того чтобы получить фотографии с отметкой GPS координат, "
        "можете использовать Notecam если у Вас Android, или Solocator если используете iOS. "
        "Ожидаю фотографии в пределах регламентного времени\n\n"
        "☝️☝️ВАЖНО ЗНАТЬ! РАССМОТРЕНИЕ И УТОЧНЕНИЕ ВАШЕЙ ЗАЯВКИ ДОПУСТИМО В ТЕЧЕНИИ 3 ЧАСОВ С МОМЕНТА ПОКУПКИ!\n\n"
        "‼️ВНИМАНИЕ‼️\n"
        "❌ПОЧЕМУ ВАМ МОЖЕТ БЫТЬ ОТКАЗАНО В РАССМОТРЕНИИ?❌\n\n"
        "1. Мы оставляем за собой право на отказ в обслуживании, УТОЧНЕНИЯХ или решении той или иной проблемы без каких-либо разъяснений.\n\n"
        "2. Претензии по ненаходам, недовесам и другим проблемам в заказах принимаются в течение 3-х  часов с момента покупки  и решаются только через ЛС!\n\n"
        "3. Передача информации о кладе третьим лицам запрещена - это лишает Вас права на помощь в поисках  в случае ненахода!\n\n"
        "4. Шантаж плохими отзывами, хамство, оскорбления сотрудников магазина и не пристойное поведение - АВТОМАТИЧЕСКИ лишает Вас права на получение помощи в поисках  в случае ненахода!\n"
        "Нет видео поисков - нет перезаклада! Замены на перезаклад нет!"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_NEWLIST_CALLBACK")
async def on_showcase(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    lines: list[str] = []
    counter = 1
    for city in settings.cities:
        if not city.products:
            continue
        lines.append(f'Доступные товары "{city.label}"')
        for product in city.products:
            for option in product.options:
                lines.append(f"📁 {product.label}")
                price_display = _option_price_display(option.key)
                lines.append(f"{counter}) {product.label} {price_display}")
                option_districts = option.districts or product.districts or city.districts
                for district in option_districts:
                    lines.append(f"{district} ✅ КУПИТЬ")
                lines.append("")
                counter += 1
    text = "\n".join(lines) if lines else "Товары временно отсутствуют."
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_INFO_CALLBACK")
async def on_info(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "📌 Информация\n\n"
        "🛒 Как сделать покупку:\n"
        "1. Пополните баланс через раздел «🖥️ Пополнить счет»\n"
        "2. Выберите город в разделе «🗺 Выбрать город»\n"
        "3. Выберите товар и район\n"
        "4. Нажмите «Купить» — сумма спишется с баланса\n"
        "5. После покупки вы получите инструкцию с координатами и фото\n\n"
        "⏳ Время ожидания:\n"
        "После оплаты товар выдаётся мгновенно. Если возникли проблемы — напишите оператору.\n\n"
        "🔒 Гарантии:\n"
        "Мы гарантируем выдачу товара или возврат средств. Все спорные ситуации решаются в течение 3 часов с момента покупки.\n\n"
        "⚠️ Правила безопасности:\n"
        "- Не сообщайте свой пароль или код от сайта третьим лицам\n"
        "- При получении товара убедитесь, что вы находитесь в безопасном месте\n"
        "- Не передавайте информацию о покупке другим лицам\n\n"
        "💬 По всем вопросам обращайтесь в раздел «🧾 Поддержка»"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_REVIEWS_CALLBACK")
async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Рейтинг магазина: ⭐ 3,9/5 (64 шт.)\n\n"
        "Ваши отзывы делают наш магазин лучше!\n\n"
        "⭐ | MEFEDRON 2G (Evil Georgia)\n"
        "📍 ТБИЛИСИ\n"
        "ძველი ადრესია ეს ყლეობა\n"
        "от 27.06.2026 02:59\n\n\n"
        "Отзывы можно оставлять только к совершенным покупкам."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="<--", callback_data="REVIEW_PREV"),
            InlineKeyboardButton(text="-->", callback_data="REVIEW_NEXT"),
        ],
        [InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.in_({"REVIEW_PREV", "REVIEW_NEXT"}))
async def on_review_page(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback, "Нет других отзывов", show_alert=True)


@router.callback_query(F.data == "CREATE_PRIVATE_BOT_CALLBACK")
async def on_private_bot(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Вы не можете создавать личных ботов, пока не совершите необходимое кол-во покупок.\n\n"
        "Всего покупок: 0\n"
        "Необходимо покупок для создания бота: 1"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_WEB_AUTH_CODE")
async def on_web_auth(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    site_code = f"fission-{random.randint(10000, 99999)}-viper"
    text = (
        f"🔑 Ваш код для входа на сайт:\n\n"
        f"{site_code}\n\n"
        f"Нажмите на скрытый текст, чтобы увидеть код.\n\n"
        f"Этот код вы можете использовать для авторизации на сайте или в мобильном приложении.\n\n"
        f"⚠️ Никому никогда не сообщайте этот код — используя его можно получить доступ "
        f"к вашему аккаунту, истории покупок и балансу."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "BUY_NOW_CALLBACK")
async def on_buy_now(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    # Save selected_price before clearing state
    data = await state.get_data()
    selected_price = data.get("selected_price", 85)
    await state.clear()
    # Restore selected_price after clearing
    await state.update_data(selected_price=selected_price)
    text = (
        f"У вас недостаточно баланса! Выберите способ пополнения счета на сумму {selected_price} $:\n\n"
        f"📊 Статистика выдачи реквизитов (1 ч.):\n\n"
        f"🟢 BTC: 100.0%\n"
        f"🟢 LTC: 100.0%"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ LTC", callback_data="PAYMENT_ltc", style="success"),
            InlineKeyboardButton(text="✅ BTC", callback_data="PAYMENT_btc", style="success"),
        ],
        [InlineKeyboardButton(text="✅ USDT TRC20", callback_data="PAYMENT_usdt", style="success")],
        [InlineKeyboardButton(text="< Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "BACK_TO_MAIN_MENU_CALLBACK")
async def on_back_to_main(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    try:
        await callback.message.edit_text(text, reply_markup=_main_menu_markup())
    except TelegramBadRequest:
        await callback.message.answer(text, reply_markup=_main_menu_markup())


def _clone_router(src: Router) -> Router:
    """Create a fresh Router that mirrors src's handlers/middleware without sharing state."""
    dst = Router(name=f"evila_{id(src)}")
    for event_name, observer in src.observers.items():
        dst_observer = dst.observers[event_name]
        for handler in observer.handlers:
            dst_observer.handlers.append(handler)
        for mw in observer.middleware:
            dst_observer.middleware(mw)
        for mw in observer.outer_middleware:
            dst_observer.outer_middleware(mw)
    for sub in src.sub_routers:
        dst.include_router(_clone_router(sub))
    return dst


def create_bot_runtime(settings: Settings) -> Router:
    return _clone_router(router)


def build_bot(token: str, settings: Settings, proxy_url: str | None = None) -> tuple[Bot, Dispatcher]:
    try:
        refresh_market_rates()
        refresh_pln_rate()
    except Exception:
        pass
    if proxy_url:
        session = AiohttpSession(proxy=proxy_url)
        bot = Bot(token=token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    else:
        bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    dp.include_router(_clone_router(router))
    return bot, dp


@dataclass(slots=True)
class BotRuntime:
    spec: "BotSpec"
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task


async def start_runtime(
    settings: Settings,
    spec: "BotSpec",
    persist_spec=None,
    register_bot=None,
    list_bots=None,
    remove_bot_by_id=None,
    toggle_bot_pause_by_id=None,
    sync_payment_methods_for_all=None,
    sync_start_text_for_all=None,
    sync_admin_ids_for_all=None,
    sync_template_for_all=None,
    proxy_url: str | None = None,
) -> BotRuntime:
    try:
        refresh_market_rates()
    except Exception:
        pass
    try:
        refresh_pln_rate()
    except Exception:
        pass
    bot, dp = build_bot(spec.token, settings, proxy_url=proxy_url)
    try:
        await bot.delete_webhook(drop_pending_updates=False)
    except Exception:
        pass
    task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
    if proxy_url:
        logger.info("Started bot @%s via proxy %s", spec.bot_username, proxy_url.split("@")[-1])
    else:
        logger.info("Started bot @%s", spec.bot_username)
    return BotRuntime(spec=spec, dispatcher=dp, bot=bot, task=task)


async def stop_runtime(runtime: BotRuntime) -> None:
    runtime.task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    try:
        await runtime.bot.session.close()
    except Exception:
        pass
    await asyncio.sleep(1)
