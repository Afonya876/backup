from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from pydantic import BaseModel

from vip_shop.config import (
    BotSpec,
    BotSummary,
    CityConfig,
    CreateBotRequest,
    PaymentMethodConfig,
    ProxyConfig,
    Settings,
    TemplateOverrides,
    get_settings,
    save_catalog_cities,
)
from vip_shop.crypto_rates import (
    get_btc_usdt_rate,
    get_ltc_usdt_rate,
    get_usdt_uah_rate,
    refresh_crypto_rub_rates,
    refresh_market_rates,
)
from vip_shop.manager import BotManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


class UpdateBotRequest(BaseModel):
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None
    is_paused: bool | None = None


class UpdateFamilyRequest(BaseModel):
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None
    proxies: list[ProxyConfig] | None = None


class CatalogUpdateRequest(BaseModel):
    cities: list[CityConfig]


class BroadcastRequest(BaseModel):
    text: str


def serialize_spec(spec: BotSpec, manager: BotManager) -> dict[str, object]:
    return {
        "token": spec.token,
        "template": spec.template.model_dump(mode="json"),
        "payment_methods": [method.model_dump(mode="json") for method in spec.payment_methods],
        "admin_ids": list(spec.admin_ids),
        "is_paused": spec.is_paused,
        "bot_id": spec.bot_id,
        "bot_username": spec.bot_username,
        "bot_name": spec.bot_name,
        "created_at": spec.created_at,
        "is_running": spec.token in manager._runtimes and not spec.is_paused,
    }


async def serialize_family(manager: BotManager) -> dict[str, object]:
    specs = await manager.registry.load()
    family_state = await manager._load_family_state()
    return {
        "template": (await manager._get_shared_template()).model_dump(mode="json"),
        "admin_ids": await manager._get_shared_admin_ids(),
        "payment_methods": [
            method.model_dump(mode="json") for method in await manager._get_shared_payment_methods()
        ],
        "proxies": [p.model_dump(mode="json") for p in family_state.proxies],
        "proxy_assignments": [
            {
                "bot_username": spec.bot_username,
                "bot_id": spec.bot_id,
                "proxy": manager._proxy_url_for_token(spec.token),
            }
            for spec in specs
        ],
        "bots_count": len(specs),
        "running_count": sum(1 for spec in specs if spec.token in manager._runtimes and not spec.is_paused),
        "recipients_count": await manager.count_recipients(),
        "bots": [serialize_spec(spec, manager) for spec in specs],
    }


def verify_api_key(
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    settings: Settings = Depends(get_settings),
) -> str:
    if x_api_key != settings.master_api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")
    return x_api_key


def create_app() -> FastAPI:
    settings = get_settings()
    manager = BotManager(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.manager = manager
        try:
            await asyncio.to_thread(refresh_market_rates)
        except Exception:
            logger.warning("Could not refresh market rates at startup", exc_info=True)
        try:
            await asyncio.to_thread(refresh_crypto_rub_rates)
        except Exception:
            logger.warning("Could not refresh crypto RUB rates at startup", exc_info=True)
        await manager.start_registered_bots()
        try:
            yield
        finally:
            await manager.shutdown()

    app = FastAPI(title="Evila bot factory", lifespan=lifespan)

    @app.get("/health")
    async def health() -> dict[str, object]:
        ltc_rate = get_ltc_usdt_rate()
        btc_rate = get_btc_usdt_rate()
        usdt_uah = get_usdt_uah_rate()
        return {
            "status": "ok",
            "bot": "evila",
            "rates": {
                "LTC_USDT": str(ltc_rate) if ltc_rate else None,
                "BTC_USDT": str(btc_rate) if btc_rate else None,
                "USDT_UAH": str(usdt_uah) if usdt_uah else None,
            },
        }

    @app.get("/bots", response_model=list[BotSummary], dependencies=[Depends(verify_api_key)])
    async def list_bots() -> list[BotSummary]:
        return await manager.list_bots()

    @app.post("/bots", dependencies=[Depends(verify_api_key)])
    async def create_bot(payload: CreateBotRequest):
        try:
            result = await manager.register_bot(payload)
        except Exception as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
        return {
            "created": result.created,
            "bot_id": result.spec.bot_id,
            "bot_username": result.spec.bot_username,
            "bot_name": result.spec.bot_name,
            "created_at": result.spec.created_at,
            "admin_ids": result.spec.admin_ids,
        }

    @app.delete("/bots", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(verify_api_key)])
    async def delete_bot(token: str, response: Response) -> Response:
        removed = await manager.remove_bot(token)
        if not removed:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        response.status_code = status.HTTP_204_NO_CONTENT
        return response

    @app.get("/admin/bots/{bot_id}", dependencies=[Depends(verify_api_key)])
    async def get_bot_details(bot_id: int):
        spec = await manager._find_by_bot_id(bot_id)
        if spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        return serialize_spec(spec, manager)

    @app.patch("/admin/bots/{bot_id}", dependencies=[Depends(verify_api_key)])
    async def update_bot(bot_id: int, payload: UpdateBotRequest):
        stored_spec = await manager._find_by_bot_id(bot_id)
        if stored_spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        if payload.template is not None:
            await manager.sync_template(payload.template)
        if payload.payment_methods is not None:
            await manager.sync_payment_methods(payload.payment_methods)
        if payload.admin_ids is not None:
            await manager.sync_admin_ids(payload.admin_ids)
        spec_after = await manager._find_by_bot_id(bot_id)
        if spec_after is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        if payload.is_paused is not None and payload.is_paused != spec_after.is_paused:
            await manager.toggle_bot_pause_by_id(bot_id)
        updated_spec = await manager._find_by_bot_id(bot_id)
        if updated_spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        return serialize_spec(updated_spec, manager)

    @app.delete("/admin/bots/{bot_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(verify_api_key)])
    async def delete_bot_by_id(bot_id: int, response: Response) -> Response:
        removed = await manager.remove_bot_by_id(bot_id)
        if not removed:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        response.status_code = status.HTTP_204_NO_CONTENT
        return response

    @app.get("/admin/family", dependencies=[Depends(verify_api_key)])
    async def get_family_details():
        return await serialize_family(manager)

    @app.patch("/admin/family", dependencies=[Depends(verify_api_key)])
    async def update_family(payload: UpdateFamilyRequest):
        if payload.template is not None:
            await manager.sync_template(payload.template)
        if payload.admin_ids is not None:
            await manager.sync_admin_ids(payload.admin_ids)
        if payload.payment_methods is not None:
            await manager.sync_payment_methods(payload.payment_methods)
        if payload.proxies is not None:
            await manager.sync_proxies(payload.proxies)
        return await serialize_family(manager)

    @app.post("/admin/family/broadcast", dependencies=[Depends(verify_api_key)])
    async def broadcast(payload: BroadcastRequest):
        text = payload.text.strip()
        if not text:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Text is required")
        return await manager.broadcast(text)

    @app.get("/admin/proxies", dependencies=[Depends(verify_api_key)])
    async def list_proxies():
        family_state = await manager._load_family_state()
        specs = await manager.registry.load()
        return {
            "proxies": [p.model_dump(mode="json") for p in family_state.proxies],
            "pool": manager._proxy_pool,
            "assignments": [
                {
                    "bot_username": spec.bot_username,
                    "bot_id": spec.bot_id,
                    "proxy": manager._proxy_url_for_token(spec.token),
                }
                for spec in specs
            ],
        }

    @app.post("/admin/proxies", dependencies=[Depends(verify_api_key)])
    async def add_proxy(payload: ProxyConfig):
        family_state = await manager._load_family_state()
        existing_urls = {p.url.strip() for p in family_state.proxies}
        if payload.url.strip() in existing_urls:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Proxy already exists")
        family_state.proxies.append(payload)
        await manager.sync_proxies(family_state.proxies)
        return {"added": payload.model_dump(mode="json"), "total": len(family_state.proxies)}

    @app.delete("/admin/proxies/{index}", dependencies=[Depends(verify_api_key)])
    async def remove_proxy(index: int):
        family_state = await manager._load_family_state()
        if index < 0 or index >= len(family_state.proxies):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proxy index out of range")
        removed = family_state.proxies.pop(index)
        await manager.sync_proxies(family_state.proxies)
        return {"removed": removed.model_dump(mode="json"), "total": len(family_state.proxies)}

    @app.get("/admin/family/catalog", dependencies=[Depends(verify_api_key)])
    async def get_catalog():
        return [city.model_dump(mode="json") for city in settings.cities]

    @app.put("/admin/family/catalog", dependencies=[Depends(verify_api_key)])
    async def update_catalog(payload: CatalogUpdateRequest):
        settings.cities.clear()
        settings.cities.extend(city.model_copy(deep=True) for city in payload.cities)
        save_catalog_cities(settings.catalog_path, settings.cities)
        return {"status": "ok", "cities_count": len(settings.cities)}

    return app
