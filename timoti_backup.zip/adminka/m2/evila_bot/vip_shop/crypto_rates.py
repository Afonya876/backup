from __future__ import annotations

import asyncio
import json
import time
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from threading import Lock
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


WHITEBIT_TICKER_URL = "https://whitebit.com/api/v4/public/ticker"
EXCHANGERATE_API_URL = "https://api.exchangerate-api.com/v4/latest/PLN"
USER_AGENT = "kfc/1.0"
REFRESH_INTERVAL_SECONDS = 3600.0
USDT_UAH_MARKET = "USDT_UAH"
PLN_USDT_MARKET = "PLN_USDT"
LTC_USDT_MARKET = "LTC_USDT"
BTC_USDT_MARKET = "BTC_USDT"
CRYPTO_AMOUNT_PRECISION = Decimal("0.00000001")
FIAT_AMOUNT_PRECISION = Decimal("0.01")

# RUB prices of coins (RUB per 1 coin), used to convert ruble order sums to crypto.
COINGECKO_URL = (
    "https://api.coingecko.com/api/v3/simple/price"
    "?ids=bitcoin,litecoin,tether&vs_currencies=rub"
)
_COIN_IDS = {"BTC": "bitcoin", "LTC": "litecoin", "USDT": "tether"}

_cache_lock = Lock()
_cached_rates: dict[str, Decimal] = {}
_cached_at = 0.0
_coin_rub_rates: dict[str, Decimal] = {}
_pln_uah_rate: Decimal | None = None


def refresh_crypto_rub_rates() -> dict[str, Decimal]:
    request = Request(COINGECKO_URL, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=6) as response:
            payload = json.load(response)
        updated: dict[str, Decimal] = {}
        for coin, coin_id in _COIN_IDS.items():
            entry = payload.get(coin_id)
            if not isinstance(entry, dict):
                continue
            rate = Decimal(str(entry.get("rub") or "0"))
            if rate > 0:
                updated[coin] = rate
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, InvalidOperation, json.JSONDecodeError):
        return dict(_coin_rub_rates)
    if updated:
        with _cache_lock:
            _coin_rub_rates.update(updated)
    return dict(_coin_rub_rates)


def refresh_pln_rate() -> Decimal | None:
    """Fetch PLN/UAH rate from exchangerate-api.com"""
    global _pln_uah_rate
    request = Request(EXCHANGERATE_API_URL, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=6) as response:
            payload = json.load(response)
        rates = payload.get("rates", {})
        uah_rate = rates.get("UAH")
        if uah_rate and uah_rate > 0:
            _pln_uah_rate = Decimal(str(uah_rate))
            return _pln_uah_rate
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, InvalidOperation, json.JSONDecodeError):
        pass
    return _pln_uah_rate


def get_pln_uah_rate() -> Decimal | None:
    """Return PLN/UAH rate (how many UAH per 1 PLN)"""
    global _pln_uah_rate
    if _pln_uah_rate is None:
        return refresh_pln_rate()
    return _pln_uah_rate


def convert_rub_to_crypto(amount_rub: Decimal, coin: str) -> Decimal | None:
    coin = coin.strip().upper()
    with _cache_lock:
        rate = _coin_rub_rates.get(coin)
    if rate is None or rate <= 0:
        return None
    precision = FIAT_AMOUNT_PRECISION if coin == "USDT" else CRYPTO_AMOUNT_PRECISION
    try:
        return (amount_rub / rate).quantize(precision, rounding=ROUND_CEILING)
    except (InvalidOperation, ZeroDivisionError):
        return None


def _read_cached_rate(market: str, max_age_seconds: float | None = None) -> Decimal | None:
    now = time.monotonic()
    with _cache_lock:
        rate = _cached_rates.get(market)
        if rate is None:
            return None
        if max_age_seconds is not None and now - _cached_at > max_age_seconds:
            return None
        return rate


def _write_cached_rates(rates: dict[str, Decimal]) -> None:
    global _cached_at
    with _cache_lock:
        _cached_rates.update(rates)
        _cached_at = time.monotonic()


def refresh_market_rates() -> dict[str, Decimal]:
    request = Request(WHITEBIT_TICKER_URL, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(request, timeout=5) as response:
            payload = json.load(response)
        updated_rates: dict[str, Decimal] = {}
        for market in (USDT_UAH_MARKET, LTC_USDT_MARKET, BTC_USDT_MARKET, PLN_USDT_MARKET):
            market_data = payload.get(market)
            if not isinstance(market_data, dict):
                continue
            rate = Decimal(str(market_data.get("last_price") or "0"))
            if rate > 0:
                updated_rates[market] = rate
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, InvalidOperation, json.JSONDecodeError):
        return dict(_cached_rates)

    if updated_rates:
        _write_cached_rates(updated_rates)
    return dict(_cached_rates)


def get_usdt_uah_rate() -> Decimal | None:
    return _read_cached_rate(USDT_UAH_MARKET)


def get_btc_usdt_rate() -> Decimal | None:
    """Return BTC/USDT rate."""
    return _read_cached_rate(BTC_USDT_MARKET)


def get_ltc_usdt_rate() -> Decimal | None:
    return _read_cached_rate(LTC_USDT_MARKET)



def get_pln_usdt_rate() -> Decimal | None:
    """Return PLN/USDT rate (how many USDT per 1 PLN)."""
    rate = _read_cached_rate(PLN_USDT_MARKET, max_age_seconds=REFRESH_INTERVAL_SECONDS)
    if rate is not None:
        return rate
    refresh_market_rates()
    return _read_cached_rate(PLN_USDT_MARKET)

def _normalize_currency(raw_currency: str) -> str:
    marker = raw_currency.strip().casefold()
    if marker in {"usd", "$"}:
        return "USD"
    if marker in {"usdt", "usdt trc20"}:
        return "USDT"
    if marker in {"uah", "грн", "₴"}:
        return "UAH"
    if marker == "ltc":
        return "LTC"
    return raw_currency.strip().upper()


def convert_amount(amount: Decimal, source_currency: str, target_currency: str) -> Decimal | None:
    source = _normalize_currency(source_currency)
    target = _normalize_currency(target_currency)

    if source == target:
        precision = CRYPTO_AMOUNT_PRECISION if target == "LTC" else FIAT_AMOUNT_PRECISION
        return amount.quantize(precision, rounding=ROUND_CEILING)

    # Treat USD as a 1:1 display alias for USDT in the current catalog.
    if source == "USD":
        source = "USDT"
    if target == "USD":
        target = "USDT"
    if source == target:
        precision = CRYPTO_AMOUNT_PRECISION if target == "LTC" else FIAT_AMOUNT_PRECISION
        return amount.quantize(precision, rounding=ROUND_CEILING)

    if source == "UAH" and target == "USDT":
        rate = get_usdt_uah_rate()
        if rate is None or rate <= 0:
            return None
        return (amount / rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "USDT" and target == "UAH":
        rate = get_usdt_uah_rate()
        if rate is None or rate <= 0:
            return None
        return (amount * rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    
    if source == "PLN" and target == "UAH":
        # PLN -> UAH direct via exchangerate-api
        pln_uah_rate = get_pln_uah_rate()
        if pln_uah_rate is None or pln_uah_rate <= 0:
            return None
        return (amount * pln_uah_rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "UAH" and target == "PLN":
        # UAH -> PLN direct via exchangerate-api
        pln_uah_rate = get_pln_uah_rate()
        if pln_uah_rate is None or pln_uah_rate <= 0:
            return None
        return (amount / pln_uah_rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "USDT" and target == "LTC":
        rate = get_ltc_usdt_rate()
        if rate is None or rate <= 0:
            return None
        return (amount / rate).quantize(CRYPTO_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if source == "LTC" and target == "USDT":
        rate = get_ltc_usdt_rate()
        if rate is None or rate <= 0:
            return None
        return (amount * rate).quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)

    if target in {"USDT", "LTC"}:
        usdt_amount = convert_amount(amount, source, "USDT")
        if usdt_amount is None:
            return None
        if target == "USDT":
            return usdt_amount
        return convert_amount(usdt_amount, "USDT", "LTC")

    if source in {"USDT", "LTC"} and target == "UAH":
        usdt_amount = convert_amount(amount, source, "USDT")
        if usdt_amount is None:
            return None
        return convert_amount(usdt_amount, "USDT", "UAH")

    return None


async def refresh_market_rates_periodically() -> None:
    while True:
        await asyncio.sleep(REFRESH_INTERVAL_SECONDS)
        await asyncio.to_thread(refresh_market_rates)
        await asyncio.to_thread(refresh_crypto_rub_rates)


def convert_pln_to_crypto(amount_pln: Decimal, coin: str) -> Decimal | None:
    """Convert PLN amount to crypto amount (USDT, LTC, BTC)"""
    coin = coin.strip().upper()
    pln_uah_rate = get_pln_uah_rate()
    if pln_uah_rate is None or pln_uah_rate <= 0:
        return None
    
    usdt_uah_rate = get_usdt_uah_rate()
    if usdt_uah_rate is None or usdt_uah_rate <= 0:
        return None
    
    # PLN -> UAH -> USDT
    uah_amount = amount_pln * pln_uah_rate
    usdt_amount = uah_amount / usdt_uah_rate
    
    if coin == "USDT":
        return usdt_amount.quantize(FIAT_AMOUNT_PRECISION, rounding=ROUND_CEILING)
    elif coin == "LTC":
        ltc_usdt_rate = get_ltc_usdt_rate()
        if ltc_usdt_rate is None or ltc_usdt_rate <= 0:
            return None
        return (usdt_amount / ltc_usdt_rate).quantize(CRYPTO_AMOUNT_PRECISION, rounding=ROUND_CEILING)
    elif coin == "BTC":
        btc_usdt_rate = get_btc_usdt_rate()
        if btc_usdt_rate is None or btc_usdt_rate <= 0:
            return None
        return (usdt_amount / btc_usdt_rate).quantize(CRYPTO_AMOUNT_PRECISION, rounding=ROUND_CEILING)
    return None
