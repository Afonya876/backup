"""VIP multi-bot template."""
