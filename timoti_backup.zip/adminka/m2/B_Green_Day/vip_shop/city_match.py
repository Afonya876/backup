"""City recognition for the registration step.

A user types a city name as free text. We resolve it against the catalog
(``settings.cities``) in three escalating steps, all within a single AI request:

1. Local exact / substring match against the configured city labels.
2. One request to the Codex Sale (``codexsale``) OpenAI-compatible API. The model
   is told the full list of known cities and asked to match the input (typos,
   transliteration, other languages) or propose the 3 nearest variants.
3. Local ``difflib`` fuzzy fallback when the AI is disabled or unreachable.

A match is accepted only when confidence is greater than 60%.
"""

from __future__ import annotations

import difflib
import json
import logging
from dataclasses import dataclass, field

import aiohttp

from vip_shop.config import CityConfig, Settings

logger = logging.getLogger(__name__)

CONFIDENCE_THRESHOLD = 60
SUGGEST_RATIO = 0.45
MAX_SUGGESTIONS = 3
AI_TIMEOUT_SECONDS = 12


def _normalize(text: str) -> str:
    return " ".join((text or "").split()).strip().casefold()


@dataclass(slots=True)
class CityResolution:
    kind: str  # "found" | "suggest" | "not_found"
    city: CityConfig | None = None
    confidence: int = 0
    suggestions: list[CityConfig] = field(default_factory=list)


def _found(city: CityConfig, confidence: int) -> CityResolution:
    return CityResolution(kind="found", city=city, confidence=confidence)


def _suggest(cities: list[CityConfig]) -> CityResolution:
    return CityResolution(kind="suggest", suggestions=cities[:MAX_SUGGESTIONS])


def _not_found() -> CityResolution:
    return CityResolution(kind="not_found")


def _label_index(cities: list[CityConfig]) -> dict[str, CityConfig]:
    index: dict[str, CityConfig] = {}
    for city in cities:
        index.setdefault(_normalize(city.label), city)
        index.setdefault(_normalize(city.key), city)
    return index


def _local_resolve(cities: list[CityConfig], text: str) -> CityResolution | None:
    """Cheap match without the AI. Returns None when undecided."""
    text_norm = _normalize(text)
    if not text_norm:
        return _not_found()

    by_label = _label_index(cities)
    exact = by_label.get(text_norm)
    if exact is not None:
        return _found(exact, 100)

    if len(text_norm) >= 3:
        contains = [
            city
            for city in cities
            if text_norm in _normalize(city.label) or _normalize(city.label) in text_norm
        ]
        if len(contains) == 1:
            return _found(contains[0], 90)

    return None


def _difflib_resolve(cities: list[CityConfig], text: str) -> CityResolution:
    text_norm = _normalize(text)
    scored = sorted(
        (
            (difflib.SequenceMatcher(None, text_norm, _normalize(city.label)).ratio(), city)
            for city in cities
        ),
        key=lambda item: item[0],
        reverse=True,
    )
    if not scored:
        return _not_found()
    best_ratio, best_city = scored[0]
    if best_ratio * 100 >= CONFIDENCE_THRESHOLD:
        return _found(best_city, int(best_ratio * 100))
    near = [city for ratio, city in scored if ratio >= SUGGEST_RATIO][:MAX_SUGGESTIONS]
    if near:
        return _suggest(near)
    return _not_found()


def _parse_ai_content(content: str) -> dict | None:
    text = (content or "").strip()
    if not text:
        return None
    if text.startswith("```"):
        text = text.strip("`")
        # Drop an optional leading language tag like "json".
        newline = text.find("\n")
        if newline != -1 and " " not in text[:newline]:
            text = text[newline + 1 :]
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None
    try:
        parsed = json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


async def _ai_resolve(settings: Settings, cities: list[CityConfig], text: str) -> dict | None:
    if not settings.ai_enabled or not settings.ai_api_key.strip():
        return None

    labels = [city.label for city in cities]
    system_prompt = (
        "Ты помощник, который сопоставляет введённый пользователем город с одним из "
        "известных городов магазина. Пользователь может ошибиться, написать на другом "
        "языке или транслитерацией. Известные города (выбирай ТОЛЬКО из этого списка, "
        "копируй название дословно):\n"
        + "\n".join(f"- {label}" for label in labels)
        + "\n\nВерни СТРОГО JSON без пояснений в формате: "
        '{"match": <точное название из списка или null>, '
        '"confidence": <целое 0-100>, '
        '"suggestions": [<до 3 точных названий из списка>]}. '
        "match заполняй только если уверен (совпадение более 60%). "
        "Если точного совпадения нет — match=null и предложи до 3 ближайших городов."
    )
    # gpt-5.4 family (Codex Sale) rejects `temperature` and `response_format`,
    # so we ask for strict JSON in the prompt and extract it from the reply text.
    payload = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": text.strip()},
        ],
    }
    headers = {
        "Authorization": f"Bearer {settings.ai_api_key.strip()}",
        "Content-Type": "application/json",
    }
    try:
        timeout = aiohttp.ClientTimeout(total=AI_TIMEOUT_SECONDS)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(settings.ai_chat_endpoint, json=payload, headers=headers) as response:
                if response.status != 200:
                    body = await response.text()
                    logger.warning("Codex Sale city match HTTP %s: %s", response.status, body[:200])
                    return None
                data = await response.json()
    except Exception as exc:  # network / timeout / decode
        logger.warning("Codex Sale city match request failed: %s", exc)
        return None

    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        logger.warning("Unexpected Codex Sale response shape: %r", data)
        return None
    return _parse_ai_content(content)


def _ai_result_to_resolution(
    cities: list[CityConfig],
    ai_payload: dict,
) -> CityResolution | None:
    by_label = _label_index(cities)
    match_label = ai_payload.get("match")
    try:
        confidence = int(ai_payload.get("confidence") or 0)
    except (TypeError, ValueError):
        confidence = 0

    if isinstance(match_label, str):
        matched_city = by_label.get(_normalize(match_label))
        if matched_city is not None and confidence >= CONFIDENCE_THRESHOLD:
            return _found(matched_city, confidence)

    suggestions: list[CityConfig] = []
    raw_suggestions = ai_payload.get("suggestions")
    if isinstance(raw_suggestions, list):
        for item in raw_suggestions:
            if not isinstance(item, str):
                continue
            city = by_label.get(_normalize(item))
            if city is not None and city not in suggestions:
                suggestions.append(city)
    if suggestions:
        return _suggest(suggestions)
    return None


async def resolve_city(settings: Settings, text: str) -> CityResolution:
    cities = settings.cities
    local = _local_resolve(cities, text)
    if local is not None and local.kind == "found":
        return local

    ai_payload = await _ai_resolve(settings, cities, text)
    if ai_payload is not None:
        ai_resolution = _ai_result_to_resolution(cities, ai_payload)
        if ai_resolution is not None:
            return ai_resolution

    # The AI was unavailable or undecided: fall back to local fuzzy matching,
    # then to whatever the local step already produced (e.g. an empty input).
    fuzzy = _difflib_resolve(cities, text)
    if fuzzy.kind != "not_found":
        return fuzzy
    return local if local is not None else fuzzy
