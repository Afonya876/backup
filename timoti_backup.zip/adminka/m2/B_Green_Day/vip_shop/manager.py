from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramUnauthorizedError

from vip_shop.bot_runtime import BotRuntime, start_runtime, stop_runtime
from vip_shop.config import (
    BotSpec,
    BotSummary,
    CreateBotRequest,
    FamilyState,
    PaymentMethodConfig,
    ProxyConfig,
    Settings,
    TemplateOverrides,
    normalize_template,
)
from vip_shop.storage import BotRegistry, FamilyRegistry, UserRegistry

logger = logging.getLogger(__name__)
DISABLED_PAYMENT_METHOD_KEYS: set[str] = set()
START_RETRY_DELAY_SECONDS = 5
START_RETRY_MAX_DELAY_SECONDS = 300
_PLAUSIBLE_CARD_REQUISITES_PATTERN = re.compile(r"^\d(?:[\s-]?\d){11,18}$")
_PLAUSIBLE_GENERIC_REQUISITES_PATTERN = re.compile(r"^[A-Za-z0-9:_-]{12,}$")


@dataclass(slots=True)
class RegisterResult:
    spec: BotSpec
    created: bool


class BotManager:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.registry = BotRegistry(settings.data_path)
        self.family_registry = FamilyRegistry(settings.data_path.with_name("family.json"))
        self._runtimes: dict[str, BotRuntime] = {}
        self._retry_tasks: dict[str, asyncio.Task[None]] = {}
        self._proxy_pool: list[str | None] = [None]

    async def start_registered_bots(self) -> None:
        specs = await self.registry.load()
        specs = await self._dedupe_specs(specs)
        family_state = await self._load_family_state(specs)
        await self.family_registry.save(family_state)
        self._proxy_pool = self._build_proxy_pool(family_state.proxies)
        specs = await self._ensure_synced_template(specs, family_state.template)
        specs = await self._ensure_synced_admin_ids(specs, family_state.admin_ids)
        specs = await self._ensure_synced_payment_methods(specs, family_state.payment_methods)
        logger.info("Restoring %s bot(s) from %s", len(specs), self.settings.data_path)
        for spec in specs:
            try:
                spec.template = normalize_template(spec.template)
                if not spec.admin_ids and self.settings.default_admin_ids:
                    spec.admin_ids = list(self.settings.default_admin_ids)
                await self.registry.upsert(spec)
                if spec.is_paused:
                    logger.info("Skipping paused bot @%s", spec.bot_username)
                    continue
                self._schedule_start(spec)
            except Exception:
                logger.exception("Failed to start stored bot %s", spec.bot_username or spec.token[:10])

    async def shutdown(self) -> None:
        for task in self._retry_tasks.values():
            task.cancel()
        for task in list(self._retry_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._retry_tasks.clear()
        for runtime in list(self._runtimes.values()):
            await stop_runtime(runtime)
        self._runtimes.clear()

    async def list_bots(self) -> list[BotSummary]:
        specs = await self.registry.load()
        items: list[BotSummary] = []
        for spec in specs:
            if spec.bot_id is None:
                continue
            items.append(
                BotSummary(
                    bot_id=spec.bot_id,
                    bot_username=spec.bot_username,
                    bot_name=spec.bot_name,
                    token=spec.token,
                    created_at=spec.created_at,
                    is_running=spec.token in self._runtimes and not spec.is_paused,
                    is_paused=spec.is_paused,
                    admin_ids=spec.admin_ids,
                    template=spec.template,
                )
            )
        return items

    async def register_bot(self, payload: CreateBotRequest) -> RegisterResult:
        existing = await self._find_by_token(payload.token)
        me = await self._fetch_me(payload.token)
        now = datetime.now(timezone.utc).isoformat()
        if payload.admin_ids is None:
            if existing and existing.admin_ids:
                admin_ids = list(existing.admin_ids)
            else:
                admin_ids = await self._get_shared_admin_ids()
        else:
            admin_ids = payload.admin_ids
        if payload.payment_methods is None:
            if existing and existing.payment_methods:
                payment_methods = self._clone_payment_methods(existing.payment_methods)
            else:
                payment_methods = await self._get_shared_payment_methods()
        else:
            payment_methods = self._clone_payment_methods(
                payload.payment_methods or await self._get_shared_payment_methods()
            )
        if payload.template is None:
            if existing is not None:
                template = normalize_template(existing.template)
            else:
                template = await self._get_shared_template()
        else:
            template = normalize_template(payload.template)
        spec = BotSpec(
            token=payload.token,
            template=template,
            payment_methods=payment_methods,
            admin_ids=admin_ids,
            is_paused=existing.is_paused if existing else False,
            bot_id=me.id,
            bot_username=me.username,
            bot_name=me.full_name,
            created_at=existing.created_at if existing else now,
        )

        created = existing is None
        await self.registry.upsert(spec)
        if payload.payment_methods is not None:
            await self.sync_payment_methods(payment_methods)
        await self._restart(spec)
        return RegisterResult(spec=spec, created=created)

    async def remove_bot(self, token: str) -> bool:
        existed = await self._exists(token)
        self._cancel_retry_task(token)
        runtime = self._runtimes.pop(token, None)
        if runtime:
            await stop_runtime(runtime)
        await self.registry.delete(token)
        return existed

    async def remove_bot_by_id(self, bot_id: int) -> bool:
        spec = await self._find_by_bot_id(bot_id)
        if spec is None:
            return False
        return await self.remove_bot(spec.token)

    async def toggle_bot_pause_by_id(self, bot_id: int) -> BotSpec | None:
        spec = await self._find_by_bot_id(bot_id)
        if spec is None:
            return None

        if spec.is_paused:
            spec.is_paused = False
            await self.registry.upsert(spec)
            self._schedule_start(spec)
            return spec

        spec.is_paused = True
        await self.registry.upsert(spec)
        self._cancel_retry_task(spec.token)
        runtime = self._runtimes.pop(spec.token, None)
        if runtime is not None:
            await stop_runtime(runtime)
        return spec

    async def persist_spec(self, spec: BotSpec) -> None:
        await self.registry.upsert(spec)

    def _users_registry_for(self, bot_id: int | None) -> UserRegistry:
        path = self.settings.data_path.with_name(
            f"{self.settings.data_path.stem}_users_{bot_id or 'unknown'}.json"
        )
        return UserRegistry(path)

    async def count_recipients(self) -> int:
        """Total known users across all running (non-paused) family bots, without sending."""
        total = 0
        for runtime in list(self._runtimes.values()):
            if runtime.spec.is_paused:
                continue
            registry = self._users_registry_for(runtime.spec.bot_id)
            user_ids = await registry.all_user_ids()
            total += len(user_ids)
        return total

    async def broadcast(self, text: str) -> dict[str, int]:
        """Send `text` to every known user of every running family bot."""
        bots_count = 0
        recipients = 0
        sent = 0
        failed = 0
        for runtime in list(self._runtimes.values()):
            if runtime.spec.is_paused:
                continue
            bots_count += 1
            registry = self._users_registry_for(runtime.spec.bot_id)
            user_ids = await registry.all_user_ids()
            recipients += len(user_ids)
            for user_id in user_ids:
                try:
                    await runtime.bot.send_message(user_id, text, disable_web_page_preview=True)
                    sent += 1
                except Exception as exc:
                    failed += 1
                    logger.debug("Broadcast to %s failed: %s", user_id, exc)
                await asyncio.sleep(0.05)  # stay under Telegram rate limits
        return {
            "bots_count": bots_count,
            "recipients_count": recipients,
            "sent_count": sent,
            "failed_count": failed,
        }

    async def sync_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> None:
        shared_payment_methods = self._clone_payment_methods(
            payment_methods or self.settings.default_payment_methods
        )
        family_state = await self._load_family_state()
        family_state.payment_methods = self._clone_payment_methods(shared_payment_methods)
        await self.family_registry.save(family_state)
        await self.registry.replace_payment_methods(shared_payment_methods)
        for runtime in self._runtimes.values():
            runtime.spec.payment_methods = self._clone_payment_methods(shared_payment_methods)

    async def sync_start_text(self, start_text: str) -> None:
        shared_template = await self._get_shared_template()
        shared_template.start_text = start_text
        family_state = await self._load_family_state()
        family_state.template = self._clone_template(shared_template)
        await self.family_registry.save(family_state)
        await self.registry.replace_template(shared_template)
        for runtime in self._runtimes.values():
            runtime.spec.template.start_text = start_text

    async def sync_template(self, template: TemplateOverrides) -> None:
        shared_template = self._clone_template(template)
        family_state = await self._load_family_state()
        family_state.template = self._clone_template(shared_template)
        await self.family_registry.save(family_state)
        await self.registry.replace_template(shared_template)
        for runtime in self._runtimes.values():
            runtime.spec.template = shared_template.model_copy(deep=True)

    async def sync_admin_ids(self, admin_ids: list[int]) -> None:
        shared_admin_ids = sorted(set(admin_ids))
        family_state = await self._load_family_state()
        family_state.admin_ids = list(shared_admin_ids)
        await self.family_registry.save(family_state)
        await self.registry.replace_admin_ids(shared_admin_ids)
        for runtime in self._runtimes.values():
            runtime.spec.admin_ids = list(shared_admin_ids)

    async def sync_proxies(self, proxies: list[ProxyConfig]) -> None:
        family_state = await self._load_family_state()
        family_state.proxies = [p.model_copy(deep=True) for p in proxies]
        await self.family_registry.save(family_state)
        self._proxy_pool = self._build_proxy_pool(proxies)
        logger.info("Proxy pool updated: %d proxies (+ server IP)", len(proxies))
        specs = await self.registry.load()
        for spec in specs:
            if spec.is_paused:
                continue
            await self._restart(spec)
            await asyncio.sleep(2)

    def _build_proxy_pool(self, proxies: list[ProxyConfig]) -> list[str | None]:
        pool: list[str | None] = [None]
        for proxy in proxies:
            url = proxy.url.strip()
            if url:
                pool.append(url)
        return pool

    def _proxy_url_for_token(self, token: str) -> str | None:
        if len(self._proxy_pool) <= 1:
            return None
        token_hash = sum(token.encode()) % len(self._proxy_pool)
        return self._proxy_pool[token_hash]

    async def _exists(self, token: str) -> bool:
        specs = await self.registry.load()
        return any(spec.token == token for spec in specs)

    async def _find_by_token(self, token: str) -> BotSpec | None:
        specs = await self.registry.load()
        return next((spec for spec in specs if spec.token == token), None)

    async def _find_by_bot_id(self, bot_id: int) -> BotSpec | None:
        specs = await self.registry.load()
        return next((spec for spec in specs if spec.bot_id == bot_id), None)

    async def _get_shared_payment_methods(self) -> list[PaymentMethodConfig]:
        family_state = await self._load_family_state()
        return self._clone_payment_methods(family_state.payment_methods)

    async def _get_shared_template(self) -> TemplateOverrides:
        family_state = await self._load_family_state()
        return self._clone_template(family_state.template)

    async def _get_shared_admin_ids(self) -> list[int]:
        family_state = await self._load_family_state()
        return list(family_state.admin_ids)

    async def _fetch_me(self, token: str):
        bot = Bot(token=token)
        try:
            return await bot.get_me()
        finally:
            await bot.session.close()

    async def _restart(self, spec: BotSpec) -> None:
        self._cancel_retry_task(spec.token)
        if spec.token in self._runtimes:
            await stop_runtime(self._runtimes.pop(spec.token))
        if spec.is_paused:
            return
        self._schedule_start(spec)

    async def _start(self, spec: BotSpec) -> None:
        proxy_url = self._proxy_url_for_token(spec.token)
        runtime = await start_runtime(
            self.settings,
            spec,
            self.persist_spec,
            self.register_bot,
            self.list_bots,
            self.remove_bot_by_id,
            self.toggle_bot_pause_by_id,
            self.sync_payment_methods,
            self.sync_start_text,
            self.sync_admin_ids,
            self.sync_template,
            proxy_url=proxy_url,
        )
        self._runtimes[spec.token] = runtime
        runtime.task.add_done_callback(
            lambda task, token=spec.token: self._handle_runtime_done(token, task)
        )

    def _handle_runtime_done(self, token: str, task) -> None:
        runtime = self._runtimes.get(token)
        if runtime is not None and runtime.task is task:
            self._runtimes.pop(token, None)
        try:
            task.result()
        except asyncio.CancelledError:
            return
        except (TelegramUnauthorizedError, TelegramForbiddenError) as error:
            # Токен отозван/бот заблокирован — перезапуск не поможет. Раньше такие
            # боты рестартовали каждые 5 с по кругу и грузили общий event loop.
            logger.error(
                "Bot %s has a permanently invalid token (%s), not retrying",
                token[:10],
                type(error).__name__,
            )
        except Exception:
            logger.exception("Bot runtime stopped with error for %s", token[:10])
            self._schedule_retry_for_token(token)

    def _schedule_start(self, spec: BotSpec) -> None:
        if spec.token in self._runtimes:
            return
        current_task = self._retry_tasks.get(spec.token)
        if current_task is not None and not current_task.done():
            return
        self._retry_tasks[spec.token] = asyncio.create_task(self._start_with_retry(spec.token))

    async def _start_with_retry(self, token: str) -> None:
        delay = START_RETRY_DELAY_SECONDS
        try:
            while True:
                spec = await self._find_by_token(token)
                if spec is None or spec.is_paused:
                    return
                try:
                    await self._start(spec)
                    return
                except asyncio.CancelledError:
                    raise
                except (TelegramUnauthorizedError, TelegramForbiddenError) as error:
                    logger.error(
                        "Cannot start bot %s: permanently invalid token (%s), giving up",
                        spec.bot_username or token[:10],
                        type(error).__name__,
                    )
                    return
                except Exception:
                    logger.exception(
                        "Failed to start bot %s, retrying in %s second(s)",
                        spec.bot_username or token[:10],
                        delay,
                    )
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, START_RETRY_MAX_DELAY_SECONDS)
        finally:
            current_task = self._retry_tasks.get(token)
            if current_task is asyncio.current_task():
                self._retry_tasks.pop(token, None)

    def _schedule_retry_for_token(self, token: str) -> None:
        if token in self._runtimes:
            return
        current_task = self._retry_tasks.get(token)
        if current_task is not None and not current_task.done():
            return
        self._retry_tasks[token] = asyncio.create_task(self._start_with_retry(token))

    def _cancel_retry_task(self, token: str) -> None:
        task = self._retry_tasks.pop(token, None)
        if task is not None:
            task.cancel()

    async def _ensure_synced_payment_methods(
        self,
        specs: list[BotSpec],
        shared_payment_methods: list[PaymentMethodConfig],
    ) -> list[BotSpec]:
        if not specs:
            return specs
        shared_payload = self._payment_methods_payload(shared_payment_methods)
        needs_sync = any(self._payment_methods_need_sync(spec.payment_methods, shared_payload) for spec in specs)
        if not needs_sync:
            for spec in specs:
                spec.payment_methods = self._clone_payment_methods(shared_payment_methods)
            return specs
        logger.info("Synchronizing payment methods for %s bot(s)", len(specs))
        return await self.registry.replace_payment_methods(shared_payment_methods)

    async def _ensure_synced_template(
        self,
        specs: list[BotSpec],
        shared_template: TemplateOverrides,
    ) -> list[BotSpec]:
        if not specs:
            return specs
        shared_payload = self._template_payload(shared_template)
        needs_sync = any(
            self._template_payload(spec.template) != shared_payload
            for spec in specs
        )
        if not needs_sync:
            for spec in specs:
                spec.template = shared_template.model_copy(deep=True)
            return specs
        logger.info("Synchronizing template for %s bot(s)", len(specs))
        return await self.registry.replace_template(shared_template)

    async def _ensure_synced_admin_ids(self, specs: list[BotSpec], shared_admin_ids: list[int]) -> list[BotSpec]:
        if not specs:
            return specs
        needs_sync = any(sorted(set(spec.admin_ids)) != shared_admin_ids for spec in specs)
        if not needs_sync:
            for spec in specs:
                spec.admin_ids = list(shared_admin_ids)
            return specs
        logger.info("Synchronizing admin IDs for %s bot(s)", len(specs))
        return await self.registry.replace_admin_ids(shared_admin_ids)

    async def _dedupe_specs(self, specs: list[BotSpec]) -> list[BotSpec]:
        if len(specs) < 2:
            return specs
        deduped_specs = self._select_unique_specs(specs)
        removed_count = len(specs) - len(deduped_specs)
        if removed_count <= 0:
            return specs
        logger.warning("Removed %s duplicate bot spec(s) from %s", removed_count, self.settings.data_path)
        await self.registry.save(deduped_specs)
        return deduped_specs

    def _select_unique_specs(self, specs: list[BotSpec]) -> list[BotSpec]:
        unique_specs: dict[tuple[str, str], BotSpec] = {}
        for spec in specs:
            identity = self._spec_identity(spec)
            current = unique_specs.get(identity)
            if current is None or self._spec_rank(spec) > self._spec_rank(current):
                unique_specs[identity] = spec
        return list(unique_specs.values())

    def _spec_identity(self, spec: BotSpec) -> tuple[str, str]:
        if spec.bot_id is not None:
            return ("bot_id", str(spec.bot_id))
        if spec.bot_username:
            return ("bot_username", spec.bot_username.casefold())
        return ("token", spec.token)

    def _spec_rank(self, spec: BotSpec) -> tuple[int, str]:
        return (
            int(self._token_matches_bot_id(spec)),
            spec.created_at or "",
        )

    def _token_matches_bot_id(self, spec: BotSpec) -> bool:
        if spec.bot_id is None:
            return False
        token_prefix = spec.token.split(":", maxsplit=1)[0]
        return token_prefix.isdigit() and int(token_prefix) == spec.bot_id

    def _resolve_shared_payment_methods(self, specs: list[BotSpec]) -> list[PaymentMethodConfig]:
        best_methods: list[PaymentMethodConfig] = []
        best_priority: tuple[int, int, int, str] | None = None
        for spec in specs:
            if not spec.payment_methods:
                continue
            normalized_methods = self._clone_payment_methods(spec.payment_methods)
            if not normalized_methods:
                continue
            priority = self._payment_methods_priority(spec, normalized_methods)
            if best_priority is None or priority > best_priority:
                best_methods = normalized_methods
                best_priority = priority
        if best_methods:
            return best_methods
        return self._clone_payment_methods(self.settings.default_payment_methods)

    def _payment_methods_priority(
        self,
        spec: BotSpec,
        payment_methods: list[PaymentMethodConfig],
    ) -> tuple[int, int, int, str]:
        populated_fields = sum(
            int(bool((method.requisites or "").strip())) + int(bool((method.details_text or "").strip()))
            for method in payment_methods
        )
        return (len(payment_methods), populated_fields, int(self._token_matches_bot_id(spec)), spec.created_at or "")

    def _resolve_shared_admin_ids(self, specs: list[BotSpec]) -> list[int]:
        for spec in specs:
            admin_ids = sorted(set(spec.admin_ids))
            if admin_ids:
                return admin_ids
        return sorted(set(self.settings.default_admin_ids))

    def _resolve_shared_template(self, specs: list[BotSpec]) -> TemplateOverrides:
        for spec in specs:
            template = self._clone_template(spec.template)
            if self._template_payload(template) != self._template_payload(None):
                return template
        if specs:
            return self._clone_template(specs[0].template)
        return self._clone_template(None)

    def _clone_template(self, template: TemplateOverrides | object | None) -> TemplateOverrides:
        return normalize_template(template).model_copy(deep=True)

    def _build_family_state(self, specs: list[BotSpec]) -> FamilyState:
        return FamilyState(
            template=self._resolve_shared_template(specs),
            payment_methods=self._resolve_shared_payment_methods(specs),
            admin_ids=self._resolve_shared_admin_ids(specs),
        )

    async def _load_family_state(self, specs: list[BotSpec] | None = None) -> FamilyState:
        current_specs = specs if specs is not None else await self.registry.load()
        fallback = self._build_family_state(current_specs)
        return await self.family_registry.load(fallback)

    def _clone_payment_methods(
        self,
        payment_methods: list[PaymentMethodConfig],
    ) -> list[PaymentMethodConfig]:
        normalized_methods: list[PaymentMethodConfig] = []
        deduped_by_identity: dict[tuple[str, str], PaymentMethodConfig] = {}
        method_order: list[tuple[str, str]] = []
        for method in payment_methods:
            normalized = method.model_copy(deep=True)
            if normalized.key in DISABLED_PAYMENT_METHOD_KEYS:
                continue
            identity = (normalized.key.strip().casefold(), normalized.label.strip().casefold())
            if identity not in deduped_by_identity:
                deduped_by_identity[identity] = normalized
                method_order.append(identity)
                continue
            deduped_by_identity[identity] = self._pick_better_payment_method(
                deduped_by_identity[identity],
                normalized,
            )
        for identity in method_order:
            normalized_methods.append(deduped_by_identity[identity].model_copy(deep=True))
        return normalized_methods

    def _pick_better_payment_method(
        self,
        current: PaymentMethodConfig,
        candidate: PaymentMethodConfig,
    ) -> PaymentMethodConfig:
        current_score = self._payment_method_quality(current)
        candidate_score = self._payment_method_quality(candidate)
        winner = current.model_copy(deep=True) if current_score >= candidate_score else candidate.model_copy(deep=True)
        loser = candidate if current_score >= candidate_score else current
        if not (winner.requisites or "").strip() and (loser.requisites or "").strip():
            winner.requisites = loser.requisites
        if not (winner.commission_text or "").strip() and (loser.commission_text or "").strip():
            winner.commission_text = loser.commission_text
        if not (winner.details_text or "").strip() and (loser.details_text or "").strip():
            winner.details_text = loser.details_text
        winner.qr_enabled = bool(winner.qr_enabled or loser.qr_enabled)
        return winner

    def _payment_method_quality(self, method: PaymentMethodConfig) -> tuple[int, int, int, int]:
        requisites = (method.requisites or "").strip()
        details_text = (method.details_text or "").strip()
        commission_text = (method.commission_text or "").strip()
        requisites_score = self._payment_requisites_quality(requisites)
        placeholder_score = int("{requisites}" in details_text)
        details_score = int(bool(details_text))
        commission_score = int(bool(commission_text))
        return (requisites_score, placeholder_score, details_score, commission_score)

    def _payment_requisites_quality(self, requisites: str) -> int:
        if not requisites:
            return 0
        upper_value = requisites.upper()
        if upper_value.endswith("_HERE"):
            return 1
        if _PLAUSIBLE_CARD_REQUISITES_PATTERN.fullmatch(requisites) is not None:
            return 4
        if _PLAUSIBLE_GENERIC_REQUISITES_PATTERN.fullmatch(requisites) is not None:
            return 3
        if len(requisites) >= 6:
            return 2
        return 0

    def _payment_methods_need_sync(
        self,
        payment_methods: list[PaymentMethodConfig],
        shared_payload: list[dict[str, object]],
    ) -> bool:
        normalized_methods = self._clone_payment_methods(payment_methods)
        if len(normalized_methods) != len(payment_methods):
            return True
        return self._payment_methods_payload(normalized_methods) != shared_payload

    def _payment_methods_payload(self, payment_methods: list[PaymentMethodConfig]) -> list[dict[str, object]]:
        return [method.model_dump(mode="json") for method in self._clone_payment_methods(payment_methods)]

    def _template_payload(self, template: TemplateOverrides | object | None) -> dict[str, object]:
        return self._clone_template(template).model_dump(mode="json")
