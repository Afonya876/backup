from __future__ import annotations

from html import escape

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from vip_shop.config import BotSpec, PaymentMethodConfig
from vip_shop.template import format_payment_method_title, resolve_payment_requisites


def payment_admin_menu(spec: BotSpec) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=format_payment_method_title(method), callback_data=f"admin:payment_method:{index}")]
        for index, method in enumerate(spec.payment_methods)
    ]
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_method_editor_menu(method_index: int, method: PaymentMethodConfig) -> InlineKeyboardMarkup:
    qr_label = "QR: включен" if method.qr_enabled else "QR: выключен"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Изменить комиссию", callback_data=f"admin:payment_commission:{method_index}")],
            [InlineKeyboardButton(text="Изменить кошелек", callback_data=f"admin:payment_requisites:{method_index}")],
            [InlineKeyboardButton(text=qr_label, callback_data=f"admin:payment_qr:{method_index}")],
            [InlineKeyboardButton(text="Назад", callback_data="admin:payments")],
        ]
    )


def build_payments_admin_text(spec: BotSpec) -> str:
    lines = ["<b>Способы оплаты</b>", ""]
    if not spec.payment_methods:
        lines.append("Методы оплаты еще не настроены.")
    else:
        for method in spec.payment_methods:
            qr_status = "QR включен" if method.qr_enabled else "QR выключен"
            commission_text = (method.commission_text or "").strip() or "без комиссии"
            requisites_text = "заданы" if resolve_payment_requisites(method) else "не заданы"
            lines.append(
                f"- {escape(method.label)} | Комиссия: {escape(commission_text)} | "
                f"Реквизиты: {requisites_text} | {qr_status}"
            )
    lines.append("")
    lines.append("Доступны только USDT TRC20 и LTC. Выберите способ для смены комиссии или кошелька.")
    return "\n".join(lines)


def build_payment_method_editor_text(method: PaymentMethodConfig) -> str:
    qr_status = "включен" if method.qr_enabled else "выключен"
    requisites_text = resolve_payment_requisites(method) or "не указаны"
    return (
        "<b>Редактор способа оплаты</b>\n\n"
        f"Название: {escape(method.label)}\n"
        f"Комиссия: {escape((method.commission_text or '').strip() or 'не указана')}\n"
        f"Кошелек: {escape(requisites_text)}\n"
        f"QR: {qr_status}\n\n"
        "Текущий шаблон:\n"
        f"<pre>{escape(method.details_text)}</pre>"
    )
