from __future__ import annotations

import io
import os
import random
import string

from PIL import Image, ImageDraw, ImageFont

_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Verdana Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]

FONT_PATH = next((p for p in _FONT_CANDIDATES if os.path.exists(p)), _FONT_CANDIDATES[0])
IMG_W, IMG_H = 480, 140
FONT_SIZE = 72
TEXT_LEN = 5
BG_COLOR = (255, 255, 255)
TEXT_COLOR = (30, 30, 30)


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_PATH, size)


def generate_captcha_image(text: str) -> bytes:
    font = _load_font(FONT_SIZE)

    img = Image.new("RGB", (IMG_W, IMG_H), BG_COLOR)
    draw = ImageDraw.Draw(img)

    for _ in range(3):
        y = random.randint(0, IMG_H)
        draw.line(
            (0, y, IMG_W, y + random.randint(-20, 20)),
            fill=(200, 200, 200),
            width=1,
        )

    total_text_w = 0
    char_widths = []
    for ch in text:
        bbox = font.getbbox(ch)
        w = bbox[2] - bbox[0]
        char_widths.append(w)
        total_text_w += w

    spacing = (IMG_W - total_text_w) / (len(text) + 1)
    x_cursor = spacing

    for i, ch in enumerate(text):
        bbox = font.getbbox(ch)
        ch_h = bbox[3] - bbox[1]
        py = (IMG_H - ch_h) // 2 + random.randint(-5, 5)
        angle = random.uniform(-5, 5)

        ch_img = Image.new("RGBA", (char_widths[i] + 10, ch_h + 10), (0, 0, 0, 0))
        ch_draw = ImageDraw.Draw(ch_img)
        ch_draw.text((5, 5 - bbox[1]), ch, fill=TEXT_COLOR, font=font)
        ch_img = ch_img.rotate(angle, expand=True, fillcolor=(0, 0, 0, 0))

        img.paste(ch_img, (int(x_cursor), py), ch_img)
        x_cursor += char_widths[i] + spacing

    for _ in range(10):
        draw.point(
            (random.randint(0, IMG_W), random.randint(0, IMG_H)),
            fill=(180, 180, 180),
        )

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def generate_captcha_text() -> str:
    chars = string.ascii_uppercase + string.digits
    chars = chars.replace("O", "").replace("0", "").replace("I", "").replace("1", "")
    return "".join(random.choices(chars, k=TEXT_LEN))
