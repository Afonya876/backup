# Деплой KFC_vip1 на сервер

## Первоначальная установка

1. Скопируйте папку `KFC_vip1` на сервер:
   ```bash
   scp -r KFC_vip1 root@your-server:/root/
   ```

2. Зайдите на сервер и запустите установку:
   ```bash
   ssh root@your-server
   cd /root/KFC_vip1
   bash scripts/install_server.sh
   ```

3. Создайте `.env` файл:
   ```bash
   cd /root/KFC_vip1
   nano .env
   ```
   
   Содержимое `.env`:
   ```
   API_HOST=127.0.0.1
   API_PORT=18748
   MASTER_API_KEY=your-secret-key-here
   BOT_TOKEN=8642711880:AAGSwasjgkjO-2kcgX3WIniMsoMZj1e8fXA
   ```

4. Запустите бота:
   ```bash
   systemctl restart kfc-vip1-bot
   systemctl status kfc-vip1-bot
   ```

## Обновление кода

Используйте скрипт `upload_to_server.sh`:

```bash
cd KFC_vip1
./scripts/upload_to_server.sh root@your-server
```

Затем перезапустите бота:
```bash
ssh root@your-server 'systemctl restart kfc-vip1-bot'
```

## Полезные команды

```bash
# Статус сервиса
systemctl status kfc-vip1-bot

# Логи в реальном времени
journalctl -u kfc-vip1-bot -f

# Перезапуск
systemctl restart kfc-vip1-bot

# Остановка
systemctl stop kfc-vip1-bot

# Проверка health endpoint
curl http://127.0.0.1:18748/health
```

## Интеграция с мультиадминкой

Добавьте в `multy_admin/central_admin/.env`:
```
VIP1_API_BASE=http://your-server:18748
VIP1_API_KEY=your-secret-key-here
```

Затем перезапустите мультиадминку.
