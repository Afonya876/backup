from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from html import escape

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from vip_shop.config import (
    BotSpec,
    BotSummary,
    build_visible_start_cities,
    CityConfig,
    ExchangerLink,
    extract_payment_requisites,
    PaymentMethodConfig,
    PAYMENT_REQUISITES_PLACEHOLDER,
    ProductConfig,
    ProductOption,
    Settings,
    TemplateOverrides,
    normalize_payment_details_template,
    normalize_template,
)
from vip_shop.crypto_rates import convert_amount


MEDICAL_HELP_BUTTON_TEXT = "Передоз"
MEDICAL_HELP_TEXT = """Передоз

Передозировка марихуаной(гашиш,масло,шишки): http://telegra.ph/Peredozirovka-marihuanoj-shishki-gashish-maslo-03-18

Острая интоксикация NBOMe: http://telegra.ph/Ostraya-intoksikaciya-25-NBOMe-03-17

Передозировка A-PVP/MDVP: http://telegra.ph/Peredozirovka-A-PVPMDPV-03-17

Передозировка амфетамином/метамфетамином: https://telegra.ph/Peredozirovka-amfetaminommetamfetaminom-03-17

Курительные смеси (синтетические каннабиноиды, миксы, спайсы):
http://telegra.ph/Kuritelnye-smesi-sinteticheskie-kannabinoidy-miksy-spajsy-03-17

Сердечно-легочная реанимация (если остановилось дыхание и сердце):
http://telegra.ph/Serdechno-legochnaya-reanimaciya-esli-ostanovilos-dyhanie-i-serdce-03-17

Передозировка опиатами (героин/метадон):
http://telegra.ph/Peredozirovka-opiatami-geroinmetadon-03-17

Передозировка Мефедроном:
http://telegra.ph/Peredozirovka-Mefedronom-03-17"""


PAYMENT_WAITING_TEXT = """Оплата ожидается
Если вы оплатили свой заказ и с момента оплаты прошло не более 10 минут, не стоит волноваться.
При оплате с помощью Bitcoin возможны задержки до нескольких часов, в зависимости от комиссии и загруженности сети."""


PAYMENT_HELP_TEXT = """Помощь по боту автопродаж
Доступные команды:
/status или /last - последний заказ.
/pin - узнать свой пин.
/bots - список ботов для покупок.
/reviews - последние отзывы.
/balance - проверить баланс.
/addbalance - пополнить баланс.

Отправить мнение о продукции магазина:
/review Отличный товар, вес и место!
Пишем команду /review и сразу после - текст отзыва о приобретенном товаре.
Аналогичным образом можно отправить боту сообщение, используя форму send:
/send Скажите, когда ждать расширения ассортимента?

Для регистрации на сайте, выполните команду:
/register username (вместо username напишите жилаемый логин), в результате которой бот пришлет пароль к учетной записи.
/newpassword passnew или /newpass passnew позволит изменить свой пароль на сайте
/profile просмотреть свой профайл
Реферальная система для ботов 🤖 по команде /referal"""


PAYMENT_EXTEND_CARD_TEXT = """Нельзя продливать данный способ оплаты"""


PIN_TEXT = PAYMENT_WAITING_TEXT


PAYMENT_EXIT_CONFIRMATION_TEXT = """Вы действительно хотите выйти из оплаты?

Если вы оплатите товар после выхода из оплаты, нужно будет заново его выбрать и нажать проверить оплату"""


ORDER_CANCEL_CONFIRMATION_TEXT = """Заказ будет отменен. Ты уверен?!"""


PAYMENT_METHOD_CHANGED_TEXT = """Вы изменили платежную систему и теперь нужно производить оплату строго по нижеследующим данным, иначе платеж не будет зачислен автоматически!"""
START_MENU_PAGE_SIZE = 8
CITY_MENU_PAGE_SIZE = 8
_START_MENU_PROMPT_RE = re.compile(r"(?:\n\s*)?ВЫБИРАЙ ГОРОД НИЖЕ:(?:\s+\d+/\d+)?\s*$", re.IGNORECASE)


def _get_start_menu_cities(settings: Settings) -> list[CityConfig]:
    return build_visible_start_cities(settings.cities)


def find_start_menu_page(settings: Settings, city_key: str) -> int:
    visible_cities = _get_start_menu_cities(settings)
    for index, city in enumerate(visible_cities):
        if city.key == city_key:
            return index // START_MENU_PAGE_SIZE
    return 0


def find_city_menu_page(city: CityConfig, product_index: int) -> int:
    total_pages = max(1, (len(city.products) + CITY_MENU_PAGE_SIZE - 1) // CITY_MENU_PAGE_SIZE)
    page = product_index // CITY_MENU_PAGE_SIZE if product_index >= 0 else 0
    return max(0, min(page, total_pages - 1))


def build_start_text(template: TemplateOverrides, *, page: int = 0, total_pages: int = 1) -> str:
    template = normalize_template(template)
    start_text = (template.start_text or "").strip()
    if not start_text:
        shop_name = escape((template.shop_name or "").strip() or "KFC")
        start_text = (
            f"Добро пожаловать в бот <b>{shop_name}</b>\n\n"
            "Мы очень ценим ваш выбор, и всегда готовы радовать вас\n"
            "высококачественным товаром, по приятным ценам)"
        )
    start_text = _START_MENU_PROMPT_RE.sub("", start_text).rstrip()
    prompt = "<b>ВЫБИРАЙ ГОРОД НИЖЕ:</b>"
    if total_pages > 1:
        prompt = f"{prompt} {page + 1}/{total_pages}"
    return f"{start_text}\n\n{prompt}" if start_text else prompt


SUPPORTED_LANGUAGES = ["ru", "en", "pl"]

LOCALE: dict[str, dict[str, str]] = {
    "ru": {
        "lang_prompt": "Выберите язык:",
        "reg_title": "РЕГИСТРАЦИЯ НОВОГО ПОЛЬЗОВАТЕЛЯ",
        "save_login": "Хотите сохранить логин <b>{login}</b>?",
        "yes": "Да",
        "no": "Нет",
        "enter_login": "Придумайте логин: больше 5 символов, латиница/цифры/_.",
        "login_short": "Логин должен быть больше 5 символов. Попробуйте ещё раз.",
        "login_bad": "Можно только латиницу, цифры и _ (6–32 символа).",
        "login_system": "Этот логин занят или системный. Придумайте другой.",
        "city_prompt": "⏩ Напишите название города в котором хотите приобретать товар",
        "ok": "Ок",
        "searching": "⏩ Идёт поиск города «{q}»…",
        "not_found": "Не удалось распознать введенное название города, возможно вы допустили ошибку. Обратитесь за помощью к нашему оператору.\n\n{op}",
        "suggestions": "Не удалось точно распознать город. Возможно, вы имели в виду один из вариантов ниже?\n\nЕсли вашего города нет — напишите его ещё раз или обратитесь к оператору {op}",
        "enter_again": "Ввести город заново",
        "city_header": "Вы выбрали город {city}. Какой товар интересует?",
        "mm_welcome": "{name}, добро пожаловать!",
        "mm_your_city": "Ваш город",
        "mm_total_buys": "Всего покупок",
        "mm_total_sum": "Общая сумма",
        "mm_desc": "Я бот-автопродаж, через меня можно совершать покупки. Покупать через меня удобно, быстро и доступно в любое время! Не торопитесь нажимать на кнопки и читайте всё, что я пишу.",
        "btn_ready": "Готовые закладки ✅",
        "btn_order": "Заказать закладку ⏳",
        "btn_questions": "Вопросы ❓",
        "btn_price": "$ Прайс $",
        "btn_site": "🌐 Сайт-инфо 🌐",
        "btn_reviews": "👍 Отзывы 👎",
        "btn_work": "⚒ Работа ⚒",
        "btn_chat": "👤 Чат 👤",
        "btn_complaints": "😈 Жалобы 😈",
        "btn_change_city": "🔄 Сменить город 🔄",
        "operator_after_pay": "После оплаты с вами свяжется оператор.",
        "not_configured": "Раздел пока не настроен.",
    },
    "en": {
        "lang_prompt": "Choose your language:",
        "reg_title": "NEW USER REGISTRATION",
        "save_login": "Do you want to save the login <b>{login}</b>?",
        "yes": "Yes",
        "no": "No",
        "enter_login": "Choose a login: more than 5 characters, latin/digits/_.",
        "login_short": "Login must be longer than 5 characters. Try again.",
        "login_bad": "Only latin letters, digits and _ (6–32 chars).",
        "login_system": "This login is taken or reserved. Choose another.",
        "city_prompt": "⏩ Write the name of the city where you want to buy",
        "ok": "OK",
        "searching": "⏩ Searching for the city «{q}»…",
        "not_found": "Could not recognize the entered city name, maybe you made a mistake. Please contact our operator.\n\n{op}",
        "suggestions": "Could not recognize the city exactly. Maybe you meant one of the options below?\n\nIf your city is not listed — type it again or contact the operator {op}",
        "enter_again": "Enter the city again",
        "city_header": "You selected {city}. Which product are you interested in?",
        "mm_welcome": "{name}, welcome!",
        "mm_your_city": "Your city",
        "mm_total_buys": "Total purchases",
        "mm_total_sum": "Total amount",
        "mm_desc": "I am an auto-sales bot, you can make purchases through me. Buying through me is convenient, fast and available any time! Don't rush to press buttons and read everything I write.",
        "btn_ready": "Ready stashes ✅",
        "btn_order": "Order a stash ⏳",
        "btn_questions": "Questions ❓",
        "btn_price": "$ Price $",
        "btn_site": "🌐 Site info 🌐",
        "btn_reviews": "👍 Reviews 👎",
        "btn_work": "⚒ Work ⚒",
        "btn_chat": "👤 Chat 👤",
        "btn_complaints": "😈 Complaints 😈",
        "btn_change_city": "🔄 Change city 🔄",
        "operator_after_pay": "After payment an operator will contact you.",
        "not_configured": "This section is not set up yet.",
    },
    "pl": {
        "lang_prompt": "Wybierz język:",
        "reg_title": "REJESTRACJA NOWEGO UŻYTKOWNIKA",
        "save_login": "Czy chcesz zapisać login <b>{login}</b>?",
        "yes": "Tak",
        "no": "Nie",
        "enter_login": "Wymyśl login: więcej niż 5 znaków, litery/cyfry/_.",
        "login_short": "Login musi mieć więcej niż 5 znaków. Spróbuj ponownie.",
        "login_bad": "Tylko litery łacińskie, cyfry i _ (6–32 znaki).",
        "login_system": "Ten login jest zajęty lub systemowy. Wybierz inny.",
        "city_prompt": "⏩ Napisz nazwę miasta, w którym chcesz kupować",
        "ok": "OK",
        "searching": "⏩ Trwa wyszukiwanie miasta «{q}»…",
        "not_found": "Nie udało się rozpoznać wprowadzonej nazwy miasta, być może popełniłeś błąd. Skontaktuj się z naszym operatorem.\n\n{op}",
        "suggestions": "Nie udało się dokładnie rozpoznać miasta. Może chodziło o jeden z poniższych wariantów?\n\nJeśli Twojego miasta nie ma — napisz je ponownie lub skontaktuj się z operatorem {op}",
        "enter_again": "Wpisz miasto ponownie",
        "city_header": "Wybrałeś miasto {city}. Jaki produkt Cię interesuje?",
        "mm_welcome": "{name}, witaj!",
        "mm_your_city": "Twoje miasto",
        "mm_total_buys": "Łączna liczba zakupów",
        "mm_total_sum": "Łączna kwota",
        "mm_desc": "Jestem botem automatycznej sprzedaży, przeze mnie możesz dokonywać zakupów. Kupowanie przeze mnie jest wygodne, szybkie i dostępne o każdej porze! Nie spiesz się z naciskaniem przycisków i czytaj wszystko, co piszę.",
        "btn_ready": "Gotowe skrytki ✅",
        "btn_order": "Zamów skrytkę ⏳",
        "btn_questions": "Pytania ❓",
        "btn_price": "$ Cennik $",
        "btn_site": "🌐 Info o stronie 🌐",
        "btn_reviews": "👍 Opinie 👎",
        "btn_work": "⚒ Praca ⚒",
        "btn_chat": "👤 Czat 👤",
        "btn_complaints": "😈 Skargi 😈",
        "btn_change_city": "🔄 Zmień miasto 🔄",
        "operator_after_pay": "Po opłaceniu skontaktuje się z Tobą operator.",
        "not_configured": "Ta sekcja nie jest jeszcze skonfigurowana.",
    },
}


def t(lang: str | None, key: str) -> str:
    table = LOCALE.get(lang or "ru", LOCALE["ru"])
    return table.get(key) or LOCALE["ru"][key]


def format_operator_handle(template: TemplateOverrides) -> str:
    username = (template.operator_username or "").strip().lstrip("@")
    return f"@{username}" if username else "оператору"


def build_language_prompt_text(lang: str | None = None) -> str:
    return "Выберите язык:"


def build_language_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Русский", callback_data="lang:ru"),
                InlineKeyboardButton(text="English", callback_data="lang:en"),
                InlineKeyboardButton(text="Polski", callback_data="lang:pl"),
            ]
        ]
    )


def start_cities_menu(cities: list[CityConfig]) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=city.label, callback_data=f"start:city:{city.key}")]
        for city in cities
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_login_confirm_text(lang: str | None, login: str) -> str:
    return (
        f"<b>{t(lang, 'reg_title')}</b>\n"
        "➖➖➖➖➖➖\n\n"
        f"{t(lang, 'save_login').format(login=escape(login))}"
    )


def login_confirm_menu(lang: str | None = None) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t(lang, "yes"), callback_data="login:yes"),
                InlineKeyboardButton(text=t(lang, "no"), callback_data="login:no"),
            ]
        ]
    )


def build_enter_login_text(lang: str | None = None) -> str:
    return f"<b>{t(lang, 'reg_title')}</b>\n➖➖➖➖➖➖\n\n{t(lang, 'enter_login')}"


def build_registration_prompt_text(lang: str | None = None) -> str:
    return (
        f"<b>{t(lang, 'reg_title')}</b>\n"
        "➖➖➖➖➖➖\n\n"
        f"{t(lang, 'city_prompt')}"
    )


def build_city_searching_text(query: str, lang: str | None = None) -> str:
    return (
        "<b>🔎 ПОИСК ГОРОДА</b>\n"
        "➖➖➖➖➖➖\n\n"
        f"{t(lang, 'searching').format(q=escape(query))}"
    )


def build_city_not_found_text(template: TemplateOverrides, lang: str | None = None) -> str:
    return t(lang, "not_found").format(op=format_operator_handle(template))


def build_city_suggestions_text(template: TemplateOverrides, lang: str | None = None) -> str:
    return t(lang, "suggestions").format(op=format_operator_handle(template))


# Bot API 9.4+: style="success" paints the button green ("danger"=red, "primary"=blue).
ORDER_TYPES = ["Магнит", "Прикоп", "Тайник", "Камень"]
SUPPORT_DOCTOR_URL = "https://t.me/dockg"


def build_order_type_text() -> str:
    return "Выберите тип ⤵️"


def build_order_summary_text(
    order_id: int,
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
) -> str:
    amount = _build_order_display_fields(product, option)[2] or extract_rub_price(option.label) or "уточняется"
    return (
        f"Идентификатор вашей покупки: № <b>{order_id}</b>\n"
        f"Сумма к оплате: <b>{escape(amount)}</b>\n"
        f"Местоположение: {escape(city.icon)} <b>{escape(city.label)}</b>\n"
        f"Локация/Ближайшая станция: <b>{escape(district)}</b>\n\n"
        "Пожалуйста, перейдите к оплате, нажав кнопку ОПЛАТИТЬ.\n"
        "Обратите внимание: после начала процесса оплаты у вас будет 30 минут для её завершения."
    )


def method_coin(method: PaymentMethodConfig) -> str | None:
    src = f"{method.key} {method.label}".casefold()
    if "btc" in src:
        return "BTC"
    if "ltc" in src:
        return "LTC"
    if "usdt" in src or "trc" in src or "bep" in src:
        return "USDT"
    return None


def is_crypto_method(method: PaymentMethodConfig) -> bool:
    return method_coin(method) is not None


def build_crypto_payment_text(
    coin: str,
    address: str,
    crypto_amount: str | None,
    rub_amount: str | None,
) -> str:
    if crypto_amount:
        head = f"Оплатите <code>{escape(crypto_amount)}</code> {escape(coin)} на адрес"
    elif rub_amount:
        head = f"Оплатите сумму, эквивалентную {escape(rub_amount)}, в {escape(coin)} на адрес"
    else:
        head = f"Оплатите в {escape(coin)} на адрес"
    return f"{head}\n<code>{escape(address)}</code>"


def crypto_payment_menu(
    exchangers: list[ExchangerLink],
    cancel_callback: str | None = None,
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for exchanger in exchangers:
        url = (exchanger.url or "").strip()
        if url:
            rows.append([InlineKeyboardButton(text=exchanger.label, url=url)])
    if cancel_callback:
        rows.append([InlineKeyboardButton(text="Отменить заказ", callback_data=cancel_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def order_cancel_only_menu(cancel_callback: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Отменить заказ", callback_data=cancel_callback)]
        ]
    )


def build_exchangers_admin_text(exchangers: list[ExchangerLink]) -> str:
    lines = ["<b>Обменники</b>", "", "Кнопки-ссылки на крипто-экране оплаты:"]
    if not exchangers:
        lines.append("Список пуст.")
    else:
        for index, exchanger in enumerate(exchangers, start=1):
            lines.append(f"{index}. {escape(exchanger.label)} → {escape(exchanger.url)}")
    lines.extend(["", "Нажмите ❌ чтобы удалить, или добавьте новый."])
    return "\n".join(lines)


def exchangers_admin_menu(exchangers: list[ExchangerLink]) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"❌ {exchanger.label}", callback_data=f"admin:exchanger_delete:{index}")]
        for index, exchanger in enumerate(exchangers)
    ]
    rows.append([InlineKeyboardButton(text="Добавить обменник", callback_data="admin:exchanger_add")])
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def order_summary_menu(
    pay_callback: str,
    cancel_callback: str,
    operator_url: str | None = None,
) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="Оплатить", callback_data=pay_callback)]]
    if operator_url:
        rows.append([InlineKeyboardButton(text="✍️ Связаться с оператором", url=operator_url)])
    rows.append([InlineKeyboardButton(text="Отмена", callback_data=cancel_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def order_type_menu(type_indexes: list[int], order_suffix: str) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=ORDER_TYPES[i], callback_data=f"ordertype:{i}:{order_suffix}")]
        for i in type_indexes
        if 0 <= i < len(ORDER_TYPES)
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def registration_menu(lang: str | None = None) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t(lang, "ok"), callback_data="reg:ok")]]
    )


def city_not_found_menu(lang: str | None = None) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t(lang, "ok"), callback_data="reg:retry")]]
    )


def city_suggestions_menu(cities: list[CityConfig], lang: str | None = None) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=city.label, callback_data=f"regcity:{city.key}")]
        for city in cities
    ]
    rows.append(
        [InlineKeyboardButton(text=t(lang, "enter_again"), callback_data="reg:retry")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def main_menu(
    settings: Settings,
    template: TemplateOverrides,
    *,
    page: int = 0,
) -> tuple[InlineKeyboardMarkup, int, int]:
    _ = template
    rows: list[list[InlineKeyboardButton]] = []
    visible_cities = _get_start_menu_cities(settings)
    total_pages = max(1, (len(visible_cities) + START_MENU_PAGE_SIZE - 1) // START_MENU_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    page_cities = visible_cities[page * START_MENU_PAGE_SIZE : (page + 1) * START_MENU_PAGE_SIZE]
    city_buttons = [
        InlineKeyboardButton(
            text=city.label,
            callback_data=f"city:{city.key}",
        )
        for city in page_cities
    ]
    for index in range(0, len(city_buttons), 2):
        rows.append(city_buttons[index : index + 2])
    if total_pages > 1:
        prev_page = (page - 1) % total_pages
        next_page = (page + 1) % total_pages
        rows.append(
            [
                InlineKeyboardButton(text="◀️", callback_data=f"nav:start_page:{prev_page}"),
                InlineKeyboardButton(text=f"{page + 1}/{total_pages}", callback_data=f"nav:start_page:{page}"),
                InlineKeyboardButton(text="▶️", callback_data=f"nav:start_page:{next_page}"),
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows), page, total_pages


def _is_delivery_product(product: ProductConfig) -> bool:
    return (product.key or "").startswith("dlv_")


def city_menu(
    city: CityConfig,
    *,
    page: int = 0,
) -> tuple[InlineKeyboardMarkup, int, int]:
    # "Готовые закладки": ready stash products only (no delivery items).
    ready_products = [(idx, p) for idx, p in enumerate(city.products) if not _is_delivery_product(p)]
    total_pages = max(1, (len(ready_products) + 7) // 8)
    current_page = max(0, min(page, total_pages - 1))
    start = current_page * 8
    end = start + 8
    page_products = ready_products[start:end]

    rows = [
        [
            InlineKeyboardButton(
                text=product.button_label or product.label,
                callback_data=f"item:{city.key}:{orig_idx}",
            )
        ]
        for orig_idx, product in page_products
    ]

    if total_pages > 1:
        prev_data = f"nav:city_page:{city.key}:{current_page - 1}" if current_page > 0 else "noop"
        next_data = f"nav:city_page:{city.key}:{current_page + 1}" if current_page < total_pages - 1 else "noop"
        nav_row = [
            InlineKeyboardButton(text="◀️", callback_data=prev_data),
            InlineKeyboardButton(text=f"{current_page + 1}/{total_pages}", callback_data="noop"),
            InlineKeyboardButton(text="▶️", callback_data=next_data),
        ]
        rows.append(nav_row)

    return InlineKeyboardMarkup(inline_keyboard=rows), current_page, total_pages


def delivery_menu(city: CityConfig) -> InlineKeyboardMarkup:
    # "Заказать закладку" / Доставка по городу: full delivery catalog (dlv_* products).
    rows = [
        [
            InlineKeyboardButton(
                text=product.button_label or product.label,
                callback_data=f"item:{city.key}:{product_index}",
            )
        ]
        for product_index, product in enumerate(city.products)
        if _is_delivery_product(product)
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=f"nav:citymenu:{city.key}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_delivery_text(city: CityConfig, lang: str | None = None) -> str:
    return f"🚚 Доставка по городу {escape(city.label)}. Выберите товар:"


def option_menu(city: CityConfig, product_index: int, product: ProductConfig) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=option.label,
                callback_data=f"variant:{city.key}:{product_index}:{option_index}",
            )
        ]
        for option_index, option in enumerate(product.options)
    ]
    back = f"shop:order:{city.key}" if (product.key or "").startswith("dlv_") else f"shop:ready:{city.key}"
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=back)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def district_menu(
    city: CityConfig,
    product_index: int,
    option_index: int,
    districts: list[tuple[int, str]],
    back_callback: str | None = None,
) -> InlineKeyboardMarkup:
    buttons = [
        InlineKeyboardButton(
            text=district,
            callback_data=f"district:{city.key}:{product_index}:{option_index}:{district_index}",
        )
        for district_index, district in districts
    ]
    # 2 districts per row.
    rows = [buttons[i : i + 2] for i in range(0, len(buttons), 2)]
    if back_callback:
        rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=back_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def promo_menu() -> InlineKeyboardMarkup | None:
    return simple_back_menu()


def purchases_menu() -> InlineKeyboardMarkup | None:
    return simple_back_menu()


def rules_menu() -> InlineKeyboardMarkup | None:
    return simple_back_menu()


def format_payment_method_title(method: PaymentMethodConfig) -> str:
    commission_text = (method.commission_text or "").strip()
    if not commission_text:
        return method.label
    return f"{method.label} ({commission_text})"


def _get_payment_method_button_label(method: PaymentMethodConfig) -> str:
    method_key = (method.key or "").strip().casefold()
    method_label = (method.label or "").strip().casefold()
    if method_key == "ltc" or method_label == "ltc":
        return "LTC"
    if method_key in {"usdt_trc20", "usdt_trx20"} or method_label in {"usdt trc20", "usdt trx20"}:
        return "USDT TRX20"
    return method.label


def format_payment_method_button_title(method: PaymentMethodConfig) -> str:
    commission_text = (method.commission_text or "").strip()
    button_label = _get_payment_method_button_label(method)
    if not commission_text:
        return button_label
    return f"{button_label} ({commission_text})"


_COMMISSION_PERCENT_PATTERN = re.compile(r"^\s*(?P<sign>[+-])\s*(?P<value>\d+(?:[.,]\d+)?)\s*%\s*$")
_AMOUNT_VALUE_PATTERN = re.compile(r"^\s*(?P<value>\d+(?:[.,]\d+)?)\s*(?P<unit>.*)$")


def _apply_commission_to_amount(amount_text: str, method: PaymentMethodConfig) -> str:
    commission_text = (method.commission_text or "").strip()
    if not commission_text:
        return amount_text

    commission_match = _COMMISSION_PERCENT_PATTERN.fullmatch(commission_text)
    amount_match = _AMOUNT_VALUE_PATTERN.fullmatch(amount_text.strip())
    if commission_match is None or amount_match is None:
        return amount_text

    raw_value = amount_match.group("value").replace(",", ".")
    unit = amount_match.group("unit").strip()
    try:
        base_amount = Decimal(raw_value)
        percent_value = Decimal(commission_match.group("value"))
    except InvalidOperation:
        return amount_text

    multiplier = Decimal("1")
    if commission_match.group("sign") == "+":
        multiplier += percent_value / Decimal("100")
    else:
        multiplier -= percent_value / Decimal("100")
    unit_marker = unit.strip().casefold().replace(".", "")
    precision = Decimal("0.00000001") if unit_marker == "ltc" else Decimal("0.01")
    adjusted_amount = (base_amount * multiplier).quantize(precision, rounding=ROUND_CEILING)
    adjusted_text = _format_decimal_amount(adjusted_amount)
    return adjusted_text if not unit else f"{adjusted_text} {unit}"


def payment_methods_menu(
    callback_prefix: str | None,
    methods: list[PaymentMethodConfig],
    cancel_callback: str | None = None,
    cancel_text: str = "Отменить оплату",
    amount_text: str | None = None,
    back_callback: str | None = None,
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for index, method in enumerate(methods):
        callback_data = f"payment:generic:{index}" if callback_prefix is None else f"payment:{callback_prefix}:{index}"
        method_title = format_payment_method_button_title(method)
        if amount_text:
            payable_amount = _format_display_amount_text(amount_text, method, apply_commission=True)
            amount_match = _AMOUNT_VALUE_PATTERN.fullmatch(payable_amount.strip())
            if amount_match is not None:
                payable_amount = amount_match.group("value")
            method_title = f"{method_title}. К оплате: {payable_amount}"
        rows.append([InlineKeyboardButton(text=method_title, callback_data=callback_data)])
    if cancel_callback:
        rows.append([InlineKeyboardButton(text=cancel_text, callback_data=cancel_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def topup_menu() -> InlineKeyboardMarkup:
    return payment_methods_menu(None, [])


def payment_detail_menu() -> InlineKeyboardMarkup | None:
    return None


def payment_action_menu(
    paid_callback: str,
    back_callback: str,
    cancel_callback: str,
    qr_callback: str | None = None,
    main_callback: str = "nav:main",
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text="Посмотреть статус", callback_data=paid_callback),
            InlineKeyboardButton(text="Отменить заказ", callback_data=cancel_callback),
        ]
    ]
    if qr_callback is not None:
        rows.append([InlineKeyboardButton(text="QR", callback_data=qr_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def order_payment_detail_menu(
    status_callback: str,
    cancel_callback: str,
    qr_callback: str | None = None,
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text="Посмотреть статус", callback_data=status_callback),
            InlineKeyboardButton(text="Отменить заказ", callback_data=cancel_callback),
        ],
    ]
    if qr_callback is not None:
        rows.append([InlineKeyboardButton(text="QR", callback_data=qr_callback)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_waiting_menu(
    help_callback: str,
    cancel_callback: str,
    extend_callback: str,
    refresh_callback: str,
    back_callback: str,
    main_callback: str = "nav:main",
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Помощь", callback_data=help_callback)],
            [InlineKeyboardButton(text="Отменить заказ", callback_data=cancel_callback)],
            [InlineKeyboardButton(text="Продлить время бронирования", callback_data=extend_callback)],
            [InlineKeyboardButton(text="Обновить статус", callback_data=refresh_callback)],
        ]
    )


def payment_waiting_back_menu(back_callback: str, main_callback: str = "nav:main") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Вернуться к оплате", callback_data=back_callback)],
        ]
    )


def payment_exit_confirmation_menu(
    stay_callback: str,
    leave_callback: str = "nav:main",
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Вернуться к оплате", callback_data=stay_callback),
            ],
        ]
    )


def order_cancel_confirmation_menu(
    pay_callback: str,
    cancel_callback: str,
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Оплатить", callback_data=pay_callback),
                InlineKeyboardButton(text="Отменить", callback_data=cancel_callback),
            ],
        ]
    )


def existing_unpaid_order_menu(
    pay_callback: str,
    cancel_callback: str,
    status_callback: str,
) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Оплатить", callback_data=pay_callback),
                InlineKeyboardButton(text="Отменить", callback_data=cancel_callback),
            ],
            [InlineKeyboardButton(text="Проверить статус", callback_data=status_callback)],
        ]
    )


def simple_back_menu() -> InlineKeyboardMarkup | None:
    return InlineKeyboardMarkup(inline_keyboard=[])


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Стартовый текст", callback_data="admin:set_start_text")],
            [InlineKeyboardButton(text="Контакты", callback_data="admin:set_contacts_text")],
            [InlineKeyboardButton(text="Оператор", callback_data="admin:set_operator")],
            [InlineKeyboardButton(text="Каталог", callback_data="admin:catalog")],
            [InlineKeyboardButton(text="Способы оплаты", callback_data="admin:payments")],
            [InlineKeyboardButton(text="Обменники", callback_data="admin:exchangers")],
            [InlineKeyboardButton(text="Ссылки кнопок", callback_data="admin:links")],
            [InlineKeyboardButton(text="Добавить админа по ID", callback_data="admin:add_admin")],
            [InlineKeyboardButton(text="Боты", callback_data="admin:bots")],
            [
                InlineKeyboardButton(text="Обновить", callback_data="admin:panel"),
                InlineKeyboardButton(text="Закрыть", callback_data="admin:close"),
            ],
        ]
    )


def admin_cancel_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Отмена", callback_data="admin:panel")]]
    )


def payment_admin_menu(spec: BotSpec) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=method.label, callback_data=f"admin:payment_method:{index}")]
        for index, method in enumerate(spec.payment_methods)
    ]
    rows.append([InlineKeyboardButton(text="Добавить способ", callback_data="admin:payment_add")])
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_method_editor_menu(method_index: int, method: PaymentMethodConfig) -> InlineKeyboardMarkup:
    qr_label = "QR: включен" if method.qr_enabled else "QR: выключен"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Редактировать текст", callback_data=f"admin:payment_edit:{method_index}")],
            [InlineKeyboardButton(text=qr_label, callback_data=f"admin:payment_qr:{method_index}")],
            [InlineKeyboardButton(text="Назад", callback_data="admin:payments")],
        ]
    )


def bots_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Загрузить токены", callback_data="admin:bots_upload")],
            [InlineKeyboardButton(text="Список ботов", callback_data="admin:bots_page:0")],
            [InlineKeyboardButton(text="Назад", callback_data="admin:panel")],
        ]
    )


def bots_upload_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Список ботов", callback_data="admin:bots_page:0")],
            [InlineKeyboardButton(text="Назад", callback_data="admin:bots")],
        ]
    )


def build_bot_list_menu(
    bots: list[BotSummary],
    page: int,
    total_pages: int,
    current_bot_id: int | None,
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for bot in bots:
        label = bot.bot_username or bot.bot_name or str(bot.bot_id)
        if bot.is_paused:
            label = f"🟠 {label}"
        info_callback = f"admin:bot_pause_switch:{bot.bot_id}:{page}"
        if bot.bot_id == current_bot_id:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"{label} (текущий)",
                        callback_data=info_callback,
                    )
                ]
            )
            continue
        rows.append(
            [
                InlineKeyboardButton(
                    text=label,
                    callback_data=info_callback,
                ),
                InlineKeyboardButton(text="Удалить", callback_data=f"admin:bot_delete:{bot.bot_id}:{page}"),
            ]
        )

    navigation: list[InlineKeyboardButton] = []
    if page > 0:
        navigation.append(InlineKeyboardButton(text="◀️", callback_data=f"admin:bots_page:{page - 1}"))
    navigation.append(InlineKeyboardButton(text=f"{page + 1}/{total_pages}", callback_data="admin:bots"))
    if page + 1 < total_pages:
        navigation.append(InlineKeyboardButton(text="▶️", callback_data=f"admin:bots_page:{page + 1}"))
    rows.append(navigation)
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:bots")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_admin_text(spec: BotSpec) -> str:
    template = normalize_template(spec.template)
    admins_text = ", ".join(str(admin_id) for admin_id in spec.admin_ids) if spec.admin_ids else "нет"
    start_text = (template.start_text or "").strip()
    preview = start_text[:700].rstrip()
    if len(start_text) > len(preview):
        preview = f"{preview}..."
    return f"""<b>Админка</b>

Бот: @{escape(spec.bot_username or "unknown_bot")}
Админы: {admins_text}

Стартовый текст:
<pre>{escape(preview or "пусто")}</pre>

Выберите действие ниже."""


def catalog_cities_menu(cities: list[CityConfig]) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=city.label, callback_data=f"admin:catalog_city:{city.key}")]
        for city in cities
    ]
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def catalog_city_menu(city: CityConfig) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=product.button_label or product.label, callback_data=f"admin:catalog_product:{city.key}:{index}")]
        for index, product in enumerate(city.products)
    ]
    rows.append([InlineKeyboardButton(text="Добавить товар", callback_data=f"admin:catalog_add_product:{city.key}")])
    rows.append([InlineKeyboardButton(text="К списку городов", callback_data="admin:catalog")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def catalog_product_menu(city_key: str, product_index: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Добавить фасовку", callback_data=f"admin:catalog_add_option:{city_key}:{product_index}")],
            [InlineKeyboardButton(text="Назад к городу", callback_data=f"admin:catalog_city:{city_key}")],
            [InlineKeyboardButton(text="К списку городов", callback_data="admin:catalog")],
        ]
    )


def build_catalog_cities_text(cities: list[CityConfig]) -> str:
    lines = ["<b>Каталог</b>", "", "Текущие города:"]
    for city in cities:
        lines.append(f"- {escape(city.label)} | товаров: {len(city.products)}")
    lines.append("")
    lines.append("Выберите город, чтобы посмотреть товары или добавить новый.")
    return "\n".join(lines)


def build_catalog_city_text(city: CityConfig) -> str:
    lines = [
        f"<b>Город: {escape(city.label)}</b>",
        "",
        f"Районов: {len(city.districts)}",
        f"Товаров: {len(city.products)}",
        "",
    ]
    if city.products:
        lines.append("Товары:")
        for index, product in enumerate(city.products, start=1):
            lines.append(f"{index}. {escape(product.button_label or product.label)} | фасовок: {len(product.options)}")
    else:
        lines.append("В этом городе пока нет товаров.")
    return "\n".join(lines)


def build_catalog_product_text(city: CityConfig, product: ProductConfig) -> str:
    lines = [
        f"<b>{escape(product.button_label or product.label)}</b>",
        "",
        f"Город: {escape(city.label)}",
        f"Название товара: {escape(product.label)}",
        "",
    ]
    if product.options:
        lines.append("Фасовки:")
        for index, option in enumerate(product.options, start=1):
            lines.append(f"{index}. {escape(option.label)}")
    else:
        lines.append("Фасовок пока нет.")
    return "\n".join(lines)


def build_payments_admin_text(spec: BotSpec) -> str:
    lines = ["<b>Способы оплаты</b>", ""]
    if not spec.payment_methods:
        lines.append("Методы оплаты не настроены.")
    else:
        for method in spec.payment_methods:
            qr_status = "QR включен" if method.qr_enabled else "QR выключен"
            lines.append(f"- {escape(method.label)} | {qr_status}")
    lines.append("")
    lines.append("Выберите метод для редактирования.")
    return "\n".join(lines)


def build_payment_method_editor_text(method: PaymentMethodConfig) -> str:
    qr_status = "включен" if method.qr_enabled else "выключен"
    return f"""<b>Редактор метода оплаты</b>

Метод: {escape(method.label)}
QR: {qr_status}

Текущий текст:
<pre>{escape(method.details_text)}</pre>"""


def build_bots_text(bot_count: int) -> str:
    return f"""<b>Боты</b>

Всего зарегистрировано: {bot_count}

Здесь можно загрузить один токен, несколько токенов списком или `.txt` файл.
Новые боты запускаются сразу после успешной загрузки."""


def build_bots_upload_text() -> str:
    return """<b>Загрузка ботов</b>

Пришлите:
- один токен;
- несколько токенов, по одному в строке;
- `.txt` файл с токенами.

Можно отправлять несколько сообщений подряд. Текущий бот будет пропущен автоматически."""


def build_bots_list_text(bots: list[BotSummary], page: int, page_size: int) -> str:
    if not bots:
        return "<b>Боты</b>\n\nСписок пуст."

    start_index = page * page_size + 1
    lines = ["<b>Боты</b>", ""]
    for offset, bot in enumerate(bots, start=start_index):
        username = f"@{escape(bot.bot_username)}" if bot.bot_username else "без username"
        name = escape(bot.bot_name or "без имени")
        status = "запущен" if bot.is_running else "остановлен"
        lines.append(f"{offset}. {username} | {name} | id {bot.bot_id} | {status}")
    lines.append("")
    lines.append("Нажмите на бота для информации или на кнопку удаления.")
    return "\n".join(lines)


def build_bot_info_alert(bot: BotSummary, is_current: bool) -> str:
    username = f"@{bot.bot_username}" if bot.bot_username else "без username"
    status = "запущен" if bot.is_running else "остановлен"
    suffix = "\nЭто текущий бот." if is_current else ""
    return f"{username}\nid {bot.bot_id}\n{status}\nадминов: {len(bot.admin_ids)}{suffix}"


def build_city_text(city: CityConfig, *, page: int = 0, total_pages: int = 1, lang: str | None = None) -> str:
    text = t(lang, "city_header").format(city=escape(city.label))
    text += f" {page + 1}/{total_pages}"
    return text


# Main menu link buttons that the admin can edit: (key, label, template attribute).
LINK_FIELDS = [
    ("price", "💲 Прайс", "vip_price_url"),
    ("reviews", "👍 Отзывы", "reviews_url"),
    ("work", "⚒ Работа", "work_url"),
    ("site", "🌐 Сайт-инфо", "site_url"),
    ("chat", "👤 Чат", "chat_url"),
    ("complaints", "😈 Жалобы", "complaints_url"),
    ("questions", "❓ Вопросы", "questions_url"),
    ("payment_support", "🩺 Саппорт оплаты (doctor)", "payment_support_url"),
]


def build_main_city_text(
    template: TemplateOverrides,
    city: CityConfig,
    *,
    lang: str | None = None,
    name: str | None = None,
    user_id: int | None = None,
    purchases: int = 0,
    total_sum: int = 0,
) -> str:
    shop = escape((template.shop_name or "monster-1").strip() or "monster-1")
    display_name = escape((name or "").strip() or "друг")
    divider = "➖➖➖➖➖➖"
    return (
        f"{t(lang, 'mm_welcome').format(name=display_name, shop=shop)}\n"
        f"{divider}\n\n"
        f"{t(lang, 'mm_your_city')}: <b>{escape(city.label)}</b>\n"
        f"ID: <code>{user_id if user_id is not None else '—'}</code>\n"
        f"{t(lang, 'mm_total_buys')}: <b>{purchases}</b>\n"
        f"{t(lang, 'mm_total_sum')}: <b>{total_sum} р.</b>\n"
        f"{divider}\n\n"
        f"{t(lang, 'mm_desc')}"
    )


def _link_button(label: str, url: object | None, fallback_callback: str) -> InlineKeyboardButton:
    if url:
        return InlineKeyboardButton(text=label, url=str(url))
    return InlineKeyboardButton(text=label, callback_data=fallback_callback)


def main_city_menu(template: TemplateOverrides, city_key: str, lang: str | None = None) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=t(lang, "btn_ready"), callback_data=f"shop:ready:{city_key}")],
        [InlineKeyboardButton(text=t(lang, "btn_order"), callback_data=f"shop:order:{city_key}")],
        [
            _link_button(t(lang, "btn_questions"), template.questions_url, "shop:unset"),
            _link_button(t(lang, "btn_price"), template.vip_price_url, "shop:unset"),
        ],
        [
            _link_button(t(lang, "btn_site"), template.site_url, "shop:unset"),
            _link_button(t(lang, "btn_reviews"), template.reviews_url, "shop:unset"),
        ],
        [
            _link_button(t(lang, "btn_work"), template.work_url, "shop:unset"),
            _link_button(t(lang, "btn_chat"), template.chat_url, "shop:unset"),
        ],
        [_link_button(t(lang, "btn_complaints"), template.complaints_url, "shop:unset")],
        [InlineKeyboardButton(text=t(lang, "btn_change_city"), callback_data="nav:change_city")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_links_admin_text(template: TemplateOverrides) -> str:
    lines = ["<b>Ссылки кнопок главного меню</b>", ""]
    for _key, label, attr in LINK_FIELDS:
        value = getattr(template, attr, None)
        lines.append(f"{label}: {escape(str(value)) if value else '—'}")
    lines.extend(["", "Нажмите, чтобы изменить ссылку (URL или @username)."])
    return "\n".join(lines)


def links_admin_menu() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"Изменить {label}", callback_data=f"admin:set_link:{key}")]
        for key, label, _attr in LINK_FIELDS
    ]
    rows.append([InlineKeyboardButton(text="Назад", callback_data="admin:panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def build_option_text(city: CityConfig, product: ProductConfig) -> str:
    city_label = escape(city.label)
    product_label = escape(product.label)
    divider = "➖➖➖➖➖➖➖➖➖➖"
    return (
        f"Вы выбрали {product_label}.\n\n"
        f"{divider}\n"
        f"Город: {city_label}\n"
        f"Товар: {product_label}\n"
        f"{divider}\n"
        "Выберите фасовку:"
    )


_OPTION_KEY_PATTERN = re.compile(r"(?P<amount>\d+(?:_\d+)?[a-z]+)_(?P<price>\d+)$", re.IGNORECASE)
_PRICE_SUFFIX_PATTERN = re.compile(
    r"(?P<price>\d+(?:[.,]\d+)?)\s*(?P<currency>грн|uah|₴|usd|usdt|ltc)\.?\s*$",
    re.IGNORECASE,
)
_AMOUNT_SUFFIX_PATTERN = re.compile(
    r"(?P<amount>\d+(?:[.,]\d+)?)\s*(?P<unit>г(?:р(?:амм(?:а|ов)?)?)?|gr|g|шт|tab)\.?\s*$",
    re.IGNORECASE,
)
_CARD_LINE_PATTERN = re.compile(r"(?<!\d)(?P<card>\d(?:[\s-]?\d){11,18}|CARD_NUMBER_HERE)(?!\d)", re.IGNORECASE)
_TRAILING_SEPARATOR_PATTERN = re.compile(r"[\s\-:|]+$")
_TRAILING_VALUE_PATTERN = re.compile(r"\s*[-:]\s*\d+(?:[.,]\d+)?\s*$")


def _normalize_amount_value(raw_value: str) -> str:
    if "_" in raw_value:
        return raw_value.replace("_", ",")
    if raw_value.startswith("0") and len(raw_value) > 1 and raw_value.isdigit():
        return f"0,{raw_value[1:]}"
    return raw_value


def _format_decimal_amount(value: Decimal) -> str:
    normalized = format(value, "f")
    if "." in normalized:
        normalized = normalized.rstrip("0").rstrip(".")
    return normalized or "0"


def _normalize_money_unit(raw_unit: str) -> str | None:
    marker = raw_unit.strip().casefold().replace(".", "")
    if marker in {"грн", "uah", "₴"}:
        return "UAH"
    if marker == "usd":
        return "USD"
    if marker == "usdt":
        return "USDT"
    if marker == "ltc":
        return "LTC"
    return None


def _format_price_text(raw_price: str, raw_currency: str) -> str:
    currency = _normalize_money_unit(raw_currency)
    display_currency = {
        "UAH": "грн.",
        "USD": "USD",
        "USDT": "USDT",
        "LTC": "LTC",
    }.get(currency, raw_currency.strip())
    price_value = raw_price.replace(",", ".")
    try:
        normalized_price = _format_decimal_amount(Decimal(price_value))
    except InvalidOperation:
        normalized_price = raw_price
    return f"{normalized_price} {display_currency}".strip()


def _format_amount_value(raw_value: str, raw_unit: str) -> str:
    value = _normalize_amount_value(raw_value)
    unit = raw_unit.lower()
    if unit in {"g", "gr"} or unit.startswith("г"):
        return f"{value} г."
    if unit in {"tab", "шт"}:
        return f"{value} шт."
    return f"{value} {raw_unit}"


def _parse_option_amount_and_price(option: ProductOption) -> tuple[str | None, str | None]:
    key_match = _OPTION_KEY_PATTERN.search(option.key)
    if key_match is not None:
        amount_token = key_match.group("amount")
        unit_match = re.fullmatch(r"(?P<value>\d+(?:_\d+)?)(?P<unit>[a-z]+)", amount_token, re.IGNORECASE)
        if unit_match is not None:
            amount_text = _format_amount_value(unit_match.group("value"), unit_match.group("unit"))
            price_text = f"{key_match.group('price')} грн."
            return amount_text, price_text

    price_match = _PRICE_SUFFIX_PATTERN.search(option.label)
    price_text = (
        None
        if price_match is None
        else _format_price_text(price_match.group("price"), price_match.group("currency"))
    )
    label_without_price = option.label if price_match is None else option.label[: price_match.start()].rstrip(" -:,.")
    amount_match = _AMOUNT_SUFFIX_PATTERN.search(label_without_price)
    amount_text = None
    if amount_match is not None:
        amount_text = _format_amount_value(amount_match.group("amount"), amount_match.group("unit"))
    return amount_text, price_text


def _clean_product_label(label: str) -> str:
    cleaned = label.strip()
    price_match = _PRICE_SUFFIX_PATTERN.search(cleaned)
    if price_match is not None:
        cleaned = cleaned[: price_match.start()].rstrip(" -:,.")
    amount_match = _AMOUNT_SUFFIX_PATTERN.search(cleaned)
    if amount_match is not None:
        cleaned = cleaned[: amount_match.start()].rstrip(" -:,.")
    cleaned = _TRAILING_VALUE_PATTERN.sub("", cleaned).rstrip(" -:,.")
    cleaned = _TRAILING_SEPARATOR_PATTERN.sub("", cleaned).strip()
    return cleaned or label.strip()


def _build_order_display_fields(
    product: ProductConfig,
    option: ProductOption,
) -> tuple[str, str | None, str | None]:
    amount_text, price_text = _parse_option_amount_and_price(option)
    product_text = _clean_product_label(product.label)
    if product_text == option.label:
        product_text = _clean_product_label(option.label)
    return product_text, amount_text, price_text


def resolve_payment_requisites(method: PaymentMethodConfig) -> str | None:
    requisites = (method.requisites or "").strip()
    if requisites:
        return requisites
    return extract_payment_requisites(method.details_text)


def _is_usdt_method(method: PaymentMethodConfig) -> bool:
    source_text = f"{method.key}\n{method.label}\n{method.details_text}".casefold()
    return "usdt" in source_text or "trc20" in source_text


def _is_ltc_method(method: PaymentMethodConfig) -> bool:
    source_text = f"{method.key}\n{method.label}\n{method.details_text}".casefold()
    return "ltc" in source_text or "litecoin" in source_text


def _uses_wallet_requisites(method: PaymentMethodConfig, requisites: str | None) -> bool:
    if _is_usdt_method(method) or _is_ltc_method(method):
        return True
    source_text = f"{method.key}\n{method.label}\n{method.details_text}".casefold()
    if "wallet" in source_text or "кошел" in source_text:
        return True
    if requisites and not requisites.replace(" ", "").isdigit():
        return True
    return False


def get_payment_target(method: PaymentMethodConfig) -> tuple[str, str]:
    requisites = resolve_payment_requisites(method) or "не указаны"
    if _uses_wallet_requisites(method, requisites):
        return "Кошелек", requisites
    return "Реквизиты", requisites


def _get_payment_target_currency(method: PaymentMethodConfig) -> str | None:
    if _is_usdt_method(method):
        return "USDT"
    if _is_ltc_method(method):
        return "LTC"
    return None


def _format_display_amount_text(
    amount_text: str,
    method: PaymentMethodConfig,
    *,
    apply_commission: bool = False,
) -> str:
    payable_amount = _apply_commission_to_amount(amount_text, method) if apply_commission else amount_text
    amount_match = _AMOUNT_VALUE_PATTERN.fullmatch(payable_amount.strip())
    if amount_match is None:
        return payable_amount

    source_currency = _normalize_money_unit(amount_match.group("unit"))
    target_currency = _get_payment_target_currency(method)
    if source_currency is None or target_currency is None:
        return payable_amount

    raw_value = amount_match.group("value").replace(",", ".")
    try:
        source_amount = Decimal(raw_value)
    except InvalidOperation:
        return payable_amount

    converted_amount = convert_amount(source_amount, source_currency, target_currency)
    if converted_amount is None:
        return payable_amount
    return f"{_format_decimal_amount(converted_amount)} {target_currency}"


def render_payment_details_text(method: PaymentMethodConfig) -> str:
    requisites = resolve_payment_requisites(method)
    template_text = normalize_payment_details_template(method.details_text, requisites)
    rendered = template_text.replace(PAYMENT_REQUISITES_PLACEHOLDER, requisites or "не указаны")
    if requisites and PAYMENT_REQUISITES_PLACEHOLDER not in template_text and requisites not in rendered:
        target_label, target_value = get_payment_target(method)
        rendered = f"{rendered}\n\n{target_label}: {target_value}" if rendered else f"{target_label}: {target_value}"
    return re.sub(r"\n{3,}", "\n\n", rendered).strip()


def render_payment_details_html(method: PaymentMethodConfig) -> str:
    """Same as render_payment_details_text, but the wallet/card is wrapped in
    <code> so it is tap-to-copy in Telegram. Returns ready HTML (do not escape)."""
    requisites = resolve_payment_requisites(method)
    template_text = normalize_payment_details_template(method.details_text, requisites)
    value_html = f"<code>{escape(requisites)}</code>" if requisites else "не указаны"
    # html.escape leaves "{requisites}" untouched, so we can swap it after escaping.
    escaped_template = escape(template_text)
    if PAYMENT_REQUISITES_PLACEHOLDER in escaped_template:
        rendered = escaped_template.replace(PAYMENT_REQUISITES_PLACEHOLDER, value_html)
    else:
        rendered = escaped_template
        if requisites:
            target_label, _ = get_payment_target(method)
            extra = f"{escape(target_label)}: {value_html}"
            rendered = f"{rendered}\n\n{extra}" if rendered else extra
    return re.sub(r"\n{3,}", "\n\n", rendered).strip()


_RUB_PRICE_PATTERN = re.compile(r"(\d[\d\s]*)\s*(?:руб|р|₽)", re.IGNORECASE)


def extract_rub_price(text: str) -> str | None:
    match = _RUB_PRICE_PATTERN.search(text or "")
    if match is None:
        return None
    digits = re.sub(r"\s+", "", match.group(1))
    return f"{digits} руб." if digits else None


def _build_order_product_text(product: ProductConfig, option: ProductOption) -> str:
    product_text, amount_text, _ = _build_order_display_fields(product, option)
    if amount_text is None:
        return product_text
    return f"{product_text} - {amount_text}"


def _build_product_short_description(product: ProductConfig, option: ProductOption) -> str | None:
    description = (product.description or "").strip()
    if description:
        return description

    product_text, _, _ = _build_order_display_fields(product, option)
    normalized = product_text.lower()
    if "pvp" in normalized or "соль" in normalized:
        return "Лучшая соль на рынке, цвета меняются"
    return None


def _with_sentence_period(text: str) -> str:
    stripped = text.rstrip()
    if not stripped:
        return stripped
    if stripped.endswith((".", "!", "?", "…")):
        return stripped
    return f"{stripped}."


def _sanitize_order_payment_details_text(details_text: str) -> str:
    lines = details_text.splitlines()
    cleaned_lines: list[str] = []
    seen_request_line = False
    for line in lines:
        stripped = line.strip()
        if stripped == "/start":
            continue
        if stripped.startswith("Заявка:"):
            if seen_request_line:
                break
            seen_request_line = True
        cleaned_lines.append(line.rstrip())

    while cleaned_lines and not cleaned_lines[-1].strip():
        cleaned_lines.pop()
    return "\n".join(cleaned_lines).strip()


def _extract_card_and_instructions(details_text: str) -> tuple[str, str]:
    lines = details_text.splitlines()
    card_value = "CARD_NUMBER_HERE"
    instruction_lines: list[str] = []
    card_consumed = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            if instruction_lines and instruction_lines[-1] != "":
                instruction_lines.append("")
            continue

        if not card_consumed:
            card_match = _CARD_LINE_PATTERN.search(stripped)
            if card_match is not None:
                card_value = card_match.group("card").replace("-", " ")
                card_value = re.sub(r"\s+", " ", card_value).strip()
                card_consumed = True
                continue
            if stripped.casefold().startswith("реквизиты для оплаты"):
                continue

        instruction_lines.append(stripped)

    while instruction_lines and instruction_lines[-1] == "":
        instruction_lines.pop()
    return card_value, "\n".join(instruction_lines).strip()


def build_order_selection_text(
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str | None = None,
) -> str:
    del city
    price_text = _build_order_display_fields(product, option)[2]
    # Strip price suffix from option label for the product name line
    # (keeps amount like "0.15г" but removes price like "70USD")
    name_label = option.label.strip()
    price_match = _PRICE_SUFFIX_PATTERN.search(name_label)
    if price_match is not None:
        name_label = name_label[: price_match.start()].rstrip(" -:,. ")
    selected_product_text = _with_sentence_period(name_label)
    description_text = _build_product_short_description(product, option)

    lines = [f"Избран продукт: {escape(selected_product_text)}"]
    if description_text:
        lines.append(f"Коротко о товаре: {escape(description_text)}")
    if price_text is not None:
        lines.append(f"Цена: {escape(price_text)}")
    if district is not None:
        lines.append(f"Район: {escape(district)}")
    return "\n".join(lines)


def build_district_text(city: CityConfig, product: ProductConfig, option: ProductOption) -> str:
    return f"{build_order_selection_text(city, product, option)}\nВыберите подходящий район: 1/1"


def build_photo_caption(
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
) -> str:
    return f"""<b>Ваш заказ сформирован</b>

{build_order_selection_text(city, product, option, district)}

Проверьте данные заказа и переходите к оплате ниже."""


def build_payment_text(
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
    payment_text: str,
) -> str:
    return f"""{build_order_selection_text(city, product, option, district)}

{escape(payment_text)}"""


def build_order_created_text() -> str:
    return "Заказ создан! Адрес забронирован!"


def build_order_payment_methods_text(
    order_id: int,
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
) -> str:
    city_label = escape(city.label)
    district_label = escape(district)
    selected_product_text = escape(_with_sentence_period(option.label.strip()))
    price_text = _build_order_display_fields(product, option)[2]
    lines = [
        f"Ваш заказ № {order_id}:",
        f"Город: {city_label}.",
        f"Район: {district_label}.",
        f"Товар: {selected_product_text}",
    ]
    if price_text is not None:
        lines.append(f"Цена: {escape(price_text)}")
    lines.append("Выберите удобный метод платы:")
    return "\n".join(lines)


def build_order_payment_details_text(
    order_id: int,
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
    method: PaymentMethodConfig,
    deadline_text: str,
    support_url: str | None = None,
) -> str:
    del deadline_text  # the requisites screen states a fixed 15-minute window
    doctor_url = (support_url or "").strip() or SUPPORT_DOCTOR_URL
    price_text = _build_order_display_fields(product, option)[2] or extract_rub_price(option.label)
    payable_amount = _format_display_amount_text(price_text, method, apply_commission=True) if price_text is not None else None
    requisites = resolve_payment_requisites(method)
    is_crypto = any(
        marker in f"{method.key} {method.label}".casefold()
        for marker in ("btc", "ltc", "usdt", "trc", "bep", "crypto", "кошел", "wallet")
    )
    target_word = "кошелёк" if is_crypto else "карту"
    amount_text = escape(payable_amount or price_text or "уточните у оператора")
    requisites_html = f"<code>{escape(requisites)}</code>" if requisites else "не указаны"

    lines = [
        "✅ ВЫДАННЫЕ РЕКВИЗИТЫ ДЕЙСТВУЮТ 15 МИНУТ",
        "✅ ВЫ ПОТЕРЯЕТЕ ДЕНЬГИ, ЕСЛИ ОПЛАТИТЕ ПОЗЖЕ",
        "✅ ПЕРЕВОДИТЕ ТОЧНУЮ СУММУ. НЕВЕРНАЯ СУММА НЕ БУДЕТ ЗАЧИСЛЕНА.",
        "✅ ОПЛАТА ДОЛЖНА ПРОХОДИТЬ ОДНИМ ПЛАТЕЖОМ.",
        f'✅ ПРОБЛЕМЫ С ОПЛАТОЙ? ПЕРЕЙДИТЕ ПО ССЫЛКЕ : <a href="{escape(doctor_url)}">doctor</a> (Нажать)',
        "Предоставить чек об оплате и",
        f"ID: <code>{order_id}</code>",
        "✅ С ПРОБЛЕМНОЙ ЗАЯВКОЙ ОБРАЩАЙТЕСЬ НЕ ПОЗДНЕЕ 24 ЧАСОВ С МОМЕНТА ОПЛАТЫ.",
        "",
        f"Заявка № {order_id}. Заплатите на {target_word} <b>{amount_text}</b>. Важно перевести ровную сумму.",
        requisites_html,
    ]
    if not is_crypto:
        lines.append("‼️ с терминала платить запрещено")
    lines.extend(
        [
            "‼️ указывать комментарий к платежу запрещено",
            "‼️ у вас есть 15 мин на оплату, после чего платёж не будет зачислен",
            "‼️ ПЕРЕВЁЛ НЕТОЧНУЮ СУММУ - ОПЛАТИЛ ЧУЖОЙ ЗАКАЗ",
        ]
    )
    return "\n".join(lines)


def build_order_payment_followup_text(
    order_id: int,
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
    method: PaymentMethodConfig,
    payable_amount: str | None,
    address: str,
) -> str:
    city_label = escape(city.label)
    district_label = escape(district)
    _, _, price_text = _build_order_display_fields(product, option)
    name_label = option.label.strip()
    price_match = _PRICE_SUFFIX_PATTERN.search(name_label)
    if price_match is not None:
        name_label = name_label[: price_match.start()].rstrip(" -:,. ")
    selected_product_text = escape(_with_sentence_period(name_label))
    lines = [
        f"Ваш заказ № {order_id}:",
        f"Город: {city_label}.",
        f"Район: {district_label}.",
        f"Товар: {selected_product_text}",
    ]
    if price_text is not None:
        lines.append(f"Цена: {escape(price_text)}")
    lines.extend([
        "",
        f"Чтобы отследить заказ на сайте, оставить отзыв или написать запрос в службу поддержки, воспользуйтесь своим /pin и номером заказа {order_id}.",
        "",
        f" 👀 Для просмотра QR кода с реквизитами для оплаты заказа, отправьте боту команду /qrcode {order_id}",
        "",
        f"Выбран метод оплаты {escape(method.label)}.",
    ])
    if payable_amount and address:
        lines.append(f"Для получения товара, оплатите на кошелек {escape(address)} сумму {escape(payable_amount)}.")
    elif address:
        lines.append(f"Для получения товара, оплатите на кошелек {escape(address)}.")
    lines.append("После оплаты нажмит кнопку СТАТУС или введи команду /status")
    return "\n".join(lines)


def build_order_payment_waiting_text(
    order_id: int,
    city: CityConfig,
    product: ProductConfig,
    option: ProductOption,
    district: str,
    deadline_text: str,
    method: PaymentMethodConfig | None = None,
    payable_amount: str | None = None,
    address: str | None = None,
) -> str:
    city_label = escape(city.label)
    district_label = escape(district)
    _, _, price_text = _build_order_display_fields(product, option)
    name_label = option.label.strip()
    price_match = _PRICE_SUFFIX_PATTERN.search(name_label)
    if price_match is not None:
        name_label = name_label[: price_match.start()].rstrip(" -:,. ")
    selected_product_text = escape(_with_sentence_period(name_label))
    lines = [
        PAYMENT_WAITING_TEXT,
        "",
        f"Ваш заказ № {order_id}:",
        f"Город: {city_label}.",
        f"Район: {district_label}.",
        f"Товар: {selected_product_text}",
    ]
    if price_text is not None:
        lines.append(f"Цена: {escape(price_text)}")
    lines.extend([
        "",
        f"Чтобы отследить заказ на сайте, оставить отзыв или написать запрос в службу поддержки, воспользуйтесь своим /pin и номером заказа {order_id}.",
        "",
        f" 👀 Для просмотра QR кода с реквизитами для оплаты заказа, отправьте боту команду /qrcode {order_id}",
        "",
    ])
    if method is not None:
        lines.append(f"Выбран метод оплаты {escape(method.label)}.")
        if payable_amount and address:
            lines.append(f"Для получения товара, оплатите на кошелек {escape(address)} сумму {escape(payable_amount)}.")
        elif address:
            lines.append(f"Для получения товара, оплатите на кошелек {escape(address)}.")
        lines.append("После оплаты нажмит кнопку СТАТУС или введи команду /status")
    lines.append(f"Оставшееся время действия брони на заказ: {escape(deadline_text)}")
    return "\n".join(lines)


def build_topup_request_text(
    order_id: int,
    topup_id: int,
    amount_uah: int,
    deadline_text: str,
) -> str:
    return f"""Заказ № {order_id}
Пополнение № {topup_id}
➖➖➖➖➖➖➖➖➖➖
Сумма: {amount_uah} грн

Вы должны пополнить до: {escape(deadline_text)}"""


def build_topup_payment_text(
    order_id: int,
    topup_id: int,
    amount_uah: int,
    deadline_text: str,
    method: PaymentMethodConfig,
) -> str:
    display_amount_text = _format_display_amount_text(f"{amount_uah} грн", method, apply_commission=True)
    return f"""{build_topup_request_text(order_id, topup_id, amount_uah, deadline_text)}

<b>{escape(format_payment_method_title(method))}</b>

Сумма к оплате: <code>{escape(display_amount_text)}</code>

{render_payment_details_html(method)}"""


def build_payment_notification_text(
    user_id: int,
    username: str | None,
    full_name: str | None,
    method: PaymentMethodConfig,
    order_summary: str | None,
) -> str:
    username_part = f"@{escape(username)}" if username else "без username"
    full_name_part = escape(full_name or "без имени")
    lines = [
        "<b>Поступило уведомление об оплате</b>",
        "",
        f"Пользователь: {username_part}",
        f"Имя: {full_name_part}",
        f"ID: <code>{user_id}</code>",
        f"Метод: {escape(method.label)}",
    ]
    if order_summary:
        lines.extend(["", order_summary])
    return "\n".join(lines)


def build_payment_notification_text_with_bot(
    bot_username: str | None,
    shop_name: str,
    user_id: int,
    username: str | None,
    full_name: str | None,
    method: PaymentMethodConfig,
    order_summary: str | None,
) -> str:
    bot_part = f"@{escape(bot_username)}" if bot_username else escape(shop_name)
    lines = build_payment_notification_text(
        user_id=user_id,
        username=username,
        full_name=full_name,
        method=method,
        order_summary=order_summary,
    ).splitlines()
    lines.insert(2, f"Р‘РѕС‚: {bot_part}")
    return "\n".join(lines)


def build_link_or_callback_button(text: str, url: str | None, callback_data: str) -> InlineKeyboardButton:
    if url:
        return InlineKeyboardButton(text=text, url=str(url))
    return InlineKeyboardButton(text=text, callback_data=callback_data)


def build_bots_list_text(bots: list[BotSummary], page: int, page_size: int) -> str:
    if not bots:
        return "<b>Боты</b>\n\nСписок пуст."

    start_index = page * page_size + 1
    lines = ["<b>Боты</b>", ""]
    for offset, bot in enumerate(bots, start=start_index):
        username = f"@{escape(bot.bot_username)}" if bot.bot_username else "без username"
        name = escape(bot.bot_name or "без имени")
        status = "🟠 пауза" if bot.is_paused else ("запущен" if bot.is_running else "остановлен")
        lines.append(f"{offset}. {username} | {name} | id {bot.bot_id} | {status}")
    lines.append("")
    lines.append("Нажмите на бота, чтобы поставить или снять паузу. Пауза отмечена 🟠.")
    return "\n".join(lines)


def build_bot_info_alert(bot: BotSummary, is_current: bool) -> str:
    username = f"@{bot.bot_username}" if bot.bot_username else "без username"
    status = "🟠 пауза" if bot.is_paused else ("запущен" if bot.is_running else "остановлен")
    suffix = "\nЭто текущий бот." if is_current else ""
    return f"{username}\nid {bot.bot_id}\n{status}\nадминов: {len(bot.admin_ids)}{suffix}"
