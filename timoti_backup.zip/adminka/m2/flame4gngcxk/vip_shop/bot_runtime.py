from __future__ import annotations

from dataclasses import dataclass

import asyncio

import json
import logging
import random
import re
import uuid
from datetime import datetime, timedelta
from decimal import Decimal
import qrcode
import io
import string
import time
from html import escape
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
)
from aiogram.types import FSInputFile

from vip_shop.config import DEFAULT_START_TEXT, Settings, get_settings, load_family_state, FamilyState, TemplateOverrides, CityConfig
from vip_shop.crypto_rates import convert_amount, convert_pln_to_crypto, get_usdt_uah_rate, refresh_market_rates
from vip_shop.captcha import generate_captcha_image, generate_captcha_text

logger = logging.getLogger(__name__)

router = Router()


class CaptchaState(StatesGroup):
    waiting = State()


_CAPTCHA_FILE: Path | None = None


def _get_captcha_path() -> Path:
    global _CAPTCHA_FILE
    if _CAPTCHA_FILE is None:
        settings = get_settings()
        _CAPTCHA_FILE = settings.data_path.with_name("evila_captcha.json")
    return _CAPTCHA_FILE


def _load_captcha_data() -> dict:
    path = _get_captcha_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_captcha_data(data: dict) -> None:
    path = _get_captcha_path()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _is_captcha_passed(user_id: int) -> bool:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return bool(user.get("passed"))


def _set_captcha_passed(user_id: int) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = True
    data[str(user_id)]["captcha_text"] = None
    _save_captcha_data(data)


def _set_captcha_challenge(user_id: int, text: str) -> None:
    data = _load_captcha_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["passed"] = False
    data[str(user_id)]["captcha_text"] = text
    _save_captcha_data(data)


def _get_captcha_text(user_id: int) -> str | None:
    data = _load_captcha_data()
    user = data.get(str(user_id), {})
    return user.get("captcha_text")


class SecretPhraseState(StatesGroup):
    waiting = State()


_SECRET_PHRASE_FILE: Path | None = None


def _get_secret_phrase_path() -> Path:
    global _SECRET_PHRASE_FILE
    if _SECRET_PHRASE_FILE is None:
        settings = get_settings()
        _SECRET_PHRASE_FILE = settings.data_path.with_name("evila_secret_phrase.json")
    return _SECRET_PHRASE_FILE


def _load_secret_phrase_data() -> dict:
    path = _get_secret_phrase_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_secret_phrase_data(data: dict) -> None:
    path = _get_secret_phrase_path()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _get_secret_phrase(user_id: int) -> str | None:
    data = _load_secret_phrase_data()
    user = data.get(str(user_id), {})
    return user.get("phrase")


def _set_secret_phrase(user_id: int, phrase: str) -> None:
    data = _load_secret_phrase_data()
    if str(user_id) not in data:
        data[str(user_id)] = {}
    data[str(user_id)]["phrase"] = phrase
    _save_secret_phrase_data(data)


_SECRET_PHRASE_PROMPT = (
    "У нашего магазина очень много фейков, так как наших ботов очень часто банят "
    "и фейки не упускают любой возможности обмануть вас.\n\n"
    "Вы можете ввести боту Секретное слово или фразу, бот ее запомнит и в любой "
    "момент вы сможете проверить на подлинность нашего бота.\n"
    "Проверяйте секретное слово перед покупкой, проверяйте каждый раз когда нашего "
    "бота банят. Кроме Вас и бота это слово никто не сможет узнать, будьте "
    "внимательны и не ведитесь на уловки фейков.\n\n"
    "Введите свое секретное слово или фразу:"
)


def _secret_phrase_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])

_template_cache: FamilyState | None = None
_template_cache_mtime: float | None = None


def _get_template() -> TemplateOverrides:
    """Load template from bots.json, кэшируя до изменения файла."""
    global _template_cache, _template_cache_mtime
    settings = get_settings()
    try:
        mtime = settings.data_path.stat().st_mtime
    except OSError:
        mtime = None
    if _template_cache is None or mtime != _template_cache_mtime:
        _template_cache = load_family_state(settings.data_path)
        _template_cache_mtime = mtime
    return _template_cache.template


REGIONS: list[tuple[str, str, str, list[str]]] = [
    ("kiev", "Киев", "🔶", ["kiev"]),
    ("kyiv_oblast", "Киевская обл.", "🔷", ['belaia_tserkov', 'brovary', 'irpen', 'borispol', 'fastov', 'vishnevoe', 'bucha', 'vasilkov', 'boiarka', 'obukhov', 'vyshhorod', 'pereiaslav', 'slavutich', 'berezan', 'bohuslav', 'kaharlyk', 'mironovka', 'rzhishchev', 'skvira', 'tarashcha', 'tetiev', 'uzin', 'ukrainka', 'iahotin', 'hostomel', 'kotsiubinskoe', 'borodianka', 'makarov', 'vorzel', 'nemeshaevo', 'kalinovka', 'hlevakha', 'chabany', 'kozin', 'baryshevka', 'rakitnoe', 'sviatopetrovskoe', 'kriukovshchina', 'hatnoe', 'novoselki', 'khotianovka', 'novye_petrovtsy', 'starye_petrovtsy', 'dymer', 'ivankov', 'velikaia_dymerka', 'kalita', 'zhurovka', 'volodarka', 'stavishche', 'hrebenki', 'doslidnitskoe', 'belohorodka', 'chaiki', 'horenka', 'horenichi', 'shpitki', 'dmitrovka', 'kapitanovka', 'mila', 'klavdievo_tarasovo', 'peskovka', 'babintsy', 'kodra', 'lesniki', 'podhortsy', 'proleski', 'schastlivoe', 'hora', 'chubinskoe', 'velikaia_aleksandrovka', 'malaia_aleksandrovka', 'revnoe', 'hnedin', 'vishenki', 'voronkov', 'dudarkov', 'pohreby', 'zazime', 'pukhovka', 'rozhny', 'trebukhov', 'kniazhichi', 'krasilovka', 'hoholev', 'rusanov', 'semipolki', 'tarasovka', 'iurovka', 'kremenishche', 'romankov', 'novye_bezradichi', 'starye_bezradichi', 'pliuty', 'tatsenki', 'bobritsa', 'muzychi', 'hnatovka']),
    ("zhytomyr_oblast", "Житомирская обл.", "🔷", ['zhitomir', 'berdichev', 'korosten', 'novohrad_volynskii', 'malin', 'korostyshev', 'ovruch', 'radomyshl', 'baranovka', 'olevsk', 'andrushevka', 'chudnov', 'emilchino', 'romanov', 'cherniakhov', 'khoroshev', 'popelnia', 'brusilov', 'luhiny', 'narodichi', 'ruzhin']),
    ("volyn_oblast", "Волынская обл.", "🔷", ['lutsk', 'kovel', 'vladimir_volynskii', 'novovolynsk', 'kamen_kashirskii', 'kivertsy', 'rozhishche', 'horokhov', 'liuboml', 'berestechko', 'ustiluh', 'manevichi', 'liubeshov', 'ratno', 'shatsk', 'turiisk', 'lokachi', 'staraia_vyzhevka', 'ivanichi', 'holoby', 'kolki', 'tsuman']),
    ("dnepr", "Днепр", "🔶", ["dnepr"]),
    ("odessa", "Одесса", "🔶", ["odessa"]),
    ("lviv_oblast", "Львовская обл.", "🔷", ['lvov', 'drohobych', 'sheptitskii_chervonohrad', 'stryi', 'sambor', 'borislav', 'novoiavorovsk', 'novyi_rozdol', 'truskavets', 'sokal', 'zolochev', 'brody', 'stebnik']),
    ("rivne_oblast", "Ровенская обл.", "🔷", ['rovno', 'varash', 'dubno', 'sarny', 'kostopol', 'zdolbunov', 'ostroh', 'berezno', 'radivilov', 'dubrovitsa', 'korets', 'vladimirets', 'rokitnoe']),
    ("uman", "Умань", "🔶", ["uman"]),
    ("khmelnytskyi", "Хмельницкий", "🔶", ["khmelnytskyi"]),
    ("chernihiv_oblast", "Черниговская обл.", "🔷", ['chernihov', 'nezhin', 'priluki', 'bakhmach', 'nosovka', 'novhorod_severskii', 'koriukovka', 'horodnia', 'mena', 'snovsk', 'ichnia', 'borzna']),
]


def _region_cities(region_key: str, settings: Settings) -> list[CityConfig]:
    region = next((r for r in REGIONS if r[0] == region_key), None)
    if not region:
        return []
    city_keys = region[3]
    cities_by_key = {city.key: city for city in settings.cities}
    return [cities_by_key[key] for key in city_keys if key in cities_by_key]


def _link_or_callback(text: str, url: object | None, callback_data: str) -> InlineKeyboardButton:
    """Use a configured URL when available, otherwise keep the button visible."""
    if url:
        return InlineKeyboardButton(text=text, url=str(url))
    return InlineKeyboardButton(text=text, callback_data=callback_data)


def _main_menu_footer_rows(lang: str = "ru") -> list[list[InlineKeyboardButton]]:
    tpl = _get_template()
    if lang == "en":
        return [
            [InlineKeyboardButton(text="Buy 🍀", callback_data="MAIN_MENU_REQUEST_CALLBACK")],
            [InlineKeyboardButton(text="Profile 👤", callback_data="MAIN_MENU_PROFILE_CALLBACK"), InlineKeyboardButton(text="Rules 📕", callback_data="MAIN_MENU_RULES_CALLBACK")],
            [InlineKeyboardButton(text="💱 Exchange", callback_data="MAIN_MENU_EXCHANGE_CALLBACK"), _link_or_callback("Reviews 📝", tpl.reviews_url, "MAIN_MENU_REVIEWS_CALLBACK")],
            [InlineKeyboardButton(text="⛑️ Medicine 🆘", callback_data="MAIN_MENU_MEDICAL_CALLBACK"), _link_or_callback("🧑‍💼 Job", tpl.work_url, "MAIN_MENU_WORK_CALLBACK")],
            [InlineKeyboardButton(text="🇷🇺 Русский", callback_data="lang:ru")],
        ]
    return [
        [InlineKeyboardButton(text="🔥 Купить 🌳", callback_data="MAIN_MENU_REQUEST_CALLBACK")],
        [InlineKeyboardButton(text="👤 Профиль", callback_data="MAIN_MENU_PROFILE_CALLBACK"), InlineKeyboardButton(text="‼️Правила 📝", callback_data="MAIN_MENU_RULES_CALLBACK")],
        [InlineKeyboardButton(text="💱 Обмен валют", callback_data="MAIN_MENU_EXCHANGE_CALLBACK"), _link_or_callback("Отзывы 📝", tpl.reviews_url, "MAIN_MENU_REVIEWS_CALLBACK")],
        [InlineKeyboardButton(text="⛑️ Медицина 🆘", callback_data="MAIN_MENU_MEDICAL_CALLBACK"), _link_or_callback("🧑‍💼 Работа", tpl.work_url, "MAIN_MENU_WORK_CALLBACK")],
        [InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:en")],
    ]


def _main_menu_markup(lang: str = "ru") -> InlineKeyboardMarkup:
    # The home screen is intentionally only the main navigation.  City/area
    # choices belong to the next screen, opened with the "Купить" button.
    return InlineKeyboardMarkup(inline_keyboard=_main_menu_footer_rows(lang))


def _main_menu_text(user_id: int = 0, bot_username: str = "") -> str:
    del user_id, bot_username
    template = _get_template()
    # The default may be changed from the central admin.  URLs pasted into the
    # text are converted to clickable Telegram links in the same way as the
    # exchange and medicine cards.
    if template.start_text and template.start_text != DEFAULT_START_TEXT:
        return _format_text_with_links(template.start_text)
    # Telegram collapses regular leading spaces; use non-breaking spaces for
    # the exact indentation of the requested welcome layout.
    help_indent = "\u00a0" * 12
    operator_indent = "\u00a0" * 18
    site_indent = "\u00a0" * 24
    site_link_indent = "\u00a0" * 22
    return (
        '〰️〰️〰️<b><u>Pirate 🏴‍☠️ Bay</u></b>〰️〰️〰️\n\n'
        '<b>Для ознакомления с наличием - жми кнопку "🔥 КУПИТЬ 🌳"</b>\n\n'
        f'{help_indent}⁉️ Нужна помощь?\n\n'
        f'{operator_indent}🙋‍♂️Оператор:\n'
        f'{operator_indent}<a href="https://t.me/PitareBuy">@PitareBuy</a>\n\n'
        f'{site_indent}🛜 Сайт:\n'
        f'{site_link_indent}<a href="https://shop.pirat.im">shop.pirat.im</a>'
    )

async def edit_or_send(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    # The entry screen is an animation.  A text edit is not valid for an
    # animation message, so update its caption instead of adding a separate
    # text bubble below the GIF.  This keeps the GIF visible throughout the
    # purchase flow.
    if message.animation or message.video:
        try:
            return await message.edit_caption(caption=text, reply_markup=markup)
        except TelegramBadRequest:
            pass
    try:
        return await message.edit_text(text, reply_markup=markup)
    except TelegramBadRequest:
        pass
    if message.photo:
        try:
            await message.delete()
            return await message.answer(text, reply_markup=markup)
        except TelegramBadRequest:
            pass
    return await message.answer(text, reply_markup=markup)


async def send_new(message: Message, text: str, markup: InlineKeyboardMarkup | None = None) -> Message:
    """Update the current menu message whenever Telegram permits it.

    Kept as a compatibility wrapper for existing handlers.  In particular,
    callbacks in the buy flow now edit the caption of the intro GIF instead
    of sending a new message for every selection.
    """
    return await edit_or_send(message, text, markup)


def _back_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])


def _option_price_display(option) -> str:
    """Return the price written in the catalog, rather than deriving it from its ID."""
    label = (option.label or "").strip()
    match = re.search(r"(?:=|—|-)\s*([^=—-]+?)\s*$", label)
    if match:
        return match.group(1).strip()
    return label or option.key


def _option_price_value(option) -> int:
    """Get the numeric amount from the configured option label for the payment flow."""
    match = re.search(r"(?:=|—|-)\s*([0-9][0-9\s.,]*)", option.label or "")
    if match:
        try:
            return int(re.sub(r"[^0-9]", "", match.group(1)))
        except ValueError:
            pass
    return 0


def _option_price_currency(option) -> str:
    """Read the configured price currency; old labels without a marker mean UAH."""
    label = (option.label or "").upper()
    if "$" in label or "USD" in label:
        return "USD"
    if "USDT" in label:
        return "USDT"
    return "UAH"


_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _resolve_product_photo(product) -> FSInputFile | None:
    if not product.photo_path:
        return None
    photo_path = Path(product.photo_path)
    if not photo_path.is_absolute():
        photo_path = _PROJECT_ROOT / photo_path
    if photo_path.exists():
        return FSInputFile(str(photo_path))
    return None


async def _edit_to_photo_or_send(
    message: Message,
    text: str,
    markup: InlineKeyboardMarkup | None,
    photo: FSInputFile | None,
) -> Message:
    if photo is None:
        return await edit_or_send(message, text, markup)
    try:
        media = InputMediaPhoto(media=photo, caption=text)
        return await message.edit_media(media, reply_markup=markup)
    except TelegramBadRequest:
        pass
    try:
        await message.delete()
    except TelegramBadRequest:
        pass
    return await message.answer_photo(photo, caption=text, reply_markup=markup)


_STRETCH_PAD = "⠀" * 40


def _stretch(text: str, min_length: int = 60) -> str:
    """Pad short single-purpose messages so the bubble stretches to the width of the buttons below it."""
    if len(text.strip()) >= min_length:
        return text
    return f"{text}\n{_STRETCH_PAD}"


async def safe_answer(callback: CallbackQuery, text: str = "", show_alert: bool = False) -> None:
    try:
        await callback.answer(text, show_alert=show_alert)
    except TelegramBadRequest:
        pass


_INTRO_VIDEO_PATH = Path(__file__).resolve().parent.parent / "assets" / "pirate_intro.mp4"


async def send_intro_screen(message: Message, text: str, markup: InlineKeyboardMarkup) -> Message:
    """Send the shared intro animation with a caption and menu buttons."""
    if _INTRO_VIDEO_PATH.exists():
        return await message.answer_animation(
            FSInputFile(_INTRO_VIDEO_PATH), caption=text, reply_markup=markup
        )
    return await message.answer(text, reply_markup=markup)


@router.message(CommandStart())
async def on_start(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id if message.from_user else 0
    data = await state.get_data()
    if data.get("order_id"):
        text, markup = _payment_exit_confirmation_view()
        await message.answer(text, reply_markup=markup)
        return

    await state.clear()

    bot_username = (await message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    await send_intro_screen(message, text, _main_menu_markup())


@router.message(SecretPhraseState.waiting)
async def on_secret_phrase_input(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id if message.from_user else 0
    phrase = (message.text or "").strip()
    if not phrase:
        await message.answer("Введите свое секретное слово или фразу:", reply_markup=_secret_phrase_markup())
        return
    _set_secret_phrase(user_id, phrase)
    await state.clear()
    bot_username = (await message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    await message.answer(text, reply_markup=_main_menu_markup())


@router.message(CaptchaState.waiting)
async def on_captcha_input(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id if message.from_user else 0
    user_input = (message.text or "").strip().upper()
    correct_text = _get_captcha_text(user_id)
    
    if correct_text and user_input == correct_text.upper():
        _set_captcha_passed(user_id)
        await state.clear()
        bot_username = (await message.bot.get_me()).username
        text = _main_menu_text(user_id, bot_username=bot_username)
        await message.answer("✅ Капча пройдена!", reply_markup=_main_menu_markup())
        await message.answer(text, reply_markup=_main_menu_markup())
    else:
        captcha_text = generate_captcha_text()
        _set_captcha_challenge(user_id, captcha_text)
        image_bytes = generate_captcha_image(captcha_text)
        await message.answer_photo(
            BufferedInputFile(image_bytes, filename="captcha.png"),
            caption="❌ Неверно. Попробуйте ещё раз:"
        )


@router.callback_query(F.data.startswith("region:"))
async def on_region_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    region_key = callback.data.split(":", 1)[1]
    settings = get_settings()
    cities = _region_cities(region_key, settings)
    region = next((r for r in REGIONS if r[0] == region_key), None)
    if not cities or not region:
        await edit_or_send(callback.message, _stretch("Область не найдена."), _back_markup())
        return
    rows = []
    for city in cities:
        label = f"{city.icon} {city.label}".strip() if city.icon else city.label
        rows.append([InlineKeyboardButton(text=label, callback_data=f"city:{city.key}")])
    rows.extend(_main_menu_footer_rows(lang))
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "MAIN_MENU_REQUEST_CALLBACK")
async def on_choose_city(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    rows = []
    for city in settings.cities:
        rows.append([InlineKeyboardButton(text=city.label, callback_data=f"city:{city.key}")])
    rows.append([InlineKeyboardButton(text="Назад ◀️", callback_data="BACK_TO_MAIN_MENU_CALLBACK")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    await edit_or_send(callback.message, "Выберите город:", markup)


@router.callback_query(F.data.startswith("city:"))
async def on_city_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    city_key = callback.data.split(":", 1)[1]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, _stretch("Город не найден."), _back_markup())
        return
    city_icon = city.icon if city.icon else "🔶"
    rows = []
    for product in city.products:
        rows.append([InlineKeyboardButton(text=product.label, callback_data=f"product:{city_key}:{product.key}")])
    rows.append([InlineKeyboardButton(text="Назад ◀️", callback_data="BACK_TO_MAIN_MENU_CALLBACK")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    text = "Наш ассортимент:"
    await send_new(callback.message, text, markup)


@router.callback_query(F.data.startswith("product:"))
async def on_product_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key = parts[1], parts[2]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, "Город не найден.", _back_markup())
        return
    product = next((p for p in city.products if p.key == product_key), None)
    if not product:
        await edit_or_send(callback.message, _stretch("Товар не найден."), _back_markup())
        return
    rows = []
    for option in product.options:
        rows.append([InlineKeyboardButton(
            text=option.label, callback_data=f"option:{city_key}:{product_key}:{option.key}"
        )])
    rows.append([InlineKeyboardButton(text="Назад ◀️", callback_data=f"city:{city_key}")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    rng = random.Random(f"product-rating:{city_key}:{product_key}")
    rating = rng.randint(46, 49) / 10
    template = _get_template()
    reviews_url = str(template.reviews_url) if template.reviews_url else None
    reviews_inline = (
        f'<a href="{escape(reviews_url)}">{rating:.1f} ⭐️ | Отзывы</a>'
        if reviews_url else f"{rating:.1f} ⭐️ | Отзывы"
    )
    description = (product.description or "").strip() or (
        "Премиальный европейский товар 🇪🇺\n"
        "Производство: Изготовлен европейскими партнёрами на лучших лабах. "
        "Прошедший все этапы очистки. Примеси стремятся к нулю. ⚡️\n"
        "Эффект: Идеально сбалансированная эйфория. Мгновенный подъём настроения, "
        "дофаминовый всплеск. 🧠 Дофамин. Эмпатия."
    )
    text = f"{description}\n\n{reviews_inline}"
    await _edit_to_photo_or_send(callback.message, text, markup, _resolve_product_photo(product))


@router.callback_query(F.data.startswith("option:"))
async def on_option_selected(callback: CallbackQuery, state: FSMContext) -> None:
    """Proceed from a selected product configuration directly to payment."""
    await safe_answer(callback)
    current = await state.get_data()
    if float(current.get("active_order_until", 0) or 0) > time.time():
        await callback.message.answer(
            "У вас уже создан заказ.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="Показать заказ", callback_data="SHOW_ACTIVE_ORDER")],
            ]),
        )
        return
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = next((p for p in city.products if p.key == product_key), None) if city else None
    option = next((o for o in product.options if o.key == option_key), None) if product else None
    if not city or not product or not option:
        await edit_or_send(callback.message, "Товар не найден.", _back_markup())
        return

    price_num = _option_price_value(option)
    await state.update_data(
        selected_price=price_num,
        selected_price_currency=_option_price_currency(option),
        selected_city_label=city.label,
        selected_product_label=product.label,
        selected_option_label=option.label,
        selected_district="",
        selected_city_key=city_key,
        selected_product_key=product_key,
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔵 BTC", callback_data="BUY_PAYMENT_crypto_btc")],
        [InlineKeyboardButton(text="🟣 LITECOIN", callback_data="BUY_PAYMENT_crypto_ltc")],
        [InlineKeyboardButton(text="🟢 USDT TRC20", callback_data="BUY_PAYMENT_crypto_usdt")],
        [InlineKeyboardButton(text="🔶 USDT (BEP20)", callback_data="BUY_PAYMENT_crypto_usdt_bep20")],
        [InlineKeyboardButton(text="Назад ◀️", callback_data=f"product:{city_key}:{product_key}")],
    ])
    await send_new(callback.message, "Выберите способ оплаты:", markup)


@router.callback_query(F.data.startswith("district:"))
async def on_district_selected(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    city_key, product_key, option_key = parts[1], parts[2], parts[3]
    district_idx = int(parts[4])
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    product = None
    option = None
    if city:
        product = next((p for p in city.products if p.key == product_key), None)
    if product:
        option = next((o for o in product.options if o.key == option_key), None)
    option_districts = option.districts if option and option.districts else None
    product_districts = product.districts if product else None
    active_districts = option_districts or product_districts or (city.districts if city else [])
    district = active_districts[district_idx] if 0 <= district_idx < len(active_districts) else "Неизвестно"
    price_num = _option_price_value(option) if option else 0
    city_icon = city.icon if city and city.icon else "🔶"
    await state.update_data(
        selected_price=price_num,
        selected_price_currency=_option_price_currency(option) if option else "UAH",
        selected_city_label=city.label if city else "",
        selected_product_label=product.label if product else "",
        selected_option_label=option.label if option else "",
        selected_district=district,
    )
    text = (
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Город: {city_icon}{city.label if city else '—'}\n"
        f"Товар: {product.label if product else '—'}\n"
        f"Фасовка: ▪️{option.label if option else '—'} за {price_num} ₴\n"
        f"Район: ▫️{district}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f" \n\n"
        f"Выберите способ оплаты:"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="♻️Global24", callback_data="BUY_PAYMENT_global24")],
        [InlineKeyboardButton(text="♻️USDT TRC20", callback_data="BUY_PAYMENT_crypto_usdt")],
        [InlineKeyboardButton(text="♻️Bitcoin", callback_data="BUY_PAYMENT_crypto_btc")],
        [InlineKeyboardButton(text="♻️Перевод на карту #1 +10%", callback_data="BUY_PAYMENT_card1")],
        [InlineKeyboardButton(text="♻️Перевод на карту #2 +10%", callback_data="BUY_PAYMENT_card2")],
        [InlineKeyboardButton(text="♻️Перевод на карту #3 +10%", callback_data="BUY_PAYMENT_card3")],
        [InlineKeyboardButton(text="💣 Сапёр", callback_data="BUY_PAYMENT_saper")],
        [
            InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
            InlineKeyboardButton(text="Назад ◀️", callback_data=f"product:{city_key}:{product_key}"),
        ],
    ])
    await send_new(callback.message, text, markup)


class TopupState(StatesGroup):
    waiting_amount = State()


TOPUP_MIN_UAH = 100
TOPUP_MAX_UAH = 100000


def _parse_amount(raw: str) -> int | None:
    """Достаём число из ввода: «500», «500 грн», «500₴» — всё подходит."""
    cleaned = (raw or "").strip().replace(",", ".").replace(" ", "")
    digits = ""
    for char in cleaned:
        if char.isdigit():
            digits += char
        elif digits:
            break
        else:
            return None
    if not digits:
        return None
    try:
        return int(digits)
    except ValueError:
        return None


def _topup_methods_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="♻️Global24", callback_data="TOPUP_PAYMENT_global24")],
        [InlineKeyboardButton(text="♻️USDT TRC20", callback_data="TOPUP_PAYMENT_crypto_usdt")],
        [InlineKeyboardButton(text="♻️Bitcoin", callback_data="TOPUP_PAYMENT_crypto_btc")],
        [InlineKeyboardButton(text="♻️Перевод на карту #1 +10%", callback_data="TOPUP_PAYMENT_card1")],
        [InlineKeyboardButton(text="♻️Перевод на карту #2 +10%", callback_data="TOPUP_PAYMENT_card2")],
        [InlineKeyboardButton(text="♻️Перевод на карту #3 +10%", callback_data="TOPUP_PAYMENT_card3")],
        [
            InlineKeyboardButton(text="Другая сумма", callback_data="MAIN_MENU_LK_CALLBACK"),
            InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
        ],
    ])


@router.callback_query(F.data == "MAIN_MENU_LK_CALLBACK")
async def on_payin(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    selected_price = int(data.get("selected_price", 0) or 0)
    await state.clear()
    await state.update_data(selected_price=selected_price)
    await state.set_state(TopupState.waiting_amount)
    hint = f"\nДля текущего заказа нужно {selected_price} ₴." if selected_price else ""
    text = (
        "Пополнение баланса\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        "Введите сумму пополнения в гривнах — просто числом.\n"
        f"От {TOPUP_MIN_UAH} до {TOPUP_MAX_UAH} ₴.{hint}"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.message(TopupState.waiting_amount)
async def on_topup_amount_input(message: Message, state: FSMContext) -> None:
    amount = _parse_amount(message.text or "")
    if amount is None:
        await message.answer(
            _stretch("Не понял сумму. Введите её числом, например: 500"),
            reply_markup=_back_markup(),
        )
        return
    if amount < TOPUP_MIN_UAH or amount > TOPUP_MAX_UAH:
        await message.answer(
            _stretch(f"Сумма должна быть от {TOPUP_MIN_UAH} до {TOPUP_MAX_UAH} ₴. Введите ещё раз:"),
            reply_markup=_back_markup(),
        )
        return
    await state.set_state(None)
    await state.update_data(topup_amount=amount)
    text = (
        "Пополнение баланса\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"Сумма: {amount} ₴\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        "Выберите способ оплаты:"
    )
    await message.answer(text, reply_markup=_topup_methods_markup())


def _topup_amount_from(data: dict) -> int:
    return int(data.get("topup_amount") or data.get("selected_price") or 0)


@router.callback_query(F.data.startswith("TOPUP_PAYMENT_crypto_"))
async def on_topup_crypto(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    coin_key = callback.data.removeprefix("TOPUP_PAYMENT_crypto_").lower()
    method = _CRYPTO_PAYMENT_METHODS.get(coin_key)
    if method is None:
        await safe_answer(callback, "Способ оплаты недоступен.", show_alert=True)
        return
    label, network, wallet_keys = method
    coin = coin_key.upper()

    data = await state.get_data()
    amount_uah = Decimal(str(_topup_amount_from(data)))
    if amount_uah <= 0:
        await safe_answer(callback, "Сначала введите сумму пополнения.", show_alert=True)
        return

    uah_rate = get_usdt_uah_rate()
    amount_crypto = convert_amount(amount_uah, "UAH", coin)
    if amount_crypto is None or amount_crypto <= 0 or uah_rate is None:
        await safe_answer(
            callback,
            "Курс сейчас недоступен, попробуйте через минуту или выберите другой способ.",
            show_alert=True,
        )
        return

    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = _find_crypto_wallet(family_state, wallet_keys)
    if not wallet:
        await safe_answer(callback, f"Кошелёк {label} не настроен. Напишите оператору.", show_alert=True)
        return

    if coin == "USDT":
        rate_display = f"1 USDT = {uah_rate.quantize(Decimal('0.01'))} ₴"
    else:
        rate_display = f"1 {coin} = {(amount_uah / amount_crypto).quantize(Decimal('0.01'))} ₴"

    order_id = random.randint(1000000, 9999999)
    expires_at = datetime.now() + timedelta(minutes=15)
    await state.update_data(
        order_kind="topup",
        payment_method=f"crypto_{coin_key}",
        order_id=order_id,
        order_coin=coin,
        order_wallet=wallet,
        order_amount=int(amount_uah),
        order_amount_crypto=str(amount_crypto),
        order_rate_display=rate_display,
        order_expires_display=expires_at.strftime("%d-%m | %H : %M : %S"),
    )

    text = (
        "Заявка на пополнение баланса\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"Заявка: {order_id}\n"
        f"На баланс: {int(amount_uah)} ₴\n"
        f"Способ: {label}\n"
        f"Сеть: {network}\n"
        f"Курс: {rate_display}\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        "👇 Кошелёк для оплаты\n"
        f"<code>{wallet}</code>\n\n"
        "👇 Сумма к отправке\n"
        f"<code>{amount_crypto}</code> {coin}\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"🔴 Отправляйте только {coin} в сети {network} — монеты из другой сети сгорят\n"
        "🔴 Отсылайте точную сумму одним переводом\n"
        "🔴 Рекомендуем отправить чуть больше: курс мог сдвинуться, пока вы платите\n"
        "🔴 Время проверки платежа от 5 до 10 минут\n\n"
        f"Заявка действительна до {expires_at.strftime('%d-%m | %H : %M : %S')}.\n"
        "❗️ После успешного пополнения баланс зачислится автоматически.❗️"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Проверить оплату", callback_data="CRYPTO_CHECK_PAYMENT")],
        [InlineKeyboardButton(text="Главное меню", callback_data="PAYMENT_EXIT_ASK")],
    ])
    await send_new(callback.message, text, markup)
    await callback.message.answer(wallet)
    await callback.message.answer(str(amount_crypto))


@router.callback_query(F.data.startswith("TOPUP_PAYMENT_"))
async def on_topup_payment_method(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    amount = _topup_amount_from(data)
    if amount <= 0:
        await safe_answer(callback, "Сначала введите сумму пополнения.", show_alert=True)
        return

    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    card = _find_card_requisites(family_state)

    order_id = random.randint(1000000, 9999999)
    expires_at = datetime.now() + timedelta(minutes=15)
    expires_display = expires_at.strftime("%d-%m | %H : %M : %S")

    await state.update_data(
        order_kind="topup",
        order_id=order_id,
        order_amount=amount,
        order_card=card,
        order_expires_display=expires_display,
    )

    text, markup = _topup_payment_view(await state.get_data())
    await send_new(callback.message, text, markup)
    await callback.message.answer(card)
    await callback.message.answer(
        f"Заявка: {order_id}\n"
        f"Сумма: {amount}\n"
        f"/start"
    )


def _topup_payment_view(data: dict) -> tuple[str, InlineKeyboardMarkup]:
    text = (
        f"Заявка на пополнение баланса\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Заявка: {data.get('order_id')}\n"
        f"Кошелек: {data.get('order_card')}\n"
        f"Сумма: {data.get('order_amount')} грн\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"❗️❗️❗️ Платежи с ТЕРМИНАЛА не принимаются\n\n"
        f"🔴 Отсылайте точную сумму\n"
        f"🔴 Сумму отсылайте одним переводом\n"
        f"🔴 Время проверки платежа от 5 до 10 минут\n\n"
        f"Если платеж не прошел в течении 10 минут, обращайтесь в бот: https://t.me/PaySyncSupportBot\n\n"
        f"Заявка действительна до {data.get('order_expires_display')}.\n"
        f"❗️ После успешного пополнения баланс зачислится автоматически.❗️"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Главное меню", callback_data="PAYMENT_EXIT_ASK")],
    ])
    return text, markup


@router.callback_query(F.data == "PAYMENT_ltc")
async def on_payment_ltc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="LTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_ltc = convert_pln_to_crypto(amount_pln, "LTC")
    if amount_ltc is None:
        amount_ltc = Decimal("0.01")
    await state.update_data(amount_usd=amount_usd, amount_ltc=str(amount_ltc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: LTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_ltc} LTC</code>\n"
        f"☝️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только LTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👌 Подтвердить", callback_data="PAYMENT_confirm_ltc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_btc")
async def on_payment_btc(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="BTC")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    amount_btc = convert_pln_to_crypto(amount_pln, "BTC")
    if amount_btc is None:
        amount_btc = Decimal("0.001")
    await state.update_data(amount_usd=amount_usd, amount_btc=str(amount_btc))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: BTC\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: <code>{amount_btc} BTC</code>\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только BTC на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_btc")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_usdt")
async def on_payment_usdt(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.update_data(coin="USDT")
    request_id = random.randint(1000000, 9999999)
    await state.update_data(request_id=request_id)
    data = await state.get_data()
    amount_usd = data.get("selected_price", 85)
    amount_pln = Decimal(str(amount_usd * 3.9))
    # USDT is 1:1 with USD, so convert PLN to USDT
    amount_usdt = amount_pln * Decimal("0.2564")  # Approx PLN to USDT rate
    await state.update_data(amount_usd=amount_usd, amount_usdt=str(amount_usdt.quantize(Decimal("0.01"))))
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: USDT TRC20\n"
        f"На баланс: {amount_usd} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount_usdt.quantize(Decimal('0.01'))} USDT\n"
        f"️ ☝️\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только USDT (TRC20) на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Рекомендуем отправить чуть больше, чтобы баланса точно хватило\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"В случае проблем по оплате, пишите в сообщение по заявке\n"
        f"После подтверждения заявки вы получите реквизиты для оплаты! У вас будет 15 минут для того, что бы оплатить.\n"
        f"Вы можете отправлять сообщения оператору технической поддержки."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=" Подтвердить", callback_data="PAYMENT_confirm_usdt")],
        [InlineKeyboardButton(text=" Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_confirm_"))
async def on_payment_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    request_id = data.get("request_id", 0)
    amount = data.get(f"amount_{coin.lower()}", "0.01")
    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh" if coin == "LTC" else "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    if coin.upper() == "USDT":
        wallet = "USDT_TRC20_WALLET_HERE"
    coin_marker = coin.lower()
    for pm in family_state.payment_methods:
        pm_key = pm.key.lower()
        # match by exact key OR by prefix (e.g. usdt_trc20 matches coin=USDT)
        if pm_key == coin_marker or pm_key.startswith(coin_marker + "_") or pm_key.startswith(coin_marker + "-"):
            if pm.requisites and "HERE" not in pm.requisites:
                wallet = pm.requisites
            break
    await state.update_data(wallet=wallet)
    text = (
        f"Заявка на пополнение #{request_id}\n"
        f"Способ пополнения: {coin}\n"
        f"На баланс: {data.get('amount_usd', 85)} $\n\n"
        f"👇 👇\n"
        f"Сумма к оплате: {amount} {coin}\n\n"
        f"Реквизиты для оплаты:\n"
        f"<code>{escape(wallet)}</code>\n"
        f"☝️ ☝️\n\n\n"
        f"Заявка подтверждена\n"
        f"Ожидайте генерации адреса {coin}. Время для оплаты - 60 минут.\n\n"
        f"ℹ️ Информация\n\n"
        f"✅ Отправляйте только {coin} на указанный адрес\n"
        f"✅ Вы можете отправить любую сумму — баланс пересчитается автоматически\n"
        f"✅ Зачисление после 1 подтверждения в сети\n\n"
        f"Для вас сгенерирован уникальный адрес для пополнения.\n"
        f"Отправьте {coin} на указанный адрес.\n\n"
        f"Вы можете отправить любую сумму — баланс будет пересчитан автоматически.\n"
        f"Рекомендуем отправить чуть больше указанной суммы, чтобы начисленного баланса точно хватило на покупку.\n\n"
        f"После 1 подтверждения в сети средства будут зачислены автоматически."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📱 LTC QRCODE 1", callback_data="PAYMENT_qr1")],
        [InlineKeyboardButton(text="📱 LTC QRCODE 2", callback_data="PAYMENT_qr2")],
        [InlineKeyboardButton(text="👍 Оплачено!", callback_data="PAYMENT_paid")],
        [InlineKeyboardButton(text="🚫 Отменить", callback_data="PAYMENT_cancel")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_message")
async def on_payment_message(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = _stretch("Вы можете написать оператору технической поддержки: @EvilSUPPORT_AU")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
        [InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_paid")
async def on_payment_paid(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text = _stretch("Ваша заявка принята на проверку. Ожидайте подтверждения от оператора.\n\nКонтакты оператора: @EvilSUPPORT_AU")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Написать оператору", url="https://t.me/EvilSUPPORT_AU")],
        [InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_cancel")
async def on_payment_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = _stretch("Оплата отменена.")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_LK_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.startswith("PAYMENT_qr"))
async def on_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    coin = data.get("coin", "LTC")
    wallet = data.get("wallet", "ltc1q3peqmfe0s6jg4tsjcvunl905hxxgvjduds2wuh")
    
    # Generate QR code
    try:
        if coin == "LTC":
            qr_data = f"litecoin:{wallet}"
        elif coin == "BTC":
            qr_data = f"bitcoin:{wallet}"
        else:
            qr_data = wallet
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        bio = io.BytesIO()
        img.save(bio, format='PNG')
        bio.seek(0)
        qr_photo = BufferedInputFile(bio.read(), filename="qr_code.png")
        
        await callback.message.answer_photo(qr_photo, caption=f"QR код для {coin}:\n<code>{escape(wallet)}</code>")
    except Exception as e:
        logger.warning(f"Could not generate QR: {e}")
        await callback.message.answer(f"Не удалось сгенерировать QR код. Адрес: <code>{escape(wallet)}</code>")


class PromoState(StatesGroup):
    waiting = State()


class DiscountCodeState(StatesGroup):
    waiting = State()


@router.callback_query(F.data == "MAIN_MENU_PROMO_CALLBACK")
async def on_promo_request(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.set_state(PromoState.waiting)
    text = _stretch("Введите промокод сообщением:")
    await edit_or_send(callback.message, text, _back_markup())


@router.message(PromoState.waiting)
async def on_promo_input(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(_stretch("Промокод не найден или уже использован."), reply_markup=_main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_PROMOTIONS_CALLBACK")
async def on_promotions(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "У нас действует накопительная программа:\n"
        "Купив 5 товаров Вы получите постоянную скидку -1%\n"
        "Купив 10 товаров Вы получите постоянную скидку -2%\n"
        "Купив 15 товаров Вы получите постоянную скидку -3%\n"
        "Купив 20 товаров Вы получите постоянную скидку -4%\n"
        "Купив 25 товаров Вы получите постоянную скидку -5%\n"
        "Купив 30 товаров Вы получите постоянную скидку -6%\n"
        "Купив 35 товаров Вы получите постоянную скидку -7%\n"
        "Купив 40 товаров, Вы получите постоянную скидку -8%\n"
        "Купив 60 товаров, Вы получите постоянную скидку -10%\n"
        "Купив 100 товаров, Вы получите скидку -12%"
    )
    await send_new(callback.message, text, _back_markup())


@router.callback_query(F.data == "MAIN_MENU_VACANCIES_CALLBACK")
async def on_vacancies(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    tpl = _get_template()
    rules_url = str(tpl.vacancy_rules_url) if tpl.vacancy_rules_url else "https://t.me/EvilSUPPORT_AU"
    apply_url = str(tpl.vacancy_apply_url) if tpl.vacancy_apply_url else "https://t.me/EvilSUPPORT_AU"
    text = _stretch("Требуются курьеры по всей Украине!")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Прочитать усовия", url=rules_url),
            InlineKeyboardButton(text="Устроиться", url=apply_url),
        ],
        [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "MAIN_MENU_PROFILE_CALLBACK")
async def on_profile(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username or ""
    ref_link = f"https://t.me/{bot_username}?start={user_id}" if bot_username else "—"
    text = (
        f"👤 Ваш ID <a href=\"tg://user?id={user_id}\">{user_id}</a>\n\n"
        "🛒 Выполнено заказов - 0\n\n"
        "💰 Баланс: 0.00 USD\n\n"
        "👥 Приглашенных пользователей: 0\n\n"
        "📎 Ссылка для приглашения:\n\n"
        f"<a href=\"{ref_link}\">{escape(ref_link.removeprefix('https://'))}</a>"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Вывод средств", callback_data="PROFILE_WITHDRAW_CALLBACK")],
        [InlineKeyboardButton(text="Назад ◀️", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await send_intro_screen(callback.message, text, markup)


@router.callback_query(F.data == "PROFILE_WITHDRAW_CALLBACK")
async def on_profile_withdraw(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await safe_answer(callback, "Минимальная сумма: 50 usd", show_alert=True)


@router.callback_query(F.data == "PROFILE_CREATE_PROMO_CALLBACK")
async def on_create_promo(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = _stretch("Извините, случилась ошибка!\nВаш баланс: 0 ₴")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
            InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_PROFILE_CALLBACK"),
        ],
    ])
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "PROFILE_MY_PURCHASES_CALLBACK")
async def on_my_purchases(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = _stretch("Ваши покупки:")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
            InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_PROFILE_CALLBACK"),
        ],
    ])
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "MAIN_MENU_SECRET_PHRASE_CALLBACK")
async def on_secret_phrase(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    user_id = callback.from_user.id if callback.from_user else 0
    phrase = _get_secret_phrase(user_id)
    if phrase:
        await state.clear()
        text = f"‼️ Секретная фраза ‼️\n\nВаше секретное слово: {escape(phrase)}"
        await send_new(callback.message, text, _main_menu_markup())
        return
    await state.set_state(SecretPhraseState.waiting)
    await send_new(callback.message, _SECRET_PHRASE_PROMPT, _secret_phrase_markup())


@router.callback_query(F.data == "MAIN_MENU_BONUS_CALLBACK")
async def on_bonus(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = (
        "Условия получения бонусов:\n    \n"
        "Мы готовы делиться с тобой прибылью с каждой продажи! "
        "Просто разошли эту ссылку своим друзьям и с каждой их покупки "
        "ты будешь получать до 5%!\n\n"
        f"👉 https://t.me/{bot_username}?start={user_id} 👈\n\n"
        "Считай сам - твои друзья совершат пару покупок, а для тебя будет уже "
        "хорошая скидка! А ведь ты можешь рассылать ссылку в любые чаты, "
        "где люди будут готовы совершить покупки! И тогда счет пойдет уже на десятки ;)"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_RULES_CALLBACK")
async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "✅ Операторы работают с 11:00 до 03:00 по Балийскому времени\n\n"
        "✅ Важно знать основные правила, нарушения которых карается отказом в обслуживании и последующим баном:\n"
        "1️⃣ Вы оставили негативный отзыв, не обратившись в л.с. магазина за помощью "
        "(в рабочее время) и не дождавшись ответа оператора\n"
        "2️⃣ Мат, оскорбления сотрудников магазина в личных сообщениях. Угрозы любого характера, "
        "включая в адрес курьера и/или угроза негативным отзывом\n"
        "3️⃣ Раскрытие локации кладов/фишинг/любые ссылки в отзывах, кроме ссылок нашего магазина"
    )
    # Replace the caption/text in the existing start-screen message and retain
    # the complete main-menu keyboard.
    await edit_or_send(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_MEDICAL_CALLBACK")
async def on_medical(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = _format_text_with_links(_get_template().medicine_text or "⛑️ Медицина")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Закрыть", callback_data="CLOSE_MESSAGE_CALLBACK")],
    ])
    # Keep the start screen untouched: medicine opens as a separate closable message.
    await callback.message.answer(text, reply_markup=markup)


_URL_RE = re.compile(r"(?P<url>https?://[^\s<>]+|tg://[^\s<>]+)")


def _format_text_with_links(text: str) -> str:
    """Render plain admin text safely, preserving any URLs as Telegram links."""
    parts: list[str] = []
    position = 0
    for match in _URL_RE.finditer(text):
        parts.append(escape(text[position:match.start()]))
        url = match.group("url").rstrip(".,;:!?")
        trailing = match.group("url")[len(url):]
        parts.append(f'<a href="{escape(url, quote=True)}">{escape(url)}</a>{escape(trailing)}')
        position = match.end()
    parts.append(escape(text[position:]))
    return "".join(parts)


@router.callback_query(F.data == "MAIN_MENU_EXCHANGE_CALLBACK")
async def on_exchange(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    template = _get_template()
    rows = [
        [InlineKeyboardButton(text=item.label, url=str(item.url))]
        for item in template.exchangers
        if item.label and item.url
    ]
    rows.append([InlineKeyboardButton(text="❌ Закрыть", callback_data="CLOSE_MESSAGE_CALLBACK")])
    text = _format_text_with_links(template.exchange_text or "💱 Обмен валют")
    # The exchange card is a separate message so the start screen remains visible.
    await callback.message.answer(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data == "MAIN_MENU_REVIEWS_CALLBACK")
async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    template = _get_template()
    if template.reviews_url:
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Отзывы 📝", url=str(template.reviews_url))],
            [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
        ])
        text = "<b>Отзывы 📝</b>\n\nОткройте отзывы по ��нопке ниже."
    else:
        markup = _back_markup()
        text = "<b>Отзывы 📝</b>\n\nСсылка на отзывы пока не настроена."
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "MAIN_MENU_WORK_CALLBACK")
async def on_work(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    template = _get_template()
    if template.work_url:
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🧑‍💼 Работа", url=str(template.work_url))],
            [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
        ])
        text = "<b>🧑‍💼 Работа</b>\n\nОткройте актуальные предложения по кнопке ниже."
    else:
        markup = _back_markup()
        text = "<b>🧑‍💼 Работа</b>\n\nРаздел пока не настроен."
    await send_new(callback.message, text, markup)


@router.callback_query(F.data == "lang:en")
async def on_english(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    try:
        await callback.message.edit_caption(caption=_main_menu_text(), reply_markup=_main_menu_markup("en"))
    except TelegramBadRequest:
        await callback.message.edit_text(_main_menu_text(), reply_markup=_main_menu_markup("en"))


@router.callback_query(F.data == "lang:ru")
async def on_russian(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    try:
        await callback.message.edit_caption(caption=_main_menu_text(), reply_markup=_main_menu_markup("ru"))
    except TelegramBadRequest:
        await callback.message.edit_text(_main_menu_text(), reply_markup=_main_menu_markup("ru"))


@router.callback_query(F.data == "MAIN_MENU_NEWLIST_CALLBACK")
async def on_showcase(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    lines: list[str] = []
    counter = 1
    for city in settings.cities:
        if not city.products:
            continue
        lines.append(f'Доступные товары "{city.label}"')
        for product in city.products:
            for option in product.options:
                lines.append(f"📁 {product.label}")
                price_display = _option_price_display(option)
                lines.append(f"{counter}) {product.label} {price_display}")
                option_districts = option.districts or product.districts or city.districts
                for district in option_districts:
                    lines.append(f"{district} ✅ КУПИТЬ")
                lines.append("")
                counter += 1
    text = "\n".join(lines) if lines else "Товары временно отсутствуют."
    await send_new(callback.message, text, _main_menu_markup())


def _instructions_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="▪️ Прайс лист", callback_data="MAIN_MENU_PRICELIST_CALLBACK"),
            InlineKeyboardButton(text="▪️ Мои покупки", callback_data="PROFILE_MY_PURCHASES_CALLBACK"),
        ],
        [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])


@router.callback_query(F.data == "MAIN_MENU_INFO_CALLBACK")
async def on_info(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Выберите: ВАШ ГОРОД ➡️ ТОВАР ➡️ РАЙОН ➡️ СПОСОБ ОПЛАТЫ ➡️ СОВЕРШИТЕ ОПЛАТУ ➡️ "
        "СЛЕДУЙТЕ ИНСТРУКЦИЯМ ВЫБРАННОЙ ПЛАТЕЖНОЙ СИСТЕМЫ ➡️ Получите оплаченный товар в течении 60сек.\n\n"
        "Оплату можно производить двумя платежами, так же можно оплатить разными платежными системами, "
        "например одну часть Global24, вторую часть Easypay.\n"
        "Если пополнили больше нужной суммы, все лишние средства будут зачислены вам на Личный счет."
    )
    await send_new(callback.message, text, _instructions_markup())




_PRICE_LIST_SEPARATOR = "-" * 37
# Лимит сообщения в Telegram — 4096 символов, держим запас.
_TG_TEXT_LIMIT = 4000
# Лимит строк inline-клавиатуры — 100, поэтому города листаем страницами.
_PRICE_CITIES_PER_PAGE = 40


def _price_list_city_chunks(city: CityConfig) -> list[str]:
    """Полный прайс города, разбитый на сообщения так, чтобы ничего не обрезалось."""
    header = f"{city.icon or '🔶'} {city.label}"
    blocks: list[str] = []
    for index, product in enumerate(city.products):
        product_lines = [] if index == 0 else [_PRICE_LIST_SEPARATOR]
        product_lines.append(f"{product.label}")
        if not product.options:
            blocks.append("\n".join(product_lines))
        # Заголовок товара приклеиваем к первой фасовке, иначе он может остаться
        # висеть в конце сообщения, а фасовки уедут в следующее.
        product_header_pending = True
        for option in product.options:
            districts = option.districts or product.districts or city.districts
            option_header = f"▪️ {option.label} за {_option_price_display(option)}"
            part = (product_lines + [""] if product_header_pending else []) + [option_header]
            product_header_pending = False
            part_len = sum(len(line) + 1 for line in part)
            for district in districts:
                line = f"▫️ {district}"
                if part_len + len(line) + 1 > _TG_TEXT_LIMIT - len(header) - 8:
                    blocks.append("\n".join(part))
                    part = [f"{option_header} (продолжение)"]
                    part_len = len(part[0])
                part.append(line)
                part_len += len(line) + 1
            blocks.append("\n".join(part))
    if not blocks:
        blocks = ["Товары временно отсутствуют."]

    chunks: list[str] = []
    current = header
    for block in blocks:
        candidate = f"{current}\n\n{block}"
        if len(candidate) > _TG_TEXT_LIMIT:
            chunks.append(current)
            current = f"{header} (продолжение {len(chunks) + 1})\n\n{block}"
        else:
            current = candidate
    chunks.append(current)
    return chunks


def _price_list_menu_markup() -> InlineKeyboardMarkup:
    settings = get_settings()
    known_city_keys = {city.key for city in settings.cities}
    rows: list[list[InlineKeyboardButton]] = []
    grouped_city_keys: set[str] = set()
    for region_key, region_label, region_icon, city_keys in REGIONS:
        available = [key for key in city_keys if key in known_city_keys]
        if not available:
            continue
        grouped_city_keys.update(available)
        callback_data = (
            f"price:{available[0]}" if len(available) == 1 else f"price_region:{region_key}:0"
        )
        rows.append([InlineKeyboardButton(text=f"{region_icon} {region_label}", callback_data=callback_data)])
    for city in settings.cities:
        if city.key in grouped_city_keys:
            continue
        label = f"{city.icon} {city.label}".strip() if city.icon else city.label
        rows.append([InlineKeyboardButton(text=label, callback_data=f"price:{city.key}")])
    rows.append([
        InlineKeyboardButton(text="▪️ Инструкции", callback_data="MAIN_MENU_INFO_CALLBACK"),
        InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "MAIN_MENU_PRICELIST_CALLBACK")
async def on_price_list(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    settings = get_settings()
    products = sum(len(city.products) for city in settings.cities)
    text = (
        "Сейчас в наличии:\n"
        f"➖ Городов: {len(settings.cities)}\n"
        f"➖ Позиций: {products}\n\n"
        "Выберите город — бот покажет полный прайс с районами."
    )
    await send_new(callback.message, text, _price_list_menu_markup())


@router.callback_query(F.data.startswith("price_region:"))
async def on_price_region(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    parts = callback.data.split(":")
    region_key = parts[1]
    page = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
    settings = get_settings()
    cities = _region_cities(region_key, settings)
    region = next((r for r in REGIONS if r[0] == region_key), None)
    if not cities or not region:
        await edit_or_send(callback.message, _stretch("Область не найдена."), _back_markup())
        return

    pages = max(1, -(-len(cities) // _PRICE_CITIES_PER_PAGE))
    page = max(0, min(page, pages - 1))
    window = cities[page * _PRICE_CITIES_PER_PAGE:(page + 1) * _PRICE_CITIES_PER_PAGE]

    rows: list[list[InlineKeyboardButton]] = []
    for city in window:
        label = f"{city.icon} {city.label}".strip() if city.icon else city.label
        rows.append([InlineKeyboardButton(text=label, callback_data=f"price:{city.key}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="<--", callback_data=f"price_region:{region_key}:{page - 1}"))
    if page < pages - 1:
        nav.append(InlineKeyboardButton(text="-->", callback_data=f"price_region:{region_key}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([
        InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
        InlineKeyboardButton(text="Назад", callback_data="MAIN_MENU_PRICELIST_CALLBACK"),
    ])

    suffix = f" (стр. {page + 1} из {pages})" if pages > 1 else ""
    text = _stretch(f"{region[2]} {region[1]}{suffix}\nВыберите город:")
    await edit_or_send(callback.message, text, InlineKeyboardMarkup(inline_keyboard=rows))


@router.callback_query(F.data.startswith("price:"))
async def on_price_city(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    city_key = callback.data.split(":", 1)[1]
    settings = get_settings()
    city = next((c for c in settings.cities if c.key == city_key), None)
    if not city:
        await edit_or_send(callback.message, _stretch("Город не найден."), _back_markup())
        return
    chunks = _price_list_city_chunks(city)
    for chunk in chunks[:-1]:
        await callback.message.answer(chunk)
    await callback.message.answer(chunks[-1], reply_markup=_price_list_menu_markup())


@router.callback_query(F.data == "MAIN_REVIEWS_CALLBACK")
async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Рейтинг магазина: ⭐ 3,9/5 (64 шт.)\n\n"
        "Ваши отзывы делают наш магазин лучше!\n\n"
        "⭐ | MEFEDRON 2G (Evil Georgia)\n"
        "📍 ТБИЛИСИ\n"
        "ძველი ადრესია ეს ყლეობა\n"
        "от 27.06.2026 02:59\n\n\n"
        "Отзывы можно оставлять только к совершенным покупкам."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="<--", callback_data="REVIEW_PREV"),
            InlineKeyboardButton(text="-->", callback_data="REVIEW_NEXT"),
        ],
        [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data.in_({"REVIEW_PREV", "REVIEW_NEXT"}))
async def on_review_page(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback, "Нет других отзывов", show_alert=True)


@router.callback_query(F.data == "CREATE_PRIVATE_BOT_CALLBACK")
async def on_private_bot(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    text = (
        "Вы не можете создавать личных ботов, пока не совершите необходимое кол-во покупок.\n\n"
        "Всего покупок: 0\n"
        "Необходимо покупок для создания бота: 1"
    )
    await send_new(callback.message, text, _main_menu_markup())


@router.callback_query(F.data == "MAIN_MENU_WEB_AUTH_CODE")
async def on_web_auth(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    site_code = f"fission-{random.randint(10000, 99999)}-viper"
    text = (
        f"🔑 Ваш код для входа на сайт:\n\n"
        f"{site_code}\n\n"
        f"Нажмите на скрытый текст, чтобы увидеть код.\n\n"
        f"Этот код вы можете использовать для авторизации на сайте или в мобильном приложении.\n\n"
        f"⚠️ Никому никогда не сообщайте этот код — используя его можно получить доступ "
        f"к вашему аккаунту, истории покупок и балансу."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Назад", callback_data="BACK_TO_MAIN_MENU_CALLBACK")],
    ])
    await edit_or_send(callback.message, text, markup)


def _find_card_requisites(family_state: FamilyState) -> str:
    for pm in family_state.payment_methods:
        pm_key = pm.key.lower()
        if "card" in pm_key or "карт" in pm_key or "паy" in pm_key:
            if pm.requisites and "HERE" not in pm.requisites:
                return pm.requisites
    return "5355 2800 6238 6170"


def _find_global24_wallet(family_state: FamilyState) -> str:
    for pm in family_state.payment_methods:
        pm_key = pm.key.lower()
        if "global24" in pm_key or "global_24" in pm_key or "g24" in pm_key:
            if pm.requisites and "HERE" not in pm.requisites:
                return pm.requisites
    return str(random.randint(10 ** 13, 10 ** 14 - 1))


def _find_purchase_card_requisites(family_state: FamilyState, method_key: str) -> str | None:
    """Реквизиты для «Перевод на карту #N»: сначала точный ключ (card1), потом общий (card).

    Возвращает то, что настроено в payment_methods: либо ссылку на оплату, либо
    номер карты. None — если ничего не настроено, тогда генерируется ex24-ссылка.
    """
    marker = method_key.strip().lower()
    for candidate in (marker, "card", "карта"):
        for pm in family_state.payment_methods:
            if pm.key.strip().lower() != candidate:
                continue
            if pm.requisites and "HERE" not in pm.requisites:
                return pm.requisites.strip()
    return None


def _is_pay_url(value: str) -> bool:
    return value.lower().startswith(("http://", "https://", "tg://"))


def _saper_view(data: dict) -> tuple[str, InlineKeyboardMarkup]:
    text = (
        "Игра Сапер!\n"
        "Суть очень проста, перед вами 12 ячеек. Вам нужно угадать ячейку с шансом на выигрыш\n"
        "-в 1 из них шанс на выигрыш 100%\n"
        "-еще в 3 шанс 50% на выигрыш\n"
        "-в остальных 8 ячейках шанс 0%\n"
        "-после каждого хода все ячейки перемешиваются\n\n"
        "Стоимость каждого шага 10% от стоимости товара.\n"
        "Чтобы пополнить свой баланс, вернитесь в главное меню и выберите (Пополнить баланс)\n\n"
        "В случае победы вы получите товар, удачи)\n"
        "(Снизили стоимость шага до 10%)\n"
        f"Бронь до {data.get('saper_expires_display')}\n"
        "Цены:\n"
        "➖ ➖ ➖ ➖ ➖ ➖ ➖ ➖ ➖\n\n"
        "Выберите свой варинат:"
    )
    rows = []
    for row_start in range(0, 12, 4):
        rows.append([
            InlineKeyboardButton(text="💣", callback_data=f"SAPER_CELL_{i}")
            for i in range(row_start, row_start + 4)
        ])
    rows.append([InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    return text, markup


@router.callback_query(F.data.startswith("SAPER_CELL_"))
async def on_saper_cell(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    price = int(data.get("selected_price", 0) or 0)
    step_cost = max(1, round(price * 0.10)) + random.randint(1, 9)
    text = _stretch(f"Извините, случилась ошибка!\nНедостаточно средств: {step_cost} ₴")
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Главное меню", callback_data="BACK_TO_MAIN_MENU_CALLBACK"),
            InlineKeyboardButton(text="Назад", callback_data="BUY_PAYMENT_saper"),
        ],
    ])
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "BUY_PAYMENT_saper")
async def on_buy_payment_saper(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    expires_at = datetime.now() + timedelta(minutes=15)
    await state.update_data(saper_expires_display=expires_at.strftime("%d-%m | %H : %M : %S"))
    text, markup = _saper_view(await state.get_data())
    await edit_or_send(callback.message, text, markup)


def _global24_view(data: dict) -> tuple[str, InlineKeyboardMarkup]:
    text = (
        f"Заказ № {data.get('order_id')}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Город: 🔸{data.get('selected_city_label') or '—'}\n"
        f"Товар: {data.get('selected_product_label') or '—'}\n"
        f"Фасовка: ▪️{data.get('selected_option_label') or '—'} за {data.get('selected_price') or 0} ₴\n"
        f"Район: ▫️{data.get('selected_district') or '—'}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Кошелек: {data.get('order_card')}\n"
        f"Сумма к оплате: {data.get('order_amount')} грн\n\n"
        f"(Если возникли трудности с пополнением кошелька, сделайте новый заказ, бот выдаст другой кошелек)\n"
        f"Как пополнить свой кошелек:\n"
        f"Скачайте или обновите приложение \n"
        f"(mob.g-24.pro 📱Androind)\n"
        f"(https://apps.apple.com/ru/app/global24/id1458873410 📱IOS)\n\n"
        f"Инструкция для оплаты с карты\n"
        f"1) Перейдите в  раздел «Пополнить — с карты Р2Р»  в нижнем меню моб. приложения\n"
        f"2) Выберите одну из доступных сумм пополнения. При пополнении от 2500 комиссия не взимается👌\n"
        f"3) Нажмите \"ПОПОЛНИТЬ\" для создания заявки на пополнение\n"
        f"4) Скопируйте номер карты получателя и сумму перевода\n"
        f"5) Переведите средства со своей карты на карту получателя ОДНИМ платежом\n"
        f"6) Нажмите кнопку  \"Я Оплатил\"\n"
        f"7) Если в Телеграм поступит запрос от бота - загрузите квитанцию 🧾 об оплате\n"
        f"⚠️ Если Вы НЕ оплатили заявку вовремя, просьба ее  НЕ оплачивать позже.\n\n"
        f"После того как вы пополни свой кошелек, переведите средства на наш кошелек и отправьте боту данные платежа.\n"
        f"➖➖➖➖➖➖➖➖➖➖\n\n"
        f"❗️❗️❗️Вы должны оплатить до: {data.get('order_expires_display')}❗️❗️❗️"
    )
    tpl = _get_template()
    pay_url = str(tpl.global24_pay_url) if tpl.global24_pay_url else "https://mob.g-24.pro"
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Перейти к оплате", url=pay_url)],
        [
            InlineKeyboardButton(text="Проверить оплату", callback_data="GLOBAL24_CHECK_PAYMENT"),
            InlineKeyboardButton(text="Главное меню", callback_data="PAYMENT_EXIT_ASK"),
        ],
    ])
    return text, markup


@router.callback_query(F.data == "BUY_PAYMENT_global24")
async def on_buy_payment_global24(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    price = int(data.get("selected_price", 0) or 0)
    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = _find_global24_wallet(family_state)
    order_id = random.randint(10000000, 99999999)
    expires_at = datetime.now() + timedelta(minutes=15)
    expires_display = expires_at.strftime("%d-%m | %H : %M : %S")

    await state.update_data(
        payment_method="global24",
        order_id=order_id,
        order_card=wallet,
        order_amount=price,
        order_expires_display=expires_display,
    )

    text, markup = _global24_view(await state.get_data())
    await send_new(callback.message, text, markup)
    await callback.message.answer(wallet)


@router.callback_query(F.data == "GLOBAL24_CHECK_PAYMENT")
async def on_global24_check_payment(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback, "Платеж не найден. Попробуйте позже.", show_alert=True)


# Крипто-методы оплаты покупки: тикер -> (подпись, сеть, ключи в payment_methods)
_CRYPTO_PAYMENT_METHODS: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "usdt": ("USDT TRC20", "TRC20 (Tron)", ("usdt_trc20", "usdt")),
    "usdt_bep20": ("USDT (BEP20)", "BEP20 (BNB Smart Chain)", ("usdt_bep20", "usdt_bsc", "usdt")),
    "ltc": ("LITECOIN", "Litecoin (LTC)", ("ltc", "litecoin")),
    "btc": ("BTC", "Bitcoin (BTC)", ("btc", "bitcoin")),
}


def _find_crypto_wallet(family_state: FamilyState, keys: tuple[str, ...]) -> str | None:
    for candidate in keys:
        for pm in family_state.payment_methods:
            if pm.key.strip().lower() != candidate:
                continue
            if pm.requisites and "HERE" not in pm.requisites:
                return pm.requisites.strip()
    return None


def _crypto_payment_view(data: dict) -> tuple[str, InlineKeyboardMarkup]:
    coin = data.get("order_coin") or "USDT"
    label, _network, _ = _CRYPTO_PAYMENT_METHODS.get(data.get("payment_method", "").removeprefix("crypto_"), (coin, coin, ()))
    order_id = data.get("order_id")
    # Keep the city, item and quantity on one line in the payment receipt.
    item = " ".join(filter(None, [
        data.get("selected_city_label"),
        data.get("selected_product_label"),
        data.get("selected_option_label"),
    ]))
    seconds_left = max(0, float(data.get("active_order_until", 0) or 0) - time.time())
    total_minutes = max(1, int((seconds_left + 59) // 60))
    hours, minutes = divmod(total_minutes, 60)
    duration_label = f"{hours}ч {minutes}мин" if hours else f"{minutes}мин"
    text = (
        f"🛒 Вы создали заказ #{order_id}\n\n"
        f"{item or 'Товар'}\n"
        "➖➖➖➖➖➖➖➖➖\n\n"
        f"💰 К оплате {data.get('order_amount_crypto')} {label}\n\n"
        f"❗️ Адрес для оплаты ТОЛЬКО {label}:\n\n"
        f"<code>{data.get('order_wallet')}</code>\n\n"
        f"⏳ Время на оплату заказа {duration_label}\n\n"
        "➖➖➖➖➖➖➖➖➖\n\n"
        "📢 Товар будет выдан автоматически после подтверждения в сети\n\n"
        "⚠️Внимание⚠️\n"
        "Если вы отправляете оплату после отмены заказа или после окончания таймера, заказ может быть выдан другому покупателю.\n"
        "❗️В ТАКОМ СЛУЧАЕ СРЕДСТВА НЕ ВОЗВРАЩАЮТСЯ, КОМПЕНСАЦИЯ НЕ ПРЕДУСМОТРЕНА.❗️\n"
        "Пожалуйста, оплачивайте только при активном заказе и в пределах времени таймера."
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Продлить время оплаты", callback_data="CRYPTO_EXTEND_PAYMENT")],
        [InlineKeyboardButton(text="Отменить ✖️", callback_data="CRYPTO_CANCEL_PAYMENT")],
    ])
    return text, markup


@router.callback_query(F.data.startswith("BUY_PAYMENT_crypto_"))
async def on_buy_payment_crypto(callback: CallbackQuery, state: FSMContext) -> None:
    """Show the order confirmation before generating crypto payment details."""
    await safe_answer(callback)
    coin_key = callback.data.removeprefix("BUY_PAYMENT_crypto_").lower()
    method = _CRYPTO_PAYMENT_METHODS.get(coin_key)
    if method is None:
        await safe_answer(callback, "Способ оплаты недоступен.", show_alert=True)
        return
    label, _network, _wallet_keys = method
    data = await state.get_data()
    price = int(data.get("selected_price", 0) or 0)
    quantity = (data.get("selected_option_label") or "—").split("=", 1)[0].strip()
    text = (
        "ℹ️ Ваш заказ:\n\n"
        f"{data.get('selected_city_label') or '—'} "
        f"{data.get('selected_product_label') or '—'} {quantity}\n\n"
        f"💵 К оплате {price}$ = {price} $\n\n"
        "Подтвердить заказ ?"
    )
    template = _get_template()
    review_button = (
        InlineKeyboardButton(text="4.8 ⭐ | Отзывы", url=str(template.reviews_url))
        if template.reviews_url else
        InlineKeyboardButton(text="4.8 ⭐ | Отзывы", callback_data="ORDER_REVIEWS_UNAVAILABLE")
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Оплатить ✅", callback_data=f"PAYMENT_CONFIRM_CRYPTO:{coin_key}")],
        [InlineKeyboardButton(text="Использовать бонусный баланс", callback_data="ORDER_USE_BONUS")],
        [InlineKeyboardButton(text="Использовать дисконт код", callback_data="ORDER_USE_DISCOUNT")],
        [review_button],
        [InlineKeyboardButton(text="Отменить ❌", callback_data=f"product:{data.get('selected_city_key') or ''}:{data.get('selected_product_key') or ''}")],
    ])
    # The order confirmation must be a plain message, not a caption on the intro GIF.
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass
    await callback.message.answer(text, reply_markup=markup)


@router.callback_query(F.data == "ORDER_USE_BONUS")
async def on_order_use_bonus(callback: CallbackQuery) -> None:
    # Deliberately no-op: this control is present in the layout only.
    await safe_answer(callback)


@router.callback_query(F.data == "ORDER_USE_DISCOUNT")
async def on_order_use_discount(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.set_state(DiscountCodeState.waiting)
    await callback.message.answer(
        "Введите код",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Закрыть", callback_data="CLOSE_MESSAGE_CALLBACK")],
        ]),
    )


@router.message(DiscountCodeState.waiting)
async def on_discount_code_input(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "Код неправильный или уже был использован",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Закрыть", callback_data="CLOSE_MESSAGE_CALLBACK")],
        ]),
    )


@router.callback_query(F.data == "ORDER_REVIEWS_UNAVAILABLE")
async def on_order_reviews_unavailable(callback: CallbackQuery) -> None:
    await safe_answer(callback, "Отзывы пока недоступны.", show_alert=True)


@router.callback_query(F.data.startswith("PAYMENT_CONFIRM_CRYPTO:"))
async def on_confirm_buy_payment_crypto(callback: CallbackQuery, state: FSMContext) -> None:
    # Do not answer the callback before validation. Telegram only permits one
    # answer per callback; answering it here used to hide every later error
    # (for example, a missing wallet), making “Оплатить” look unresponsive.
    coin_key = callback.data.removeprefix("PAYMENT_CONFIRM_CRYPTO:").lower()
    method = _CRYPTO_PAYMENT_METHODS.get(coin_key)
    if method is None:
        await safe_answer(callback, "Способ оплаты недоступен.", show_alert=True)
        return
    label, _network, wallet_keys = method
    coin = "USDT" if coin_key in {"usdt", "usdt_bep20"} else coin_key.upper()

    data = await state.get_data()
    price = Decimal(str(int(data.get("selected_price", 0) or 0)))
    price_currency = str(data.get("selected_price_currency") or "UAH")

    # The cache is normally populated during application startup.  Refresh it
    # once on demand too: otherwise a temporary failure at startup made the
    # “Оплатить” button appear to do nothing for the next five minutes.
    uah_rate = get_usdt_uah_rate()
    if uah_rate is None:
        await asyncio.to_thread(refresh_market_rates)
        uah_rate = get_usdt_uah_rate()

    amount_crypto = convert_amount(price, price_currency, coin)
    if amount_crypto is None or amount_crypto <= 0 or uah_rate is None:
        await safe_answer(
            callback,
            "Не удалось получить курс. Попробуйте ещё раз через минуту.",
            show_alert=True,
        )
        return

    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    wallet = _find_crypto_wallet(family_state, wallet_keys)
    if not wallet:
        await safe_answer(
            callback,
            f"Кошелёк {label} не настроен. Напишите оператору.",
            show_alert=True,
        )
        return

    if coin == "USDT":
        rate_display = f"1 USDT = {uah_rate.quantize(Decimal('0.01'))} ₴"
    else:
        coin_price = (price / amount_crypto).quantize(Decimal("0.01"))
        rate_display = f"1 {coin} = {coin_price} {price_currency}"

    expires_at = datetime.now() + timedelta(hours=1)
    await state.update_data(
        payment_method=f"crypto_{coin_key}",
        order_kind="purchase",
        order_id=f"order_{uuid.uuid4().hex[:8]}",
        active_order_until=time.time() + 3600,
        order_coin=coin,
        order_wallet=wallet,
        order_amount_uah=int(price),
        order_amount_crypto=str(amount_crypto),
        order_rate_display=rate_display,
        order_expires_display=expires_at.strftime("%d-%m | %H : %M : %S"),
    )

    text, markup = _crypto_payment_view(await state.get_data())
    # Put the QR first in the chat, then send the payment instructions below it.
    # Editing the older confirmation message would display the text above the QR.
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass
    qr_message = await _send_payment_qr(callback.message, coin, wallet)
    payment_message = await qr_message.answer(text, reply_markup=markup)
    order_id = (await state.get_data()).get("order_id")
    if order_id:
        asyncio.create_task(_expire_crypto_order_after_hour(state, payment_message, str(order_id)))


async def _expire_crypto_order_after_hour(state: FSMContext, message: Message, expected_order_id: str) -> None:
    """Cancel this order after one hour, unless it was replaced or cancelled."""
    # Wait against the stored deadline so a minor scheduler delay cannot leave
    # the order active forever.
    while True:
        data = await state.get_data()
        if data.get("order_id") != expected_order_id:
            return
        seconds_left = float(data.get("active_order_until", 0) or 0) - time.time()
        if seconds_left <= 0:
            break
        await asyncio.sleep(seconds_left + 0.5)
    await state.clear()
    try:
        await message.answer(f"Истёк срок ожидания оплаты для вашего заказа #{expected_order_id}")
    except Exception:
        logger.exception("Could not send automatic payment-expiry notice")


async def _send_payment_qr(message: Message, coin: str, wallet: str) -> Message:
    """Send a compact payment QR and return its Telegram message."""
    try:
        # 5px modules and a 3-module margin keep the image noticeably smaller
        # while retaining reliable scanning.
        qr = qrcode.QRCode(version=1, box_size=5, border=3)
        scheme = "litecoin" if coin == "LTC" else "bitcoin" if coin == "BTC" else ""
        qr.add_data(f"{scheme}:{wallet}" if scheme else wallet)
        qr.make(fit=True)
        image = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        image.save(buffer, format="PNG", optimize=True)
        return await message.answer_photo(BufferedInputFile(buffer.getvalue(), filename="payment_qr.png"))
    except Exception:
        logger.exception("Could not generate payment QR")
        return await message.answer("Не удалось создать QR-код. Используйте адрес из сообщения ниже.")


@router.callback_query(F.data == "SHOW_ACTIVE_ORDER")
async def on_show_active_order(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    if float(data.get("active_order_until", 0) or 0) <= time.time():
        await state.update_data(active_order_until=0)
        await edit_or_send(callback.message, "Активных заказов нет.", _back_markup())
        return
    text, markup = _crypto_payment_view(data)
    await edit_or_send(callback.message, text, markup)
    await _send_payment_qr(callback.message, data.get("order_coin") or "USDT", data.get("order_wallet") or "")


@router.callback_query(F.data == "CRYPTO_EXTEND_PAYMENT")
async def on_crypto_extend_payment(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    if not data.get("order_id") or float(data.get("active_order_until", 0) or 0) <= time.time():
        await safe_answer(callback, "Этот заказ уже истёк.", show_alert=True)
        return
    # Each click adds one hour. Show the new total in the Telegram alert,
    # matching the requested payment-screen confirmation.
    previous_deadline = max(float(data.get("active_order_until", 0)), time.time())
    new_deadline = previous_deadline + 3600
    total_hours = max(1, round((new_deadline - time.time()) / 3600))
    await state.update_data(
        active_order_until=new_deadline,
        order_expires_display=datetime.fromtimestamp(new_deadline).strftime("%d-%m | %H : %M : %S"),
    )
    updated_text, updated_markup = _crypto_payment_view(await state.get_data())
    try:
        await callback.message.edit_text(updated_text, reply_markup=updated_markup)
    except TelegramBadRequest:
        pass
    await safe_answer(callback, f"Время на оплату продлено до {total_hours}ч 0мин", show_alert=True)


@router.callback_query(F.data == "CRYPTO_CANCEL_PAYMENT")
async def on_crypto_cancel_payment(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    # Leave the payment message in place, but remove its now-invalid controls.
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass
    await callback.message.answer("Заказ отменен.\n\n/start - главное меню")


@router.callback_query(F.data == "CRYPTO_CHECK_PAYMENT")
async def on_crypto_check_payment(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback, "Платеж не найден. Попробуйте позже.", show_alert=True)


@router.callback_query(F.data.startswith("BUY_PAYMENT_"))
async def on_buy_payment_method(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    price = int(data.get("selected_price", 0) or 0)

    method_key = callback.data.removeprefix("BUY_PAYMENT_")
    order_id = random.randint(1000000, 9999999)
    topup_id = str(uuid.uuid4())
    total_amount = round(price * 1.10)
    expires_at = datetime.now() + timedelta(minutes=15)
    expires_display = expires_at.strftime("%d-%m | %H : %M : %S")

    settings = get_settings()
    family_state = load_family_state(settings.data_path)
    configured = _find_purchase_card_requisites(family_state, method_key)

    if configured and not _is_pay_url(configured):
        pay_link = None
        pay_card = configured
    else:
        pay_link = configured or f"https://ex24.co/payments/pay/{topup_id}"
        pay_card = None

    await state.update_data(
        payment_method="card",
        order_id=order_id,
        order_topup_id=topup_id,
        order_amount=total_amount,
        order_pay_link=pay_link,
        order_pay_card=pay_card,
        order_expires_display=expires_display,
    )

    text, markup = _order_payment_view(await state.get_data())
    await send_new(callback.message, text, markup)
    if pay_card:
        # Реквизиты идут первым сообщением, блок с заявкой — вторым.
        await callback.message.answer(pay_card)
        await callback.message.answer(
            f"Заявка: {order_id}\n"
            f"Сумма: {total_amount}\n"
            f"/start"
        )
    else:
        await callback.message.answer(
            f"Заявка: {order_id}\n"
            f"Ссылка: {pay_link}\n"
            f"Сумма: {total_amount}\n"
            f"/start"
        )


def _order_payment_view(data: dict) -> tuple[str, InlineKeyboardMarkup]:
    pay_card = data.get("order_pay_card")
    pay_link = data.get("order_pay_link")
    # Карта вместо ссылки: URL-кнопку с номером карты Telegram не примет,
    # поэтому в этом случае кнопки «Перейти к оплате» нет.
    pay_line = f"Карта: <code>{pay_card}</code>" if pay_card else f"Оплата: {pay_link}"

    text = (
        f"Заказ № {data.get('order_id')}\n"
        f"Пополнение № {data.get('order_topup_id')}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Город: 🔸{data.get('selected_city_label') or '—'}\n"
        f"Товар: {data.get('selected_product_label') or '—'}\n"
        f"Фасовка: ▪️{data.get('selected_option_label') or '—'} за {data.get('order_amount') or 0} ₴\n"
        f"Район: ▫️{data.get('selected_district') or '—'}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"{pay_line}\n"
        f"Сумма: {data.get('order_amount')} грн\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"Товар забронирован до {data.get('order_expires_display')}. "
        f"После успешной оплаты бот сам отправит товар в чат. Не создавайте новых заказов, иначе этот аннулируется.❗️"
    )
    rows: list[list[InlineKeyboardButton]] = []
    if not pay_card:
        rows.append([InlineKeyboardButton(text="Перейти к оплате", url=pay_link or "https://ex24.co")])
    rows.append([InlineKeyboardButton(text="Главное меню", callback_data="PAYMENT_EXIT_ASK")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


def _payment_exit_confirmation_view() -> tuple[str, InlineKeyboardMarkup]:
    text = (
        "Вы действительно хотите выйти из оплаты?\n\n"
        "Если вы оплатите товар после выхода из оплаты, нужно будет заново его выбрать и нажать проверить оплату"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Вернуться к оплате", callback_data="PAYMENT_EXIT_STAY")],
        [InlineKeyboardButton(text="Главное меню", callback_data="PAYMENT_EXIT_CONFIRM")],
    ])
    return text, markup


@router.callback_query(F.data == "PAYMENT_EXIT_ASK")
async def on_payment_exit_ask(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    text, markup = _payment_exit_confirmation_view()
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_EXIT_STAY")
async def on_payment_exit_stay(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    data = await state.get_data()
    if not data.get("order_id"):
        await on_back_to_main(callback, state)
        return
    if data.get("order_kind") == "topup":
        text, markup = _topup_payment_view(data)
    elif data.get("payment_method") == "global24":
        text, markup = _global24_view(data)
    else:
        text, markup = _order_payment_view(data)
    await edit_or_send(callback.message, text, markup)


@router.callback_query(F.data == "PAYMENT_EXIT_CONFIRM")
async def on_payment_exit_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    await on_back_to_main(callback, state)


@router.callback_query(F.data == "CLOSE_MESSAGE_CALLBACK")
async def on_close_message(callback: CallbackQuery) -> None:
    await safe_answer(callback)
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass


@router.callback_query(F.data == "BACK_TO_MAIN_MENU_CALLBACK")
async def on_back_to_main(callback: CallbackQuery, state: FSMContext) -> None:
    await safe_answer(callback)
    await state.clear()
    user_id = callback.from_user.id if callback.from_user else 0
    bot_username = (await callback.message.bot.get_me()).username
    text = _main_menu_text(user_id, bot_username=bot_username)
    try:
        await callback.message.delete()
    except TelegramBadRequest:
        pass
    await send_intro_screen(callback.message, text, _main_menu_markup())


def _clone_router(src: Router) -> Router:
    """Create a fresh Router that mirrors src's handlers/middleware without sharing state."""
    dst = Router(name=f"evila_{id(src)}")
    for event_name, observer in src.observers.items():
        dst_observer = dst.observers[event_name]
        for handler in observer.handlers:
            dst_observer.handlers.append(handler)
        for mw in observer.middleware:
            dst_observer.middleware(mw)
        for mw in observer.outer_middleware:
            dst_observer.outer_middleware(mw)
    for sub in src.sub_routers:
        dst.include_router(_clone_router(sub))
    return dst


def create_bot_runtime(settings: Settings) -> Router:
    return _clone_router(router)


def build_bot(token: str, settings: Settings, proxy_url: str | None = None) -> tuple[Bot, Dispatcher]:
    # Курсы греются один раз в lifespan приложения и обновляются фоновой задачей.
    # Синхронный urlopen здесь блокировал общий event loop всех ботов на ~1 с при
    # каждом старте бота, поэтому его тут нет.
    if proxy_url:
        session = AiohttpSession(proxy=proxy_url)
        bot = Bot(token=token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    else:
        bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    dp.include_router(_clone_router(router))
    return bot, dp


@dataclass(slots=True)
class BotRuntime:
    spec: "BotSpec"
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task


async def start_runtime(
    settings: Settings,
    spec: "BotSpec",
    persist_spec=None,
    register_bot=None,
    list_bots=None,
    remove_bot_by_id=None,
    toggle_bot_pause_by_id=None,
    sync_payment_methods_for_all=None,
    sync_start_text_for_all=None,
    sync_admin_ids_for_all=None,
    sync_template_for_all=None,
    proxy_url: str | None = None,
) -> BotRuntime:
    bot, dp = build_bot(spec.token, settings, proxy_url=proxy_url)
    try:
        await bot.delete_webhook(drop_pending_updates=False)
    except Exception:
        pass
    task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
    if proxy_url:
        logger.info("Started bot @%s via proxy %s", spec.bot_username, proxy_url.split("@")[-1])
    else:
        logger.info("Started bot @%s", spec.bot_username)
    return BotRuntime(spec=spec, dispatcher=dp, bot=bot, task=task)


async def stop_runtime(runtime: BotRuntime) -> None:
    runtime.task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    try:
        await runtime.bot.session.close()
    except Exception:
        pass
    await asyncio.sleep(1)
