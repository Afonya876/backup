from __future__ import annotations

import os
import socket
from pathlib import Path

import uvicorn
from dotenv import load_dotenv


def is_port_busy(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
        except OSError:
            return True
    return False


def main() -> None:
    load_dotenv(Path(__file__).resolve().with_name(".env"))
    host = os.getenv("API_HOST", "127.0.0.1")
    port = int(os.getenv("API_PORT", "18746"))
    if is_port_busy(host, port):
        raise SystemExit(
            f"KFC is already running on {host}:{port}. "
            "Stop the existing process or change API_PORT in .env before starting another instance."
        )
    uvicorn.run("vip_shop.api:create_app", factory=True, host=host, port=port)


if __name__ == "__main__":
    main()
