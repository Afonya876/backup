from __future__ import annotations

import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"


def main() -> None:
    captcha_files = sorted(DATA_DIR.glob("*_captcha_*.json"))
    if not captcha_files:
        print("Captcha files not found. Nothing to reset.")
        return

    for path in captcha_files:
        path.write_text(json.dumps({}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Reset: {path}")


if __name__ == "__main__":
    main()
