from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


DEFAULT_CATALOG_PATH = Path(__file__).resolve().parent / "data" / "catalog.json"
DEFAULT_INPUT_PATH = Path(__file__).resolve().parent / "catalog_input.txt"
SECTION_HEADER_RE = re.compile(r"^===\s*(?P<city>.+?)\s*===\s*$")
PLACEHOLDER_DISTRICT_MARKERS = {
    "заполните районы",
    "заполните районы этого города",
}
GENERIC_DISTRICT_SEED = [
    "Центр",
    "Вокзал",
    "Северный",
    "Южный",
    "Западный",
    "Восточный",
    "Новый район",
    "Старый район",
    "Промзона",
]
CITY_DISTRICT_COUNT_OVERRIDES = {
    "Кишинев": 9,
}
CITY_DISTRICT_SEEDS = {
    "Кишинев": [
        "Центр",
        "Рышкановка",
        "Ботаника",
        "Чеканы",
        "Буюканы",
        "Скулянка",
        "Телецентр",
        "Старый город",
        "Почта Веке",
    ],
    "Оргеев": [
        "Центр",
        "Слобозия Доамней",
        "Лупоайка",
        "Вокзал",
        "Северный",
        "Южный",
    ],
    "Бельцы": [
        "Центр",
        "БАМ",
        "8-й квартал",
        "Молодово",
        "Дачия",
        "Северный",
    ],
    "Бендеры": [
        "Центр",
        "Борисовка",
        "Солнечный",
        "Ленинский",
        "Хомутяновка",
        "Шелковый",
    ],
    "ТИРАСПОЛЬ": [
        "Центр",
        "Балка",
        "Западный",
        "Кировский",
        "Октябрьский",
        "Красные казармы",
    ],
    "ФЛОРЕШТЫ": [
        "Центр",
        "Автовокзал",
        "Сахарный",
        "Северный",
        "Южный",
        "Станция",
    ],
    "СОРОКИ": [
        "Центр",
        "Сорока Ноуэ",
        "Вокзал",
        "Нагорный",
        "Речпорт",
        "Западный",
    ],
    "Единец": [
        "Центр",
        "Северный",
        "Южный",
        "Вокзал",
        "Старый район",
        "Новый район",
    ],
    "Комрат": [
        "Центр",
        "Автовокзал",
        "Южный",
        "Северный",
        "Новый район",
    ],
    "КАГУЛ": [
        "Центр",
        "Лапушна",
        "Северный",
        "Южный",
        "Вокзал",
        "Западный",
    ],
    "Унгены": [
        "Центр",
        "Молодежный",
        "Березовка",
        "Вокзал",
        "Северный",
        "Южный",
    ],
}


def normalize_name(value: str) -> str:
    return " ".join(value.strip().casefold().split())


def split_top_level(value: str, delimiter: str) -> list[str]:
    parts: list[str] = []
    current: list[str] = []
    depth = 0

    for char in value:
        if char == "[":
            depth += 1
        elif char == "]":
            depth -= 1
            if depth < 0:
                raise ValueError("Лишняя закрывающая скобка ']'.")

        if char == delimiter and depth == 0:
            chunk = "".join(current).strip()
            if chunk:
                parts.append(chunk)
            current = []
            continue

        current.append(char)

    if depth != 0:
        raise ValueError("Не хватает закрывающей скобки ']'.")

    tail = "".join(current).strip()
    if tail:
        parts.append(tail)
    return parts


def decode_meta_value(value: str) -> str:
    return value.strip().replace("\\n", "\n")


def has_placeholder_districts(raw_districts: object) -> bool:
    if not isinstance(raw_districts, list):
        return True
    normalized = [normalize_name(str(district)) for district in raw_districts if str(district).strip()]
    if not normalized:
        return True
    return all(marker in PLACEHOLDER_DISTRICT_MARKERS for marker in normalized)


def target_district_count(city_name: str, product_count: int) -> int:
    city_marker = normalize_name(city_name)
    for label, count in CITY_DISTRICT_COUNT_OVERRIDES.items():
        if normalize_name(label) == city_marker:
            return count
    if product_count >= 10:
        return 6
    if product_count >= 7:
        return 5
    if product_count >= 4:
        return 4
    if product_count >= 2:
        return 3
    return 2


def generate_city_districts(city_name: str, product_count: int) -> list[str]:
    city_marker = normalize_name(city_name)
    seed = list(GENERIC_DISTRICT_SEED)
    for label, districts in CITY_DISTRICT_SEEDS.items():
        if normalize_name(label) == city_marker:
            seed = list(districts)
            break
    for district in GENERIC_DISTRICT_SEED:
        if district not in seed:
            seed.append(district)
    return seed[: target_district_count(city_name, product_count)]


def parse_inline_meta(raw_meta: str) -> dict[str, str]:
    meta: dict[str, str] = {}
    for field in split_top_level(raw_meta, ";"):
        key, separator, value = field.partition("=")
        if separator != "=":
            continue
        normalized_key = normalize_name(key)
        decoded_value = decode_meta_value(value)
        if not decoded_value:
            continue
        if normalized_key in {"desc", "description", "описание"}:
            meta["description"] = decoded_value
        elif normalized_key in {"photo", "photo_keyword", "фото", "ключ"}:
            meta["photo"] = decoded_value
    return meta


def extract_inline_meta(chunk: str) -> tuple[str, dict[str, str]]:
    value = chunk.strip()
    if not value.endswith("}"):
        return value, {}
    meta_start = value.rfind("{")
    if meta_start == -1:
        return value, {}
    body = value[:meta_start].strip()
    raw_meta = value[meta_start + 1 : -1].strip()
    if not body or not raw_meta:
        return value, {}
    return body, parse_inline_meta(raw_meta)


def strip_repeated_city_prefix(chunk: str, city_name: str) -> str:
    value = chunk.strip()
    prefix, separator, tail = value.partition("/")
    if separator == "/" and normalize_name(prefix) == normalize_name(city_name):
        return tail.strip()
    return value


def looks_like_city_name(value: str) -> bool:
    candidate = value.strip()
    if not candidate:
        return False
    return re.fullmatch(r"[A-Za-zА-Яа-яЁёІіЇїЄєҐґ0-9 .,'’`()-]+", candidate) is not None


def build_product(product_index: int, label: str, options: list[str], meta: dict[str, str] | None = None) -> dict[str, object]:
    prepared_meta = meta or {}
    description = prepared_meta.get("description", "")
    photo_value = prepared_meta.get("photo", "")
    photo_url = photo_value if photo_value.startswith(("http://", "https://")) else None
    photo_path = ""
    if photo_value and photo_url is None:
        photo_path = photo_value if "/" in photo_value or "\\" in photo_value else f"keyword:{photo_value}"

    normalized_options = [option.strip() for option in options if option.strip()]
    if not normalized_options:
        normalized_options = [label]

    return {
        "key": f"product_{product_index}",
        "label": label,
        "button_label": label,
        "description": description,
        "photo_id": None,
        "photo_url": photo_url,
        "photo_path": photo_path,
        "options": [
            {"key": f"option_{option_index}", "label": option_label}
            for option_index, option_label in enumerate(normalized_options, start=1)
        ],
    }


def parse_product(chunk: str, product_index: int) -> dict[str, object]:
    chunk, meta = extract_inline_meta(chunk)
    left = chunk.find("[")
    right = chunk.rfind("]")
    if left == -1 and right == -1:
        label = chunk.strip()
        if not label:
            raise ValueError(f"У товара нет названия: '{chunk}'.")
        return build_product(product_index, label, [label], meta)

    if left == -1 or right == -1 or right < left:
        raise ValueError(
            f"Неверный блок товара: '{chunk}'. Ожидается формат товар[фасовка1,фасовка2] "
            "или готовая кнопка целиком без скобок."
        )

    label = chunk[:left].strip()
    if not label:
        raise ValueError(f"У товара нет названия: '{chunk}'.")

    raw_options = chunk[left + 1 : right].strip()
    options = [item.strip() for item in split_top_level(raw_options, ",") if item.strip()] if raw_options else []
    return build_product(product_index, label, options, meta)


def is_block_catalog_text(products_text: str) -> bool:
    lines = [line.strip() for line in products_text.splitlines() if line.strip()]
    if len(lines) < 2:
        return False

    has_option_lines = any("|" in line for line in lines)
    has_title_lines = any("|" not in line for line in lines)
    return has_option_lines and has_title_lines


def parse_line_catalog_input(products_text: str) -> list[dict[str, object]]:
    product_chunks = [line.strip() for line in products_text.splitlines() if line.strip()]
    if not product_chunks:
        raise ValueError("После города не найдено ни одного товара.")
    return [parse_product(chunk, index) for index, chunk in enumerate(product_chunks, start=1)]


def parse_classic_catalog_input(city_name: str, products_text: str) -> list[dict[str, object]]:
    if is_block_catalog_text(products_text):
        return parse_block_catalog_input(products_text)

    if "\n" in products_text:
        return parse_line_catalog_input(products_text)
    elif "|" in products_text:
        product_chunks = split_top_level(products_text, "|")
    else:
        product_chunks = split_top_level(products_text, "-")
    if not product_chunks:
        raise ValueError("После города не найдено ни одного товара.")

    product_chunks = [strip_repeated_city_prefix(chunk, city_name) for chunk in product_chunks]
    product_chunks = [chunk for chunk in product_chunks if chunk]
    return [parse_product(chunk, index) for index, chunk in enumerate(product_chunks, start=1)]


def parse_block_catalog_input(products_text: str) -> list[dict[str, object]]:
    lines = [line.strip() for line in products_text.splitlines()]
    products: list[dict[str, object]] = []
    current_label = ""
    current_options: list[str] = []
    current_meta: dict[str, str] = {}

    def flush_current_product() -> None:
        nonlocal current_label, current_options, current_meta
        if not current_label:
            return
        products.append(build_product(len(products) + 1, current_label, current_options, current_meta))
        current_label = ""
        current_options = []
        current_meta = {}

    for line in lines:
        if not line:
            flush_current_product()
            continue

        if "|" in line:
            if not current_label:
                raise ValueError(f"Строка фасовки указана раньше названия товара: '{line}'.")
            current_options.append(line)
            continue

        flush_current_product()
        current_label, current_meta = extract_inline_meta(line)
        current_label = current_label.strip()
        if not current_label:
            raise ValueError("У товара нет названия.")

    flush_current_product()

    if not products:
        raise ValueError("После города не найдено ни одного товара.")
    return products


def parse_catalog_input(raw_value: str) -> tuple[str | None, list[dict[str, object]]]:
    value = raw_value.strip()
    if not value:
        raise ValueError("Пустой ввод.")

    first_line = next((line.strip() for line in value.splitlines() if line.strip()), "")
    city_part, separator, products_part = first_line.partition("/")
    if separator == "/" and looks_like_city_name(city_part):
        city_name = city_part.strip()
        if not city_name:
            raise ValueError("Не указан город до символа '/'.")
        remainder = value[len(first_line):].lstrip("\n")
        products_text = "\n".join(part for part in [products_part.strip(), remainder.strip()] if part.strip())
        if not products_text:
            raise ValueError("После города не найдено ни одного товара.")
        return city_name, parse_classic_catalog_input(city_name, products_text)

    if "\n" not in value:
        raise ValueError(
            "Ожидается формат город/товар1[фасовка1,фасовка2]-товар2[...] "
            "или многострочный блок/список без города."
        )

    if is_block_catalog_text(value):
        return None, parse_block_catalog_input(value)
    return None, parse_line_catalog_input(value)


def parse_multi_city_catalog_input(raw_value: str) -> dict[str, list[dict[str, object]]] | None:
    lines = raw_value.splitlines()
    has_headers = any(SECTION_HEADER_RE.fullmatch(line.strip()) for line in lines if line.strip())
    if not has_headers:
        return None

    city_products: dict[str, list[dict[str, object]]] = {}
    seen_markers: set[str] = set()
    current_city: str | None = None
    current_lines: list[str] = []

    def flush_current_city() -> None:
        nonlocal current_city, current_lines
        if current_city is None:
            return
        products_text = "\n".join(current_lines).strip()
        if not products_text:
            raise ValueError(f"После заголовка города '{current_city}' не найдено ни одного товара.")
        city_products[current_city] = parse_classic_catalog_input(current_city, products_text)
        current_city = None
        current_lines = []

    for raw_line in lines:
        stripped_line = raw_line.strip()
        match = SECTION_HEADER_RE.fullmatch(stripped_line) if stripped_line else None
        if match is not None:
            flush_current_city()
            city_name = match.group("city").strip()
            if not city_name:
                raise ValueError("У заголовка города отсутствует название.")
            city_marker = normalize_name(city_name)
            if city_marker in seen_markers:
                raise ValueError(f"Город '{city_name}' указан в конфиге больше одного раза.")
            seen_markers.add(city_marker)
            current_city = city_name
            current_lines = []
            continue
        if current_city is None:
            if stripped_line:
                raise ValueError("Много-городный конфиг должен начинаться с заголовка вида === Город ===.")
            continue
        current_lines.append(raw_line)

    flush_current_city()
    if not city_products:
        raise ValueError("В конфиге не найдено ни одного города.")
    return city_products


def prompt_city_names() -> list[str]:
    try:
        raw_value = input("Введите название города или несколько через запятую: ").strip()
    except EOFError as exc:
        raise ValueError("Город не указан, а ввод из консоли недоступен.") from exc
    if not raw_value:
        raise ValueError("Название города не должно быть пустым.")
    city_names = [item.strip() for item in raw_value.split(",") if item.strip()]
    if not city_names:
        raise ValueError("Название города не должно быть пустым.")
    return city_names


def load_catalog(catalog_path: Path) -> list[dict[str, object]]:
    if not catalog_path.exists():
        raise ValueError(f"Файл каталога не найден: {catalog_path}")
    try:
        raw_data = json.loads(catalog_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Не удалось прочитать JSON: {catalog_path}") from exc
    if not isinstance(raw_data, list):
        raise ValueError("В catalog.json должен быть массив городов.")
    return raw_data


def save_catalog(catalog_path: Path, cities: list[dict[str, object]]) -> None:
    catalog_path.parent.mkdir(parents=True, exist_ok=True)
    catalog_path.write_text(json.dumps(cities, ensure_ascii=False, indent=2), encoding="utf-8")


def update_city_products(catalog_path: Path, city_names: list[str], products: list[dict[str, object]]) -> list[str]:
    cities = load_catalog(catalog_path)
    markers = {normalize_name(city_name): city_name for city_name in city_names}
    matched_labels: list[str] = []

    for city in cities:
        if not isinstance(city, dict):
            continue
        city_label = str(city.get("label", "")).strip()
        if normalize_name(city_label) not in markers:
            continue
        city["products"] = products
        if has_placeholder_districts(city.get("districts")):
            city["districts"] = generate_city_districts(city_label, len(products))
            city["district_selection_percent"] = 100
        matched_labels.append(city_label)

    if len(matched_labels) == len(markers):
        save_catalog(catalog_path, cities)
        return matched_labels

    available = ", ".join(
        str(city.get("label", "")).strip()
        for city in cities
        if isinstance(city, dict) and str(city.get("label", "")).strip()
    )
    matched_markers = {normalize_name(label) for label in matched_labels}
    missing_names = [city_name for city_name in city_names if normalize_name(city_name) not in matched_markers]
    missing_display = ", ".join(missing_names)
    raise ValueError(f"Город '{missing_display}' не найден. Доступные города: {available}")


def update_multiple_city_products(
    catalog_path: Path,
    city_products: dict[str, list[dict[str, object]]],
) -> list[str]:
    cities = load_catalog(catalog_path)
    products_by_marker = {normalize_name(city_name): products for city_name, products in city_products.items()}
    matched_markers: set[str] = set()
    matched_labels: list[str] = []

    for city in cities:
        if not isinstance(city, dict):
            continue
        city_label = str(city.get("label", "")).strip()
        city_marker = normalize_name(city_label)
        products = products_by_marker.get(city_marker)
        if products is None:
            continue
        city["products"] = products
        if has_placeholder_districts(city.get("districts")):
            city["districts"] = generate_city_districts(city_label, len(products))
            city["district_selection_percent"] = 100
        matched_markers.add(city_marker)
        matched_labels.append(city_label)

    if len(matched_markers) == len(products_by_marker):
        save_catalog(catalog_path, cities)
        return matched_labels

    available = ", ".join(
        str(city.get("label", "")).strip()
        for city in cities
        if isinstance(city, dict) and str(city.get("label", "")).strip()
    )
    missing_names = [
        city_name
        for city_name in city_products
        if normalize_name(city_name) not in matched_markers
    ]
    missing_display = ", ".join(missing_names)
    raise ValueError(f"Город '{missing_display}' не найден. Доступные города: {available}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Обновляет товары выбранного города или нескольких городов в data/catalog.json, не трогая районы."
    )
    parser.add_argument(
        "value",
        nargs="?",
        help="Строка вида: Город/Товар 1[Фасовка 1,Фасовка 2]-Товар 2[Фасовка 1], Город/Готовая кнопка 1|Готовая кнопка 2, многострочный блок товара или набор секций === Город ===",
    )
    parser.add_argument(
        "--catalog",
        default=str(DEFAULT_CATALOG_PATH),
        help="Путь к catalog.json. По умолчанию используется data/catalog.json",
    )
    parser.add_argument(
        "--file",
        dest="input_file",
        help="Путь к .txt файлу со строкой формата город/товар[фасовки]-товар[...], город/кнопка|кнопка, многострочным блоком товара или набором секций === Город ===",
    )
    return parser


def read_input_value(raw_value: str | None, input_file: str | None) -> str:
    if raw_value:
        return raw_value.strip()
    path = DEFAULT_INPUT_PATH if not input_file else Path(input_file)
    if not path.exists():
        raise ValueError(f"Файл не найден: {path}")
    return path.read_text(encoding="utf-8").strip()


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        raw_value = read_input_value(args.value, args.input_file)
        city_products = parse_multi_city_catalog_input(raw_value)
        if city_products is not None:
            matched_cities = update_multiple_city_products(Path(args.catalog), city_products)
        else:
            city_name, products = parse_catalog_input(raw_value)
            city_names = [city_name] if city_name is not None else prompt_city_names()
            matched_cities = update_city_products(Path(args.catalog), city_names, products)
    except ValueError as exc:
        raise SystemExit(str(exc))

    print(f"Города: {', '.join(matched_cities)}")
    if city_products is not None:
        print(f"Городов обновлено: {len(city_products)}")
        total_products = sum(len(products) for products in city_products.values())
        print(f"Товаров обновлено: {total_products}")
        for city_name, products in city_products.items():
            print(f"- {city_name}: {len(products)} товаров")
    else:
        print(f"Товаров обновлено: {len(products)}")
        for product in products:
            options = product.get("options", [])
            print(f"- {product.get('button_label', product.get('label', ''))}: {len(options)} фасовок")


if __name__ == "__main__":
    main()
