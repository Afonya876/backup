from pathlib import Path

path = Path('.solo-batch-ban/bot.py')
source = path.read_text()

marker = 'ERROR_MESSAGE_MAX_LEN = 700\n'
replacement = 'ERROR_MESSAGE_MAX_LEN = 700\nMAX_SOLO_BAN_IDS_PER_BATCH = 200\n'
if marker not in source:
    raise RuntimeError('constants marker not found')
source = source.replace(marker, replacement, 1)

marker = '\n\ndef build_family_bans_menu(family_key: str, banned_ids: list[int]) -> InlineKeyboardMarkup:\n'
helper = '''\n\ndef parse_solo_ban_ids(raw_value: str) -> tuple[list[int], list[str]]:
    """Parse Telegram user IDs from lines, spaces, or comma-separated input."""
    tokens = [item for item in re.split(r"[\\s,;]+", raw_value.strip()) if item]
    ids: list[int] = []
    invalid: list[str] = []
    seen: set[int] = set()
    for token in tokens:
        normalized = token.lstrip("@")
        if not normalized.isdigit():
            invalid.append(token)
            continue
        user_id = int(normalized)
        if user_id <= 0:
            invalid.append(token)
            continue
        if user_id not in seen:
            seen.add(user_id)
            ids.append(user_id)
    return ids, invalid
'''
if marker not in source:
    raise RuntimeError('ban menu marker not found')
source = source.replace(marker, helper + marker, 1)

source = source.replace(
    'rows = [[custom_button("Забанить", callback_data=f"family_ban_add:{family_key}", emoji_name="pause")]]',
    'rows = [[custom_button("Забанить список", callback_data=f"family_ban_add:{family_key}", emoji_name="pause")]]',
    1,
)
source = source.replace(
    '"Бан применяется сразу ко всем ботам этого семейства.",\n',
    '"Бан применяется сразу ко всем ботам этого семейства.",\n            "Для SOLO можно вставить список ID: по одному в строке, через пробелы или запятые.",\n',
    1,
)

old_prompt = '''    if mode == "ban_add":
        return f"{ce('pause')} Пришлите Telegram ID пользователя, которого нужно забанить. Для него бот перестанет отвечать."
'''
new_prompt = '''    if mode == "ban_add":
        return (
            f"{ce('pause')} Пришлите Telegram ID для бана.\\n\\n"
            "В SOLO можно вставить до 200 ID: по одному в строке, через пробелы или запятые. "
            "Дубли будут пропущены."
        )
'''
if old_prompt not in source:
    raise RuntimeError('ban prompt not found')
source = source.replace(old_prompt, new_prompt, 1)

old_handler = '''        if mode == "ban_add":
            normalized = raw_value.lstrip("@") if raw_value.startswith("@") else raw_value
            if not normalized.lstrip("-").isdigit():
                await message.answer(
                    "🆔 Нужен числовой Telegram ID.",
                    reply_markup=build_back_family_menu(family_key),
                )
                return
            await ban_family_user(family_key, int(normalized))
            await show_family_bans(message, state, family_key)
            return
'''
new_handler = '''        if mode == "ban_add":
            if family_key != "solo":
                await message.answer(
                    "Массовый бан доступен только для SOLO.",
                    reply_markup=build_back_family_menu(family_key),
                )
                return
            user_ids, invalid_items = parse_solo_ban_ids(raw_value)
            if invalid_items:
                preview = ", ".join(escape(item) for item in invalid_items[:10])
                suffix = " …" if len(invalid_items) > 10 else ""
                await message.answer(
                    f"🆔 Некорректные ID: <code>{preview}{suffix}</code>. "
                    "Используйте только числа, разделённые пробелами, запятыми или новыми строками.",
                    reply_markup=build_back_family_menu(family_key),
                )
                return
            if not user_ids:
                await message.answer(
                    "🆔 В списке нет Telegram ID.",
                    reply_markup=build_back_family_menu(family_key),
                )
                return
            if len(user_ids) > MAX_SOLO_BAN_IDS_PER_BATCH:
                await message.answer(
                    f"🆔 За один раз можно забанить не более {MAX_SOLO_BAN_IDS_PER_BATCH} уникальных ID. "
                    f"Получено: {len(user_ids)}.",
                    reply_markup=build_back_family_menu(family_key),
                )
                return

            existing_bans = set(await fetch_family_bans(family_key))
            ids_to_add = [user_id for user_id in user_ids if user_id not in existing_bans]
            failed_ids: list[int] = []
            for user_id in ids_to_add:
                try:
                    await ban_family_user(family_key, user_id)
                except ServiceError:
                    logger.exception("Failed to ban SOLO user %s", user_id)
                    failed_ids.append(user_id)

            await state.clear()
            confirmed_bans = set(await fetch_family_bans(family_key))
            confirmed_new = len(set(ids_to_add) & confirmed_bans)
            lines = [
                "<b>Блокировка SOLO завершена</b>",
                "",
                f"Получено уникальных ID: {len(user_ids)}",
                f"Добавлено в бан: {confirmed_new}",
                f"Уже были в бане: {len(user_ids) - len(ids_to_add)}",
                f"Не подтверждено: {len(set(ids_to_add) - confirmed_bans)}",
                f"Всего в бане: {len(confirmed_bans)}",
            ]
            if failed_ids:
                preview = ", ".join(str(item) for item in failed_ids[:10])
                suffix = " …" if len(failed_ids) > 10 else ""
                lines.extend(["", f"Ошибки API: <code>{preview}{suffix}</code>"])
            await message.answer(
                "\\n".join(lines),
                reply_markup=build_family_bans_menu(family_key, sorted(confirmed_bans)),
            )
            return
'''
if old_handler not in source:
    raise RuntimeError('ban handler not found')
source = source.replace(old_handler, new_handler, 1)

path.write_text(source)
