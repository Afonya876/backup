from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException, Response, status
from pydantic import BaseModel

from neon_shop.config import (
    BotSpec,
    BotSummary,
    CreateBotRequest,
    PaymentMethodConfig,
    Settings,
    TemplateOverrides,
    normalize_template,
    get_settings,
)
from neon_shop.manager import BotManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


class UpdateBotRequest(BaseModel):
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None
    is_paused: bool | None = None


class BroadcastRequest(BaseModel):
    text: str


class UpdateFamilyRequest(BaseModel):
    template: TemplateOverrides | None = None
    payment_methods: list[PaymentMethodConfig] | None = None
    admin_ids: list[int] | None = None


def serialize_spec(spec: BotSpec, manager: BotManager) -> dict[str, object]:
    return {
        "token": spec.token,
        "template": spec.template.model_dump(mode="json"),
        "payment_methods": [method.model_dump(mode="json") for method in spec.payment_methods],
        "admin_ids": list(spec.admin_ids),
        "is_paused": spec.is_paused,
        "bot_id": spec.bot_id,
        "bot_username": spec.bot_username,
        "bot_name": spec.bot_name,
        "created_at": spec.created_at,
        "is_running": spec.token in manager._runtimes and not spec.is_paused,
    }


async def serialize_family(manager: BotManager) -> dict[str, object]:
    specs = await manager.registry.load()
    return {
        "template": (await manager._get_shared_template()).model_dump(mode="json"),
        "admin_ids": await manager._get_shared_admin_ids(),
        "payment_methods": [method.model_dump(mode="json") for method in await manager._get_shared_payment_methods()],
        "bots_count": len(specs),
        "running_count": sum(1 for spec in specs if spec.token in manager._runtimes and not spec.is_paused),
        "recipients_count": 0,
        "bots": [serialize_spec(spec, manager) for spec in specs],
    }


def verify_api_key(
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    settings: Settings = Depends(get_settings),
) -> str:
    if x_api_key != settings.master_api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")
    return x_api_key


def create_app() -> FastAPI:
    settings = get_settings()
    manager = BotManager(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.manager = manager
        await manager.start_registered_bots()
        yield
        await manager.shutdown()

    app = FastAPI(title="NEON bot factory", lifespan=lifespan)

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/bots", response_model=list[BotSummary], dependencies=[Depends(verify_api_key)])
    async def list_bots() -> list[BotSummary]:
        return await manager.list_bots()

    @app.post("/bots", dependencies=[Depends(verify_api_key)])
    async def create_bot(payload: CreateBotRequest):
        try:
            result = await manager.register_bot(payload)
        except Exception as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
        return {
            "created": result.created,
            "bot_id": result.spec.bot_id,
            "bot_username": result.spec.bot_username,
            "bot_name": result.spec.bot_name,
            "created_at": result.spec.created_at,
            "admin_ids": result.spec.admin_ids,
        }

    @app.delete("/bots", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(verify_api_key)])
    async def delete_bot(token: str, response: Response) -> Response:
        removed = await manager.remove_bot(token)
        if not removed:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        response.status_code = status.HTTP_204_NO_CONTENT
        return response

    @app.get("/admin/bots/{bot_id}", dependencies=[Depends(verify_api_key)])
    async def get_bot_details(bot_id: int):
        spec = await manager._find_by_bot_id(bot_id)
        if spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        return serialize_spec(spec, manager)

    @app.patch("/admin/bots/{bot_id}", dependencies=[Depends(verify_api_key)])
    async def update_bot(bot_id: int, payload: UpdateBotRequest):
        stored_spec = await manager._find_by_bot_id(bot_id)
        if stored_spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")

        runtime = manager._runtimes.get(stored_spec.token)
        live_spec = runtime.spec if runtime is not None else stored_spec
        initial_pause = live_spec.is_paused

        if payload.template is not None:
            live_spec.template = normalize_template(payload.template)

        if payload.admin_ids is not None:
            live_spec.admin_ids = sorted(set(payload.admin_ids))

        if payload.payment_methods is not None:
            payment_methods = manager._clone_payment_methods(payload.payment_methods)
            live_spec.payment_methods = payment_methods
            await manager.sync_payment_methods(payment_methods)

        if payload.template is not None or payload.admin_ids is not None:
            await manager.persist_spec(live_spec)

        if payload.is_paused is not None and payload.is_paused != initial_pause:
            await manager.toggle_bot_pause_by_id(bot_id)

        updated_spec = await manager._find_by_bot_id(bot_id)
        if updated_spec is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        return serialize_spec(updated_spec, manager)

    @app.delete("/admin/bots/{bot_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(verify_api_key)])
    async def delete_bot_by_id(bot_id: int, response: Response) -> Response:
        removed = await manager.remove_bot_by_id(bot_id)
        if not removed:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Bot not found")
        response.status_code = status.HTTP_204_NO_CONTENT
        return response

    @app.get("/admin/family", dependencies=[Depends(verify_api_key)])
    async def get_family_details():
        return await serialize_family(manager)

    @app.patch("/admin/family", dependencies=[Depends(verify_api_key)])
    async def update_family(payload: UpdateFamilyRequest):
        if payload.template is not None:
            await manager.sync_template(payload.template)
        if payload.admin_ids is not None:
            await manager.sync_admin_ids(payload.admin_ids)
        if payload.payment_methods is not None:
            await manager.sync_payment_methods(payload.payment_methods)
        return await serialize_family(manager)

    @app.post("/admin/family/broadcast", dependencies=[Depends(verify_api_key)])
    async def broadcast_family(payload: BroadcastRequest):
        text = payload.text.strip()
        if not text:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Text is required")
        return await manager.broadcast_message(text)

    return app
