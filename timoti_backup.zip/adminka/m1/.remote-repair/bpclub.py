from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path
from typing import Any

from logics.config import (
    BotSpec,
    FamilyState,
    PaymentMethodConfig,
    TemplateOverrides,
    normalize_template,
)


def _atomic_write_json(path: Path, content: str) -> None:
    """Persist JSON without exposing a partially written file to readers."""
    temporary_path = path.with_name(f".{path.name}.tmp")
    temporary_path.write_text(content, encoding="utf-8")
    temporary_path.replace(path)


class BotRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self) -> list[BotSpec]:
        async with self._lock:
            return self._read_specs()

    async def save(self, specs: list[BotSpec]) -> None:
        async with self._lock:
            self._write_specs(specs)

    async def upsert(self, spec: BotSpec) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            replaced = False
            for index, existing in enumerate(specs):
                if existing.token == spec.token:
                    specs[index] = spec
                    replaced = True
                    break
            if not replaced:
                specs.append(spec)
            self._write_specs(specs)
            return specs

    async def delete(self, token: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            filtered = [spec for spec in specs if spec.token != token]
            self._write_specs(filtered)
            return filtered

    async def replace_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_methods = [method.model_dump(mode="json") for method in payment_methods]
            for item in payload:
                item["payment_methods"] = deepcopy(normalized_methods)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_start_text(self, start_text: str) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            for item in payload:
                template_payload = item.get("template")
                if not isinstance(template_payload, dict):
                    template_payload = {}
                else:
                    template_payload = dict(template_payload)
                template_payload["start_text"] = start_text
                item["template"] = template_payload
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_template(self, template: TemplateOverrides) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_template = normalize_template(template).model_dump(mode="json")
            for item in payload:
                item["template"] = deepcopy(normalized_template)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_admin_ids(self, admin_ids: list[int]) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_admin_ids = sorted(set(admin_ids))
            for item in payload:
                item["admin_ids"] = list(normalized_admin_ids)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    def _read_specs(self) -> list[BotSpec]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BotSpec.model_validate(item) for item in data]

    def _read_specs_payload(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        return [dict(item) for item in data if isinstance(item, dict)]

    def _write_specs(self, specs: list[BotSpec]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = [spec.model_dump(mode="json") for spec in specs]
        self._write_specs_payload(payload)

    def _write_specs_payload(self, payload: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class FamilyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self, fallback: FamilyState) -> FamilyState:
        async with self._lock:
            return self._read_state(fallback)

    async def save(self, state: FamilyState) -> FamilyState:
        async with self._lock:
            normalized_state = FamilyState(
                template=normalize_template(state.template),
                payment_methods=[method.model_copy(deep=True) for method in state.payment_methods],
                admin_ids=sorted(set(state.admin_ids)),
            )
            self._write_state(normalized_state)
            return normalized_state

    def _read_state(self, fallback: FamilyState) -> FamilyState:
        normalized_fallback = FamilyState(
            template=normalize_template(fallback.template),
            payment_methods=[method.model_copy(deep=True) for method in fallback.payment_methods],
            admin_ids=sorted(set(fallback.admin_ids)),
        )
        if not self.path.exists():
            return normalized_fallback

        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return normalized_fallback

        payload = normalized_fallback.model_dump(mode="python")
        raw_template = data.get("template")
        if isinstance(raw_template, dict):
            template_payload = payload["template"]
            template_payload.update(raw_template)
            payload["template"] = template_payload
        if "payment_methods" in data:
            payload["payment_methods"] = data["payment_methods"]
        if "admin_ids" in data:
            payload["admin_ids"] = data["admin_ids"]
        return FamilyState.model_validate(payload)

    def _write_state(self, state: FamilyState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = state.model_dump(mode="json")
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class CaptchaRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_user(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, dict):
                return {}
            return dict(user_payload)

    async def update_user(
        self,
        user_id: int,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[str(user_id)] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class OrderRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def list_user_orders(self, user_id: int) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, list):
                return []
            return [dict(item) for item in user_payload if isinstance(item, dict)]

    async def upsert_user_order(self, user_id: int, order_payload: dict[str, Any]) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current_items = payload.get(str(user_id))
            orders = [dict(item) for item in current_items if isinstance(item, dict)] if isinstance(current_items, list) else []
            order_id = order_payload.get("order_id")
            replaced = False
            for index, existing in enumerate(orders):
                if str(existing.get("order_id")) == str(order_id):
                    orders[index] = dict(order_payload)
                    replaced = True
                    break
            if not replaced:
                orders.insert(0, dict(order_payload))
            payload[str(user_id)] = orders[:20]
            self._write_payload(payload)
            return [dict(item) for item in payload[str(user_id)]]

    async def get_user_order(self, user_id: int, order_id: str | int) -> dict[str, Any] | None:
        async with self._lock:
            payload = self._read_payload()
            current_items = payload.get(str(user_id))
            if not isinstance(current_items, list):
                return None
            order_id_text = str(order_id)
            for item in current_items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("order_id")) == order_id_text:
                    return dict(item)
            return None

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class CartRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def list_items(self, user_id: int) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            items = payload.get(str(user_id))
            if not isinstance(items, list):
                return []
            return [dict(item) for item in items if isinstance(item, dict)]

    async def add_item(self, user_id: int, item: dict[str, Any]) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            items = [dict(x) for x in current if isinstance(x, dict)] if isinstance(current, list) else []
            for existing in items:
                if (
                    existing.get("city_key") == item.get("city_key")
                    and existing.get("product_index") == item.get("product_index")
                    and existing.get("option_index") == item.get("option_index")
                ):
                    existing["qty"] = int(existing.get("qty", 1)) + 1
                    payload[str(user_id)] = items
                    self._write_payload(payload)
                    return [dict(x) for x in items]
            items.append(dict(item))
            payload[str(user_id)] = items
            self._write_payload(payload)
            return [dict(x) for x in items]

    async def remove_by_match(
        self,
        user_id: int,
        city_key: str,
        product_index: int,
        option_index: int,
    ) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            items = [dict(x) for x in current if isinstance(x, dict)] if isinstance(current, list) else []
            for index, existing in enumerate(items):
                if (
                    existing.get("city_key") == city_key
                    and existing.get("product_index") == product_index
                    and existing.get("option_index") == option_index
                ):
                    qty = int(existing.get("qty", 1)) - 1
                    if qty <= 0:
                        items.pop(index)
                    else:
                        existing["qty"] = qty
                    break
            payload[str(user_id)] = items
            self._write_payload(payload)
            return [dict(x) for x in items]

    async def remove_at(self, user_id: int, index: int) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            items = [dict(x) for x in current if isinstance(x, dict)] if isinstance(current, list) else []
            if 0 <= index < len(items):
                items.pop(index)
            payload[str(user_id)] = items
            self._write_payload(payload)
            return [dict(x) for x in items]

    async def clear(self, user_id: int) -> None:
        async with self._lock:
            payload = self._read_payload()
            payload.pop(str(user_id), None)
            self._write_payload(payload)

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class DistrictRotationRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_city(self, city_key: str) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            city_payload = payload.get(city_key)
            if not isinstance(city_payload, dict):
                return {}
            return dict(city_payload)

    async def update_city(
        self,
        city_key: str,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(city_key)
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[city_key] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class UserPhotoRegistry:
    """Tracks which users have already received the start photo (persistent per user_id)."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def has_seen_start_photo(self, user_id: int) -> bool:
        async with self._lock:
            payload = self._read_payload()
            return bool(payload.get(str(user_id), {}).get("start_photo_sent", False))

    async def mark_start_photo_seen(self, user_id: int) -> None:
        async with self._lock:
            payload = self._read_payload()
            payload.setdefault(str(user_id), {})["start_photo_sent"] = True
            self._write_payload(payload)

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))
