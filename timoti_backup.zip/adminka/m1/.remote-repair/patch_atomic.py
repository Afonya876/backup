from pathlib import Path
import re

files = [p for p in Path('.remote-repair').glob('*.py') if p.name != 'patch_atomic.py']
helper = '''\n\ndef _atomic_write_json(path: Path, content: str) -> None:\n    """Persist JSON without exposing a partially written file to readers."""\n    temporary_path = path.with_name(f".{path.name}.tmp")\n    temporary_path.write_text(content, encoding="utf-8")\n    temporary_path.replace(path)\n'''
pattern = re.compile(
    r'self\.path\.write_text\(\s*'
    r'(json\.dumps\(.*?\))\s*,\s*encoding="utf-8"\s*,?\s*\)',
    re.DOTALL,
)
for path in files:
    source = path.read_text()
    if '_atomic_write_json' not in source:
        insert_at = source.index('\n\nclass ')
        source = source[:insert_at] + helper + source[insert_at:]
    source, replaced = pattern.subn(r'_atomic_write_json(self.path, \1)', source)
    if 'self.path.write_text' in source:
        raise RuntimeError(f'unhandled write_text in {path}')
    if not replaced:
        raise RuntimeError(f'no writes replaced in {path}')
    path.write_text(source)
    print(path, replaced)
