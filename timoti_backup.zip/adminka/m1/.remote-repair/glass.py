from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from glass_cr_shop.config import (
    BotSpec,
    FamilyState,
    PaymentMethodConfig,
    TemplateOverrides,
    normalize_template,
)


def _atomic_write_json(path: Path, content: str) -> None:
    """Persist JSON without exposing a partially written file to readers."""
    temporary_path = path.with_name(f".{path.name}.tmp")
    temporary_path.write_text(content, encoding="utf-8")
    temporary_path.replace(path)


class BotRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self) -> list[BotSpec]:
        async with self._lock:
            return self._read_specs()

    async def save(self, specs: list[BotSpec]) -> None:
        async with self._lock:
            self._write_specs(specs)

    async def upsert(self, spec: BotSpec) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            replaced = False
            for index, existing in enumerate(specs):
                if existing.token == spec.token:
                    specs[index] = spec
                    replaced = True
                    break
            if not replaced:
                specs.append(spec)
            self._write_specs(specs)
            return specs

    async def delete(self, token: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            filtered = [spec for spec in specs if spec.token != token]
            self._write_specs(filtered)
            return filtered

    async def replace_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.payment_methods = [method.model_copy(deep=True) for method in payment_methods]
            self._write_specs(specs)
            return specs

    async def replace_start_text(self, start_text: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.template.start_text = start_text
            self._write_specs(specs)
            return specs

    async def replace_template(self, template: TemplateOverrides) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.template = template.model_copy(deep=True)
            self._write_specs(specs)
            return specs

    async def replace_admin_ids(self, admin_ids: list[int]) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.admin_ids = list(admin_ids)
            self._write_specs(specs)
            return specs

    def _read_specs(self) -> list[BotSpec]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BotSpec.model_validate(item) for item in data]

    def _write_specs(self, specs: list[BotSpec]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = [spec.model_dump(mode="json") for spec in specs]
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class FamilyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self, fallback: FamilyState) -> FamilyState:
        async with self._lock:
            return self._read_state(fallback)

    async def save(self, state: FamilyState) -> FamilyState:
        async with self._lock:
            normalized_state = FamilyState(
                template=normalize_template(state.template),
                payment_methods=[method.model_copy(deep=True) for method in state.payment_methods],
                admin_ids=sorted(set(state.admin_ids)),
            )
            self._write_state(normalized_state)
            return normalized_state

    def _read_state(self, fallback: FamilyState) -> FamilyState:
        normalized_fallback = FamilyState(
            template=normalize_template(fallback.template),
            payment_methods=[method.model_copy(deep=True) for method in fallback.payment_methods],
            admin_ids=sorted(set(fallback.admin_ids)),
        )
        if not self.path.exists():
            return normalized_fallback

        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return normalized_fallback

        payload = normalized_fallback.model_dump(mode="python")
        raw_template = data.get("template")
        if isinstance(raw_template, dict):
            template_payload = payload["template"]
            template_payload.update(raw_template)
            payload["template"] = template_payload
        if "payment_methods" in data:
            payload["payment_methods"] = data["payment_methods"]
        if "admin_ids" in data:
            payload["admin_ids"] = data["admin_ids"]
        return FamilyState.model_validate(payload)

    def _write_state(self, state: FamilyState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = state.model_dump(mode="json")
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class CaptchaRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_user(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, dict):
                return {}
            return dict(user_payload)

    async def update_user(
        self,
        user_id: int,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[str(user_id)] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class OrderRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def list_user_orders(self, user_id: int) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, list):
                return []
            return [dict(item) for item in user_payload if isinstance(item, dict)]

    async def upsert_user_order(self, user_id: int, order_payload: dict[str, Any]) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current_items = payload.get(str(user_id))
            orders = [dict(item) for item in current_items if isinstance(item, dict)] if isinstance(current_items, list) else []
            order_id = order_payload.get("order_id")
            replaced = False
            for index, existing in enumerate(orders):
                if existing.get("order_id") == order_id:
                    orders[index] = dict(order_payload)
                    replaced = True
                    break
            if not replaced:
                orders.insert(0, dict(order_payload))
            payload[str(user_id)] = orders[:20]
            self._write_payload(payload)
            return [dict(item) for item in payload[str(user_id)]]

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class DistrictRotationRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_city(self, city_key: str) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            city_payload = payload.get(city_key)
            if not isinstance(city_payload, dict):
                return {}
            return dict(city_payload)

    async def update_city(
        self,
        city_key: str,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(city_key)
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[city_key] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))
