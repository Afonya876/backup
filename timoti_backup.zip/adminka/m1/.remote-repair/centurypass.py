from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path
from typing import Any

from vip_shop.config import (
    BotSpec,
    FamilyState,
    PaymentMethodConfig,
    TemplateOverrides,
    normalize_template,
)


def _atomic_write_json(path: Path, content: str) -> None:
    """Persist JSON without exposing a partially written file to readers."""
    temporary_path = path.with_name(f".{path.name}.tmp")
    temporary_path.write_text(content, encoding="utf-8")
    temporary_path.replace(path)


class BotRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self) -> list[BotSpec]:
        async with self._lock:
            return self._read_specs()

    async def save(self, specs: list[BotSpec]) -> None:
        async with self._lock:
            self._write_specs(specs)

    async def upsert(self, spec: BotSpec) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            replaced = False
            for index, existing in enumerate(specs):
                if existing.token == spec.token:
                    specs[index] = spec
                    replaced = True
                    break
            if not replaced:
                specs.append(spec)
            self._write_specs(specs)
            return specs

    async def delete(self, token: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            filtered = [spec for spec in specs if spec.token != token]
            self._write_specs(filtered)
            return filtered

    async def replace_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_methods = [method.model_dump(mode="json") for method in payment_methods]
            for item in payload:
                item["payment_methods"] = deepcopy(normalized_methods)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_start_text(self, start_text: str) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            for item in payload:
                template_payload = item.get("template")
                if not isinstance(template_payload, dict):
                    template_payload = {}
                else:
                    template_payload = dict(template_payload)
                template_payload["start_text"] = start_text
                item["template"] = template_payload
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_template(self, template: TemplateOverrides) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_template = normalize_template(template).model_dump(mode="json")
            for item in payload:
                item["template"] = deepcopy(normalized_template)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_admin_ids(self, admin_ids: list[int]) -> list[BotSpec]:
        async with self._lock:
            shared_admin_ids = sorted(set(admin_ids))
            payload = self._read_specs_payload()
            for item in payload:
                item["admin_ids"] = list(shared_admin_ids)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    def _read_specs(self) -> list[BotSpec]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BotSpec.model_validate(item) for item in data]

    def _read_specs_payload(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        return [dict(item) for item in data if isinstance(item, dict)]

    def _write_specs(self, specs: list[BotSpec]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = [spec.model_dump(mode="json") for spec in specs]
        self._write_specs_payload(payload)

    def _write_specs_payload(self, payload: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class FamilyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self, fallback: FamilyState) -> FamilyState:
        async with self._lock:
            return self._read_state(fallback)

    async def save(self, state: FamilyState) -> FamilyState:
        async with self._lock:
            normalized_state = FamilyState(
                template=normalize_template(state.template),
                payment_methods=[method.model_copy(deep=True) for method in state.payment_methods],
                admin_ids=sorted(set(state.admin_ids)),
            )
            self._write_state(normalized_state)
            return normalized_state

    def _read_state(self, fallback: FamilyState) -> FamilyState:
        normalized_fallback = FamilyState(
            template=normalize_template(fallback.template),
            payment_methods=[method.model_copy(deep=True) for method in fallback.payment_methods],
            admin_ids=sorted(set(fallback.admin_ids)),
        )
        if not self.path.exists():
            return normalized_fallback
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return normalized_fallback
        payload = normalized_fallback.model_dump(mode="python")
        raw_template = data.get("template")
        if isinstance(raw_template, dict):
            template_payload = payload["template"]
            template_payload.update(raw_template)
            payload["template"] = template_payload
        if "payment_methods" in data:
            payload["payment_methods"] = data["payment_methods"]
        if "admin_ids" in data:
            payload["admin_ids"] = data["admin_ids"]
        return FamilyState.model_validate(payload)

    def _write_state(self, state: FamilyState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = state.model_dump(mode="json")
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class AnalyticsRegistry:
    """Tracks who is a real user vs a bot.

    A user who only ever pressed /start (and never typed or tapped anything
    else) stays ``is_human=False``. As soon as they write any other text or
    interact with a button, they are flagged ``is_human=True``.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def record(
        self,
        user_id: int,
        *,
        human: bool,
        timestamp: str,
        username: str | None = None,
        full_name: str | None = None,
        note: str | None = None,
    ) -> None:
        if user_id is None:
            return
        async with self._lock:
            payload = self._read_payload()
            key = str(user_id)
            record = payload.get(key)
            if not isinstance(record, dict):
                record = {
                    "user_id": user_id,
                    "is_human": False,
                    "events": 0,
                    "first_seen": timestamp,
                }
            record["events"] = int(record.get("events", 0)) + 1
            record["last_seen"] = timestamp
            if username:
                record["username"] = username
            if full_name:
                record["full_name"] = full_name
            if human:
                record["is_human"] = True
                if note:
                    record["human_reason"] = note
            payload[key] = record
            self._write_payload(payload)

    async def stats(self) -> dict[str, int]:
        async with self._lock:
            payload = self._read_payload()
        total = len(payload)
        humans = sum(1 for r in payload.values() if isinstance(r, dict) and r.get("is_human"))
        return {"total": total, "humans": humans, "bots": total - humans}

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class UserRegistry:
    """Per-user registration: chosen language, saved login, registered flag."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            record = payload.get(str(user_id))
            return dict(record) if isinstance(record, dict) else {}

    async def update(self, user_id: int, **fields: Any) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            record = payload.get(str(user_id))
            record = dict(record) if isinstance(record, dict) else {}
            record.update(fields)
            payload[str(user_id)] = record
            self._write_payload(payload)
            return record

    async def all_user_ids(self) -> list[int]:
        async with self._lock:
            payload = self._read_payload()
        ids: list[int] = []
        for key in payload:
            try:
                ids.append(int(key))
            except (TypeError, ValueError):
                continue
        return ids

    async def login_exists(self, login: str) -> bool:
        marker = login.strip().casefold()
        async with self._lock:
            payload = self._read_payload()
        return any(
            isinstance(r, dict) and str(r.get("login", "")).strip().casefold() == marker
            for r in payload.values()
        )

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class CaptchaRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_user(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, dict):
                return {}
            return dict(user_payload)

    async def update_user(
        self,
        user_id: int,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[str(user_id)] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))
