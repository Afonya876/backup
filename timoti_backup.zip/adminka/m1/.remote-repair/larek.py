from __future__ import annotations

import asyncio
import json
from pathlib import Path

from neon_shop.config import (
    BotSpec,
    FamilyState,
    PaymentMethodConfig,
    TemplateOverrides,
    normalize_template,
)


def _atomic_write_json(path: Path, content: str) -> None:
    """Persist JSON without exposing a partially written file to readers."""
    temporary_path = path.with_name(f".{path.name}.tmp")
    temporary_path.write_text(content, encoding="utf-8")
    temporary_path.replace(path)


class BotRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self) -> list[BotSpec]:
        async with self._lock:
            return self._read_specs()

    async def save(self, specs: list[BotSpec]) -> None:
        async with self._lock:
            self._write_specs(specs)

    async def upsert(self, spec: BotSpec) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            replaced = False
            for index, existing in enumerate(specs):
                if existing.token == spec.token:
                    specs[index] = spec
                    replaced = True
                    break
            if not replaced:
                specs.append(spec)
            self._write_specs(specs)
            return specs

    async def delete(self, token: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            filtered = [spec for spec in specs if spec.token != token]
            self._write_specs(filtered)
            return filtered

    async def replace_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.payment_methods = [method.model_copy(deep=True) for method in payment_methods]
            self._write_specs(specs)
            return specs

    async def replace_start_text(self, start_text: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            for spec in specs:
                spec.template = normalize_template(spec.template)
                spec.template.start_text = start_text
            self._write_specs(specs)
            return specs

    async def replace_template(self, template: TemplateOverrides) -> list[BotSpec]:
        async with self._lock:
            normalized_template = normalize_template(template)
            specs = self._read_specs()
            for spec in specs:
                spec.template = normalized_template.model_copy(deep=True)
            self._write_specs(specs)
            return specs

    async def replace_admin_ids(self, admin_ids: list[int]) -> list[BotSpec]:
        async with self._lock:
            shared_admin_ids = sorted(set(admin_ids))
            specs = self._read_specs()
            for spec in specs:
                spec.admin_ids = list(shared_admin_ids)
            self._write_specs(specs)
            return specs

    def _read_specs(self) -> list[BotSpec]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BotSpec.model_validate(item) for item in data]

    def _write_specs(self, specs: list[BotSpec]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = [spec.model_dump(mode="json") for spec in specs]
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class FamilyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self, fallback: FamilyState) -> FamilyState:
        async with self._lock:
            return self._read_state(fallback)

    async def save(self, state: FamilyState) -> FamilyState:
        async with self._lock:
            normalized_state = FamilyState(
                template=normalize_template(state.template),
                payment_methods=[method.model_copy(deep=True) for method in state.payment_methods],
                admin_ids=sorted(set(state.admin_ids)),
            )
            self._write_state(normalized_state)
            return normalized_state

    def _read_state(self, fallback: FamilyState) -> FamilyState:
        normalized_fallback = FamilyState(
            template=normalize_template(fallback.template),
            payment_methods=[method.model_copy(deep=True) for method in fallback.payment_methods],
            admin_ids=sorted(set(fallback.admin_ids)),
        )
        if not self.path.exists():
            return normalized_fallback

        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return normalized_fallback

        payload = normalized_fallback.model_dump(mode="python")
        raw_template = data.get("template")
        if isinstance(raw_template, dict):
            template_payload = payload["template"]
            template_payload.update(raw_template)
            payload["template"] = template_payload
        if "payment_methods" in data:
            payload["payment_methods"] = data["payment_methods"]
        if "admin_ids" in data:
            payload["admin_ids"] = data["admin_ids"]
        return FamilyState.model_validate(payload)

    def _write_state(self, state: FamilyState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = state.model_dump(mode="json")
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))


class RecipientRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def add_chat(self, token: str, chat_id: int) -> None:
        async with self._lock:
            payload = self._read_payload()
            items = {
                int(item)
                for item in payload.get(token, [])
                if isinstance(item, int) or str(item).lstrip("-").isdigit()
            }
            items.add(int(chat_id))
            payload[token] = sorted(items)
            self._write_payload(payload)

    async def get_chats(self, token: str) -> list[int]:
        async with self._lock:
            payload = self._read_payload()
            return [
                int(item)
                for item in payload.get(token, [])
                if isinstance(item, int) or str(item).lstrip("-").isdigit()
            ]

    def _read_payload(self) -> dict[str, list[int]]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, list[int]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(self.path, json.dumps(payload, ensure_ascii=False, indent=2))
