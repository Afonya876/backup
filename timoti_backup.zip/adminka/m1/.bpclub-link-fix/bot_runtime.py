from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import uuid
import random
import re
import struct
import zlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from html import escape
from pathlib import Path

from deep_translator import GoogleTranslator
from typing import Any, Protocol
from urllib.parse import urlparse

import aiohttp
import qrcode
from aiogram import BaseMiddleware, Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from pydantic import HttpUrl, TypeAdapter, ValidationError

from logics.config import (
    BotSpec,
    BotSummary,
    CityConfig,
    CountryConfig,
    CreateBotRequest,
    PAYMENT_REQUISITES_PLACEHOLDER,
    PaymentMethodConfig,
    ProductConfig,
    ProductOption,
    Settings,
    extract_payment_requisites,
    normalize_template,
    save_catalog_cities,
)
from logics.payment_admin_ui import (
    build_payment_method_editor_text,
    build_payments_admin_text,
    payment_admin_menu,
    payment_method_editor_menu,
)
from logics.storage import CaptchaRegistry
from logics.storage import CartRegistry
from logics.storage import DistrictRotationRegistry
from logics.storage import OrderRegistry
from logics.storage import UserPhotoRegistry
from logics.template import (
    DISPLAY_CURRENCY,
    MEDICAL_HELP_TEXT,
    PAYMENT_EXTEND_CARD_TEXT,
    PAYMENT_EXIT_CONFIRMATION_TEXT,
    PAYMENT_HELP_TEXT,
    PIN_TEXT,
    _build_order_display_fields,
    _extract_payment_target,
    _format_crypto_amount,
    _resolve_crypto_currency_code,
    _resolve_option_base_amount,
    _resolve_option_base_amount_and_currency,
    _normalize_display_currency_text,
    admin_cancel_menu,
    admin_menu,
    bots_menu,
    bots_upload_menu,
    build_admin_text,
    build_catalog_cities_text,
    build_catalog_city_text,
    build_catalog_product_text,
    build_bot_info_alert,
    build_bot_list_menu,
    build_bots_list_text,
    build_bots_text,
    build_bots_upload_text,
    build_country_text,
    build_city_text,
    build_district_text,
    build_option_text,
    build_order_created_text,
    build_photo_caption,
    build_order_payment_details_text,
    build_order_payment_followup_text,
    build_order_payment_methods_text,
    build_order_payment_waiting_text,
    build_orders_text,
    build_profile_text,
    build_start_text,
    catalog_cities_menu,
    catalog_city_menu,
    catalog_product_menu,
    build_topup_payment_text,
    build_topup_request_text,
    country_menu,
    city_menu,
    district_menu,
    main_menu,
    orders_menu,
    option_menu,
    order_confirm_menu,
    order_payment_detail_menu,
    payment_action_menu,
    cancel_order_confirmation_menu,
    payment_exit_confirmation_menu,
    payment_waiting_back_menu,
    payment_waiting_menu,
    payment_methods_menu,
    main_only_menu,
    profile_menu,
    promo_menu,
    purchases_menu,
    referrals_menu,
    reviews_menu,
    rules_menu,
    simple_back_menu,
    format_payment_method_title,
    resolve_payment_requisites,
    render_payment_details_text,
    persistent_bottom_menu,
    reviews_page_menu,
    BTN_MAIN_MENU,
    BTN_PROFILE,
    BTN_BASKET,
    BTN_SUPPORT,
    BTN_REVIEWS,
    BTN_HELP,
)

logger = logging.getLogger(__name__)

PersistSpec = Callable[[BotSpec], Awaitable[None]]
ListBotsAction = Callable[[], Awaitable[list[BotSummary]]]
RemoveBotAction = Callable[[int], Awaitable[bool]]
ToggleBotPauseAction = Callable[[int], Awaitable[BotSpec | None]]
SyncPaymentMethodsAction = Callable[[list[PaymentMethodConfig]], Awaitable[None]]
SyncStartTextAction = Callable[[str], Awaitable[None]]
SyncAdminIdsAction = Callable[[list[int]], Awaitable[None]]
SyncTemplateAction = Callable[[object], Awaitable[None]]
HTTP_URL_ADAPTER = TypeAdapter(HttpUrl)
TELEGRAM_HOSTS = {"t.me", "www.t.me", "telegram.me", "www.telegram.me"}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{5,32}$")
TOKEN_RE = re.compile(r"\b\d{5,}:[A-Za-z0-9_-]{20,}\b")
TELEGRAM_FILE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{20,}$")
SHISHKI_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-23_14-45-32.jpg"
SALT_PHOTO_URL = "https://144-31-221-169.sslip.io/img_UUURL/photo_2026-03-12_19-02-55.jpg"
BLUE_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-02-27_18-31-55.jpg"
GREEN_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-04-10.jpg"
A_PVP_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-06-08.jpg"
CRYSTAL_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-02-09_07-04-49.jpg"
MDMA_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-23_14-46-05.jpg"
EXTASY_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-04-10.jpg"
KETAMINE_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-02-14_12-20-28.jpg"
BOTS_PAGE_SIZE = 8
EXPIRED_CALLBACK_ERROR_FRAGMENTS = (
    "query is too old",
    "response timeout expired",
    "query id is invalid",
)
INVALID_FILE_ID_ERROR_FRAGMENTS = (
    "wrong file identifier",
    "wrong remote file identifier",
    "failed to get http url content",
    "wrong type of the web page content",
)
CAPTCHA_RATE_LIMIT_CLICKS = 10
CAPTCHA_RATE_LIMIT_WINDOW_SECONDS = 30
CAPTCHA_CODE_LENGTH = 6
CAPTCHA_ALLOWED_CHARS = "0123456789"
CRYPTO_RATE_CACHE_TTL_SECONDS = 900
CRYPTO_RATE_CACHE: dict[str, tuple[datetime, Decimal]] = {}
COINGECKO_ASSET_IDS = {
    "BTC": "bitcoin",
    "LTC": "litecoin",
    "TRX": "tron",
    "TON": "the-open-network",
    "ETH": "ethereum",
}
FIAT_RATE_CACHE_TTL_SECONDS = 900
FIAT_RATE_CACHE: dict[str, tuple[datetime, Decimal]] = {}
RATE_CACHE_PATH = Path("data/rates_cache.json")
ORDER_DEADLINE_HOURS = 1
ORDER_DEADLINE_FORMAT = "%d.%m.%Y %H:%M:%S"

REVIEWS: list[dict[str, str | int]] = [
    {"date": "23.05.2026", "user": "@essensiall", "rating": 5, "text": "Kakve su ovo legendice ❤️"},
    {"date": "21.05.2026", "user": "@nikodim_98", "rating": 5, "text": "All clean and on time, thanks!"},
    {"date": "18.05.2026", "user": "@deniska", "rating": 4, "text": "Норм, забрал быстро"},
    {"date": "15.05.2026", "user": "@maks_77", "rating": 5, "text": "Качество огонь 🔥"},
    {"date": "12.05.2026", "user": "@kostya_p", "rating": 5, "text": "Спасибо, все четко"},
    {"date": "08.05.2026", "user": "@user_x21", "rating": 5, "text": "Best service ever"},
    {"date": "04.05.2026", "user": "@miraculous", "rating": 5, "text": "Огромное спасибо, ребята топ"},
    {"date": "29.04.2026", "user": "@green_apple", "rating": 4, "text": "Все ок, пришло как надо"},
    {"date": "24.04.2026", "user": "@drakon_42", "rating": 5, "text": "Касание с первого раза, спасибо"},
    {"date": "19.04.2026", "user": "@steve_b", "rating": 5, "text": "Perfect quality 💯"},
    {"date": "14.04.2026", "user": "@samvel_x", "rating": 5, "text": "Все ровно, рекомендую"},
    {"date": "09.04.2026", "user": "@chillout", "rating": 4, "text": "Норм, можно лучше"},
    {"date": "03.04.2026", "user": "@joey_2k", "rating": 5, "text": "Top tier shop"},
    {"date": "28.03.2026", "user": "@anton_999", "rating": 5, "text": "Все супер, спасибо за оперативность"},
    {"date": "22.03.2026", "user": "@lex_a", "rating": 5, "text": "Качество стабильное, беру не первый раз"},
    {"date": "17.03.2026", "user": "@marko_22", "rating": 5, "text": "Sve top, hvala 🙏"},
    {"date": "12.03.2026", "user": "@dimon_kgb", "rating": 4, "text": "Норм"},
    {"date": "06.03.2026", "user": "@grizzly", "rating": 5, "text": "Качество кайф, спасибо"},
    {"date": "01.03.2026", "user": "@ramses", "rating": 5, "text": "Отлично, заберу еще"},
    {"date": "24.02.2026", "user": "@petr_a", "rating": 5, "text": "Все четко, без замечаний"},
    {"date": "18.02.2026", "user": "@viktor_x", "rating": 5, "text": "Спасибо за качество и скорость"},
    {"date": "10.02.2026", "user": "@john_doe", "rating": 5, "text": "Excellent!"},
]


def _build_review_text(index: int) -> str:
    item = REVIEWS[index]
    bars = "➖ ➖ ➖ ➖ ➖ ➖ ➖ ➖"
    return (
        f"▪ <b>Review from:</b> <code>{escape(str(item['date']))}</code>\n"
        f"{bars}\n"
        f"▪ <b>User:</b> <code>{escape(str(item['user']))}</code>\n"
        f"▪ <b>Rating:</b> <code>{item['rating']}/5</code>\n"
        f"▪ <b>Text:</b> <code>{escape(str(item['text']))}</code>"
    )


def _load_rates_cache() -> dict[str, float]:
    if RATE_CACHE_PATH.exists():
        try:
            with open(RATE_CACHE_PATH) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_rates_cache(rates: dict[str, float]) -> None:
    RATE_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RATE_CACHE_PATH, "w") as f:
        json.dump(rates, f, ensure_ascii=False)


async def _refresh_rates_from_api() -> dict[str, float]:
    rates: dict[str, float] = {}
    timeout = aiohttp.ClientTimeout(total=10)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get("https://api.coingecko.com/api/v3/simple/price", params={"ids": "bitcoin,tron,litecoin", "vs_currencies": "usd"}) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    rates["BTC_USD"] = float(data["bitcoin"]["usd"])
                    rates["TRX_USD"] = float(data["tron"]["usd"])
                    rates["LTC_USD"] = float(data["litecoin"]["usd"])
    except Exception:
        pass
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get("https://open.er-api.com/v6/latest/USD") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    rates["USD_GEL"] = float(data["rates"].get("GEL", 1))
    except Exception:
        pass
    _save_rates_cache(rates)
    return rates
CAPTCHA_PROMPT_TEXT = "🔒 Enter the 6-digit code from the image:"





def _build_captcha_image(code: str) -> BufferedInputFile:
    from io import BytesIO
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    import math

    width, height = 320, 110

    # Pure white background
    img = Image.new("RGB", (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(img)

    # Visible specks — small darker dots scattered across the white bg
    for _ in range(120):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        shade = random.randint(140, 200)
        size = random.choice([0, 0, 0, 1])  # mostly single pixels, some 2x2
        color = (shade, shade, shade)
        if size == 0:
            draw.point((x, y), fill=color)
        else:
            draw.ellipse([x, y, x + size, y + size], fill=color)

    # Some larger sparse specks
    for _ in range(15):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        shade = random.randint(120, 170)
        draw.ellipse([x, y, x + 2, y + 2], fill=(shade, shade, shade))

    # Single clean line
    def _sketch_stroke(x1: int, y1: int, x2: int, y2: int, color: tuple[int, int, int], passes: int = 1) -> None:
        del passes
        draw.line([(x1, y1), (x2, y2)], fill=color, width=1)

    # Saturated sketchy line colors like the reference
    line_colors = [
        (160, 50, 60),     # red
        (60, 130, 70),     # green
        (170, 80, 110),    # pink/magenta
        (140, 100, 60),    # brown
    ]

    # Long crossing strokes under digits (3-4 like the reference)
    for _ in range(random.randint(3, 4)):
        x1 = random.randint(0, width // 4)
        y1 = random.randint(30, height - 15)
        x2 = random.randint(3 * width // 4, width)
        y2 = random.randint(30, height - 15)
        _sketch_stroke(x1, y1, x2, y2, random.choice(line_colors), passes=4)

    # Try to load a regular (non-bold) font for thinner digits
    font_size = 50
    font = ImageFont.load_default()
    for font_path in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ):
        if not Path(font_path).exists():
            continue
        try:
            font = ImageFont.truetype(font_path, font_size)
            break
        except Exception:
            continue

    # Dark ink colors matching the reference
    digit_colors = [
        (40, 80, 50),      # dark green
        (140, 40, 50),     # brick red
        (60, 80, 130),     # dark blue
        (160, 80, 40),     # burnt orange
        (90, 50, 110),     # plum
    ]
    random.shuffle(digit_colors)

    digit_spacing = width // (len(code) + 1)
    for i, digit in enumerate(code):
        # Varying sizes for each digit (like reference)
        local_size = font_size + random.randint(-10, 6)
        local_font = font
        for font_path in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/System/Library/Fonts/Helvetica.ttc",
        ):
            if not Path(font_path).exists():
                continue
            try:
                local_font = ImageFont.truetype(font_path, local_size)
                break
            except Exception:
                continue

        wave_y = random.randint(-12, 12)
        wave_x = random.randint(-4, 4)
        angle = random.uniform(-15, 15)

        digit_color = digit_colors[i % len(digit_colors)]

        digit_img = Image.new("RGBA", (local_size + 10, local_size + 20), (0, 0, 0, 0))
        digit_draw = ImageDraw.Draw(digit_img)
        digit_draw.text((0, 0), digit, font=local_font, fill=digit_color + (255,))
        rotated = digit_img.rotate(angle, resample=Image.BICUBIC, expand=True)

        x_pos = digit_spacing * (i + 1) - rotated.width // 2 + wave_x
        y_pos = height // 2 - rotated.height // 2 + wave_y
        img.paste(rotated, (x_pos, y_pos), rotated)

    # 2-3 short sketchy strokes ON TOP of digits
    for _ in range(random.randint(2, 3)):
        cx = random.randint(40, width - 40)
        cy = random.randint(30, height - 30)
        length = random.randint(50, 110)
        ang = random.uniform(-math.pi / 4, math.pi / 4)
        x1 = cx - int(length * math.cos(ang) / 2)
        y1 = cy - int(length * math.sin(ang) / 2)
        x2 = cx + int(length * math.cos(ang) / 2)
        y2 = cy + int(length * math.sin(ang) / 2)
        _sketch_stroke(x1, y1, x2, y2, random.choice(line_colors), passes=4)

    # Slight blur to soften everything (like a poor scan)
    img = img.filter(ImageFilter.GaussianBlur(radius=0.4))

    # Save as JPEG with low quality for grainy feel
    buf = BytesIO()
    img.save(buf, format="JPEG", quality=55)
    buf.seek(0)
    return BufferedInputFile(buf.read(), filename="captcha.jpg")


def _generate_captcha_code() -> str:
    return "".join(random.choice(CAPTCHA_ALLOWED_CHARS) for _ in range(CAPTCHA_CODE_LENGTH))


class RegisterResultLike(Protocol):
    spec: BotSpec
    created: bool


RegisterBotAction = Callable[[CreateBotRequest], Awaitable[RegisterResultLike]]


class CaptchaState(StatesGroup):
    waiting_for_code = State()
    waiting_for_language = State()


class PromoState(StatesGroup):
    waiting_for_code = State()


class TopupState(StatesGroup):
    waiting_for_method = State()
    waiting_for_amount = State()
    waiting_for_payment = State()


class AdminState(StatesGroup):
    waiting_for_start_text = State()
    waiting_for_contacts_text = State()
    waiting_for_info_url = State()
    waiting_for_giveaway_url = State()
    waiting_for_payment_label = State()
    waiting_for_payment_commission = State()
    waiting_for_payment_text = State()
    waiting_for_payment_requisites = State()
    waiting_for_new_payment_label = State()
    waiting_for_new_payment_text = State()
    waiting_for_new_payment_requisites = State()
    waiting_for_admin_id = State()
    waiting_for_bot_tokens = State()
    waiting_for_catalog_product_name = State()
    waiting_for_catalog_product_first_option = State()
    waiting_for_catalog_option_label = State()


@dataclass(slots=True)
class OrderSelection:
    city_key: str
    product_index: int
    option_index: int
    district_index: int
    order_id: str | None = None


@dataclass(slots=True)
class TopupSelection:
    order_id: int
    topup_id: int
    amount_uah: int
    deadline_text: str


@dataclass(slots=True)
class BotRuntime:
    spec: BotSpec
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task[None]


PAYMENT_GUARD_KEY = "active_payment_guard"
LANGUAGE_PROMPT_TEXT = (
    "🇷🇺 Выберите язык 🇷🇺\n"
    "🇺🇸 Choose your language 🇺🇸\n"
    "🇺🇦 Оберіть мову 🇺🇦\n"
    "🇰🇿 Тілді таңдаңыз 🇰🇿\n"
    "🇵🇱 Wybierz język 🇵🇱\n"
    "🇲🇩 Selectați limba 🇲🇩\n"
    "🇹🇷 Dil seçin 🇹🇷"
)
SUPPORTED_LANGUAGES = {"RU", "EN", "UK", "KK", "PL", "RO", "TR", "SR"}

TRANSLATED_START_TEXTS: dict[str, str] = {
    "RU": "👉🏻 Выберите страну",
    "EN": "👉🏻 Select a country",
    "SR": "👉🏻 Izaberite zemlju",
    "UK": "👉🏻 Оберіть країну",
    "KK": "👉🏻 Елді таңдаңыз",
    "PL": "👉🏻 Wybierz kraj",
    "RO": "👉🏻 Selectați țara",
    "TR": "👉🏻 Ülke seçin",
}

TRANSLATED_CITY_TEXTS: dict[str, str] = {
    "RU": "👉🏻 Выберите подкатегорию товара",
    "EN": "👉🏻 Select a product subcategory",
    "SR": "👉🏻 Izaberite potkategoriju proizvoda",
    "UK": "👉🏻 Виберіть підкатегорію товару",
    "KK": "👉🏻 Тауар санатын таңдаңыз",
    "PL": "👉🏻 Wybierz podkategorię produktu",
    "RO": "👉🏻 Selectați subcategoria produsului",
    "TR": "👉🏻 Ürün alt kategorisini seçin",
}

TRANSLATED_PRODUCT_TEXTS: dict[str, str] = {
    "RU": "👉🏻 Выберите товар",
    "EN": "👉🏻 Select a product",
    "SR": "👉🏻 Izaberite proizvod",
    "UK": "👉🏻 Виберіть товар",
    "KK": "👉🏻 Тауарды таңдаңыз",
    "PL": "👉🏻 Wybierz produkt",
    "RO": "👉🏻 Selectați produsul",
    "TR": "👉🏻 Ürün seçin",
}

TRANSLATED_LOCATION_TEXTS: dict[str, str] = {
    "RU": "👉🏻 Выберите локацию",
    "EN": "👉🏻 Select a location",
    "SR": "👉🏻 Izaberite lokaciju",
    "UK": "👉🏻 Виберіть локацію",
    "KK": "👉🏻 Орынды таңдаңыз",
    "PL": "👉🏻 Wybierz lokalizację",
    "RO": "👉🏻 Selectați locația",
    "TR": "👉🏻 Konum seçin",
}

TRANSLATED_DISTRICT_TEXTS: dict[str, str] = {
    "RU": "👉🏻 Выберите район",
    "EN": "👉🏻 Select a district",
    "SR": "👉🏻 Izaberite kvart",
    "UK": "👉🏻 Виберіть район",
    "KK": "👉🏻 Ауданды таңдаңыз",
    "PL": "👉🏻 Wybierz dzielnicę",
    "RO": "👉🏻 Selectați cartierul",
    "TR": "👉🏻 Mahalle seçin",
}


def parse_bot_callback_payload(callback_data: str | None) -> tuple[int, int] | None:
    if not callback_data:
        return None
    try:
        _prefix, bot_id_text, page_text = callback_data.rsplit(":", maxsplit=2)
        return int(bot_id_text), int(page_text)
    except ValueError:
        logger.warning("Invalid bot callback payload: %r", callback_data)
        return None


def create_dispatcher(
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
) -> Dispatcher:
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    router = Router()
    spec.template = normalize_template(spec.template)
    spec.payment_methods = [PaymentMethodConfig.model_validate(m) for m in (spec.payment_methods or [])]
    captcha_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_captcha_{spec.bot_id or 'unknown'}.json"
    )
    captcha_registry = CaptchaRegistry(captcha_storage_path)
    order_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_orders_{spec.bot_id or 'unknown'}.json"
    )
    order_registry = OrderRegistry(order_storage_path)
    district_rotation_registry = DistrictRotationRegistry(
        settings.catalog_path.with_name("district_rotation.json")
    )
    user_photo_registry = UserPhotoRegistry(
        settings.data_path.with_name(f"{settings.data_path.stem}_user_photos_{spec.bot_id or 'unknown'}.json")
    )
    cart_registry = CartRegistry(
        settings.data_path.with_name(f"{settings.data_path.stem}_cart_{spec.bot_id or 'unknown'}.json")
    )

    async def _refresh_rates_periodically() -> None:
        while True:
            try:
                await _refresh_rates_from_api()
            except Exception:
                pass
            await asyncio.sleep(900)  # 15 minutes

    asyncio.create_task(_refresh_rates_periodically())

    def is_admin(user_id: int | None) -> bool:
        return user_id is not None and user_id in spec.admin_ids

    def has_photo_message(message: Message) -> bool:
        return bool(message.photo)

    def is_expired_callback_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in EXPIRED_CALLBACK_ERROR_FRAGMENTS)

    def is_invalid_file_id_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in INVALID_FILE_ID_ERROR_FRAGMENTS)

    async def download_photo_from_url(url: str) -> BufferedInputFile | None:
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        logger.warning("Could not download product photo %s: HTTP %s", url, response.status)
                        return None
                    content = await response.read()
                    if not content:
                        logger.warning("Downloaded empty product photo from %s", url)
                        return None
                    parsed = urlparse(url)
                    filename = Path(parsed.path).name or "product.jpg"
                    return BufferedInputFile(content, filename=filename)
        except Exception as exc:
            logger.warning("Could not download product photo %s: %s", url, exc)
            return None

    async def fetch_crypto_usd_rate(currency_code: str) -> Decimal | None:
        normalized_code = currency_code.upper()
        if normalized_code == "USDT":
            return Decimal("1")

        asset_id = COINGECKO_ASSET_IDS.get(normalized_code)
        if asset_id is None:
            return None

        cached = CRYPTO_RATE_CACHE.get(normalized_code)
        now = datetime.now().astimezone()
        if cached is not None:
            cached_at, cached_rate = cached
            if (now - cached_at).total_seconds() < CRYPTO_RATE_CACHE_TTL_SECONDS:
                return cached_rate

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={"ids": asset_id, "vs_currencies": "usd"},
                ) as response:
                    if response.status != 200:
                        logger.warning(
                            "Could not fetch crypto rate for %s: HTTP %s",
                            normalized_code,
                            response.status,
                        )
                        return None
                    payload = await response.json()
        except Exception as exc:
            logger.warning("Could not fetch crypto rate for %s: %s", normalized_code, exc)
            return None

        try:
            rate = Decimal(str(payload[asset_id]["usd"]))
        except (KeyError, TypeError, InvalidOperation) as exc:
            logger.warning("Unexpected crypto rate payload for %s: %s", normalized_code, exc)
            return None

        CRYPTO_RATE_CACHE[normalized_code] = (now, rate)
        return rate

    async def fetch_usd_fiat_rate(currency_code: str) -> Decimal | None:
        normalized_code = currency_code.upper()
        cached = FIAT_RATE_CACHE.get(f"USD_{normalized_code}")
        now = datetime.now().astimezone()
        if cached is not None:
            cached_at, cached_rate = cached
            if (now - cached_at).total_seconds() < FIAT_RATE_CACHE_TTL_SECONDS:
                return cached_rate

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get("https://open.er-api.com/v6/latest/USD") as response:
                    if response.status != 200:
                        logger.warning("Could not fetch USD/%s rate: HTTP %s", normalized_code, response.status)
                        return None
                    payload = await response.json()
        except Exception as exc:
            logger.warning("Could not fetch USD/%s rate: %s", normalized_code, exc)
            return None

        try:
            rate = Decimal(str(payload["rates"][normalized_code]))
        except (KeyError, TypeError, InvalidOperation) as exc:
            logger.warning("Unexpected USD/%s payload: %s", normalized_code, exc)
            return None

        FIAT_RATE_CACHE[f"USD_{normalized_code}"] = (now, rate)
        return rate

    async def fetch_usd_rub_rate() -> Decimal | None:
        return await fetch_usd_fiat_rate("RUB")

    def resolve_fiat_currency_code(method: PaymentMethodConfig) -> str | None:
        if isinstance(method, dict):
            rendered_details = (method.get("details_text") or "").replace("{requisites}", "не указаны")
            combined = " ".join([method.get("key") or "", method.get("label") or "", method.get("commission_text") or "", rendered_details]).casefold()
        else:
            rendered_details = render_payment_details_text(method)
            target_label, _target_value = _extract_payment_target(rendered_details)
            combined = " ".join(
                part for part in (method.key, method.label, method.commission_text or "", rendered_details) if part
            ).casefold()
            if target_label == "Карта":
                return "RUB"
        if "₽" in combined or "руб" in combined or "rub" in combined:
            return "RUB"
        if "€" in combined or "eur" in combined:
            return "EUR"
        if "$" in combined or "usd" in combined:
            return "USD"
        if "₾" in combined or "gel" in combined or "lari" in combined:
            return "GEL"
        return None

    def format_fiat_amount(amount: Decimal, currency_code: str) -> str:
        normalized_code = currency_code.upper()
        quantize_map = {
            "RUB": Decimal("1"),
            "USD": Decimal("0.01"),
            "EUR": Decimal("0.01"),
            "GEL": Decimal("0.01"),
        }
        symbol_map = {
            "RUB": "₽",
            "USD": "$",
            "EUR": "€",
            "GEL": DISPLAY_CURRENCY,
        }
        quantum = quantize_map.get(normalized_code, Decimal("0.01"))
        formatted_amount = amount.quantize(quantum, rounding=ROUND_CEILING)
        return f"{formatted_amount} {symbol_map.get(normalized_code, normalized_code)}"

    async def resolve_payment_amount_label(option: ProductOption, method: PaymentMethodConfig) -> str | None:
        currency_code = _resolve_crypto_currency_code(method)
        rates = _load_rates_cache()
        if currency_code in {"BTC", "LTC", "TRX", "USDT", "USDC"}:
            base_amount, base_currency_code = _resolve_option_base_amount_and_currency(option, method)
            usd_gel_rate = await fetch_usd_fiat_rate("GEL")
            if usd_gel_rate is None or usd_gel_rate <= 0:
                cached_usd_gel_rate = rates.get("USD_GEL")
                usd_gel_rate = Decimal(str(cached_usd_gel_rate)) if cached_usd_gel_rate else None
            usd_uah_rate: Decimal | None = None
            usd_rub_rate: Decimal | None = None
            normalized_base_currency = (base_currency_code or "GEL").upper()
            if normalized_base_currency == "USD":
                usd_amount = base_amount
            elif normalized_base_currency == "UAH":
                usd_uah_rate = await fetch_usd_fiat_rate("UAH")
                if usd_uah_rate is None or usd_uah_rate <= 0:
                    cached_usd_uah_rate = rates.get("USD_UAH")
                    usd_uah_rate = Decimal(str(cached_usd_uah_rate)) if cached_usd_uah_rate else None
                usd_amount = base_amount / usd_uah_rate if usd_uah_rate and usd_uah_rate > 0 else base_amount
            elif normalized_base_currency == "RUB":
                usd_rub_rate = await fetch_usd_fiat_rate("RUB")
                if usd_rub_rate is None or usd_rub_rate <= 0:
                    cached_usd_rub_rate = rates.get("USD_RUB")
                    usd_rub_rate = Decimal(str(cached_usd_rub_rate)) if cached_usd_rub_rate else None
                usd_amount = base_amount / usd_rub_rate if usd_rub_rate and usd_rub_rate > 0 else base_amount
            else:
                usd_amount = base_amount / usd_gel_rate if usd_gel_rate and usd_gel_rate > 0 else base_amount
            if currency_code in {"USDT", "USDC"}:
                crypto_usd_rate = Decimal("1")
            else:
                crypto_usd_rate = await fetch_crypto_usd_rate(currency_code)
                if crypto_usd_rate is None or crypto_usd_rate <= 0:
                    cached_crypto_rate = rates.get(f"{currency_code}_USD")
                    crypto_usd_rate = Decimal(str(cached_crypto_rate)) if cached_crypto_rate else None
            if crypto_usd_rate and crypto_usd_rate > 0:
                if currency_code in {"USDT", "USDC"}:
                    resolved_ = usd_amount.quantize(Decimal("0.01"), rounding=ROUND_CEILING)
                    return f"{resolved_} {currency_code}"
                elif currency_code == "BTC":
                    quantum = Decimal("0.00000001")
                elif currency_code == "LTC":
                    quantum = Decimal("0.000001")
                else:
                    quantum = Decimal("0.01")
                crypto_amount = (usd_amount / crypto_usd_rate).quantize(quantum, rounding=ROUND_CEILING)
                return f"{crypto_amount} {currency_code}"
            return f"{usd_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)} $"

        fiat_currency_code = resolve_fiat_currency_code(method)
        if fiat_currency_code is None:
            return None
        base_amount, base_currency_code = _resolve_option_base_amount_and_currency(option, method)
        usd_gel_rate = await fetch_usd_fiat_rate("GEL")
        if usd_gel_rate is None or usd_gel_rate <= 0:
            cached_usd_gel_rate = rates.get("USD_GEL")
            usd_gel_rate = Decimal(str(cached_usd_gel_rate)) if cached_usd_gel_rate else None
        normalized_base_currency = (base_currency_code or "GEL").upper()
        if normalized_base_currency == "USD":
            usd_amount = base_amount
        elif normalized_base_currency == "UAH":
            usd_uah_rate = await fetch_usd_fiat_rate("UAH")
            if usd_uah_rate is None or usd_uah_rate <= 0:
                cached_usd_uah_rate = rates.get("USD_UAH")
                usd_uah_rate = Decimal(str(cached_usd_uah_rate)) if cached_usd_uah_rate else None
            if usd_uah_rate is None or usd_uah_rate <= 0:
                return f"{base_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)} UAH"
            usd_amount = base_amount / usd_uah_rate
        elif normalized_base_currency == "RUB":
            usd_rub_rate = await fetch_usd_fiat_rate("RUB")
            if usd_rub_rate is None or usd_rub_rate <= 0:
                cached_usd_rub_rate = rates.get("USD_RUB")
                usd_rub_rate = Decimal(str(cached_usd_rub_rate)) if cached_usd_rub_rate else None
            if usd_rub_rate is None or usd_rub_rate <= 0:
                return f"{base_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)} RUB"
            usd_amount = base_amount / usd_rub_rate
        else:
            if usd_gel_rate is None or usd_gel_rate <= 0:
                return f"{base_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)} {DISPLAY_CURRENCY}"
            usd_amount = base_amount / usd_gel_rate
        if fiat_currency_code == "USD":
            return format_fiat_amount(usd_amount, fiat_currency_code)
        target_rate = await fetch_usd_fiat_rate(fiat_currency_code)
        if target_rate is None or target_rate <= 0:
            return format_fiat_amount(usd_amount, "USD")
        return format_fiat_amount(usd_amount * target_rate, fiat_currency_code)

    async def safe_answer_callback(
        callback: CallbackQuery,
        text: str | None = None,
        *,
        show_alert: bool = False,
    ) -> bool:
        try:
            await callback.answer(text, show_alert=show_alert)
            return True
        except TelegramBadRequest as exc:
            if not is_expired_callback_error(exc):
                raise
            logger.info("Callback answer expired for %r: %s", callback.data, exc)
            return False

    async def replace_with_text_message(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        await message.answer(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete previous message %s", message.message_id)

    async def show_text_screen(
        target: Message | CallbackQuery,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        if isinstance(target, Message):
            await target.answer(
                text,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview,
            )
            return
        message = target.message
        if message is None:
            return
        # Try to edit in place; fall back to new message if not possible (e.g. photo)
        if not has_photo_message(message):
            try:
                await message.edit_text(
                    text,
                    reply_markup=reply_markup,
                    disable_web_page_preview=disable_web_page_preview,
                )
                return
            except TelegramBadRequest:
                pass
        await message.answer(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )

    async def edit_message_copy(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        if not has_photo_message(message):
            try:
                await message.edit_text(text, reply_markup=reply_markup)
                return
            except TelegramBadRequest:
                pass
        await message.answer(text, reply_markup=reply_markup)

    async def safe_delete_message(message: Message | None) -> None:
        if message is None:
            return
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete message %s", getattr(message, "message_id", "unknown"))

    async def send_product_photo_message(message: Message, product: ProductConfig) -> None:
        photo = resolve_product_photo(product, settings)
        if photo is None:
            return
        try:
            await message.answer_photo(photo)
        except Exception:
            logger.exception("Could not send product photo for %s", product.label)

    async def show_order_confirm_screen(
        callback: CallbackQuery,
        order: OrderSelection,
    ) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        caption = build_photo_caption(city, product, option, district)
        back_callback = await resolve_order_back_callback(order)
        markup = order_confirm_menu(
            f"confirm:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}",
            back_callback,
        )
        photo = resolve_product_photo(product, settings)
        if photo is not None:
            await callback.message.answer_photo(photo, caption=caption, reply_markup=markup)
            return
        await show_text_screen(callback, caption, markup)

    def build_language_keyboard() -> InlineKeyboardMarkup:
        rows = [
            [
                InlineKeyboardButton(text="RU", callback_data="lang:RU"),
                InlineKeyboardButton(text="EN", callback_data="lang:EN"),
            ],
            [
                InlineKeyboardButton(text="UK", callback_data="lang:UK"),
                InlineKeyboardButton(text="KK", callback_data="lang:KK"),
            ],
            [
                InlineKeyboardButton(text="PL", callback_data="lang:PL"),
                InlineKeyboardButton(text="RO", callback_data="lang:RO"),
            ],
            [InlineKeyboardButton(text="TR", callback_data="lang:TR")],
        ]
        return InlineKeyboardMarkup(inline_keyboard=rows)

    async def get_language_record(user_id: int) -> dict[str, object]:
        return await captcha_registry.get_user(user_id)

    _translator_cache: dict[str, GoogleTranslator] = {}

    async def _translate_start_text(base_text: str, lang: str) -> str:
        if lang in ("RU", "EN"):
            return base_text
        source_lang = "ru"
        target_lang = lang.lower()
        cache_key = f"{source_lang}-{target_lang}"
        if cache_key not in _translator_cache:
            _translator_cache[cache_key] = GoogleTranslator(source=source_lang, target=target_lang)
        translator = _translator_cache[cache_key]
        lines = base_text.split("\n")
        translated_lines = []
        for line in lines:
            if not line.strip():
                translated_lines.append(line)
                continue
            # Translate line by line, strip and re-add trailing content
            try:
                result = await asyncio.to_thread(translator.translate, line)
                translated_lines.append(result or line)
            except Exception:
                translated_lines.append(line)
        return "\n".join(translated_lines)

    async def _get_user_lang(user_id: int | None) -> str:
        if user_id is None:
            return "RU"
        record = await get_language_record(user_id)
        lang = record.get("language", "RU") or "RU"
        return lang if lang in SUPPORTED_LANGUAGES else "RU"

    def _t(key: str, lang: str) -> str:
        return {
            "city": TRANSLATED_CITY_TEXTS,
            "product": TRANSLATED_PRODUCT_TEXTS,
            "district": TRANSLATED_DISTRICT_TEXTS,
            "location": TRANSLATED_LOCATION_TEXTS,
        }.get(key, {}).get(lang, "")

    async def is_language_selected(user_id: int | None) -> bool:
        if user_id is None:
            return False
        record = await get_language_record(user_id)
        selected_language = record.get("language")
        return isinstance(selected_language, str) and selected_language in SUPPORTED_LANGUAGES

    async def send_language_prompt(message: Message) -> None:
        await message.answer(LANGUAGE_PROMPT_TEXT, reply_markup=build_language_keyboard())

    async def ensure_language_access(message: Message, state: FSMContext) -> bool:
        user_id = message.from_user.id if message.from_user else None
        if user_id is None:
            return True
        record = await get_language_record(user_id)
        if not record.get("captcha_solved"):
            await state.clear()
            await send_captcha_challenge(message)
            await state.set_state(CaptchaState.waiting_for_code)
            return False
        return True

    async def ensure_language_callback_access(callback: CallbackQuery, state: FSMContext) -> bool:
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            return True
        record = await get_language_record(user_id)
        if not record.get("captcha_solved"):
            await safe_answer_callback(callback)
            if callback.message is not None:
                await state.clear()
                await callback.message.answer(CAPTCHA_PROMPT_TEXT)
            return False
        return True

    def captcha_is_active(record: dict[str, object]) -> bool:
        return bool(record.get("captcha_code")) and isinstance(record.get("captcha_code"), str)

    async def send_captcha_challenge(target: Message | CallbackQuery) -> None:
        if isinstance(target, CallbackQuery):
            message = target.message
            if message is None:
                return
            await message.answer_photo(
                _build_captcha_image(await get_or_create_captcha_code(target.from_user.id)),
                caption=CAPTCHA_PROMPT_TEXT,
            )
            return
        await target.answer_photo(
            _build_captcha_image(await get_or_create_captcha_code(target.from_user.id)),
            caption=CAPTCHA_PROMPT_TEXT,
        )

    async def get_or_create_captcha_code(user_id: int | None) -> str:
        if user_id is None:
            return _generate_captcha_code()
        record = await captcha_registry.get_user(user_id)
        code = record.get("captcha_code")
        if isinstance(code, str) and code:
            return code
        updated = await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "captcha_required": True,
                "captcha_code": _generate_captcha_code(),
                "click_timestamps": [],
            },
        )
        return str(updated.get("captcha_code") or _generate_captcha_code())

    async def mark_captcha_solved(user_id: int | None) -> None:
        if user_id is None:
            return
        await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "captcha_required": False,
                "captcha_code": "",
                "click_timestamps": [],
                "captcha_solved": True,
                "language": current.get("language") or "EN",
            },
        )

    async def check_and_update_callback_rate(user_id: int | None) -> tuple[bool, bool]:
        if user_id is None:
            return False, False
        now = datetime.now().timestamp()

        def updater(current: dict[str, object]) -> dict[str, object]:
            click_timestamps = current.get("click_timestamps")
            raw_timestamps = click_timestamps if isinstance(click_timestamps, list) else []
            timestamps = [
                float(value)
                for value in raw_timestamps
                if isinstance(value, (int, float))
            ]
            timestamps = [value for value in timestamps if now - value <= CAPTCHA_RATE_LIMIT_WINDOW_SECONDS]
            if captcha_is_active(current):
                current["click_timestamps"] = timestamps
                return current
            timestamps.append(now)
            current["click_timestamps"] = timestamps
            if len(timestamps) > CAPTCHA_RATE_LIMIT_CLICKS:
                current["captcha_required"] = True
                current["captcha_code"] = _generate_captcha_code()
                current["click_timestamps"] = []
            return current

        updated = await captcha_registry.update_user(user_id, updater)
        return captcha_is_active(updated), bool(updated.get("captcha_code"))

    class CallbackCaptchaMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[CallbackQuery, dict[str, Any]], Awaitable[Any]], event: CallbackQuery, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is None:
                return await handler(event, data)
            record = await captcha_registry.get_user(user_id)
            if captcha_is_active(record):
                await safe_answer_callback(event, "Введи код с картинки", show_alert=True)
                return None
            captcha_triggered, _ = await check_and_update_callback_rate(user_id)
            if captcha_triggered:
                await safe_answer_callback(event, "Слишком много нажатий", show_alert=True)
                await send_captcha_challenge(event)
                return None
            return await handler(event, data)

    class MessageCaptchaMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[Message, dict[str, Any]], Awaitable[Any]], event: Message, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is None:
                return await handler(event, data)
            record = await captcha_registry.get_user(user_id)
            if not captcha_is_active(record):
                return await handler(event, data)
            expected_code = str(record.get("captcha_code") or "").strip().upper()
            provided_code = (event.text or "").strip().upper()
            if provided_code and provided_code == expected_code:
                await mark_captcha_solved(user_id)
                state = data.get("state")
                user_name = get_user_display_name(event)

                # Send captcha passed message with bold text
                await event.answer("✅ <b>Captcha passed!</b>", parse_mode="HTML")

                # Send welcome message with the persistent reply keyboard
                welcome_text = f"✨ Welcome, {escape(user_name)}!"
                await event.answer(
                    welcome_text,
                    parse_mode="HTML",
                    reply_markup=persistent_bottom_menu(),
                )
                if isinstance(state, FSMContext):
                    await state.clear()
                return None
            await event.answer("❌ Wrong code. Try again.")
            await send_captcha_challenge(event)
            return None

    def get_user_display_name(target: Message | CallbackQuery) -> str:
        user = target.from_user if isinstance(target, Message) else target.from_user
        if user is None:
            return "user"
        parts: list[str] = []
        if user.first_name:
            parts.append(user.first_name)
        if user.last_name:
            parts.append(user.last_name)
        if parts:
            return " ".join(parts)
        if user.username:
            return user.username
        return "user"

    def get_actor_user_id(target: Message | CallbackQuery) -> int | None:
        user = target.from_user if isinstance(target, Message) else target.from_user
        return user.id if user is not None else None

    async def remember_unpaid_order(user_id: int | None, order: OrderSelection) -> None:
        if user_id is None or order.order_id is None:
            return
        existing_payload = await order_registry.get_user_order(user_id, order.order_id)
        await order_registry.upsert_user_order(
            user_id,
            {
                **(existing_payload or {}),
                "order_id": order.order_id,
                "status": "Не оплаченный",
                "city_key": order.city_key,
                "product_index": order.product_index,
                "option_index": order.option_index,
                "district_index": order.district_index,
            },
        )

    def build_order_deadline(now: datetime | None = None) -> datetime:
        base_dt = now or datetime.now().astimezone()
        return base_dt + timedelta(hours=ORDER_DEADLINE_HOURS)

    def format_order_deadline(deadline: datetime) -> str:
        return deadline.astimezone().strftime(ORDER_DEADLINE_FORMAT)

    def parse_order_deadline(raw_value: object | None) -> datetime | None:
        if raw_value is None:
            return None
        raw_text = str(raw_value).strip()
        if not raw_text:
            return None
        try:
            deadline = datetime.fromisoformat(raw_text)
        except ValueError:
            return None
        if deadline.tzinfo is None:
            return deadline.astimezone()
        return deadline

    async def resolve_order_deadline(user_id: int | None, order: OrderSelection) -> datetime:
        now = datetime.now().astimezone()
        if user_id is not None and order.order_id is not None:
            existing_payload = await order_registry.get_user_order(user_id, order.order_id)
            if existing_payload is not None:
                existing_deadline = parse_order_deadline(existing_payload.get("deadline_at"))
                if existing_deadline is not None and existing_deadline > now:
                    return existing_deadline
        return build_order_deadline(now)

    async def show_main_screen(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        await state.update_data(last_country=None)
        await state.update_data(last_city=None)

        user_id = get_actor_user_id(target)
        lang = "RU"
        if user_id is not None:
            record = await get_language_record(user_id)
            lang = record.get("language", "RU") or "RU"

        base_text = (spec.template.start_text or "").strip()
        if base_text:
            translated = await _translate_start_text(base_text, lang)
        else:
            translated = TRANSLATED_START_TEXTS.get(lang, TRANSLATED_START_TEXTS["RU"])

        display_name = get_user_display_name(target)
        start_text = translated.replace("{user}", display_name)

        markup = main_menu(settings, spec.template)

        start_photo_id = (spec.template.start_photo_id or "").strip()
        start_photo_url = str(spec.template.start_photo_url).strip() if spec.template.start_photo_url else ""

        # Check if photo is disabled by keyword
        bot_name = (spec.template.shop_name or "").upper()
        photo_disabled = "NO_PHOTO" in bot_name

        # Determine photo source: file_id takes priority, then URL
        photo_source = start_photo_id or start_photo_url

        if photo_source and not photo_disabled:
            if isinstance(target, Message):
                await target.answer_photo(photo_source, caption=start_text, reply_markup=markup)
                return
            await target.message.answer_photo(photo_source, caption=start_text, reply_markup=markup)
            return
        await show_text_screen(target, start_text, markup, disable_web_page_preview=True)

    async def show_orders_screen(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        user_id = get_actor_user_id(target)
        orders = await order_registry.list_user_orders(user_id) if user_id is not None else []
        order_buttons: list[tuple[str, str]] = []
        for item in orders:
            try:
                order = OrderSelection(
                    city_key=str(item["city_key"]),
                    product_index=int(item["product_index"]),
                    option_index=int(item["option_index"]),
                    district_index=int(item["district_index"]),
                    order_id=str(item["order_id"]),
                )
            except (KeyError, TypeError, ValueError):
                continue
            status = str(item.get("status") or "Не оплаченный")
            order_buttons.append(
                (f"{status} #{order.order_id}", f"orderopenid:{order.order_id}")
            )
        await show_text_screen(target, build_orders_text(bool(order_buttons)), orders_menu(order_buttons))

    _CART_PRICE_PATTERNS = (
        re.compile(r"(\d+(?:[.,]\d+)?)\s*€"),
        re.compile(r"(\d+(?:[.,]\d+)?)\s*EUR", re.IGNORECASE),
        re.compile(r"(\d+(?:[.,]\d+)?)\s*(?:₴|грн|UAH)", re.IGNORECASE),
        re.compile(r"(\d+(?:[.,]\d+)?)"),
    )

    def _extract_price_eur(*labels: str) -> int:
        for label in labels:
            if not label:
                continue
            for pattern in _CART_PRICE_PATTERNS:
                match = pattern.search(label)
                if match:
                    try:
                        return max(int(float(match.group(1).replace(",", "."))), 1)
                    except ValueError:
                        continue
        return 60

    def _cart_item_label(item: dict[str, object]) -> str:
        return str(item.get("label") or "Item")

    def _cart_item_total(item: dict[str, object]) -> int:
        price = int(item.get("price_eur") or 0)
        qty = int(item.get("qty") or 1)
        return price * qty

    def _cart_total(items: list[dict[str, object]]) -> int:
        return sum(_cart_item_total(i) for i in items)

    def _build_cart_text(items: list[dict[str, object]]) -> str:
        if not items:
            return "🛒 Your basket is empty"
        # Group by category (city_label)
        groups: dict[str, list[tuple[int, dict[str, object]]]] = {}
        order_keys: list[str] = []
        for idx, item in enumerate(items):
            key = str(item.get("category") or item.get("city_label") or "")
            if key not in groups:
                groups[key] = []
                order_keys.append(key)
            groups[key].append((idx, item))
        lines: list[str] = []
        for key in order_keys:
            lines.append(f"─ ─ ─ <b>{escape(key)}</b> ─ ─ ─")
            for idx, item in groups[key]:
                label = _cart_item_label(item)
                price = int(item.get("price_eur") or 0)
                qty = int(item.get("qty") or 1)
                lines.append(
                    f"{idx + 1}. {escape(label)} | {qty} * {price}€ = {price * qty}€"
                )
        return "\n".join(lines)

    def _cart_menu(items: list[dict[str, object]], delete_mode: bool = False) -> InlineKeyboardMarkup | None:
        if not items:
            return None
        rows: list[list[InlineKeyboardButton]] = []
        if delete_mode:
            for idx, item in enumerate(items):
                label = _cart_item_label(item)
                trimmed = (label[:24] + "…") if len(label) > 25 else label
                rows.append([
                    InlineKeyboardButton(text=trimmed, callback_data="cart:noop"),
                    InlineKeyboardButton(text="🗑", callback_data=f"cart:rm:{idx}"),
                ])
            rows.append([InlineKeyboardButton(text="◀️ Back", callback_data="cart:open")])
            return InlineKeyboardMarkup(inline_keyboard=rows)
        total = _cart_total(items)
        rows.append([InlineKeyboardButton(text="🗑 Remove", callback_data="cart:delete_mode")])
        rows.append([InlineKeyboardButton(text=f"✅ Place order | {total}€", callback_data="cart:place_order")])
        return InlineKeyboardMarkup(inline_keyboard=rows)

    async def show_cart_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        *,
        delete_mode: bool = False,
    ) -> None:
        await state.clear()
        user_id = get_actor_user_id(target)
        items = await cart_registry.list_items(user_id) if user_id is not None else []
        text = _build_cart_text(items)
        markup = _cart_menu(items, delete_mode=delete_mode and bool(items))
        await show_text_screen(target, text, markup)

    def _build_product_card_text(
        city: CityConfig,
        product: ProductConfig,
        option: ProductOption,
        price_eur: int,
    ) -> str:
        category = (city.label or "").strip() or "Catalog"
        description = (product.description or "").strip() or "—"
        name = (option.label or product.label or "").strip()
        line = "〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️"
        return (
            f"👉🏻 <b>Category:</b> <code>{escape(category)}</code>\n"
            f"{line}\n"
            f"▪ <b>Name:</b> <code>{escape(name)}</code>\n"
            f"▪ <b>Price:</b> <code>{price_eur} €</code>\n"
            f"▪ <b>Description:</b> {escape(description)}"
        )

    def _product_card_menu(
        in_cart: bool,
        city_key: str,
        product_index: int,
        option_index: int,
    ) -> InlineKeyboardMarkup:
        rows: list[list[InlineKeyboardButton]] = []
        suffix = f"{city_key}:{product_index}:{option_index}"
        if in_cart:
            rows.append([InlineKeyboardButton(text="➖ Remove from cart", callback_data=f"cart:dec:{suffix}")])
            rows.append([InlineKeyboardButton(text="🛒 Go to cart", callback_data="cart:open")])
        else:
            rows.append([InlineKeyboardButton(text="🛒 Add to cart", callback_data=f"cart:add:{suffix}")])
        rows.append([InlineKeyboardButton(text="◀️ Back", callback_data=f"loc:{city_key}:{product_index}")])
        return InlineKeyboardMarkup(inline_keyboard=rows)

    async def _is_item_in_cart(user_id: int | None, city_key: str, product_index: int, option_index: int) -> bool:
        if user_id is None:
            return False
        items = await cart_registry.list_items(user_id)
        for item in items:
            if (
                item.get("city_key") == city_key
                and int(item.get("product_index", -1)) == product_index
                and int(item.get("option_index", -1)) == option_index
            ):
                return True
        return False

    async def show_product_card(
        target: Message | CallbackQuery,
        city: CityConfig,
        product_index: int,
        option_index: int,
    ) -> None:
        product = get_product(city, product_index)
        option = get_option(product, option_index)
        price = _extract_price_eur(option.label, product.label)
        user_id = get_actor_user_id(target)
        in_cart = await _is_item_in_cart(user_id, city.key, product_index, option_index)
        text = _build_product_card_text(city, product, option, price)
        markup = _product_card_menu(in_cart, city.key, product_index, option_index)
        await show_text_screen(target, text, markup)

    def load_showcase_text() -> str:
        catalog_input_path = Path(settings.catalog_path).resolve().parent.parent / "catalog_input.txt"
        try:
            raw_text = catalog_input_path.read_text(encoding="utf-8").strip()
        except OSError:
            raw_text = ""
        if raw_text:
            return raw_text
        return "Витрина пока пуста."

    def current_rotation_day() -> str:
        return datetime.now().astimezone().date().isoformat()

    async def select_visible_districts(
        city: CityConfig,
        product: ProductConfig | None = None,
        option: ProductOption | None = None,
    ) -> list[tuple[int, str]]:
        source_districts = product.districts if product is not None and product.districts else city.districts
        districts = list(enumerate(source_districts))
        if not districts:
            return []
        if len(districts) <= 1:
            return districts

        max_visible_count = (len(districts) * city.district_selection_percent) // 100
        max_visible_count = max(1, min(max_visible_count, len(districts)))
        districts_snapshot = list(source_districts)
        rotation_day = current_rotation_day()
        rotation_key = city.key
        if product is not None:
            rotation_key = f"{rotation_key}:{product.key}"
        if option is not None:
            rotation_key = f"{rotation_key}:{option.key}"
        record = await district_rotation_registry.get_city(rotation_key)

        selected_positions = record.get("selected_positions")
        record_day = record.get("rotation_day")
        record_count = record.get("visible_count")
        record_snapshot = record.get("districts")
        has_valid_snapshot = (
            isinstance(selected_positions, list)
            and record_day == rotation_day
            and isinstance(record_count, int)
            and record_snapshot == districts_snapshot
            and all(isinstance(position, int) and 0 <= position < len(districts) for position in selected_positions)
        )
        if has_valid_snapshot:
            return [districts[position] for position in sorted(selected_positions)]

        visible_count = random.randint(1, max_visible_count)
        selected_positions = sorted(random.sample(range(len(districts)), k=visible_count))
        await district_rotation_registry.update_city(
            rotation_key,
            lambda _current: {
                "rotation_day": rotation_day,
                "visible_count": visible_count,
                "districts": districts_snapshot,
                "selected_positions": selected_positions,
            },
        )
        return [districts[position] for position in selected_positions]

    async def resolve_order_back_callback(order: OrderSelection) -> str:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        visible_districts = await select_visible_districts(city, product, option)
        if len(visible_districts) > 1:
            return f"variant:{order.city_key}:{order.product_index}:{order.option_index}"
        return f"product:{order.city_key}:{order.product_index}"

    async def set_payment_guard(
        state: FSMContext,
        stay_callback: str,
        *,
        exit_prompt_shown: bool = False,
    ) -> None:
        data = await state.get_data()
        await state.update_data(
            **{
                **data,
                PAYMENT_GUARD_KEY: {
                    "stay_callback": stay_callback,
                    "exit_prompt_shown": exit_prompt_shown,
                },
            }
        )

    async def clear_payment_guard(state: FSMContext) -> None:
        data = await state.get_data()
        if PAYMENT_GUARD_KEY not in data:
            return
        data.pop(PAYMENT_GUARD_KEY, None)
        await state.set_data(data)

    async def get_payment_guard_stay_callback(state: FSMContext) -> str | None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return None
        stay_callback = guard.get("stay_callback")
        return stay_callback if isinstance(stay_callback, str) and stay_callback else None

    async def is_payment_exit_prompt_shown(state: FSMContext) -> bool:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        return isinstance(guard, dict) and bool(guard.get("exit_prompt_shown"))

    async def mark_payment_exit_prompt(state: FSMContext, shown: bool) -> None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return
        guard["exit_prompt_shown"] = shown
        data[PAYMENT_GUARD_KEY] = guard
        await state.set_data(data)

    async def show_order_payment_detail_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        method_index: int,
        *,
        resend: bool = False,
    ) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        method = get_payment_method(spec, method_index)
        current_order_id = order.order_id or create_order_id()
        order = OrderSelection(
            city_key=order.city_key,
            product_index=order.product_index,
            option_index=order.option_index,
            district_index=order.district_index,
            order_id=current_order_id,
        )
        stay_callback = f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index}"
        await set_payment_guard(state, stay_callback)
        user_id = get_actor_user_id(target)
        await remember_unpaid_order(user_id, order)
        deadline = await resolve_order_deadline(user_id, order)
        deadline_text = format_order_deadline(deadline)
        if user_id is not None:
            await order_registry.upsert_user_order(
                user_id,
                {
                    "order_id": current_order_id,
                    "status": "Не оплаченный",
                    "city_key": order.city_key,
                    "product_index": order.product_index,
                    "option_index": order.option_index,
                    "district_index": order.district_index,
                    "deadline_at": deadline.isoformat(),
                    "deadline_text": deadline_text,
                    "updated_at": datetime.now().astimezone().isoformat(),
                },
            )
        resolved_amount_label = await resolve_payment_amount_label(option, method)
        wallet_requisites = get_payment_method_requisites(method)
        payment_text = build_order_payment_details_text(
            current_order_id,
            city,
            product,
            option,
            method,
            deadline_text,
            spec.template.operator_username,
            resolved_amount_label,
            wallet_requisites,
        )
        payment_markup = order_payment_detail_menu(
            f"cancel:{order_prefix(order)}",
            f"paymentdetail:{order_prefix(order)}:{method_index}",
            f"qr:{order_prefix(order)}:{method_index}" if supports_payment_qr(method) else None,
        )

        if isinstance(target, Message):
            await target.answer(payment_text, reply_markup=payment_markup)
            return
        if resend:
            await target.message.answer(payment_text, reply_markup=payment_markup)
            await safe_delete_message(target.message)
            return
        await edit_message_copy(target.message, payment_text, reply_markup=payment_markup)

    async def show_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_admin_text(spec)
        markup = admin_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payments_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_payments_admin_text(spec)
        markup = payment_admin_menu(spec)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payment_method_editor(
        target: Message | CallbackQuery,
        state: FSMContext,
        method_index: int,
    ) -> None:
        await state.clear()
        method = get_payment_method(spec, method_index)
        text = build_payment_method_editor_text(method)
        markup = payment_method_editor_menu(method_index, method)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def persist_catalog() -> None:
        save_catalog_cities(settings.catalog_path, settings.cities)

    def next_product_key(city: CityConfig) -> str:
        index = len(city.products) + 1
        while any(product.key == f"product_{index}" for product in city.products):
            index += 1
        return f"product_{index}"

    def next_option_key(product: ProductConfig) -> str:
        index = len(product.options) + 1
        while any(option.key == f"option_{index}" for option in product.options):
            index += 1
        return f"option_{index}"

    async def show_catalog_cities(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_catalog_cities_text(settings.cities)
        markup = catalog_cities_menu(settings.cities)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_city(target: Message | CallbackQuery, state: FSMContext, city_key: str) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        text = build_catalog_city_text(city)
        markup = catalog_city_menu(city)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_product(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        product_index: int,
    ) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        product = get_product(city, product_index)
        text = build_catalog_product_text(city, product)
        markup = catalog_product_menu(city_key, product_index)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        bots = await list_bots()
        text = build_bots_text(len(bots))
        markup = bots_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_upload(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(AdminState.waiting_for_bot_tokens)
        text = build_bots_upload_text()
        markup = bots_upload_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_list(target: Message | CallbackQuery, state: FSMContext, page: int = 0) -> None:
        await state.clear()
        bots = await list_bots()
        total_pages = max(1, (len(bots) + BOTS_PAGE_SIZE - 1) // BOTS_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        visible_bots = bots[page * BOTS_PAGE_SIZE : (page + 1) * BOTS_PAGE_SIZE]
        text = build_bots_list_text(visible_bots, page, BOTS_PAGE_SIZE)
        markup = build_bot_list_menu(visible_bots, page, total_pages, spec.bot_id)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def process_uploaded_tokens(message: Message, raw_text: str) -> None:
        tokens = extract_bot_tokens(raw_text)
        if not tokens:
            await message.answer(
                "Не нашел ни одного Telegram-токена. Пришли токен текстом или `.txt` файл.",
                reply_markup=bots_upload_menu(),
            )
            return

        created_count = 0
        updated_count = 0
        skipped_count = 0
        lines: list[str] = []

        for token in tokens:
            if token == spec.token:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: пропущен, это текущий бот")
                continue
            payload = CreateBotRequest(
                token=token,
                template=spec.template.model_copy(deep=True),
                payment_methods=[method.model_copy(deep=True) for method in spec.payment_methods],
                admin_ids=list(spec.admin_ids),
            )
            try:
                result = await register_bot(payload)
            except Exception as exc:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: ошибка, {escape(short_error(exc))}")
                continue
            if result.created:
                created_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: создан и запущен")
            else:
                updated_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: обновлен и перезапущен")

        summary = [
            "<b>Загрузка завершена</b>",
            "",
            f"Создано: {created_count}",
            f"Обновлено: {updated_count}",
            f"Пропущено/ошибок: {skipped_count}",
        ]
        if lines:
            summary.extend(["", *lines[:20]])
            if len(lines) > 20:
                summary.append(f"... и еще {len(lines) - 20}")
        await message.answer("\n".join(summary), reply_markup=bots_upload_menu())

    async def show_payment_selector(
        target: Message | CallbackQuery,
        order: OrderSelection | None,
        topup: TopupSelection | None = None,
    ) -> None:
        if not spec.payment_methods:
            text = "Способы оплаты пока не настроены."
            if isinstance(target, Message):
                await target.answer(text, reply_markup=simple_back_menu())
            else:
                await edit_message_copy(target.message, text, simple_back_menu())
            return

        if topup is not None:
            text = build_topup_request_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
            )
            markup = payment_methods_menu(
                None,
                spec.payment_methods,
                cancel_callback="cancel:topup",
                amount_text=f"{topup.amount_uah} {DISPLAY_CURRENCY}",
                back_callback="nav:main",
            )
        elif order is None:
            text = settings.payment_text
            markup = payment_methods_menu(
                None,
                spec.payment_methods,
                cancel_callback="cancel:generic",
                back_callback="nav:main",
            )
        else:
            if order.order_id is None:
                order = OrderSelection(
                    city_key=order.city_key,
                    product_index=order.product_index,
                    option_index=order.option_index,
                    district_index=order.district_index,
                    order_id=create_order_id(),
                )
            await remember_unpaid_order(get_actor_user_id(target), order)
            city = get_city(settings, order.city_key)
            product = get_product(city, order.product_index)
            option = get_option(product, order.option_index)
            _, _, price_text = _build_order_display_fields(product, option)
            back_callback = await resolve_order_back_callback(order)
            text = "Товар зарезервирован, выберите платёжную систему"
            markup = payment_methods_menu(
                order_prefix(order),
                spec.payment_methods,
                cancel_callback=f"cancel:{order_prefix(order)}",
                amount_text=price_text,
                back_callback=back_callback,
            )

        if isinstance(target, Message):
            if order is not None:
                photo = resolve_product_photo(product, settings)
                if photo is not None:
                    await target.answer_photo(photo, caption=text, reply_markup=markup)
                    return
            await target.answer(text, reply_markup=markup)
            return
        if order is not None:
            photo = resolve_product_photo(product, settings)
            if photo is not None:
                await target.message.answer_photo(photo, caption=text, reply_markup=markup)
                return
        await edit_message_copy(target.message, text, markup)

    async def show_topup_method_selector(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(TopupState.waiting_for_method)
        text = "💰 <b>Choose a top-up method</b>"
        markup = payment_methods_menu(
            None,
            spec.payment_methods,
            cancel_callback="cancel:topup",
            back_callback="nav:main",
        )
        await show_text_screen(target, text, markup)

    async def start_order_checkout(
        callback: CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        *,
        announce_creation: bool,
    ) -> None:
        del announce_creation
        if not spec.payment_methods:
            await state.clear()
            await edit_message_copy(callback.message, "Способы оплаты пока не настроены.")
            return
        if order.order_id is None:
            order = OrderSelection(
                city_key=order.city_key,
                product_index=order.product_index,
                option_index=order.option_index,
                district_index=order.district_index,
                order_id=create_order_id(),
            )
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await state.clear()
        await state.update_data(last_city=city.key)
        await show_payment_selector(callback, order)

    async def send_qr_if_needed(message: Message, method: PaymentMethodConfig) -> None:
        del message, method

    async def send_payment_qr(message: Message, method: PaymentMethodConfig) -> None:
        requisites = get_payment_method_requisites(method)
        if not requisites:
            await message.answer("Кошелек не указан.")
            return
        if not supports_payment_qr(method):
            await message.answer("QR доступен только для крипто-кошельков.")
            return
        await message.answer_photo(generate_qr_file(method, qr_payload=requisites))

    async def notify_admins_about_payment(
        payer_message: Message,
        method: PaymentMethodConfig,
        summary_text: str | None,
    ) -> None:
        # Payment notifications to admins are intentionally disabled.
        return

    async def show_order_payment_waiting_screen(message: Message, order: OrderSelection, method_index: int) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await edit_message_copy(
            message,
            build_order_payment_waiting_text(
                order.order_id or create_order_id(),
                city,
                product,
                option,
                district,
            ),
            reply_markup=payment_waiting_menu(
                f"paymenthelp:{order_prefix(order)}:{method_index}",
                f"cancel:{order_prefix(order)}",
                f"paymentextend:{order_prefix(order)}:{method_index}",
                f"paymentrefresh:{order_prefix(order)}:{method_index}",
                f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index}",
            ),
        )

    @router.message(F.photo)
    async def on_photo_sent(message: Message) -> None:
        # Capture the file_id of the photo sent by the user (for use as start photo)
        file_id = message.photo[-1].file_id if message.photo else None
        if file_id:
            logger.info("User %s sent photo with file_id: %s", message.from_user.id, file_id)

    @router.message(F.text == BTN_MAIN_MENU)
    async def on_btn_main_menu(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await show_main_screen(message, state)

    @router.message(F.text == BTN_PROFILE)
    async def on_btn_profile(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        user_id = get_actor_user_id(message)
        lang = await _get_user_lang(user_id) if user_id is not None else "EN"
        await message.answer(build_profile_text(user_id=user_id), reply_markup=profile_menu(lang))

    @router.message(F.text == BTN_BASKET)
    async def on_btn_basket(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await show_cart_screen(message, state)

    @router.message(F.text == BTN_SUPPORT)
    async def on_btn_support(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        support_url = (
            spec.template.support_url
            or spec.template.work_url
            or spec.template.operator_url
        )
        markup = None
        if support_url:
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="👨🏼‍💻 Open chat", url=str(support_url))],
            ])
        await message.answer(
            "👑 <b>Contacts and support</b>",
            reply_markup=markup,
            disable_web_page_preview=True,
        )

    @router.message(F.text == BTN_REVIEWS)
    async def on_btn_reviews(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        await render_review_page(message, 0)

    @router.message(F.text == BTN_HELP)
    async def on_btn_help(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        text = (spec.template.help_text or settings.rules_text).strip()
        markup = None
        if spec.template.help_url:
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❓ Open help", url=str(spec.template.help_url))],
            ])
        await message.answer(
            text,
            reply_markup=markup,
            disable_web_page_preview=True,
        )

    @router.message(CommandStart())
    async def on_start(message: Message, state: FSMContext) -> None:
        # Always require captcha on /start
        user_id = message.from_user.id if message.from_user else None
        if user_id is not None:
            await captcha_registry.update_user(
                user_id,
                lambda current: {
                    **current,
                    "captcha_required": True,
                    "captcha_code": _generate_captcha_code(),
                    "click_timestamps": [],
                },
            )
            await state.clear()
            await send_captcha_challenge(message)
            await state.set_state(CaptchaState.waiting_for_code)
            return
        if not await ensure_language_access(message, state):
            return
        stay_callback = await get_payment_guard_stay_callback(state)
        if stay_callback is not None:
            if await is_payment_exit_prompt_shown(state):
                await clear_payment_guard(state)
                await show_main_screen(message, state)
                return
            await mark_payment_exit_prompt(state, True)
            await message.answer(
                PAYMENT_EXIT_CONFIRMATION_TEXT,
                reply_markup=payment_exit_confirmation_menu(
                    stay_callback,
                    leave_callback="nav:main:confirmed",
                ),
            )
            return
        await show_main_screen(message, state)

    @router.message(F.text.in_(SUPPORTED_LANGUAGES))
    async def on_language_selected(message: Message, state: FSMContext) -> None:
        current_state = await state.get_state()
        user_id = message.from_user.id if message.from_user else None
        if user_id is None:
            return
        record = await get_language_record(user_id)
        if not record.get("captcha_solved"):
            return
        selected_language_value = record.get("language")
        language_missing = not (
            isinstance(selected_language_value, str) and selected_language_value in SUPPORTED_LANGUAGES
        )
        if current_state != CaptchaState.waiting_for_language.state and not language_missing:
            return
        selected_language = (message.text or "").strip().upper()
        await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "language": selected_language,
            },
        )
        await state.clear()
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete language selection message %s", message.message_id, exc_info=True)
        try:
            keyboard_cleanup = await message.answer("\u2060", reply_markup=ReplyKeyboardRemove())
            await keyboard_cleanup.delete()
        except Exception:
            logger.debug("Could not remove language keyboard for user %s", user_id, exc_info=True)
        await show_main_screen(message, state)
        return

    @router.callback_query(F.data.startswith("lang:"))
    async def on_language_selected_callback(callback: CallbackQuery, state: FSMContext) -> None:
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            return
        selected_language = callback.data.split(":", maxsplit=1)[1].strip().upper()
        if selected_language not in SUPPORTED_LANGUAGES:
            await safe_answer_callback(callback)
            return
        record = await get_language_record(user_id)
        if not record.get("captcha_solved"):
            await safe_answer_callback(callback)
            if callback.message is not None:
                await state.clear()
                await send_captcha_challenge(callback)
                await state.set_state(CaptchaState.waiting_for_code)
            return
        await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "language": selected_language,
            },
        )
        await state.clear()
        await safe_answer_callback(callback)
        await safe_delete_message(callback.message)
        await show_main_screen(callback, state)
        return

    @router.message(CaptchaState.waiting_for_code)
    async def on_captcha_code(message: Message, state: FSMContext) -> None:
        user_id = message.from_user.id if message.from_user else None
        if user_id is None:
            return
        record = await get_language_record(user_id)
        stored_code = record.get("captcha_code")
        entered = (message.text or "").strip().upper()
        if entered == (stored_code or "").upper():
            await mark_captcha_solved(user_id)
            try:
                await message.delete()
            except Exception:
                pass
            await state.clear()
            user_name = get_user_display_name(message)
            await message.answer("\u2705 <b>Captcha passed!</b>", parse_mode="HTML")
            welcome_text = f"\u2728 Welcome, {escape(user_name)}!"
            await message.answer(
                welcome_text,
                parse_mode="HTML",
                reply_markup=persistent_bottom_menu(),
            )
            return
        # Wrong code - show new captcha
        await message.answer("\u274c Wrong code. Try again.")
        await send_captcha_challenge(message)
        return

    @router.message(Command("bot"))
    async def on_personal_bot_command(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        tokens = extract_bot_tokens(message.text or "")
        if not tokens:
            await message.answer(
                "Пришли команду так:\n/bot 1111111111:AAAAAAAAAA_GchLGbMkBdSBRIEspy11",
                reply_markup=simple_back_menu(),
            )
            return

        token = tokens[0]
        if token == spec.token:
            await message.answer("Нельзя подключить текущий бот как персональный.", reply_markup=simple_back_menu())
            return

        payload = CreateBotRequest(
            token=token,
            template=spec.template.model_copy(deep=True),
            payment_methods=[method.model_copy(deep=True) for method in spec.payment_methods],
            admin_ids=[],
        )
        try:
            result = await register_bot(payload)
        except Exception as exc:
            await message.answer(
                f"Не получилось подключить бота: {escape(short_error(exc))}",
                reply_markup=simple_back_menu(),
            )
            return

        bot_username = (result.spec.bot_username or "").strip()
        if bot_username:
            response_text = (
                f"Твой бот подключен.\n"
                f"Ссылка: https://t.me/{escape(bot_username)}"
            )
        else:
            response_text = "Твой бот подключен."
        await message.answer(response_text, reply_markup=simple_back_menu())

    @router.message(Command("admin"))
    async def on_admin(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_admin_panel(message, state)

    @router.message(Command("catalog"))
    async def on_catalog(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_catalog_cities(message, state)

    @router.callback_query(F.data == "admin:panel")
    async def on_admin_panel(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:close")
    async def on_admin_close(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text("Админка закрыта.")

    @router.callback_query(F.data == "admin:payments")
    async def on_admin_payments(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_payments_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:catalog")
    async def on_admin_catalog(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_catalog_cities(callback, state)

    @router.callback_query(F.data.startswith("admin:catalog_city:"))
    async def on_admin_catalog_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        await safe_answer_callback(callback)
        await show_catalog_city(callback, state, city_key)

    @router.callback_query(F.data.startswith("admin:catalog_product:"))
    async def on_admin_catalog_product(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, product_index_text = callback.data.split(":")
        await safe_answer_callback(callback)
        await show_catalog_product(callback, state, city_key, int(product_index_text))

    @router.callback_query(F.data.startswith("admin:catalog_add_product:"))
    async def on_admin_catalog_add_product(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_catalog_product_name)
        await state.update_data(catalog_city_key=city_key)
        await callback.message.edit_text(
            f"Город: <b>{escape(city.label)}</b>\n\nПришли название нового товара одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_add_option:"))
    async def on_admin_catalog_add_option(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_catalog_option_label)
        await state.update_data(catalog_city_key=city_key, catalog_product_index=product_index)
        await callback.message.edit_text(
            f"Товар: <b>{escape(_normalize_display_currency_text(product.button_label or product.label))}</b>\n\n"
            f"Пришли новую фасовку одним сообщением. Пример: <code>0.2г за 280 {DISPLAY_CURRENCY} -30%</code>",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_method:"))
    async def on_admin_payment_method(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_payment_method_editor(callback, state, method_index)

    @router.callback_query(F.data == "admin:payment_add")
    async def on_admin_payment_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_new_payment_label)
        await callback.message.edit_text(
            "Пришли название нового способа оплаты одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_label:"))
    async def on_admin_payment_label(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_label)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущее название: <b>{escape(method.label)}</b>\n\nПришли новое название одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_edit:"))
    async def on_admin_payment_edit(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_text)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущий текст метода <b>{escape(method.label)}</b>:\n\n"
            f"<pre>{escape(method.details_text)}</pre>\n\n"
            "Реквизиты меняются отдельно. В тексте можно оставить <code>{requisites}</code>, "
            "и бот сам подставит номер карты или кошелек.\n\n"
            "Пришли новый текст одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_requisites:"))
    async def on_admin_payment_requisites(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        current_requisites = resolve_payment_requisites(method) or "не указаны"
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_requisites)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущие реквизиты метода <b>{escape(format_payment_method_title(method))}</b>: "
            f"<b>{escape(current_requisites)}</b>\n\n"
            "Пришли новые реквизиты одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_commission:"))
    async def on_admin_payment_commission(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        current_commission = (method.commission_text or "").strip() or "не указана"
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_commission)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущая комиссия метода <b>{escape(format_payment_method_title(method))}</b>: "
            f"<b>{escape(current_commission)}</b>\n\n"
            "Пришли новую комиссию одним сообщением. Например: <code>-5%</code>\n"
            "Чтобы убрать комиссию, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_qr:"))
    async def on_admin_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        method.qr_enabled = not method.qr_enabled
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(callback, state, method_index)
        await safe_answer_callback(callback, "QR обновлен.")

    @router.callback_query(F.data.startswith("admin:payment_delete:"))
    async def on_admin_payment_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        if method_index < 0 or method_index >= len(spec.payment_methods):
            await safe_answer_callback(callback, "Способ оплаты не найден.", show_alert=True)
            return
        removed_method = spec.payment_methods.pop(method_index)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payments_admin_panel(callback, state)
        await safe_answer_callback(callback, f"Удален способ: {removed_method.label}")

    @router.callback_query(F.data == "admin:bots")
    async def on_bots(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_panel(callback, state)

    @router.callback_query(F.data == "admin:bots_upload")
    async def on_bots_upload(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_upload(callback, state)

    @router.callback_query(F.data.startswith("admin:bots_page:"))
    async def on_bots_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        page = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_bots_list(callback, state, page)

    @router.callback_query(F.data.startswith("admin:bot_toggle_pause:"))
    async def on_bot_toggle_pause(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, _page = payload
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await safe_answer_callback(
            callback,
            build_bot_info_alert(bot_summary, bot_id == spec.bot_id),
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:bot_pause_switch:"))
    async def on_bot_pause_switch(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if bot_id == spec.bot_id:
            await safe_answer_callback(callback, "Текущего бота нельзя приостановить из его собственной админки.", show_alert=True)
            return
        updated_spec = await toggle_bot_pause_by_id(bot_id)
        if updated_spec is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await show_bots_list(callback, state, page)
        if updated_spec.is_paused:
            await safe_answer_callback(callback, "🟠 Бот приостановлен.")
            return
        await safe_answer_callback(callback, "Бот снова запущен.")

    @router.callback_query(F.data.startswith("admin:bot_delete:"))
    async def on_bot_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if spec.bot_id == bot_id:
            await safe_answer_callback(callback, "Нельзя удалить текущего бота из его собственной админки.", show_alert=True)
            return
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот уже удален или не найден.", show_alert=True)
            return
        await safe_answer_callback(callback, "Удаляю бота и останавливаю токен...")
        removed = await remove_bot_by_id(bot_id)
        if not removed:
            await show_bots_list(callback, state, page)
            if callback.message is not None:
                await callback.message.answer("Бот уже удален или не найден.")
            return
        await show_bots_list(callback, state, page)
        if callback.message is not None:
            await callback.message.answer(
                "Бот удален и остановлен.\n"
                f"Токен удаленного бота:\n<code>{escape(bot_summary.token)}</code>"
            )

    @router.callback_query(F.data == "admin:set_start_text")
    async def on_set_start_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_start_text)
        await callback.message.edit_text(
            "Текущий стартовый текст:\n\n"
            f"<pre>{escape(spec.template.start_text)}</pre>\n\n"
            "Пришли новый стартовый текст одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_contacts_text")
    async def on_set_contacts_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_contacts_text)
        await callback.message.edit_text(
            "Текущий текст контактов:\n\n"
            f"<pre>{escape(spec.template.contacts_text)}</pre>\n\n"
            "Пришли новый текст контактов одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_info_url")
    async def on_set_info_url(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_info_url)
        current_value = str(spec.template.info_url).strip() if spec.template.info_url else "не задана"
        await callback.message.edit_text(
            "Текущая ссылка кнопки Инфо:\n\n"
            f"<code>{escape(current_value)}</code>\n\n"
            "Пришли новый URL одним сообщением.\n"
            "Отправь <code>-</code>, чтобы очистить ссылку.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_giveaway_url")
    async def on_set_giveaway_url(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_giveaway_url)
        current_value = str(spec.template.giveaway_url).strip() if spec.template.giveaway_url else "не задана"
        await callback.message.edit_text(
            "Текущая ссылка кнопки Розыгрыши:\n\n"
            f"<code>{escape(current_value)}</code>\n\n"
            "Пришли новый URL одним сообщением.\n"
            "Отправь <code>-</code>, чтобы очистить ссылку.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:add_admin")
    async def on_add_admin(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_admin_id)
        await callback.message.edit_text(
            "Пришли Telegram ID нового админа одним числом.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_catalog_product_name)
    async def on_catalog_product_name(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        product_name = (message.text or "").strip()
        if not product_name:
            await message.answer("Название товара не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        city = get_city(settings, city_key)
        await state.set_state(AdminState.waiting_for_catalog_product_first_option)
        await state.update_data(catalog_product_name=product_name)
        await message.answer(
            f"Город: <b>{escape(city.label)}</b>\n"
            f"Товар: <b>{escape(product_name)}</b>\n\n"
            f"Теперь пришли первую фасовку одним сообщением. Пример: <code>0.2г за 280 {DISPLAY_CURRENCY} -30%</code>",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_catalog_product_first_option)
    async def on_catalog_product_first_option(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        option_label = (message.text or "").strip()
        if not option_label:
            await message.answer("Фасовка не должна быть пустой.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        product_name = str(data["catalog_product_name"])
        city = get_city(settings, city_key)
        product = ProductConfig(
            key=next_product_key(city),
            label=product_name,
            button_label=product_name,
            options=[ProductOption(key="option_1", label=option_label)],
            description=None,
            photo_id=None,
            photo_url=None,
            photo_path="",
        )
        city.products.append(product)
        await persist_catalog()
        await show_catalog_city(message, state, city_key)

    @router.message(AdminState.waiting_for_catalog_option_label)
    async def on_catalog_option_label(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        option_label = (message.text or "").strip()
        if not option_label:
            await message.answer("Фасовка не должна быть пустой.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        product_index = int(data["catalog_product_index"])
        city = get_city(settings, city_key)
        product = get_product(city, product_index)
        product.options.append(ProductOption(key=next_option_key(product), label=option_label))
        await persist_catalog()
        await show_catalog_product(message, state, city_key, product_index)

    @router.message(AdminState.waiting_for_start_text)
    async def on_start_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Стартовый текст не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.start_text = new_text
        await sync_start_text_for_all(new_text)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_contacts_text)
    async def on_contacts_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст контактов не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.contacts_text = new_text
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_info_url)
    async def on_info_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            spec.template.info_url = validate_url_input(message.text or "")
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_giveaway_url)
    async def on_giveaway_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            spec.template.giveaway_url = validate_url_input(message.text or "")
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_payment_label)
    async def on_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        new_label = (message.text or "").strip()
        if not new_label:
            await message.answer("Название способа оплаты не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        set_payment_method(spec, method_index, label=new_label)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_text)
    async def on_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст способа оплаты не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        method = get_payment_method(spec, method_index)
        current_requisites = resolve_payment_requisites(method)
        extracted_requisites = extract_payment_requisites(new_text)
        next_requisites = (
            current_requisites
            if PAYMENT_REQUISITES_PLACEHOLDER in new_text or extracted_requisites is None
            else extracted_requisites
        )
        set_payment_method(spec, method_index, details_text=new_text, requisites=next_requisites)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_commission)
    async def on_payment_commission_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        raw_value = (message.text or "").strip()
        commission_text = None if raw_value.casefold() in {"-", "—", "–", "нет", "none", "null"} else raw_value
        set_payment_method(spec, method_index, commission_text=commission_text)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_requisites)
    async def on_payment_requisites_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        new_requisites = (message.text or "").strip()
        if not new_requisites:
            await message.answer("Реквизиты не должны быть пустыми.", reply_markup=admin_cancel_menu())
            return
        set_payment_method(spec, method_index, requisites=new_requisites)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_new_payment_label)
    async def on_new_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_label = (message.text or "").strip()
        if not new_label:
            await message.answer("Название способа оплаты не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        await state.set_state(AdminState.waiting_for_new_payment_text)
        await state.update_data(new_payment_label=new_label)
        await message.answer(
            f"Название сохранено: <b>{escape(new_label)}</b>\n\nТеперь пришли текст этого способа оплаты.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_new_payment_text)
    async def on_new_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст способа оплаты не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        await state.set_state(AdminState.waiting_for_new_payment_requisites)
        await state.update_data(new_payment_text=new_text)
        await message.answer(
            "Теперь пришли реквизиты для этого способа оплаты.\n"
            "Если реквизиты не нужны, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_new_payment_requisites)
    async def on_new_payment_requisites_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        new_label = (data.get("new_payment_label") or "").strip()
        new_text = (data.get("new_payment_text") or "").strip()
        if not new_label or not new_text:
            await state.clear()
            await show_payments_admin_panel(message, state)
            return
        raw_requisites = (message.text or "").strip()
        requisites = None if raw_requisites.casefold() in {"-", "—", "–", "нет", "none", "null"} else raw_requisites
        new_method = PaymentMethodConfig(
            key=build_payment_method_key(spec, new_label),
            label=new_label,
            commission_text=None,
            details_text=new_text,
            requisites=requisites,
            qr_enabled=False,
        )
        spec.payment_methods.append(new_method)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, len(spec.payment_methods) - 1)

    @router.message(AdminState.waiting_for_admin_id)
    async def on_admin_id_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        value = (message.text or "").strip()
        if not value.isdigit():
            await message.answer("Нужен числовой Telegram ID.", reply_markup=admin_cancel_menu())
            return
        admin_id = int(value)
        if admin_id not in spec.admin_ids:
            spec.admin_ids.append(admin_id)
            spec.admin_ids.sort()
            await sync_admin_ids_for_all(spec.admin_ids)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_bot_tokens, F.document)
    async def on_bot_tokens_document(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            raw_text = await read_document_text(message)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=bots_upload_menu())
            return
        await process_uploaded_tokens(message, raw_text)

    @router.message(AdminState.waiting_for_bot_tokens)
    async def on_bot_tokens_text(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        raw_text = message.text or message.caption or ""
        await process_uploaded_tokens(message, raw_text)

    @router.callback_query(F.data.startswith("country:"))
    async def on_country(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        country_key = callback.data.split(":", maxsplit=1)[1]
        country = get_country(settings, country_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=country.key, last_city=None)
        await show_text_screen(callback, build_country_text(country), country_menu(country))

    @router.callback_query(F.data.startswith("city:"))
    async def on_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        if len(parts) == 3:
            _, country_key, city_key = parts
        elif len(parts) == 2:
            _, city_key = parts
            city = get_city(settings, city_key)
            country_key = city.country_key or ""
        else:
            await safe_answer_callback(callback, "Некорректный город")
            return
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=country_key, last_city=city.key)
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id)
        await show_text_screen(callback, _t("city", lang), city_menu(city))

    @router.callback_query(F.data.startswith("product:"))
    async def on_product(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        await safe_answer_callback(callback)
        await state.update_data(last_city=city.key, last_product=product_index)
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id)
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Po gradu", callback_data=f"loc:{city.key}:{product_index}")],
            [InlineKeyboardButton(text="◀️ Back", callback_data=f"city:{city.key}")],
        ])
        await show_text_screen(callback, _t("location", lang), markup)

    @router.callback_query(F.data.startswith("loc:"))
    async def on_location(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        await safe_answer_callback(callback)
        await state.update_data(last_city=city.key, last_product=product_index)
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id)
        districts = list(city.districts) or ["Centar"]
        rng = random.Random(f"{user_id}:{city.key}:{product_index}:{datetime.now().date().isoformat()}")
        sample_size = min(rng.randint(5, 10), len(districts))
        picked = rng.sample(districts, sample_size)
        rows: list[list[InlineKeyboardButton]] = []
        for district_name in picked:
            real_index = city.districts.index(district_name)
            rows.append([InlineKeyboardButton(
                text=district_name,
                callback_data=f"distpick:{city.key}:{product_index}:{real_index}",
            )])
        rows.append([InlineKeyboardButton(text="◀️ Back", callback_data=f"product:{city.key}:{product_index}")])
        await show_text_screen(
            callback,
            _t("district", lang) or "👉🏻 Select a district",
            InlineKeyboardMarkup(inline_keyboard=rows),
        )

    @router.callback_query(F.data.startswith("distpick:"))
    async def on_district_pick(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, district_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        await safe_answer_callback(callback)
        await state.update_data(
            last_city=city.key,
            last_product=product_index,
            last_district=int(district_index_text),
        )
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id)
        await show_text_screen(
            callback,
            _t("product", lang),
            option_menu(city, product_index, product),
        )

    @router.callback_query(F.data.startswith("item:"))
    async def on_item(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        await safe_answer_callback(callback)
        await state.update_data(last_city=city.key, last_product=product_index)
        if len(product.options) == 1:
            option = get_option(product, 0)
            visible_districts = await select_visible_districts(city, product, option)
            await state.update_data(last_option=0)
            if len(visible_districts) == 1:
                district_index, _district = visible_districts[0]
                await show_order_confirm_screen(
                    callback,
                    OrderSelection(
                        city_key=city.key,
                        product_index=product_index,
                        option_index=0,
                        district_index=district_index,
                        order_id=create_order_id(),
                    ),
                )
                return
            await edit_message_copy(
                callback.message,
                build_district_text(city, product, option),
                reply_markup=district_menu(
                    city,
                    product_index,
                    0,
                    visible_districts,
                    back_callback=f"city:{city.key}",
                ),
            )
            return
        await show_text_screen(
            callback,
            build_option_text(city, product),
            reply_markup=option_menu(city, product_index, product),
        )

    @router.callback_query(F.data.startswith("variant:"))
    async def on_variant(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        option_index = int(option_index_text)
        await safe_answer_callback(callback)
        await state.update_data(
            last_city=city.key,
            last_product=product_index,
            last_option=option_index,
        )
        await show_product_card(callback, city, product_index, option_index)

    @router.callback_query(F.data.startswith("cart:add:"))
    async def on_cart_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        _, _, city_key, product_index_text, option_index_text = callback.data.split(":")
        product_index = int(product_index_text)
        option_index = int(option_index_text)
        city = get_city(settings, city_key)
        product = get_product(city, product_index)
        option = get_option(product, option_index)
        price = _extract_price_eur(option.label, product.label)
        await cart_registry.add_item(user_id, {
            "city_key": city.key,
            "city_label": city.label,
            "category": city.label,
            "product_index": product_index,
            "option_index": option_index,
            "label": option.label or product.label,
            "price_eur": price,
            "qty": 1,
        })
        await safe_answer_callback(callback, "✅ Added to cart")
        await show_product_card(callback, city, product_index, option_index)

    @router.callback_query(F.data.startswith("cart:dec:"))
    async def on_cart_dec(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        _, _, city_key, product_index_text, option_index_text = callback.data.split(":")
        product_index = int(product_index_text)
        option_index = int(option_index_text)
        await cart_registry.remove_by_match(user_id, city_key, product_index, option_index)
        await safe_answer_callback(callback, "Removed from cart")
        city = get_city(settings, city_key)
        await show_product_card(callback, city, product_index, option_index)

    @router.callback_query(F.data == "cart:open")
    async def on_cart_open(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await show_cart_screen(callback, state)

    @router.callback_query(F.data == "cart:delete_mode")
    async def on_cart_delete_mode(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await show_cart_screen(callback, state, delete_mode=True)

    @router.callback_query(F.data.startswith("cart:rm:"))
    async def on_cart_rm(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        try:
            idx = int(callback.data.rsplit(":", 1)[1])
        except (ValueError, IndexError):
            await safe_answer_callback(callback)
            return
        await cart_registry.remove_at(user_id, idx)
        await safe_answer_callback(callback, "Removed")
        await show_cart_screen(callback, state, delete_mode=True)

    @router.callback_query(F.data == "cart:noop")
    async def on_cart_noop(callback: CallbackQuery) -> None:
        await safe_answer_callback(callback)

    @router.callback_query(F.data == "cart:place_order")
    async def on_cart_place_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        user_id = callback.from_user.id if callback.from_user else None
        items = await cart_registry.list_items(user_id) if user_id is not None else []
        total = _cart_total(items)
        if total <= 0:
            await safe_answer_callback(callback, "🛒 Your basket is empty", show_alert=True)
            return
        await safe_answer_callback(
            callback,
            f"🛒 Your balance is insufficient. Top up another {total}€",
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("district:"))
    async def on_district(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await safe_answer_callback(callback)
        logger.debug("Selected district %s for %s", district, order)
        await state.clear()
        await state.update_data(
            last_city=city.key,
            last_product=order.product_index,
            last_option=order.option_index,
        )
        await show_order_confirm_screen(callback, order)

    @router.callback_query(F.data.startswith("confirm:"))
    async def on_confirm_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        await safe_answer_callback(callback)
        await start_order_checkout(callback, state, order, announce_creation=False)

    @router.callback_query(F.data == "action:promo")
    async def on_promo(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await show_text_screen(callback, "Введите код купона:", promo_menu())

    @router.callback_query(F.data == "action:orders")
    async def on_orders(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await show_orders_screen(callback, state)

    @router.callback_query(F.data.startswith("orderopenid:"))
    @router.callback_query(F.data.startswith("orderopen:order:"))
    async def on_order_open(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        if callback.data.startswith("orderopenid:"):
            user_id = get_actor_user_id(callback)
            order_id = callback.data.split(":", maxsplit=1)[1]
            if user_id is None:
                return
            order_payload = await order_registry.get_user_order(user_id, order_id)
            if order_payload is None:
                await show_text_screen(callback, "Заказ не найден.", simple_back_menu())
                return
            try:
                order = OrderSelection(
                    city_key=str(order_payload["city_key"]),
                    product_index=int(order_payload["product_index"]),
                    option_index=int(order_payload["option_index"]),
                    district_index=int(order_payload["district_index"]),
                    order_id=str(order_payload["order_id"]),
                )
            except (KeyError, TypeError, ValueError):
                await show_text_screen(callback, "Заказ поврежден и не может быть открыт.", simple_back_menu())
                return
        else:
            order = parse_order_callback_values(callback.data.split(":")[2:])
        await state.clear()
        await show_payment_selector(callback, order)

    @router.callback_query(F.data == "action:discounts")
    async def on_discounts(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (
            "Твоя персональная скидка - 0.00%, оборот - 0.00\n\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%"
        )
        await show_text_screen(callback, text, main_only_menu())

    @router.callback_query(F.data.startswith("city_shortcut:"))
    async def on_city_shortcut(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        city_key = callback.data.split(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=city.country_key, last_city=city.key)
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id)
        await show_text_screen(callback, _t("city", lang), city_menu(city))

    @router.callback_query(F.data == "action:profile")
    async def on_profile(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        user_id = callback.from_user.id if callback.from_user else None
        lang = await _get_user_lang(user_id) if user_id is not None else "EN"
        await show_text_screen(
            callback,
            build_profile_text(user_id=user_id),
            profile_menu(lang),
        )

    @router.callback_query(F.data == "action:my_orders")
    async def on_my_orders(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        del state
        await safe_answer_callback(callback, "❗ You have no purchases", show_alert=True)

    @router.callback_query(F.data == "action:lang_toggle")
    async def on_lang_toggle(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        del state
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None:
            await safe_answer_callback(callback)
            return
        current = (await _get_user_lang(user_id) or "EN").upper()
        cycle = {"RU": "SR", "SR": "EN", "EN": "RU"}
        next_lang = cycle.get(current, "RU")
        await captcha_registry.update_user(
            user_id,
            lambda data, lang=next_lang: {**data, "language": lang},
        )
        confirmation = {
            "SR": "🇷🇸 Jezik je promenjen na Srpski",
            "RU": "🇷🇺 Язык был изменён на Русский",
            "EN": "🇺🇸 Language has been changed to English",
        }[next_lang]
        await safe_answer_callback(callback)
        if callback.message is not None:
            await callback.message.answer(confirmation)
        try:
            await callback.message.edit_reply_markup(reply_markup=profile_menu(next_lang))
        except TelegramBadRequest:
            pass

    @router.callback_query(F.data == "action:secret_phrase")
    async def on_secret_phrase(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await show_text_screen(callback, "Введите секретную фразу", promo_menu())

    @router.message(PromoState.waiting_for_code)
    async def on_promo_code(message: Message, state: FSMContext) -> None:
        code = (message.text or "").strip()
        del code
        await state.clear()
        await message.answer(
            "Купон не найден",
            reply_markup=promo_menu(),
        )

    @router.callback_query(F.data == "action:purchases")
    async def on_purchases(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, "Ваши покупки:", purchases_menu())

    @router.callback_query(F.data == "action:rules")
    async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (spec.template.help_text or settings.rules_text).strip()
        await show_text_screen(callback, text, rules_menu(), disable_web_page_preview=True)

    @router.callback_query(F.data == "action:info")
    async def on_info(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        info_text = "📌 Информация о боте:\n\nВыберите страну выше для просмотра каталога."
        await show_text_screen(callback, info_text, simple_back_menu())

    @router.callback_query(F.data == "action:giveaway")
    async def on_giveaway(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        giveaway_text = "🎉 Розыгрыши\n\nСледите за нашими обновлениями!"
        await show_text_screen(callback, giveaway_text, simple_back_menu())

    @router.callback_query(F.data == "action:topup")
    async def on_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_topup_method_selector(callback, state)

    async def _convert_eur_to_crypto(amount_eur: Decimal, method: PaymentMethodConfig) -> tuple[str, str]:
        currency = _resolve_crypto_currency_code(method)
        usd_per_eur_inverse = await fetch_usd_fiat_rate("EUR")  # EUR per 1 USD
        if usd_per_eur_inverse is None or usd_per_eur_inverse <= 0:
            usd_amount = amount_eur
        else:
            usd_amount = amount_eur / usd_per_eur_inverse
        if currency in {"USDT", "USDC"}:
            value = usd_amount.quantize(Decimal("0.01"), rounding=ROUND_CEILING)
            return f"{value}", currency
        rate = await fetch_crypto_usd_rate(currency)
        if rate is None or rate <= 0:
            return f"{usd_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)}", "USD"
        crypto_amount = (usd_amount / rate).quantize(Decimal("0.00000001"), rounding=ROUND_CEILING)
        return f"{crypto_amount}", currency

    def _build_topup_english_text(method: PaymentMethodConfig, amount_label: str, address: str) -> str:
        title_label = (method.label or "").strip() or _resolve_crypto_currency_code(method)
        line = "〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️"
        return (
            f"📡 <b>Balance Top-Up - {escape(title_label)}</b>\n"
            f"{line}\n"
            f"❗ To top up your balance, transfer the specified amount to the address\n"
            f"💰 <b>Amount:</b> <code>{escape(amount_label)}</code>\n"
            f"💰 <b>Address:</b> <code>{escape(address)}</code>\n"
            f"{line}\n"
            f"❗ After the transfer, click 🔄 Check Payment"
        )

    def _topup_check_markup(method_index: int) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="🔄 Check Payment", callback_data=f"paid:generic:{method_index}")],
            ]
        )

    @router.message(TopupState.waiting_for_amount)
    async def on_topup_amount(message: Message, state: FSMContext) -> None:
        try:
            amount_eur = Decimal((message.text or "").strip().replace(",", ".").replace(" ", ""))
            if amount_eur <= 0:
                raise InvalidOperation
        except (InvalidOperation, ValueError):
            await message.answer("❌ Enter a positive number in euros.")
            return
        data = await state.get_data()
        selected_method_index = data.get("selected_topup_method_index")
        if not isinstance(selected_method_index, int):
            await state.clear()
            await show_topup_method_selector(message, state)
            return
        method = get_payment_method(spec, selected_method_index)
        amount_label, currency = await _convert_eur_to_crypto(amount_eur, method)
        address = get_payment_method_requisites(method) or ""
        topup = create_topup_selection(int(amount_eur))
        await state.set_state(TopupState.waiting_for_payment)
        await state.update_data(
            topup=serialize_topup_selection(topup),
            selected_topup_method_index=selected_method_index,
        )
        text = _build_topup_english_text(method, f"{amount_label} {currency}", address)
        await message.answer(text, reply_markup=_topup_check_markup(selected_method_index))

    @router.callback_query(F.data == "paymenu:generic")
    async def on_paymenu_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        if topup is None:
            await show_topup_method_selector(callback, state)
            return
        await state.set_state(TopupState.waiting_for_payment)
        await show_payment_selector(callback, None, topup)

    @router.callback_query(F.data.startswith("paymenu:order:"))
    async def on_paymenu_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await safe_answer_callback(callback)
        await state.clear()
        await show_payment_selector(callback, order)

    @router.callback_query(F.data.startswith("payment:generic:"))
    async def on_payment_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        current_state = await state.get_state()
        if topup is None and current_state == TopupState.waiting_for_method.state:
            await state.set_state(TopupState.waiting_for_amount)
            await state.update_data(selected_topup_method_index=method_index)
            cancel_markup = InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="❌ Отменить", callback_data="cancel:topup")]]
            )
            await show_text_screen(
                callback,
                "💰 <b>Enter the top-up amount (in euros):</b>",
                cancel_markup,
            )
            return
        if topup is None:
            await state.clear()
            text = f"<b>{escape(format_payment_method_title(method))}</b>\n\n{escape(render_payment_details_text(method))}"
        else:
            await state.set_state(TopupState.waiting_for_payment)
            currency_code = _resolve_crypto_currency_code(method)
            resolved_amount_label: str | None = None
            if currency_code in {"BTC", "LTC", "TRX", "USDT", "USDC"}:
                usd_gel_rate = await fetch_usd_fiat_rate("GEL")
                crypto_usd_rate = await fetch_crypto_usd_rate(currency_code) if currency_code not in {"USDT", "USDC"} else await fetch_crypto_usd_rate("USDT")
                gel_amount = Decimal(str(topup.amount_uah))
                if crypto_usd_rate and usd_gel_rate and usd_gel_rate > 0:
                    usd_amount = gel_amount / usd_gel_rate
                    if currency_code in {"USDT", "USDC"}:
                        resolved_amount_label = f"{usd_amount.quantize(Decimal('0.01'), rounding=ROUND_CEILING)} {currency_code}"
                    else:
                        crypto_amount = (usd_amount / crypto_usd_rate).quantize(Decimal("0.00000001"), rounding=ROUND_CEILING)
                        resolved_amount_label = f"{crypto_amount} {currency_code}"
            text = build_topup_payment_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
                method,
                resolved_amount_label,
            )
        await show_text_screen(
            callback,
            text,
            payment_action_menu(
                f"paid:generic:{method_index}",
                "paymenu:generic",
                "cancel:generic" if topup is None else "cancel:topup",
                f"qr:generic:{method_index}" if supports_payment_qr(method) else None,
            ),
        )

    @router.callback_query(F.data.startswith("payment:order:"))
    async def on_payment_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await state.clear()
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text), resend=True)

    @router.callback_query(F.data.startswith("paymentdetail:order:"))
    async def on_payment_detail_refresh(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        method = get_payment_method(spec, int(method_index_text))
        price_text = await resolve_payment_amount_label(option, method)
        if not price_text:
            price_text = _build_order_display_fields(product, option)[2] or f"0 {DISPLAY_CURRENCY}"
        deadline_text = format_order_deadline(await resolve_order_deadline(get_actor_user_id(callback), order))
        alert_text = (
            "Заказ проверен\n"
            "Оплачено: 0\n"
            f"Цена: {price_text}\n"
            "Ждёт подтверждения: 0\n"
            f"Конец заказа: {deadline_text}\n\n"
            "/cancel - отмена\n\n"
            "/current - показать заказ"
        )
        await safe_answer_callback(callback, alert_text, show_alert=True)

    @router.callback_query(F.data.startswith("qr:generic:"))
    async def on_qr_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        if not supports_payment_qr(method):
            await safe_answer_callback(callback, "QR доступен только для крипто-кошельков.", show_alert=True)
            return
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("qr:order:"))
    async def on_qr_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        if not supports_payment_qr(method):
            await safe_answer_callback(callback, "QR доступен только для крипто-кошельков.", show_alert=True)
            return
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("copywallet:order:"))
    async def on_copywallet(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        method = get_payment_method(spec, int(method_index_text))
        wallet = get_payment_method_requisites(method)
        await safe_answer_callback(callback, wallet, show_alert=True)

    @router.callback_query(F.data.startswith("paid:generic:"))
    async def on_paid_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        del state
        await safe_answer_callback(
            callback,
            "❗ The payment was not found or has not yet entered the network. Try again later",
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("paid:order:"))
    async def on_paid_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        method = get_payment_method(spec, int(method_index_text))
        await safe_answer_callback(callback)
        await set_payment_guard(state, f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}")
        await show_order_payment_waiting_screen(callback.message, order, int(method_index_text))
        await notify_admins_about_payment(callback.message, method, build_order_summary(settings, order))

    @router.callback_query(F.data == "cancel:generic")
    async def on_cancel_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await edit_message_copy(callback.message, "Оплата отменена.")

    @router.callback_query(F.data == "cancel:topup")
    async def on_cancel_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        if callback.message is not None:
            try:
                await callback.message.delete()
            except Exception:
                pass

    @router.callback_query(F.data.startswith("cancel:order:"))
    async def on_cancel_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await edit_message_copy(
            callback.message,
            "Вы действительно хотите отменить заказ?",
            cancel_order_confirmation_menu(
                f"cancelconfirm:{order_prefix(order)}",
                f"paymenu:{order_prefix(order)}",
            ),
        )

    @router.callback_query(F.data.startswith("cancelconfirm:order:"))
    async def on_cancel_order_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_main_screen(callback, state)

    @router.callback_query(F.data.startswith("paymentexit:detail:"))
    async def on_payment_exit_detail(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentexit:waiting:"))
    async def on_payment_exit_waiting(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymenthelp:order:"))
    async def on_payment_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await set_payment_guard(state, f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}")
        await edit_message_copy(
            callback.message,
            PAYMENT_HELP_TEXT,
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index_text}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentextend:order:"))
    async def on_payment_extend(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await set_payment_guard(state, f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}")
        await edit_message_copy(
            callback.message,
            PAYMENT_EXTEND_CARD_TEXT,
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index_text}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentrefresh:order:"))
    async def on_payment_refresh(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await set_payment_guard(state, f"paymentdetail:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{method_index_text}")
        await show_order_payment_waiting_screen(callback.message, order, int(method_index_text))

    @router.callback_query(F.data == "action:instructions")
    async def on_instructions(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, settings.instructions_text, simple_back_menu())

    @router.callback_query(F.data.in_({"action:medical_help", "action:overdose"}))
    async def on_medical_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, MEDICAL_HELP_TEXT, simple_back_menu())

    @router.callback_query(F.data == "action:operator")
    async def on_operator(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (spec.template.contacts_text or "").strip()
        if not text:
            text = f"Оператор: @{escape(spec.template.operator_username)}"
            if spec.template.operator_url:
                text += f"\nСсылка: {spec.template.operator_url}"
        await show_text_screen(callback, text, simple_back_menu())

    @router.callback_query(F.data == "action:price")
    async def on_price(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, load_showcase_text(), simple_back_menu(), disable_web_page_preview=True)

    @router.callback_query(F.data == "action:work")
    async def on_work(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (
            "🤖 Подключение собственного бота\n\n\n"
            f"Бонус на баланс за подключение: 20 {DISPLAY_CURRENCY} единоразово\n"
            "Собственный бот позволит Вам всегда оставаться \"в зоне покупок\", при блокировке основного бота у Вас будет возможность приобрести товар в нем, таким образом - мы никогда не потеряем с Вами связь!\n\n\n"
            "Инструкция по созданию и подключению бота:\n\n"
            "1. Перейдите в бот - https://t.me/BotFather\n\n"
            "2. Нажмите кнопку \"START\"\n\n"
            "3. Введите команду \"/newbot\"\n\n"
            "4. Придумайте и введите название бота, название подойдет любое\n\n"
            "5. Придумайте и введите юзернейм (username) бота, подойдут любые латинские буквы, главное чтобы юзернейм оканчивался на \"bot\"\n\n"
            "6. Если Вы все сделали верно, Вам придет сообщение, которое начинается на:\n\n"
            "Done! Congratulations on your new bot.\n\n\n"
            "В данном сообщении будет набор букв и цифр в формате:\n\n"
            "1111111111:AAAAAAAAAAAAAA_GchLGbMkBdSBRIEspy11\n\n\n"
            "7. Нажмите на данный текст, он скопирируется и зайдите на этот бот и пишите вот так\n"
            "Вы должны сначала написать /bot, затем вставить выданный вам токен, и для вас будет создан специальный бот.\n\n"
            "Пример команды :\n\n"
            "/bot 1111111111:AAAAAAAAAA_GchLGbMkBdSBRIEspy11\n\n"
            "бот вышлет ссылку на ваш бот - покупайте через него"
        )
        await show_text_screen(callback, text, simple_back_menu())

    async def render_review_page(
        target: Message | CallbackQuery, page: int
    ) -> None:
        if not REVIEWS:
            await show_text_screen(target, "Отзывов пока нет.", reviews_menu())
            return
        page = max(0, min(page, len(REVIEWS) - 1))
        text = _build_review_text(page)
        await show_text_screen(target, text, reviews_page_menu(page, len(REVIEWS)))

    @router.callback_query(F.data == "action:reviews")
    async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await render_review_page(callback, 0)

    @router.callback_query(F.data.startswith("reviews:page:"))
    async def on_reviews_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        try:
            page = int(callback.data.rsplit(":", 1)[1])
        except (ValueError, IndexError):
            page = 0
        await render_review_page(callback, page)

    @router.callback_query(F.data == "reviews:noop")
    async def on_reviews_noop(callback: CallbackQuery) -> None:
        await safe_answer_callback(callback)

    @router.callback_query(F.data == "reviews:my_review")
    async def on_reviews_my_review(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(
            callback,
            "Leave your review via operator.",
            show_alert=True,
        )

    @router.callback_query(F.data == "action:my_referrals")
    async def on_my_referrals(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, "Ваши рефералы: еще нету", referrals_menu())

    @router.callback_query(F.data == "nav:last_city")
    async def on_back_to_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        data = await state.get_data()
        last_city_key = data.get("last_city")
        if not last_city_key:
            last_country_key = data.get("last_country")
            if isinstance(last_country_key, str) and last_country_key:
                country = get_country(settings, last_country_key)
                await show_text_screen(callback, build_country_text(country), country_menu(country))
                return
            await show_main_screen(callback, state)
            return
        city = get_city(settings, last_city_key)
        await show_text_screen(callback, build_city_text(city), city_menu(city))

    @router.callback_query(F.data == "nav:main")
    async def on_main(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        stay_callback = await get_payment_guard_stay_callback(state)
        if stay_callback is not None:
            await mark_payment_exit_prompt(state, True)
            await edit_message_copy(
                callback.message,
                PAYMENT_EXIT_CONFIRMATION_TEXT,
                reply_markup=payment_exit_confirmation_menu(
                    stay_callback,
                    leave_callback="nav:main:confirmed",
                ),
            )
            return
        await show_main_screen(callback, state)

    @router.callback_query(F.data.startswith("nav:country:"))
    async def on_nav_country(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        country_key = callback.data.split(":", 2)[-1]
        try:
            country = get_country(settings, country_key)
        except StopIteration:
            await safe_answer_callback(callback, "Страна не найдена")
            return
        await safe_answer_callback(callback)
        await show_text_screen(callback, build_country_text(country), country_menu(country))

    @router.callback_query(F.data == "nav:main:confirmed")
    async def on_main_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await clear_payment_guard(state)
        await show_main_screen(callback, state)

    @router.message()
    async def on_fallback_message(message: Message, state: FSMContext) -> None:
        user_id = message.from_user.id if message.from_user else None
        if user_id is None:
            return
        if await is_language_selected(user_id):
            return
        await state.clear()
        await message.answer("Сначала выберите язык кнопками ниже.")

    dp.include_router(router)
    return dp


def get_country(settings: Settings, country_key: str) -> CountryConfig:
    return next(country for country in settings.countries if country.key == country_key)


def get_city(settings: Settings, city_key: str) -> CityConfig:
    return next(city for city in settings.cities if city.key == city_key)


def get_product(city: CityConfig, product_index: int) -> ProductConfig:
    return city.products[product_index]


def get_option(product: ProductConfig, option_index: int) -> ProductOption:
    return product.options[option_index]


def get_district(city: CityConfig, district_index: int, product: ProductConfig | None = None) -> str:
    districts = product.districts if product is not None and product.districts else city.districts
    return districts[district_index]


def get_payment_method(spec: BotSpec, method_index: int) -> PaymentMethodConfig:
    method = spec.payment_methods[method_index]
    if not isinstance(method, PaymentMethodConfig):
        method = PaymentMethodConfig.model_validate(method)
        spec.payment_methods[method_index] = method
    return method


def _normalize_method(m: object) -> PaymentMethodConfig:
    if isinstance(m, PaymentMethodConfig):
        return m
    return PaymentMethodConfig.model_validate(m)


def set_payment_method(spec: BotSpec, method_index: int, **updates: object) -> PaymentMethodConfig:
    current_method = get_payment_method(spec, method_index)
    payload = current_method.model_dump(mode="python")
    payload.update(updates)
    updated_method = PaymentMethodConfig.model_validate(payload)
    spec.payment_methods[method_index] = updated_method
    return updated_method


def build_payment_method_key(spec: BotSpec, label: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    if not base:
        base = "custom_payment"
    existing_keys = {method.key for method in spec.payment_methods}
    candidate = base
    suffix = 2
    while candidate in existing_keys:
        candidate = f"{base}_{suffix}"
        suffix += 1
    return candidate


def create_order_id() -> str:
    return str(uuid.uuid4())


def get_payment_method_requisites(method: PaymentMethodConfig) -> str:
    if isinstance(method, PaymentMethodConfig):
        raw = resolve_payment_requisites(method)
        if raw:
            return raw
        details = method.details_text or ""
    elif isinstance(method, dict):
        raw = method.get("requisites")
        if raw and str(raw).strip():
            return str(raw).strip()
        details = method.get("details_text") or ""
    else:
        details = str(method) if method else ""
    # extract wallet/card from details_text
    extracted = extract_payment_requisites(details)
    if extracted:
        return extracted
    # clean up placeholder text
    cleaned = details.replace("Адрес LTC кошелька:", "").replace("Адрес USDT (TRC-20):", "").replace("Адрес TRX кошелька:", "").replace("Адрес USDC (BEP-20):", "").replace("Адрес BTC кошелька:", "").replace("Вставьте реальный адрес.", "").replace("WALLET_HERE", "").strip()
    return cleaned or ""


def supports_payment_qr(method: PaymentMethodConfig) -> bool:
    currency_code = _resolve_crypto_currency_code(method)
    if currency_code not in {"BTC", "LTC", "TRX", "USDT", "USDC"}:
        return False
    return True


def parse_order_callback_values(values: list[str]) -> OrderSelection:
    if len(values) not in {4, 5}:
        raise ValueError("Invalid order callback payload.")
    return OrderSelection(
        city_key=values[0],
        product_index=int(values[1]),
        option_index=int(values[2]),
        district_index=int(values[3]),
        order_id=values[4] if len(values) == 5 else None,
    )


def order_prefix(order: OrderSelection) -> str:
    """Prefix WITHOUT order_id — keeps callback strings short for Telegram's 64-byte limit."""
    return f"order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}"


def build_order_payment_callback(order: OrderSelection, method_index: int) -> str:
    """Callback WITH order_id embedded — safe because payment: prefix is short."""
    order_id = order.order_id or create_order_id()
    return f"payment:order:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}:{order_id}:{method_index}"


def build_order_summary(settings: Settings, order: OrderSelection) -> str:
    city = get_city(settings, order.city_key)
    product = get_product(city, order.product_index)
    option = get_option(product, order.option_index)
    district = get_district(city, order.district_index)
    return (
        f"Город: {city.icon} {escape(city.label)}\n"
        f"Товар: {escape(_normalize_display_currency_text(product.label))}\n"
        f"Количество: {escape(_normalize_display_currency_text(option.label))}\n"
        f"Район: {escape(district)}"
    )


def parse_topup_amount(raw_value: str) -> int:
    normalized = (
        raw_value.strip()
        .lower()
        .replace("грн", "")
        .replace("uah", "")
        .replace("usd", "")
        .replace("gel", "")
        .replace("lari", "")
        .replace("₴", "")
        .replace("₾", "")
        .replace("$", "")
        .replace(" ", "")
    )
    if not normalized.isdigit():
        raise ValueError("Top-up amount must be numeric.")
    amount_uah = int(normalized)
    if amount_uah <= 0:
        raise ValueError("Top-up amount must be positive.")
    return amount_uah


def create_topup_selection(amount_uah: int) -> TopupSelection:
    deadline = datetime.now().astimezone() + timedelta(hours=1)
    return TopupSelection(
        order_id=random.randint(10_000_000, 99_999_999),
        topup_id=random.randint(10_000_000, 99_999_999),
        amount_uah=amount_uah,
        deadline_text=deadline.strftime("%d-%m | %H : %M : %S"),
    )


def serialize_topup_selection(topup: TopupSelection) -> dict[str, int | str]:
    return {
        "order_id": topup.order_id,
        "topup_id": topup.topup_id,
        "amount_uah": topup.amount_uah,
        "deadline_text": topup.deadline_text,
    }


async def load_topup_selection(state: FSMContext) -> TopupSelection | None:
    data = await state.get_data()
    payload = data.get("topup")
    if not isinstance(payload, dict):
        return None
    try:
        return TopupSelection(
            order_id=int(payload["order_id"]),
            topup_id=int(payload["topup_id"]),
            amount_uah=int(payload["amount_uah"]),
            deadline_text=str(payload["deadline_text"]),
        )
    except (KeyError, TypeError, ValueError):
        return None


def generate_qr_file(method: PaymentMethodConfig, qr_payload: str | None = None) -> BufferedInputFile:
    image = qrcode.make(qr_payload or resolve_payment_requisites(method) or render_payment_details_text(method))
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return BufferedInputFile(buffer.getvalue(), filename=f"{method.key}.png")


def resolve_product_photo(product: ProductConfig, settings: Settings) -> str | FSInputFile | None:
    return None

def validate_url_input(raw_value: str, allow_telegram_handle: bool = False) -> HttpUrl | None:
    value = raw_value.strip()
    if not value:
        raise ValueError("Пустое значение. Пришли ссылку или отправь - чтобы очистить.")
    if value.casefold() in {"-", "none", "null", "нет"}:
        return None
    if allow_telegram_handle and value.startswith("@"):
        value = f"https://t.me/{value[1:]}"
    elif allow_telegram_handle and USERNAME_RE.fullmatch(value):
        value = f"https://t.me/{value}"
    elif value.startswith("t.me/") or value.startswith("telegram.me/"):
        value = f"https://{value}"
    elif "://" not in value and "." in value:
        value = f"https://{value}"
    try:
        return HTTP_URL_ADAPTER.validate_python(value)
    except ValidationError as exc:
        raise ValueError("Некорректная ссылка. Пришли полный URL.") from exc


def extract_telegram_username(url: HttpUrl | None) -> str | None:
    if url is None:
        return None
    parsed = urlparse(str(url))
    if parsed.netloc not in TELEGRAM_HOSTS:
        return None
    candidate = parsed.path.strip("/").split("/", maxsplit=1)[0]
    if USERNAME_RE.fullmatch(candidate):
        return candidate
    return None


def extract_bot_tokens(raw_text: str) -> list[str]:
    tokens = TOKEN_RE.findall(raw_text)
    unique_tokens: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique_tokens.append(token)
    return unique_tokens


def mask_token(token: str) -> str:
    if len(token) <= 16:
        return token
    return f"{token[:10]}...{token[-4:]}"


def short_error(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return text[:160]


async def read_document_text(message: Message) -> str:
    if message.document is None:
        raise ValueError("Файл не найден.")
    buffer = io.BytesIO()
    await message.bot.download(message.document, destination=buffer)
    data = buffer.getvalue()
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("Не удалось прочитать файл. Используй обычный `.txt` с токенами.")


async def start_runtime(
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
) -> BotRuntime:
    bot = Bot(
        token=spec.token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    try:
        # Some bots may still have a webhook configured from previous deployments.
        # Polling will fail immediately in that case, so clear the webhook first.
        await bot.delete_webhook(drop_pending_updates=False)
        dp = create_dispatcher(
            settings,
            spec,
            persist_spec,
            register_bot,
            list_bots,
            remove_bot_by_id,
            toggle_bot_pause_by_id,
            sync_payment_methods_for_all,
            sync_start_text_for_all,
            sync_admin_ids_for_all,
            sync_template_for_all,
        )
        task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
        logger.info("Started bot @%s", spec.bot_username)
        return BotRuntime(spec=spec, dispatcher=dp, bot=bot, task=task)
    except Exception:
        await bot.session.close()
        raise


async def stop_runtime(runtime: BotRuntime) -> None:
    runtime.task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    await runtime.bot.session.close()
