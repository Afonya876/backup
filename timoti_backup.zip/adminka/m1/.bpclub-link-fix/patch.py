from pathlib import Path

config = Path('.bpclub-link-fix/config.py')
source = config.read_text()
source = source.replace(
    '"info_url", "giveaway_url", "start_photo_url", "support_url",\n',
    '"info_url", "giveaway_url", "start_photo_url", "support_url", "help_url",\n',
    1,
)
source = source.replace(
    '    help_text: str | None = None\n    support_url: HttpUrl | None = None\n',
    '    help_text: str | None = None\n    support_url: HttpUrl | None = None\n    help_url: HttpUrl | None = None\n',
    1,
)
if 'help_url: HttpUrl | None' not in source:
    raise RuntimeError('failed to add help_url to Bpclub template')
config.write_text(source)

runtime = Path('.bpclub-link-fix/bot_runtime.py')
source = runtime.read_text()
old = '''    @router.message(F.text == BTN_HELP)
    async def on_btn_help(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        text = (spec.template.help_text or settings.rules_text).strip()
        await message.answer(text, disable_web_page_preview=True)
'''
new = '''    @router.message(F.text == BTN_HELP)
    async def on_btn_help(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        await state.clear()
        text = (spec.template.help_text or settings.rules_text).strip()
        markup = None
        if spec.template.help_url:
            markup = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❓ Open help", url=str(spec.template.help_url))],
            ])
        await message.answer(
            text,
            reply_markup=markup,
            disable_web_page_preview=True,
        )
'''
if old not in source:
    raise RuntimeError('Help handler was not found')
source = source.replace(old, new, 1)
runtime.write_text(source)

central = Path('.bpclub-link-fix/central_bot.py')
source = central.read_text()
source = source.replace(
    '    "operator_url": "🔗 Ссылка оператора",\n',
    '    "operator_url": "🔗 Ссылка оператора",\n    "support_url": "🆘 Ссылка Support",\n    "help_url": "❓ Ссылка Help",\n',
    1,
)
source = source.replace(
    '    "operator_url": "link",\n',
    '    "operator_url": "link",\n    "support_url": "link",\n    "help_url": "info",\n',
    1,
)
source = source.replace(
    '        "operator_url",\n        "work_url",\n',
    '        "operator_url",\n        "support_url",\n        "help_url",\n        "work_url",\n',
    1,
)
old_condition = '''        if get_template_field_value(family_key, template, key) is not None:
            rows.append(
'''
new_condition = '''        if (
            get_template_field_value(family_key, template, key) is not None
            or (family_key == "bpclub9shop" and key in {"support_url", "help_url"})
        ):
            rows.append(
'''
if old_condition not in source:
    raise RuntimeError('central menu condition was not found')
source = source.replace(old_condition, new_condition, 1)
for text in ('"support_url": "🆘 Ссылка Support"', '"help_url": "❓ Ссылка Help"'):
    if text not in source:
        raise RuntimeError(f'missing central field label: {text}')
central.write_text(source)
