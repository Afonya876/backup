from pathlib import Path

path = Path('.central-callback-fix/bot.py')
source = path.read_text()
marker = '\ndef require_admin(func):\n'
helper = '''\n_CALLBACK_EXPIRED_MARKERS = (\n    "query is too old",\n    "response timeout expired",\n    "query id is invalid",\n)\n\n\ndef is_expired_callback_error(exc: TelegramBadRequest) -> bool:\n    message = str(exc).casefold()\n    return any(marker in message for marker in _CALLBACK_EXPIRED_MARKERS)\n\n\nasync def safe_answer_callback(\n    callback: CallbackQuery,\n    text: str | None = None,\n    *,\n    show_alert: bool = False,\n) -> bool:\n    """Acknowledge a callback; stale Telegram callbacks are harmless."""\n    try:\n        await callback.answer(text, show_alert=show_alert)\n        return True\n    except TelegramBadRequest as exc:\n        if is_expired_callback_error(exc):\n            logger.info("Ignoring expired callback query %s", callback.id)\n            return False\n        raise\n\n'''
if marker not in source:
    raise RuntimeError('require_admin marker not found')
source = source.replace(marker, helper + marker, 1)
old = '''        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected error while handling %s", func.__name__)
            message = build_exception_notice(exc, title="Ошибка общей админки")
            if isinstance(event, Message):
                await event.answer(message)
            else:
                try:
                    await event.answer(message, show_alert=True)
                except TelegramBadRequest:
                    if event.message is not None:
                        await event.message.answer(message)
'''
new = '''        except TelegramBadRequest as exc:
            if isinstance(event, CallbackQuery) and is_expired_callback_error(exc):
                logger.info("Ignoring expired callback while handling %s", func.__name__)
                return None
            logger.exception("Telegram error while handling %s", func.__name__)
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected error while handling %s", func.__name__)
            message = build_exception_notice(exc, title="Ошибка общей админки")
            if isinstance(event, Message):
                await event.answer(message)
            else:
                try:
                    await safe_answer_callback(event, message, show_alert=True)
                except TelegramBadRequest:
                    if event.message is not None:
                        await event.message.answer(message)
'''
if old not in source:
    raise RuntimeError('require_admin exception block not found')
source = source.replace(old, new, 1)
# All direct callback answers in callback handlers become safe and ignore stale IDs.
source = source.replace('await callback.answer(', 'await safe_answer_callback(callback, ')
# The preceding replacement also altered the helper itself; restore its direct API call.
source = source.replace('await safe_answer_callback(callback, text, show_alert=show_alert)', 'await callback.answer(text, show_alert=show_alert)', 1)
if source.count('await callback.answer(') != 1:
    raise RuntimeError('unexpected remaining direct callback.answer calls')
path.write_text(source)
