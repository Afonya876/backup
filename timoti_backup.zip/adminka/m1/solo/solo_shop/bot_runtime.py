from __future__ import annotations

import asyncio
import io
import logging
import random
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from html import escape
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

import aiohttp
import qrcode
from aiogram import BaseMiddleware, Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    ReplyKeyboardRemove,
)
from PIL import Image, ImageDraw, ImageFont
from pydantic import HttpUrl, TypeAdapter, ValidationError

from solo_shop.config import (
    BotSpec,
    BotSummary,
    CityConfig,
    CountryConfig,
    CreateBotRequest,
    PaymentMethodConfig,
    ProductConfig,
    ProductOption,
    Settings,
    clone_products,
    group_cities_by_country,
    normalize_template,
    slugify_key,
)
from solo_shop.payment_admin_ui import (
    build_payment_method_editor_text,
    build_payments_admin_text,
    payment_admin_menu,
    payment_method_editor_menu,
)
from solo_shop.storage import BanRegistry
from solo_shop.storage import CaptchaRegistry
from solo_shop.storage import RequisiteClickRegistry
from solo_shop.storage import DistrictRotationRegistry
from solo_shop.storage import OrderRegistry
from solo_shop.storage import ProductRotationRegistry
from solo_shop.template import (
    MEDICAL_HELP_TEXT,
    PAYMENT_EXTEND_CARD_TEXT,
    PAYMENT_EXIT_CONFIRMATION_TEXT,
    PAYMENT_HELP_TEXT,
    PIN_TEXT,
    _apply_commission_to_amount,
    _build_discounted_dollar_offer,
    _build_order_display_fields,
    _extract_payment_target,
    _is_balance_payment_method,
    _format_crypto_amount,
    _is_ruble_payment_method,
    _parse_option_amount_and_price,
    _resolve_crypto_usd_amount,
    _resolve_crypto_currency_code,
    _resolve_option_base_amount_and_currency,
    admin_cancel_menu,
    admin_menu,
    bots_menu,
    bots_upload_menu,
    build_admin_text,
    build_catalog_cities_text,
    build_catalog_city_text,
    build_catalog_district_text,
    build_catalog_products_text,
    build_bot_info_alert,
    build_bot_list_menu,
    build_bots_list_text,
    build_bots_text,
    build_bots_upload_text,
    build_country_text,
    build_city_text,
    build_district_text,
    build_my_bots_text,
    build_option_text,
    build_order_created_text,
    build_order_payment_check_text,
    build_photo_caption,
    build_order_payment_details_text,
    order_payment_warning_menu,
    order_payment_warning_text,
    build_order_payment_followup_text,
    build_order_payment_methods_text,
    build_order_payment_waiting_text,
    build_orders_text,
    build_profile_text,
    build_site_text,
    build_start_text,
    catalog_cities_menu,
    catalog_city_menu,
    catalog_district_menu,
    catalog_products_menu,
    build_topup_payment_text,
    build_topup_request_text,
    country_menu,
    city_menu,
    district_menu,
    main_menu,
    my_bots_locked_menu,
    my_bots_menu,
    orders_menu,
    option_menu,
    order_confirm_menu,
    order_payment_detail_menu,
    payment_action_menu,
    cancel_order_confirmation_menu,
    payment_exit_confirmation_menu,
    payment_waiting_back_menu,
    payment_waiting_menu,
    payment_methods_menu,
    unpaid_order_menu,
    main_only_menu,
    profile_menu,
    promo_menu,
    purchases_menu,
    referrals_menu,
    reviews_menu,
    rules_menu,
    simple_back_menu,
    format_payment_method_title,
    render_payment_details_text,
)

logger = logging.getLogger(__name__)

PersistSpec = Callable[[BotSpec], Awaitable[None]]
ListBotsAction = Callable[[], Awaitable[list[BotSummary]]]
RemoveBotAction = Callable[[int], Awaitable[bool]]
ToggleBotPauseAction = Callable[[int], Awaitable[BotSpec | None]]
SyncPaymentMethodsAction = Callable[[list[PaymentMethodConfig]], Awaitable[None]]
SyncStartTextAction = Callable[[str], Awaitable[None]]
SyncAdminIdsAction = Callable[[list[int]], Awaitable[None]]
SyncTemplateAction = Callable[[object], Awaitable[None]]
SyncProductsTextAction = Callable[[str], Awaitable[list[object]]]
GetProductsTextAction = Callable[[], Awaitable[str]]
SaveBotCatalogAction = Callable[[str, list[CityConfig]], Awaitable[list[CityConfig]]]
RememberRecipientAction = Callable[[str, int], Awaitable[list[int]]]
HTTP_URL_ADAPTER = TypeAdapter(HttpUrl)
TELEGRAM_HOSTS = {"t.me", "www.t.me", "telegram.me", "www.telegram.me"}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{5,32}$")
TOKEN_RE = re.compile(r"\b\d{5,}:[A-Za-z0-9_-]{20,}\b")
TELEGRAM_FILE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{20,}$")
SHISHKI_PHOTO_URL = "https://144-31-221-169.sslip.io/img_UUURL/photo_2026-03-12_19-04-51.jpg"
SALT_PHOTO_URL = "https://144-31-221-169.sslip.io/img_UUURL/photo_2026-03-12_19-02-55.jpg"
BLUE_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-02-27_18-31-55.jpg"
GREEN_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-04-10.jpg"
A_PVP_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-06-08.jpg"
CRYSTAL_PHOTO_URL = "https://144-31-223-230.sslip.io/photo_2026-03-22_17-18-01.jpg"
BOTS_PAGE_SIZE = 8
EXPIRED_CALLBACK_ERROR_FRAGMENTS = (
    "query is too old",
    "response timeout expired",
    "query id is invalid",
)
INVALID_FILE_ID_ERROR_FRAGMENTS = (
    "wrong file identifier",
    "wrong remote file identifier",
    "failed to get http url content",
    "wrong type of the web page content",
)
CAPTCHA_RATE_LIMIT_CLICKS = 10
CAPTCHA_RATE_LIMIT_WINDOW_SECONDS = 30
CAPTCHA_CODE_LENGTH = 5
CAPTCHA_ALLOWED_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ"
CAPTCHA_FONT_CANDIDATES = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/System/Library/Fonts/Geneva.ttf",
    "/System/Library/Fonts/SFNS.ttf",
    "/System/Library/Fonts/NewYork.ttf",
)
CRYPTO_RATE_CACHE_TTL_SECONDS = 120
UNPAID_ORDER_EXPIRY_MINUTES = 30
CRYPTO_RATE_CACHE: dict[str, tuple[datetime, Decimal]] = {}
COINGECKO_ASSET_IDS = {
    "BTC": "bitcoin",
    "LTC": "litecoin",
    "TRX": "tron",
}
FIAT_RATE_CACHE_TTL_SECONDS = 120
FIAT_RATE_CACHE: dict[str, tuple[datetime, Decimal]] = {}
MIN_VISIBLE_PRODUCTS_PERCENT = 60
CAPTCHA_PROMPT_TEXT = (
    '1. [EN]: "Enter the code from the picture"\n'
    '2. [RU]: "Введи код с картинки"\n'
    '3. [UA]: "Введіть код з картинки"\n'
    '4. [KZ]: "Суреттен кодты енгізіңіз"\n'
    '5. [PL]: "Wprowadź kod z obrazka"\n'
    '6. [MD]: "Introduceți codul de pe imagine"\n'
    '7. [TR]: "Resimdeki kodu girin"\n'
    '8. [ES]: "Introduce el código de la imagen."\n'
    '9. [KA]: "შეიყვანეთ კოდი სურათიდან"'
)

CAPTCHA_FONT: dict[str, tuple[str, ...]] = {
    "0": ("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
    "1": ("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
    "2": ("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
    "3": ("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
    "4": ("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
    "5": ("11111", "10000", "10000", "11110", "00001", "00001", "11110"),
    "6": ("01110", "10000", "10000", "11110", "10001", "10001", "01110"),
    "7": ("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
    "8": ("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
    "9": ("01110", "10001", "10001", "01111", "00001", "00001", "01110"),
    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
    "B": ("11110", "10001", "10001", "11110", "10001", "10001", "11110"),
    "C": ("01111", "10000", "10000", "10000", "10000", "10000", "01111"),
    "D": ("11110", "10001", "10001", "10001", "10001", "10001", "11110"),
    "E": ("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
    "F": ("11111", "10000", "10000", "11110", "10000", "10000", "10000"),
    "G": ("01111", "10000", "10000", "10111", "10001", "10001", "01110"),
    "H": ("10001", "10001", "10001", "11111", "10001", "10001", "10001"),
    "J": ("00001", "00001", "00001", "00001", "10001", "10001", "01110"),
    "K": ("10001", "10010", "10100", "11000", "10100", "10010", "10001"),
    "L": ("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
    "M": ("10001", "11011", "10101", "10101", "10001", "10001", "10001"),
    "N": ("10001", "11001", "10101", "10011", "10001", "10001", "10001"),
    "P": ("11110", "10001", "10001", "11110", "10000", "10000", "10000"),
    "Q": ("01110", "10001", "10001", "10001", "10101", "10010", "01101"),
    "R": ("11110", "10001", "10001", "11110", "10100", "10010", "10001"),
    "S": ("01111", "10000", "10000", "01110", "00001", "00001", "11110"),
    "T": ("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
    "U": ("10001", "10001", "10001", "10001", "10001", "10001", "01110"),
    "V": ("10001", "10001", "10001", "10001", "10001", "01010", "00100"),
    "W": ("10001", "10001", "10001", "10101", "10101", "11011", "10001"),
    "X": ("10001", "10001", "01010", "00100", "01010", "10001", "10001"),
    "Y": ("10001", "10001", "01010", "00100", "00100", "00100", "00100"),
    "Z": ("11111", "00001", "00010", "00100", "01000", "10000", "11111"),
}


def _clamp_color(value: int) -> int:
    return max(0, min(255, value))


def _shift_color(color: tuple[int, int, int], delta: int) -> tuple[int, int, int]:
    return tuple(_clamp_color(channel + random.randint(-delta, delta)) for channel in color)


def _load_captcha_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for font_path in CAPTCHA_FONT_CANDIDATES:
        if Path(font_path).exists():
            try:
                return ImageFont.truetype(font_path, size=size)
            except OSError:
                continue
    return ImageFont.load_default()


def _interpolate_color(
    start: tuple[int, int, int],
    end: tuple[int, int, int],
    ratio: float,
) -> tuple[int, int, int]:
    return tuple(
        int(round(start[index] + (end[index] - start[index]) * ratio))
        for index in range(3)
    )


def _draw_captcha_red_line(draw: ImageDraw.ImageDraw, width: int, height: int) -> None:
    points = [
        (int(width * 0.12), int(height * 0.16)),
        (int(width * 0.22), int(height * 0.24)),
        (int(width * 0.32), int(height * 0.40)),
        (int(width * 0.43), int(height * 0.54)),
        (int(width * 0.53), int(height * 0.60)),
        (int(width * 0.61), int(height * 0.50)),
        (int(width * 0.69), int(height * 0.46)),
        (int(width * 0.77), int(height * 0.41)),
        (int(width * 0.84), int(height * 0.36)),
    ]
    draw.line(points, fill=(220, 0, 0), width=4)


def _build_captcha_image(code: str) -> BufferedInputFile:
    width = 176
    height = 60
    left_color = (0, 0, 255)
    right_color = (0, 255, 0)
    image = Image.new("RGB", (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    for x in range(width):
        ratio = x / max(1, width - 1)
        draw.line(((x, 0), (x, height)), fill=_interpolate_color(left_color, right_color, ratio))

    font = _load_captcha_font(36)
    glyph_widths: list[int] = []
    glyph_heights: list[int] = []
    for char in code:
        bbox = draw.textbbox((0, 0), char, font=font)
        glyph_widths.append(bbox[2] - bbox[0])
        glyph_heights.append(bbox[3] - bbox[1])

    overlap = 6
    stretch_factor = 1.18
    stretched_widths = [max(1, int(round(width_value * stretch_factor))) for width_value in glyph_widths]
    text_width = sum(stretched_widths) - overlap * max(0, len(stretched_widths) - 1)
    text_height = max(glyph_heights, default=0)
    text_x = max(10, (width - text_width) // 2)
    text_y = max(4, (height - text_height) // 2 - 3)

    cursor_x = text_x
    for index, char in enumerate(code):
        offset_y = text_y + (1 if index % 2 else 0)
        glyph_bbox = draw.textbbox((0, 0), char, font=font)
        glyph_width = glyph_bbox[2] - glyph_bbox[0]
        glyph_height = glyph_bbox[3] - glyph_bbox[1]
        glyph_layer = Image.new("RGBA", (glyph_width + 10, glyph_height + 10), (255, 255, 255, 0))
        glyph_draw = ImageDraw.Draw(glyph_layer)
        for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1), (2, 0), (0, 2), (2, 1), (1, 2)):
            glyph_draw.text((dx, dy), char, font=font, fill=(0, 0, 0, 255))
        glyph_layer = glyph_layer.resize(
            (stretched_widths[index] + 6, glyph_layer.height),
            Image.Resampling.BICUBIC,
        )
        image.paste(glyph_layer, (cursor_x, offset_y), glyph_layer)
        cursor_x += stretched_widths[index] - overlap

    _draw_captcha_red_line(draw, width, height)

    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    png_bytes = buffer.getvalue()
    return BufferedInputFile(png_bytes, filename="captcha.png")


def _generate_captcha_code() -> str:
    return "".join(random.choice(CAPTCHA_ALLOWED_CHARS) for _ in range(CAPTCHA_CODE_LENGTH))


class RegisterResultLike(Protocol):
    spec: BotSpec
    created: bool


RegisterBotAction = Callable[[CreateBotRequest], Awaitable[RegisterResultLike]]


class PromoState(StatesGroup):
    waiting_for_code = State()


class TopupState(StatesGroup):
    waiting_for_method = State()
    waiting_for_amount = State()
    waiting_for_payment = State()


class AdminState(StatesGroup):
    waiting_for_start_text = State()
    waiting_for_contacts_text = State()
    waiting_for_operator_url = State()
    waiting_for_work_url = State()
    waiting_for_site_text = State()
    waiting_for_reviews_url = State()
    waiting_for_work_button_text = State()
    waiting_for_payment_label = State()
    waiting_for_payment_commission = State()
    waiting_for_payment_text = State()
    waiting_for_new_payment_label = State()
    waiting_for_new_payment_text = State()
    waiting_for_admin_id = State()
    waiting_for_bot_tokens = State()
    waiting_for_products_text = State()
    waiting_for_city_name = State()
    waiting_for_city_rename = State()
    waiting_for_district_name = State()
    waiting_for_district_rename = State()


@dataclass(slots=True)
class OrderSelection:
    city_key: str
    product_index: int
    option_index: int
    district_index: int
    order_id: int | None = None


@dataclass(slots=True)
class TopupSelection:
    order_id: int
    topup_id: int
    amount_uah: int
    deadline_text: str


@dataclass(slots=True)
class BotRuntime:
    spec: BotSpec
    settings: Settings
    dispatcher: Dispatcher
    bot: Bot
    task: asyncio.Task[None]
    background_tasks: list[asyncio.Task[None]]


PAYMENT_GUARD_KEY = "active_payment_guard"
EXPIRED_ORDER_SWEEP_INTERVAL_SECONDS = 30
ACTIVE_ORDER_STATUS_BUTTON_TEXT = "Я оплатил"
ACTIVE_ORDER_CANCEL_BUTTON_TEXT = "Отменить"
ACTIVE_ORDER_BLOCKED_COMMAND_TEXT = "У тебя уже есть активный заказ. Оплати его или отмени."
ACTIVE_ORDER_CANCEL_CONFIRMATION_TEXT = "Вы уверены, что хотите отменить заказ? Подтвердите отмену заказа:"
ORDER_PAYMENT_REMINDER_DELAY_MINUTES = 20
FULL_ASSORTMENT_CITY_KEYS = {
    "kyevskaia_obl_kyiv",
    "volynskaia_obl_kovel",
}
OPTION_DISTRICT_ROTATION_MIN_PERCENT = 45
OPTION_DISTRICT_ROTATION_MAX_PERCENT = 75


def parse_bot_callback_payload(callback_data: str | None) -> tuple[int, int] | None:
    if not callback_data:
        return None
    try:
        _prefix, bot_id_text, page_text = callback_data.rsplit(":", maxsplit=2)
        return int(bot_id_text), int(page_text)
    except ValueError:
        logger.warning("Invalid bot callback payload: %r", callback_data)
        return None


def active_order_cancel_confirmation_menu(confirm_callback: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=ACTIVE_ORDER_CANCEL_BUTTON_TEXT, callback_data=confirm_callback)],
        ]
    )


def create_dispatcher(
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
    sync_products_text_for_all: SyncProductsTextAction,
    get_products_text: GetProductsTextAction,
    save_bot_catalog: SaveBotCatalogAction,
    remember_recipient: RememberRecipientAction,
) -> Dispatcher:
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    router = Router()
    spec.template = normalize_template(spec.template)
    captcha_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_captcha_{spec.bot_id or 'unknown'}.json"
    )
    captcha_registry = CaptchaRegistry(captcha_storage_path)
    ban_registry = BanRegistry(settings.data_path.with_name("banned_users.json"))
    requisite_click_registry = RequisiteClickRegistry(settings.data_path.with_name("requisite_clicks.json"))
    order_storage_path = settings.data_path.with_name(
        f"{settings.data_path.stem}_orders_{spec.bot_id or 'unknown'}.json"
    )
    order_registry = OrderRegistry(order_storage_path)
    district_rotation_registry = DistrictRotationRegistry(
        settings.catalog_path.with_name("district_rotation.json")
    )
    product_rotation_registry = ProductRotationRegistry(
        settings.data_path.with_name(
            f"{settings.data_path.stem}_product_rotation_{spec.bot_id or 'unknown'}.json"
        )
    )

    def is_admin(user_id: int | None) -> bool:
        return user_id is not None and user_id in spec.admin_ids

    def has_photo_message(message: Message) -> bool:
        return bool(message.photo)

    def is_expired_callback_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in EXPIRED_CALLBACK_ERROR_FRAGMENTS)

    def is_invalid_file_id_error(exc: TelegramBadRequest) -> bool:
        message = str(exc).lower()
        return any(fragment in message for fragment in INVALID_FILE_ID_ERROR_FRAGMENTS)

    async def download_photo_from_url(url: str) -> BufferedInputFile | None:
        try:
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        logger.warning("Could not download product photo %s: HTTP %s", url, response.status)
                        return None
                    content = await response.read()
                    if not content:
                        logger.warning("Downloaded empty product photo from %s", url)
                        return None
                    parsed = urlparse(url)
                    filename = Path(parsed.path).name or "product.jpg"
                    return BufferedInputFile(content, filename=filename)
        except Exception as exc:
            logger.warning("Could not download product photo %s: %s", url, exc)
            return None

    async def fetch_crypto_usd_rate(currency_code: str) -> Decimal | None:
        normalized_code = currency_code.upper()
        if normalized_code == "USDT":
            return Decimal("1")

        asset_id = COINGECKO_ASSET_IDS.get(normalized_code)
        if asset_id is None:
            return None

        cached = CRYPTO_RATE_CACHE.get(normalized_code)
        now = datetime.now().astimezone()
        if cached is not None:
            cached_at, cached_rate = cached
            if (now - cached_at).total_seconds() < CRYPTO_RATE_CACHE_TTL_SECONDS:
                return cached_rate

        rate: Decimal | None = None
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={"ids": asset_id, "vs_currencies": "usd"},
                ) as response:
                    if response.status == 200:
                        payload = await response.json()
                        try:
                            rate = Decimal(str(payload[asset_id]["usd"]))
                        except (KeyError, TypeError, InvalidOperation) as exc:
                            logger.warning("Unexpected CoinGecko payload for %s: %s", normalized_code, exc)
                    else:
                        logger.warning(
                            "Could not fetch crypto rate for %s from CoinGecko: HTTP %s",
                            normalized_code,
                            response.status,
                        )

                if rate is None:
                    async with session.get(
                        "https://min-api.cryptocompare.com/data/price",
                        params={"fsym": normalized_code, "tsyms": "USD"},
                    ) as response:
                        if response.status == 200:
                            payload = await response.json()
                            try:
                                rate = Decimal(str(payload["USD"]))
                            except (KeyError, TypeError, InvalidOperation) as exc:
                                logger.warning("Unexpected CryptoCompare payload for %s: %s", normalized_code, exc)
                        else:
                            logger.warning(
                                "Could not fetch crypto rate for %s from CryptoCompare: HTTP %s",
                                normalized_code,
                                response.status,
                            )
        except Exception as exc:
            logger.warning("Could not fetch crypto rate for %s: %s", normalized_code, exc)
            return None

        if rate is None or rate <= 0:
            return None

        CRYPTO_RATE_CACHE[normalized_code] = (now, rate)
        return rate

    async def fetch_usd_rub_rate() -> Decimal | None:
        cached = FIAT_RATE_CACHE.get("USD_RUB")
        now = datetime.now().astimezone()
        if cached is not None:
            cached_at, cached_rate = cached
            if (now - cached_at).total_seconds() < FIAT_RATE_CACHE_TTL_SECONDS:
                return cached_rate

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get("https://open.er-api.com/v6/latest/USD") as response:
                    if response.status != 200:
                        logger.warning("Could not fetch USD/RUB rate: HTTP %s", response.status)
                        return None
                    payload = await response.json()
        except Exception as exc:
            logger.warning("Could not fetch USD/RUB rate: %s", exc)
            return None

        try:
            rate = Decimal(str(payload["rates"]["RUB"]))
        except (KeyError, TypeError, InvalidOperation) as exc:
            logger.warning("Unexpected USD/RUB payload: %s", exc)
            return None

        FIAT_RATE_CACHE["USD_RUB"] = (now, rate)
        return rate

    async def fetch_usd_fiat_rate(currency_code: str) -> Decimal | None:
        normalized_code = currency_code.upper()
        cache_key = f"USD_{normalized_code}"
        cached = FIAT_RATE_CACHE.get(cache_key)
        now = datetime.now().astimezone()
        if cached is not None:
            cached_at, cached_rate = cached
            if (now - cached_at).total_seconds() < FIAT_RATE_CACHE_TTL_SECONDS:
                return cached_rate

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get("https://open.er-api.com/v6/latest/USD") as response:
                    if response.status != 200:
                        logger.warning("Could not fetch USD/%s rate: HTTP %s", normalized_code, response.status)
                        return None
                    payload = await response.json()
        except Exception as exc:
            logger.warning("Could not fetch USD/%s rate: %s", normalized_code, exc)
            return None

        try:
            rate = Decimal(str(payload["rates"][normalized_code]))
        except (KeyError, TypeError, InvalidOperation) as exc:
            logger.warning("Unexpected USD/%s payload: %s", normalized_code, exc)
            return None

        if rate <= 0:
            return None

        FIAT_RATE_CACHE[cache_key] = (now, rate)
        return rate

    async def resolve_payment_amount_label(option: ProductOption, method: PaymentMethodConfig) -> str | None:
        if _is_balance_payment_method(method):
            amount_text, price_text = _parse_option_amount_and_price(option)
            del amount_text
            if price_text is None:
                return None
            adjusted = _apply_commission_to_amount(price_text, method)
            match = re.search(r"(\\d+(?:[.,]\\d+)?)", adjusted)
            if match is None:
                return adjusted.replace("грн.", "UAH").replace("грн", "UAH")
            base_value = Decimal(match.group(1).replace(",", "."))
            remaining = max(Decimal("0"), base_value - Decimal("50"))
            remaining_text = f"{remaining.quantize(Decimal('1'), rounding=ROUND_CEILING)} UAH"
            return remaining_text
        currency_code = _resolve_crypto_currency_code(method)
        if currency_code not in {"BTC", "LTC", "TRX", "USDT"}:
            target_label, _target_value = _extract_payment_target(render_payment_details_text(method))
            if target_label != "Карта":
                return None
            amount_text, price_text = _parse_option_amount_and_price(option)
            del amount_text
            if price_text is None:
                return None
            return _apply_commission_to_amount(price_text, method).replace("грн.", "UAH").replace("грн", "UAH")

        usd_rate = await fetch_crypto_usd_rate(currency_code)
        _base_amount, base_currency = _resolve_option_base_amount_and_currency(option)
        usd_uah_rate: Decimal | None = None
        usd_eur_rate: Decimal | None = None
        if base_currency == "UAH":
            usd_uah_rate = await fetch_usd_fiat_rate("UAH")
        elif base_currency == "EUR":
            usd_eur_rate = await fetch_usd_fiat_rate("EUR")
        return _format_crypto_amount(
            option,
            method,
            usd_rate,
            usd_uah_rate=usd_uah_rate,
            usd_eur_rate=usd_eur_rate,
        )

    async def safe_answer_callback(
        callback: CallbackQuery,
        text: str | None = None,
        *,
        show_alert: bool = False,
    ) -> bool:
        try:
            await callback.answer(text, show_alert=show_alert)
            return True
        except TelegramBadRequest as exc:
            if not is_expired_callback_error(exc):
                raise
            logger.info("Callback answer expired for %r: %s", callback.data, exc)
            return False

    async def replace_with_text_message(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        await message.answer(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete previous message %s", message.message_id)

    async def show_text_screen(
        target: Message | CallbackQuery,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
        *,
        disable_web_page_preview: bool = False,
    ) -> None:
        if isinstance(target, Message):
            await target.answer(
                text,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview,
            )
            return
        if has_photo_message(target.message):
            await replace_with_text_message(
                target.message,
                text,
                reply_markup,
                disable_web_page_preview=disable_web_page_preview,
            )
            return
        await target.message.answer(
            text,
            reply_markup=reply_markup,
            disable_web_page_preview=disable_web_page_preview,
        )

    async def edit_message_copy(
        message: Message,
        text: str,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        if has_photo_message(message):
            await message.answer(text, reply_markup=reply_markup)
            return
        await message.answer(text, reply_markup=reply_markup)

    async def safe_delete_message(message: Message | None) -> None:
        if message is None:
            return
        try:
            await message.delete()
        except Exception:
            logger.debug("Could not delete message %s", getattr(message, "message_id", "unknown"))

    async def send_product_photo_message(message: Message, product: ProductConfig) -> None:
        photo = resolve_product_photo(product, settings)
        if photo is None:
            return
        try:
            await message.answer_photo(photo)
        except Exception:
            logger.exception("Could not send product photo for %s", product.label)

    async def show_order_confirm_screen(
        callback: CallbackQuery,
        order: OrderSelection,
    ) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        caption = build_photo_caption(city, product, option, district)
        markup = order_confirm_menu(
            f"confirm:{order.city_key}:{order.product_index}:{order.option_index}:{order.district_index}",
            f"variant:{order.city_key}:{order.product_index}:{order.option_index}",
        )
        photo = resolve_product_photo(product, settings)
        if photo is not None:
            await callback.message.answer_photo(photo, caption=caption, reply_markup=markup)
            return
        await show_text_screen(callback, caption, markup)

    async def ensure_language_access(message: Message, state: FSMContext) -> bool:
        if message.chat is not None:
            await remember_recipient(spec.token, message.chat.id)
        user_id = message.from_user.id if message.from_user else None
        if user_id is None or is_admin(user_id):
            return True
        record = await captcha_registry.get_user(user_id)
        if not captcha_is_active(record):
            return True
        await state.clear()
        await send_captcha_challenge(message)
        return False

    async def ensure_language_callback_access(callback: CallbackQuery, state: FSMContext) -> bool:
        if callback.message is not None and callback.message.chat is not None:
            await remember_recipient(spec.token, callback.message.chat.id)
        user_id = callback.from_user.id if callback.from_user else None
        if user_id is None or is_admin(user_id):
            return True
        record = await captcha_registry.get_user(user_id)
        if not captcha_is_active(record):
            return True
        await safe_answer_callback(callback)
        if callback.message is not None:
            await state.clear()
            await send_captcha_challenge(callback)
        return False

    def captcha_is_active(record: dict[str, object]) -> bool:
        return bool(record.get("captcha_required")) and isinstance(record.get("captcha_code"), str)

    async def send_captcha_challenge(target: Message | CallbackQuery) -> None:
        if isinstance(target, CallbackQuery):
            message = target.message
            if message is None:
                return
            await message.answer_photo(
                _build_captcha_image(await get_or_create_captcha_code(target.from_user.id)),
                caption=CAPTCHA_PROMPT_TEXT,
            )
            return
        await target.answer_photo(
            _build_captcha_image(await get_or_create_captcha_code(target.from_user.id)),
            caption=CAPTCHA_PROMPT_TEXT,
        )

    async def get_or_create_captcha_code(user_id: int | None) -> str:
        if user_id is None:
            return _generate_captcha_code()
        record = await captcha_registry.get_user(user_id)
        code = record.get("captcha_code")
        if isinstance(code, str) and code:
            return code
        updated = await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "captcha_required": True,
                "captcha_passed": False,
                "captcha_code": _generate_captcha_code(),
                "click_timestamps": [],
            },
        )
        return str(updated.get("captcha_code") or _generate_captcha_code())

    async def mark_captcha_solved(user_id: int | None) -> None:
        if user_id is None:
            return
        await captcha_registry.update_user(
            user_id,
            lambda current: {
                **current,
                "captcha_required": False,
                "captcha_passed": True,
                "captcha_code": "",
                "click_timestamps": [],
            },
        )

    async def check_and_update_callback_rate(user_id: int | None) -> tuple[bool, bool]:
        if user_id is None:
            return False, False
        now = datetime.now().timestamp()

        def updater(current: dict[str, object]) -> dict[str, object]:
            click_timestamps = current.get("click_timestamps")
            raw_timestamps = click_timestamps if isinstance(click_timestamps, list) else []
            timestamps = [
                float(value)
                for value in raw_timestamps
                if isinstance(value, (int, float))
            ]
            timestamps = [value for value in timestamps if now - value <= CAPTCHA_RATE_LIMIT_WINDOW_SECONDS]
            if captcha_is_active(current):
                current["click_timestamps"] = timestamps
                return current
            timestamps.append(now)
            current["click_timestamps"] = timestamps
            if len(timestamps) > CAPTCHA_RATE_LIMIT_CLICKS:
                current["captcha_required"] = True
                current["captcha_code"] = _generate_captcha_code()
                current["click_timestamps"] = []
            return current

        updated = await captcha_registry.update_user(user_id, updater)
        return captcha_is_active(updated), bool(updated.get("captcha_code"))

    class BanMessageMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[Message, dict[str, Any]], Awaitable[Any]], event: Message, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is not None and not is_admin(user_id) and await ban_registry.is_banned(user_id):
                # Silently drop everything from banned users so the bot looks dead to them.
                return None
            return await handler(event, data)

    class BanCallbackMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[CallbackQuery, dict[str, Any]], Awaitable[Any]], event: CallbackQuery, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is not None and not is_admin(user_id) and await ban_registry.is_banned(user_id):
                return None
            return await handler(event, data)

    class CallbackCaptchaMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[CallbackQuery, dict[str, Any]], Awaitable[Any]], event: CallbackQuery, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is None:
                return await handler(event, data)
            record = await captcha_registry.get_user(user_id)
            if captcha_is_active(record):
                await safe_answer_callback(event, "Введи код с картинки", show_alert=True)
                return None
            captcha_triggered, _ = await check_and_update_callback_rate(user_id)
            if captcha_triggered:
                await safe_answer_callback(event, "Слишком много нажатий", show_alert=True)
                await send_captcha_challenge(event)
                return None
            return await handler(event, data)

    class MessageCaptchaMiddleware(BaseMiddleware):
        async def __call__(self, handler: Callable[[Message, dict[str, Any]], Awaitable[Any]], event: Message, data: dict[str, Any]) -> Any:
            user_id = event.from_user.id if event.from_user else None
            if user_id is None:
                return await handler(event, data)
            record = await captcha_registry.get_user(user_id)
            if not captcha_is_active(record):
                return await handler(event, data)
            expected_code = str(record.get("captcha_code") or "").strip().upper()
            provided_code = (event.text or "").strip().upper()
            if provided_code and provided_code == expected_code:
                await mark_captcha_solved(user_id)
                state = data.get("state")
                if isinstance(state, FSMContext):
                    await show_main_screen(event, state)
                else:
                    await event.answer("Капча пройдена.")
                return None
            await event.answer("Неверный код. Попробуй еще раз.")
            await send_captcha_challenge(event)
            return None

    def get_user_display_name(target: Message | CallbackQuery) -> str:
        user = target.from_user if isinstance(target, Message) else target.from_user
        if user is None:
            return "user"
        if user.username:
            return user.username
        if user.first_name:
            return user.first_name
        return "user"

    def get_actor_user_id(target: Message | CallbackQuery) -> int | None:
        user = target.from_user if isinstance(target, Message) else target.from_user
        return user.id if user is not None else None

    async def get_user_order_payload(user_id: int | None, order_id: int | None) -> dict[str, Any] | None:
        if user_id is None or order_id is None:
            return None
        orders = await order_registry.list_user_orders(user_id)
        for item in orders:
            try:
                stored_order_id = int(item.get("order_id"))
            except (TypeError, ValueError):
                continue
            if stored_order_id == order_id:
                return dict(item)
        return None

    async def remember_unpaid_order(
        user_id: int | None,
        order: OrderSelection,
        method_index: int | None = None,
    ) -> None:
        if user_id is None or order.order_id is None:
            return
        existing_order = await get_user_order_payload(user_id, order.order_id)
        created_at = str(existing_order.get("created_at") or "").strip() if existing_order is not None else ""
        if not created_at:
            created_at = datetime.now().astimezone().isoformat()
        stored_method_index = existing_order.get("method_index") if existing_order is not None else None
        if method_index is None:
            try:
                method_index = int(stored_method_index) if stored_method_index is not None else None
            except (TypeError, ValueError):
                method_index = None
        order_payload: dict[str, Any] = {
            "order_id": order.order_id,
            "status": "Не оплаченный",
            "city_key": order.city_key,
            "product_index": order.product_index,
            "option_index": order.option_index,
            "district_index": order.district_index,
            "created_at": created_at,
        }
        if existing_order is not None and isinstance(existing_order.get("reminder_sent_at"), str):
            order_payload["reminder_sent_at"] = str(existing_order["reminder_sent_at"])
        if method_index is not None:
            order_payload["method_index"] = method_index
        await order_registry.upsert_user_order(
            user_id,
            order_payload,
        )

    def parse_order_created_at(item: dict[str, Any]) -> datetime | None:
        created_at_raw = str(item.get("created_at") or "").strip()
        if not created_at_raw:
            return None
        try:
            created_at = datetime.fromisoformat(created_at_raw)
        except ValueError:
            return None
        if created_at.tzinfo is None:
            created_at = created_at.astimezone()
        return created_at

    def parse_stored_order(item: dict[str, Any]) -> tuple[OrderSelection, int | None] | None:
        try:
            order = OrderSelection(
                city_key=str(item["city_key"]),
                product_index=int(item["product_index"]),
                option_index=int(item["option_index"]),
                district_index=int(item["district_index"]),
                order_id=int(item["order_id"]),
            )
        except (KeyError, TypeError, ValueError):
            return None
        raw_method_index = item.get("method_index")
        try:
            method_index = int(raw_method_index) if raw_method_index is not None else None
        except (TypeError, ValueError):
            method_index = None
        return order, method_index

    def is_expired_unpaid_order(item: dict[str, Any]) -> bool:
        status = str(item.get("status") or "").strip().casefold()
        if status != "не оплаченный":
            return False
        created_at = parse_order_created_at(item)
        if created_at is None:
            return False
        return created_at + timedelta(minutes=UNPAID_ORDER_EXPIRY_MINUTES) <= datetime.now().astimezone()

    async def cleanup_expired_unpaid_orders(user_id: int | None) -> bool:
        if user_id is None:
            return False
        orders = await order_registry.list_user_orders(user_id)
        filtered_orders: list[dict[str, Any]] = []
        expired_removed = False
        for item in orders:
            if is_expired_unpaid_order(item):
                expired_removed = True
                continue
            filtered_orders.append(item)
        if expired_removed:
            await order_registry.save_user_orders(user_id, filtered_orders)
        return expired_removed

    async def maybe_notify_expired_orders(target: Message | CallbackQuery) -> None:
        user_id = get_actor_user_id(target)
        await cleanup_expired_unpaid_orders(user_id)

    async def sweep_expired_unpaid_orders(bot: Bot) -> None:
        while True:
            await asyncio.sleep(EXPIRED_ORDER_SWEEP_INTERVAL_SECONDS)
            try:
                orders_by_user = await order_registry.list_all_orders()
                updated_orders: dict[int, list[dict[str, Any]]] = {}
                expired_items: list[tuple[int, int]] = []
                changed = False

                for user_id, orders in orders_by_user.items():
                    filtered_orders: list[dict[str, Any]] = []
                    for item in orders:
                        parsed = parse_stored_order(item)
                        created_at = parse_order_created_at(item)
                        status = str(item.get("status") or "").strip().casefold()
                        reminder_sent = bool(str(item.get("reminder_sent_at") or "").strip())
                        if (
                            parsed is not None
                            and created_at is not None
                            and status == "не оплаченный"
                            and not reminder_sent
                            and created_at + timedelta(minutes=ORDER_PAYMENT_REMINDER_DELAY_MINUTES) <= datetime.now().astimezone()
                        ):
                            item = {
                                **dict(item),
                                "reminder_sent_at": datetime.now().astimezone().isoformat(),
                            }
                            changed = True
                        if is_expired_unpaid_order(item):
                            try:
                                order_id = int(item.get("order_id"))
                            except (TypeError, ValueError):
                                order_id = 0
                            if order_id > 0:
                                expired_items.append((user_id, order_id))
                            continue
                        filtered_orders.append(item)
                    updated_orders[user_id] = filtered_orders

                if not expired_items and not changed:
                    continue

                await order_registry.save_all_orders(updated_orders)
                del expired_items
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("Expired order sweep failed: %s", exc)

    async def get_existing_unpaid_order(
        user_id: int | None,
        exclude_order_id: int | None = None,
    ) -> tuple[OrderSelection, int | None] | None:
        if user_id is None:
            return None
        await cleanup_expired_unpaid_orders(user_id)
        orders = await order_registry.list_user_orders(user_id)
        for item in orders:
            parsed = parse_stored_order(item)
            if parsed is None:
                continue
            order, method_index = parsed
            if exclude_order_id is not None and order.order_id == exclude_order_id:
                continue
            status = str(item.get("status") or "").strip().casefold()
            if status == "не оплаченный":
                return order, method_index
        return None

    async def has_existing_unpaid_orders(user_id: int | None, exclude_order_id: int | None = None) -> bool:
        return await get_existing_unpaid_order(user_id, exclude_order_id) is not None

    async def get_active_unpaid_order_context(
        user_id: int | None,
    ) -> tuple[OrderSelection, int] | None:
        existing_order = await get_existing_unpaid_order(user_id)
        if existing_order is None:
            return None
        order, method_index = existing_order
        return order, (method_index if method_index is not None else 0)

    async def resolve_order_deadline_text(user_id: int | None, order_id: int | None) -> str:
        order_payload = await get_user_order_payload(user_id, order_id)
        created_at_raw = str(order_payload.get("created_at") or "").strip() if order_payload is not None else ""
        try:
            created_at = datetime.fromisoformat(created_at_raw) if created_at_raw else datetime.now().astimezone()
        except ValueError:
            created_at = datetime.now().astimezone()
        if created_at.tzinfo is None:
            created_at = created_at.astimezone()
        deadline = created_at + timedelta(minutes=UNPAID_ORDER_EXPIRY_MINUTES)
        return deadline.strftime("%d.%m.%Y %H:%M")

    def filter_crypto_payment_methods(methods: list[PaymentMethodConfig]) -> list[PaymentMethodConfig]:
        crypto_codes = {"BTC", "LTC", "TRX", "USDT"}
        filtered: list[PaymentMethodConfig] = []
        for method in methods:
            if _resolve_crypto_currency_code(method) in crypto_codes:
                filtered.append(method)
        return filtered

    def build_existing_unpaid_order_text(order_id: int | None) -> str:
        order_number = order_id if order_id is not None else "?"
        return (
            f"У вас уже есть заказ № {order_number}.\n"
            "Оплатите его или отмените, прежде чем создавать новый."
        )

    async def show_main_screen(target: Message | CallbackQuery, state: FSMContext) -> None:
        await maybe_notify_expired_orders(target)
        await state.clear()
        await state.update_data(last_country=None)
        await state.update_data(last_city=None)
        await state.update_data(active_order_notice_shown=False)
        text = build_start_text(
            spec.template,
            get_user_display_name(target),
            user_id=get_actor_user_id(target),
            bot_username=spec.bot_username,
        )
        markup = main_menu(settings, spec.template)
        await show_text_screen(target, text, markup, disable_web_page_preview=False)

    async def show_orders_screen(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        user_id = get_actor_user_id(target)
        await cleanup_expired_unpaid_orders(user_id)
        orders = await order_registry.list_user_orders(user_id) if user_id is not None else []
        order_buttons: list[tuple[str, str]] = []
        for item in orders:
            try:
                order = OrderSelection(
                    city_key=str(item["city_key"]),
                    product_index=int(item["product_index"]),
                    option_index=int(item["option_index"]),
                    district_index=int(item["district_index"]),
                    order_id=int(item["order_id"]),
                )
            except (KeyError, TypeError, ValueError):
                continue
            status = str(item.get("status") or "Не оплаченный")
            order_buttons.append(
                (f"{status} #{order.order_id}", f"orderopen:{order_prefix(order)}")
            )
        await show_text_screen(target, build_orders_text(bool(order_buttons)), orders_menu(order_buttons))

    def current_rotation_day() -> str:
        return datetime.now().astimezone().date().isoformat()

    def build_products_snapshot(products: list[ProductConfig]) -> list[str]:
        snapshot: list[str] = []
        for product in products:
            option_keys = ",".join(option.key for option in product.options)
            snapshot.append(f"{product.key}|{product.label}|{option_keys}")
        return snapshot

    async def select_visible_products(city: CityConfig) -> list[tuple[int, ProductConfig]]:
        products = list(enumerate(city.products))
        if not products:
            return []
        if len(products) <= 1:
            return products
        if city.key in FULL_ASSORTMENT_CITY_KEYS:
            return products

        min_visible_count = max(1, (len(products) * MIN_VISIBLE_PRODUCTS_PERCENT + 99) // 100)
        min_visible_count = min(min_visible_count, len(products))
        products_snapshot = build_products_snapshot(city.products)
        record = await product_rotation_registry.get_city(city.key)

        selected_positions = record.get("selected_positions")
        record_day = record.get("rotation_day")
        record_snapshot = record.get("products")
        has_valid_snapshot = (
            isinstance(selected_positions, list)
            and record_day == current_rotation_day()
            and record_snapshot == products_snapshot
            and all(isinstance(position, int) and 0 <= position < len(products) for position in selected_positions)
        )
        if has_valid_snapshot:
            return [products[position] for position in sorted(selected_positions)]

        max_visible_count = len(products)
        if len(products) > min_visible_count:
            max_visible_count = len(products) - 1
        visible_count = random.randint(min_visible_count, max_visible_count)
        selected_positions = sorted(random.sample(range(len(products)), k=visible_count))
        await product_rotation_registry.update_city(
            city.key,
            lambda _current: {
                "rotation_day": current_rotation_day(),
                "visible_count": visible_count,
                "products": products_snapshot,
                "selected_positions": selected_positions,
            },
        )
        return [products[position] for position in selected_positions]

    async def select_visible_districts(
        city: CityConfig,
        product: ProductConfig | None = None,
        option: ProductOption | None = None,
    ) -> list[tuple[int, str]]:
        source_districts = product.districts if product is not None and product.districts else city.districts
        districts = list(enumerate(source_districts))
        if not districts:
            return []
        if len(districts) <= 1:
            return districts

        max_visible_count = (len(districts) * city.district_selection_percent) // 100
        max_visible_count = max(1, min(max_visible_count, len(districts)))
        use_option_rotation = option is not None and len(districts) > 2
        if not use_option_rotation and (city.district_selection_percent >= 100 or max_visible_count >= len(districts)):
            return districts
        districts_snapshot = list(source_districts)
        rotation_day = current_rotation_day()
        rotation_key = city.key
        if product is not None:
            rotation_key = f"{rotation_key}:{product.key}"
        if option is not None:
            rotation_key = f"{rotation_key}:{option.key}"
        record = await district_rotation_registry.get_city(rotation_key)

        selected_positions = record.get("selected_positions")
        record_day = record.get("rotation_day")
        record_count = record.get("visible_count")
        record_snapshot = record.get("districts")
        has_valid_snapshot = (
            isinstance(selected_positions, list)
            and record_day == rotation_day
            and isinstance(record_count, int)
            and record_snapshot == districts_snapshot
            and all(isinstance(position, int) and 0 <= position < len(districts) for position in selected_positions)
        )
        if has_valid_snapshot:
            return [districts[position] for position in sorted(selected_positions)]

        if use_option_rotation:
            min_visible_count = max(2, (len(districts) * OPTION_DISTRICT_ROTATION_MIN_PERCENT + 99) // 100)
            max_visible_count = max(min_visible_count, (len(districts) * OPTION_DISTRICT_ROTATION_MAX_PERCENT) // 100)
            max_visible_count = min(max_visible_count, len(districts))
            visible_count = random.randint(min_visible_count, max_visible_count)
        else:
            visible_count = random.randint(1, max_visible_count)
        selected_positions = sorted(random.sample(range(len(districts)), k=visible_count))
        await district_rotation_registry.update_city(
            rotation_key,
            lambda _current: {
                "rotation_day": rotation_day,
                "visible_count": visible_count,
                "districts": districts_snapshot,
                "selected_positions": selected_positions,
            },
        )
        return [districts[position] for position in selected_positions]

    async def set_payment_guard(
        state: FSMContext,
        stay_callback: str,
        *,
        exit_prompt_shown: bool = False,
    ) -> None:
        data = await state.get_data()
        await state.update_data(
            **{
                **data,
                PAYMENT_GUARD_KEY: {
                    "stay_callback": stay_callback,
                    "exit_prompt_shown": exit_prompt_shown,
                },
            }
        )

    async def clear_payment_guard(state: FSMContext) -> None:
        data = await state.get_data()
        if PAYMENT_GUARD_KEY not in data:
            return
        data.pop(PAYMENT_GUARD_KEY, None)
        await state.set_data(data)

    async def get_payment_guard_stay_callback(state: FSMContext) -> str | None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return None
        stay_callback = guard.get("stay_callback")
        return stay_callback if isinstance(stay_callback, str) and stay_callback else None

    async def is_payment_exit_prompt_shown(state: FSMContext) -> bool:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        return isinstance(guard, dict) and bool(guard.get("exit_prompt_shown"))

    async def mark_payment_exit_prompt(state: FSMContext, shown: bool) -> None:
        data = await state.get_data()
        guard = data.get(PAYMENT_GUARD_KEY)
        if not isinstance(guard, dict):
            return
        guard["exit_prompt_shown"] = shown
        data[PAYMENT_GUARD_KEY] = guard
        await state.set_data(data)

    async def show_order_payment_detail_screen(
        target: Message | CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        method_index: int,
        *,
        resend: bool = False,
    ) -> None:
        actor = target.from_user
        actor_id = actor.id if actor is not None else None
        if actor_id is not None and not is_admin(actor_id):
            try:
                await requisite_click_registry.record(
                    actor_id,
                    actor.username if actor is not None else None,
                    actor.first_name if actor is not None else None,
                )
            except Exception:  # verification logging must never break the payment screen
                logger.exception("Failed to record requisite click for %s", actor_id)
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        method = get_payment_method(spec, method_index)
        current_order_id = order.order_id or create_order_id()
        order = OrderSelection(
            city_key=order.city_key,
            product_index=order.product_index,
            option_index=order.option_index,
            district_index=order.district_index,
            order_id=current_order_id,
        )
        stay_callback = build_order_payment_callback(order, method_index)
        deadline_text = await resolve_order_deadline_text(get_actor_user_id(target), current_order_id)

        await set_payment_guard(state, stay_callback)
        await remember_unpaid_order(get_actor_user_id(target), order, method_index)
        resolved_amount_label = await resolve_payment_amount_label(option, method)
        payment_text = build_order_payment_details_text(
            current_order_id,
            city,
            product,
            option,
            district,
            method,
            deadline_text,
            spec.template.operator_username,
            spec.template.payment_support_username,
            str(spec.template.operator_url) if spec.template.operator_url else None,
            resolved_amount_label,
            spec.template.exchangers_text,
        )
        payment_markup = order_payment_detail_menu(
            f"cancel:{order_prefix(order)}",
            f"paymentstatus:{order_prefix(order)}:{method_index}",
            f"qr:{order_prefix(order)}:{method_index}" if method.qr_enabled else None,
            f"paymenu:{order_prefix(order)}",
        )

        payment_target_label, payment_target_value = _extract_payment_target(render_payment_details_text(method))
        qr_file = None
        if not _is_ruble_payment_method(method) and payment_target_label == "Кошелек" and payment_target_value:
            qr_file = generate_qr_file(payment_target_value, method.key)

        if isinstance(target, Message):
            if qr_file is not None:
                await target.answer_photo(qr_file)
            await target.answer(payment_text, reply_markup=payment_markup)
            return
        if resend:
            if qr_file is not None:
                await target.message.answer_photo(qr_file)
            await target.message.answer(payment_text, reply_markup=payment_markup)
            await safe_delete_message(target.message)
            return
        if qr_file is not None:
            await target.message.answer_photo(qr_file)
        await target.message.answer(payment_text, reply_markup=payment_markup)
        await safe_delete_message(target.message)

    async def show_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_admin_text(spec)
        markup = admin_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payments_admin_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_payments_admin_text(spec)
        markup = payment_admin_menu(spec)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_payment_method_editor(
        target: Message | CallbackQuery,
        state: FSMContext,
        method_index: int,
    ) -> None:
        await state.clear()
        method = get_payment_method(spec, method_index)
        text = build_payment_method_editor_text(method)
        markup = payment_method_editor_menu(method_index, method)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def persist_catalog() -> None:
        settings.cities = await save_bot_catalog(spec.token, settings.cities)
        settings.countries = group_cities_by_country(settings.cities)

    def next_city_key(city_label: str) -> str:
        base_key = slugify_key(city_label, "city")
        key = base_key
        counter = 2
        existing_keys = {city.key for city in settings.cities}
        while key in existing_keys:
            key = f"{base_key}_{counter}"
            counter += 1
        return key

    async def show_catalog_cities(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_catalog_cities_text(settings.cities)
        markup = catalog_cities_menu(settings.cities)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_city(target: Message | CallbackQuery, state: FSMContext, city_key: str) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        text = build_catalog_city_text(city)
        markup = catalog_city_menu(city)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_catalog_district(
        target: Message | CallbackQuery,
        state: FSMContext,
        city_key: str,
        district_index: int,
    ) -> None:
        await state.clear()
        city = get_city(settings, city_key)
        district = city.districts[district_index]
        text = build_catalog_district_text(city, district, district_index)
        markup = catalog_district_menu(city_key, district_index)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_products_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        text = build_catalog_products_text(settings.products)
        markup = catalog_products_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_panel(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        bots = await list_bots()
        text = build_bots_text(len(bots))
        markup = bots_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_upload(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(AdminState.waiting_for_bot_tokens)
        text = build_bots_upload_text()
        markup = bots_upload_menu()
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def show_bots_list(target: Message | CallbackQuery, state: FSMContext, page: int = 0) -> None:
        await state.clear()
        bots = await list_bots()
        total_pages = max(1, (len(bots) + BOTS_PAGE_SIZE - 1) // BOTS_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        visible_bots = bots[page * BOTS_PAGE_SIZE : (page + 1) * BOTS_PAGE_SIZE]
        text = build_bots_list_text(visible_bots, page, BOTS_PAGE_SIZE)
        markup = build_bot_list_menu(visible_bots, page, total_pages, spec.bot_id)
        await show_text_screen(target, text, markup, disable_web_page_preview=True)

    async def process_uploaded_tokens(message: Message, raw_text: str) -> None:
        tokens = extract_bot_tokens(raw_text)
        if not tokens:
            await message.answer(
                "Не нашел ни одного Telegram-токена. Пришли токен текстом или `.txt` файл.",
                reply_markup=bots_upload_menu(),
            )
            return

        created_count = 0
        updated_count = 0
        skipped_count = 0
        lines: list[str] = []

        for token in tokens:
            if token == spec.token:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: пропущен, это текущий бот")
                continue
            payload = CreateBotRequest(
                token=token,
                template=spec.template.model_copy(deep=True),
                payment_methods=[method.model_copy(deep=True) for method in spec.payment_methods],
                admin_ids=list(spec.admin_ids),
            )
            try:
                result = await register_bot(payload)
            except Exception as exc:
                skipped_count += 1
                lines.append(f"- {mask_token(token)}: ошибка, {escape(short_error(exc))}")
                continue
            if result.created:
                created_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: создан и запущен")
            else:
                updated_count += 1
                lines.append(f"- @{escape(result.spec.bot_username or 'unknown_bot')}: обновлен и перезапущен")

        summary = [
            "<b>Загрузка завершена</b>",
            "",
            f"Создано: {created_count}",
            f"Обновлено: {updated_count}",
            f"Пропущено/ошибок: {skipped_count}",
        ]
        if lines:
            summary.extend(["", *lines[:20]])
            if len(lines) > 20:
                summary.append(f"... и еще {len(lines) - 20}")
        await message.answer("\n".join(summary), reply_markup=bots_upload_menu())

    async def show_payment_selector(
        target: Message | CallbackQuery,
        order: OrderSelection | None,
        topup: TopupSelection | None = None,
        state: FSMContext | None = None,
    ) -> None:
        if not spec.payment_methods:
            text = "Способы оплаты пока не настроены."
            if isinstance(target, Message):
                await target.answer(text, reply_markup=simple_back_menu())
            else:
                await edit_message_copy(target.message, text, simple_back_menu())
            return

        actor_user_id = get_actor_user_id(target)
        expired_removed = await cleanup_expired_unpaid_orders(actor_user_id)
        if expired_removed and isinstance(target, CallbackQuery):
            await safe_answer_callback(target, "Вы не успели оплатить заказ, он удален.", show_alert=True)
        existing_unpaid_order = await get_existing_unpaid_order(
            actor_user_id,
            exclude_order_id=order.order_id if order is not None else None,
        )
        available_payment_methods = list(spec.payment_methods)
        if existing_unpaid_order is not None and order is not None:
            existing_order, existing_method_index = existing_unpaid_order
            refresh_method_index = existing_method_index if existing_method_index is not None else 0
            if state is not None:
                if isinstance(target, CallbackQuery):
                    await safe_answer_callback(target, f"Открываю заказ № {existing_order.order_id}.")
                await state.clear()
                await show_order_payment_detail_screen(
                    target,
                    state,
                    existing_order,
                    refresh_method_index,
                    resend=isinstance(target, CallbackQuery),
                )
                return
            menu = unpaid_order_menu(
                build_order_payment_callback(existing_order, refresh_method_index),
                f"paid:{order_prefix(existing_order)}:{refresh_method_index}",
                f"cancel:{order_prefix(existing_order)}",
            )
            text = build_existing_unpaid_order_text(existing_order.order_id)
            if isinstance(target, Message):
                await target.answer(text, reply_markup=menu)
            else:
                await edit_message_copy(target.message, text, menu)
            return
        if existing_unpaid_order is not None:
            available_payment_methods = filter_crypto_payment_methods(available_payment_methods)

        if not available_payment_methods:
            text = "Способы оплаты пока не настроены."
            if isinstance(target, Message):
                await target.answer(text, reply_markup=simple_back_menu())
            else:
                await edit_message_copy(target.message, text, simple_back_menu())
            return

        if topup is not None:
            text = build_topup_request_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
            )
            markup = payment_methods_menu(
                None,
                available_payment_methods,
                cancel_callback="cancel:topup",
                amount_text=f"{topup.amount_uah} грн.",
                back_callback="nav:main",
            )
        elif order is None:
            text = settings.payment_text
            markup = payment_methods_menu(
                None,
                available_payment_methods,
                cancel_callback="cancel:generic",
                back_callback="nav:main",
            )
        else:
            if order.order_id is None:
                order = OrderSelection(
                    city_key=order.city_key,
                    product_index=order.product_index,
                    option_index=order.option_index,
                    district_index=order.district_index,
                    order_id=create_order_id(),
                )
            await remember_unpaid_order(actor_user_id, order)
            city = get_city(settings, order.city_key)
            product = get_product(city, order.product_index)
            option = get_option(product, order.option_index)
            district = get_district(city, order.district_index, product)
            _, _, price_text = _build_order_display_fields(product, option)
            method_amounts = [
                await resolve_payment_amount_label(option, method)
                for method in available_payment_methods
            ]
            text = build_order_payment_methods_text(
                order.order_id,
                city,
                product,
                option,
                district,
            )
            markup = payment_methods_menu(
                order_prefix(order),
                available_payment_methods,
                cancel_callback=f"cancel:{order_prefix(order)}",
                amount_text=price_text,
                back_callback=f"variant:{order.city_key}:{order.product_index}:{order.option_index}",
                method_amounts=method_amounts,
            )

        if isinstance(target, Message):
            if order is not None:
                photo = resolve_product_photo(product, settings)
                if photo is not None:
                    await target.answer_photo(photo, caption=text, reply_markup=markup)
                    return
            await target.answer(text, reply_markup=markup)
            return
        if order is not None:
            photo = resolve_product_photo(product, settings)
            if photo is not None:
                await target.message.answer_photo(photo, caption=text, reply_markup=markup)
                return
        await edit_message_copy(target.message, text, markup)

    async def show_topup_method_selector(target: Message | CallbackQuery, state: FSMContext) -> None:
        await state.set_state(TopupState.waiting_for_method)
        text = "Желаете пополнить баланс?\nПожалуйста, выберите тип платежной системы."
        markup = payment_methods_menu(
            None,
            spec.payment_methods,
            cancel_callback="cancel:topup",
            back_callback="nav:main",
        )
        if isinstance(target, Message):
            await target.answer(text, reply_markup=markup)
            return
        await edit_message_copy(target.message, text, markup)

    async def start_order_checkout(
        callback: CallbackQuery,
        state: FSMContext,
        order: OrderSelection,
        *,
        announce_creation: bool,
    ) -> None:
        del announce_creation
        if not spec.payment_methods:
            await state.clear()
            await edit_message_copy(callback.message, "Способы оплаты пока не настроены.")
            return
        if order.order_id is None:
            order = OrderSelection(
                city_key=order.city_key,
                product_index=order.product_index,
                option_index=order.option_index,
                district_index=order.district_index,
                order_id=create_order_id(),
            )
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await state.clear()
        await state.update_data(last_city=city.key)
        await show_payment_selector(callback, order, state=state)

    async def send_qr_if_needed(message: Message, method: PaymentMethodConfig) -> None:
        del message, method

    async def send_payment_qr(message: Message, method: PaymentMethodConfig) -> None:
        payment_target_label, payment_target_value = _extract_payment_target(render_payment_details_text(method))
        if payment_target_label != "Кошелек" or not payment_target_value:
            return
        await message.answer_photo(generate_qr_file(payment_target_value, method.key))

    async def notify_admins_about_payment(
        payer_message: Message,
        method: PaymentMethodConfig,
        summary_text: str | None,
    ) -> None:
        # Payment notifications to admins are intentionally disabled.
        return

    async def show_order_payment_waiting_screen(message: Message, order: OrderSelection, method_index: int) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await edit_message_copy(
            message,
            build_order_payment_waiting_text(
                order.order_id or create_order_id(),
                city,
                product,
                option,
                district,
            ),
            reply_markup=payment_waiting_menu(
                f"paymenthelp:{order_prefix(order)}:{method_index}",
                f"cancel:{order_prefix(order)}",
                f"paymentextend:{order_prefix(order)}:{method_index}",
                f"paymentrefresh:{order_prefix(order)}:{method_index}",
                build_order_payment_callback(order, method_index),
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index}",
            ),
        )

    async def show_payment_not_found_screen(message: Message, order: OrderSelection, method_index: int) -> None:
        await asyncio.sleep(6)
        await edit_message_copy(
            message,
            'К сожалению, платеж не найден. Если вы произвели оплату, но видите это сообщение, '
            'подождите 5 минут и проверьте оплату еще раз, нажав 👉 "проверить оплату"\n'
            'Для того, чтобы вернуться к выбору городов нажмите \n'
            '👉 "Главное меню", либо напишите любое сообщение.',
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index}",
                main_callback="nav:main",
                cancel_callback=f"cancel:{order_prefix(order)}",
            ),
        )

    async def send_active_order_payment_status(message: Message, order: OrderSelection, method_index: int) -> None:
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        method = get_payment_method(spec, method_index)
        deadline_text = await resolve_order_deadline_text(get_actor_user_id(message), order.order_id)
        resolved_amount_label = await resolve_payment_amount_label(option, method)
        await message.answer(
            build_order_payment_check_text(
                order.order_id or create_order_id(),
                option,
                method,
                deadline_text,
                spec.template.operator_username,
                resolved_amount_label,
            )
        )

    async def send_active_order_cancel_confirmation(message: Message, order: OrderSelection) -> None:
        await message.answer(
            ACTIVE_ORDER_CANCEL_CONFIRMATION_TEXT,
            reply_markup=active_order_cancel_confirmation_menu(f"cancelconfirm:{order_prefix(order)}"),
        )

    @router.message(CommandStart())
    async def on_start(message: Message, state: FSMContext) -> None:
        user_id = message.from_user.id if message.from_user else None
        if user_id is not None and not is_admin(user_id):
            record = await captcha_registry.get_user(user_id)
            if not bool(record.get("captcha_passed")):
                await get_or_create_captcha_code(user_id)
        if not await ensure_language_access(message, state):
            return
        await maybe_notify_expired_orders(message)
        if user_id is not None and not is_admin(user_id):
            active_order = await get_active_unpaid_order_context(user_id)
            if active_order is not None:
                notice_shown = bool((await state.get_data()).get("active_order_notice_shown"))
                if not notice_shown:
                    await state.update_data(active_order_notice_shown=True)
                    await message.answer(ACTIVE_ORDER_BLOCKED_COMMAND_TEXT)
                    return
                await show_main_screen(message, state)
                return
        stay_callback = await get_payment_guard_stay_callback(state)
        if stay_callback is not None:
            if await is_payment_exit_prompt_shown(state):
                await clear_payment_guard(state)
                await show_main_screen(message, state)
                return
            await mark_payment_exit_prompt(state, True)
            await message.answer(
                PAYMENT_EXIT_CONFIRMATION_TEXT,
                reply_markup=payment_exit_confirmation_menu(
                    stay_callback,
                    leave_callback="nav:main:confirmed",
                ),
            )
            return
        await show_main_screen(message, state)

    @router.message(Command("bot"))
    async def on_personal_bot_command(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        tokens = extract_bot_tokens(message.text or "")
        if not tokens:
            await message.answer(
                "Пришли команду так:\n/bot 1111111111:AAAAAAAAAA_GchLGbMkBdSBRIEspy11",
                reply_markup=simple_back_menu(),
            )
            return

        token = tokens[0]
        if token == spec.token:
            await message.answer("Нельзя подключить текущий бот как персональный.", reply_markup=simple_back_menu())
            return

        payload = CreateBotRequest(
            token=token,
            template=spec.template.model_copy(deep=True),
            payment_methods=[method.model_copy(deep=True) for method in spec.payment_methods],
            admin_ids=[],
        )
        try:
            result = await register_bot(payload)
        except Exception as exc:
            await message.answer(
                f"Не получилось подключить бота: {escape(short_error(exc))}",
                reply_markup=simple_back_menu(),
            )
            return

        bot_username = (result.spec.bot_username or "").strip()
        if bot_username:
            response_text = (
                f"Твой бот подключен.\n"
                f"Ссылка: https://t.me/{escape(bot_username)}"
            )
        else:
            response_text = "Твой бот подключен."
        await message.answer(response_text, reply_markup=simple_back_menu())

    @router.message(Command("admin"))
    async def on_admin(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_admin_panel(message, state)

    @router.message(Command("catalog"))
    async def on_catalog(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        await show_catalog_cities(message, state)

    @router.callback_query(F.data == "admin:panel")
    async def on_admin_panel(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:close")
    async def on_admin_close(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await callback.message.edit_text("Админка закрыта.")

    @router.callback_query(F.data == "admin:payments")
    async def on_admin_payments(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_payments_admin_panel(callback, state)

    @router.callback_query(F.data == "admin:catalog")
    async def on_admin_catalog(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_catalog_cities(callback, state)

    @router.callback_query(F.data == "admin:products")
    async def on_admin_products(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_products_panel(callback, state)

    @router.callback_query(F.data == "admin:products_upload")
    async def on_admin_products_upload(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_products_text)
        current_text = await get_products_text()
        await callback.message.edit_text(
            "Пришли общий список товаров текстом или `.txt` файлом.\n\n"
            "Каждая строка должна быть в формате:\n"
            "<code>РОЗОВЫЙ СНЕГ 0,5гр 49 $</code>\n\n"
            f"Текущий список:\n<pre>{escape(current_text)}</pre>",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:catalog_add_city")
    async def on_admin_catalog_add_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_city_name)
        await callback.message.edit_text(
            "Пришли название нового города одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_city:"))
    async def on_admin_catalog_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        await safe_answer_callback(callback)
        await show_catalog_city(callback, state, city_key)

    @router.callback_query(F.data.startswith("admin:catalog_city_rename:"))
    async def on_admin_catalog_city_rename(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_city_rename)
        await state.update_data(catalog_city_key=city_key)
        await callback.message.edit_text(
            f"Текущее название города: <b>{escape(city.label)}</b>\n\nПришли новое название.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_city_delete:"))
    async def on_admin_catalog_city_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        await safe_answer_callback(callback)
        settings.cities = [city for city in settings.cities if city.key != city_key]
        await persist_catalog()
        await show_catalog_cities(callback, state)

    @router.callback_query(F.data.startswith("admin:catalog_district:"))
    async def on_admin_catalog_district(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, district_index_text = callback.data.split(":")
        await safe_answer_callback(callback)
        await show_catalog_district(callback, state, city_key, int(district_index_text))

    @router.callback_query(F.data.startswith("admin:catalog_add_district:"))
    async def on_admin_catalog_add_district(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        city_key = callback.data.rsplit(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_district_name)
        await state.update_data(catalog_city_key=city_key)
        await callback.message.edit_text(
            f"Город: <b>{escape(city.label)}</b>\n\nПришли название нового района.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_district_rename:"))
    async def on_admin_catalog_district_rename(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, district_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        district_index = int(district_index_text)
        district = city.districts[district_index]
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_district_rename)
        await state.update_data(catalog_city_key=city_key, catalog_district_index=district_index)
        await callback.message.edit_text(
            f"Текущий район: <b>{escape(district)}</b>\n\nПришли новое название района.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:catalog_district_delete:"))
    async def on_admin_catalog_district_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        _, _, _, city_key, district_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        district_index = int(district_index_text)
        if 0 <= district_index < len(city.districts):
            city.districts.pop(district_index)
        await safe_answer_callback(callback)
        await persist_catalog()
        await show_catalog_city(callback, state, city_key)

    @router.callback_query(F.data.startswith("admin:payment_method:"))
    async def on_admin_payment_method(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_payment_method_editor(callback, state, method_index)

    @router.callback_query(F.data == "admin:payment_add")
    async def on_admin_payment_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_new_payment_label)
        await callback.message.edit_text(
            "Пришли название нового способа оплаты одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_label:"))
    async def on_admin_payment_label(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_label)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущее название: <b>{escape(method.label)}</b>\n\nПришли новое название одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_edit:"))
    async def on_admin_payment_edit(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_text)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущий текст метода <b>{escape(method.label)}</b>:\n\n<pre>{escape(method.details_text)}</pre>\n\nПришли новый текст одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_commission:"))
    async def on_admin_payment_commission(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        current_commission = (method.commission_text or "").strip() or "не указана"
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_payment_commission)
        await state.update_data(payment_method_index=method_index)
        await callback.message.edit_text(
            f"Текущая комиссия метода <b>{escape(format_payment_method_title(method))}</b>: "
            f"<b>{escape(current_commission)}</b>\n\n"
            "Пришли новую комиссию одним сообщением. Например: <code>-5%</code>\n"
            "Чтобы убрать комиссию, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data.startswith("admin:payment_qr:"))
    async def on_admin_payment_qr(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        method.qr_enabled = not method.qr_enabled
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(callback, state, method_index)
        await safe_answer_callback(callback, "QR обновлен.")

    @router.callback_query(F.data.startswith("admin:payment_delete:"))
    async def on_admin_payment_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        if method_index < 0 or method_index >= len(spec.payment_methods):
            await safe_answer_callback(callback, "Способ оплаты не найден.", show_alert=True)
            return
        removed_method = spec.payment_methods.pop(method_index)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payments_admin_panel(callback, state)
        await safe_answer_callback(callback, f"Удален способ: {removed_method.label}")

    @router.callback_query(F.data == "admin:bots")
    async def on_bots(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_panel(callback, state)

    @router.callback_query(F.data == "admin:bots_upload")
    async def on_bots_upload(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await show_bots_upload(callback, state)

    @router.callback_query(F.data.startswith("admin:bots_page:"))
    async def on_bots_page(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        page = int(callback.data.rsplit(":", maxsplit=1)[1])
        await safe_answer_callback(callback)
        await show_bots_list(callback, state, page)

    @router.callback_query(F.data.startswith("admin:bot_toggle_pause:"))
    async def on_bot_toggle_pause(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, _page = payload
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await safe_answer_callback(
            callback,
            build_bot_info_alert(bot_summary, bot_id == spec.bot_id),
            show_alert=True,
        )

    @router.callback_query(F.data.startswith("admin:bot_pause_switch:"))
    async def on_bot_pause_switch(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if bot_id == spec.bot_id:
            await safe_answer_callback(callback, "Текущего бота нельзя приостановить из его собственной админки.", show_alert=True)
            return
        updated_spec = await toggle_bot_pause_by_id(bot_id)
        if updated_spec is None:
            await safe_answer_callback(callback, "Бот не найден.", show_alert=True)
            return
        await show_bots_list(callback, state, page)
        if updated_spec.is_paused:
            await safe_answer_callback(callback, "🟠 Бот приостановлен.")
            return
        await safe_answer_callback(callback, "Бот снова запущен.")

    @router.callback_query(F.data.startswith("admin:bot_delete:"))
    async def on_bot_delete(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        payload = parse_bot_callback_payload(callback.data)
        if payload is None:
            await safe_answer_callback(callback, "Некорректные данные кнопки.", show_alert=True)
            return
        bot_id, page = payload
        if spec.bot_id == bot_id:
            await safe_answer_callback(callback, "Нельзя удалить текущего бота из его собственной админки.", show_alert=True)
            return
        bots = await list_bots()
        bot_summary = next((item for item in bots if item.bot_id == bot_id), None)
        if bot_summary is None:
            await safe_answer_callback(callback, "Бот уже удален или не найден.", show_alert=True)
            return
        await safe_answer_callback(callback, "Удаляю бота и останавливаю токен...")
        removed = await remove_bot_by_id(bot_id)
        if not removed:
            await show_bots_list(callback, state, page)
            if callback.message is not None:
                await callback.message.answer("Бот уже удален или не найден.")
            return
        await show_bots_list(callback, state, page)
        if callback.message is not None:
            await callback.message.answer(
                "Бот удален и остановлен.\n"
                f"Токен удаленного бота:\n<code>{escape(bot_summary.token)}</code>"
            )

    @router.callback_query(F.data == "admin:set_start_text")
    async def on_set_start_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_start_text)
        await callback.message.edit_text(
            "Текущий стартовый текст:\n\n"
            f"<pre>{escape(spec.template.start_text)}</pre>\n\n"
            "Пришли новый стартовый текст одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.\n\n"
            "Переменные:\n"
            "<code>{user_name}</code>, <code>{first_name}</code>, <code>{user_id}</code>, <code>{balance}</code>\n"
            "<code>{shop_name}</code>, <code>{bot_username}</code>, <code>{bot_mention}</code>\n"
            "<code>{operator_username}</code>, <code>{operator_url}</code>, <code>{work_url}</code>\n"
            "<code>{site_text}</code>\n"
            "<code>{reviews_url}</code>, <code>{vip_price_url}</code>, <code>{work_button_text}</code>, <code>{contacts_text}</code>",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_contacts_text")
    async def on_set_contacts_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_contacts_text)
        await callback.message.edit_text(
            "Текущий текст контактов:\n\n"
            f"<pre>{escape(spec.template.contacts_text)}</pre>\n\n"
            "Пришли новый текст контактов одним сообщением.\n"
            "Текст сохранится как есть, с переносами строк и эмодзи.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_operator_url")
    async def on_set_operator_url(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_operator_url)
        current_value = str(spec.template.operator_url) if spec.template.operator_url else "не задана"
        await callback.message.edit_text(
            "Текущая ссылка оператора:\n\n"
            f"<pre>{escape(current_value)}</pre>\n\n"
            "Пришли новую ссылку одним сообщением.\n"
            "Чтобы убрать ссылку, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_work_url")
    async def on_set_work_url(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_work_url)
        current_value = str(spec.template.work_url) if spec.template.work_url else "не задана"
        await callback.message.edit_text(
            "Текущая ссылка кнопки дохода:\n\n"
            f"<pre>{escape(current_value)}</pre>\n\n"
            "Пришли новую ссылку одним сообщением.\n"
            "Чтобы убрать ссылку, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_site_text")
    async def on_set_site_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_site_text)
        current_value = (spec.template.site_text or "").strip() or "не задан"
        await callback.message.edit_text(
            "Текущий текст кнопки «Сайт»:\n\n"
            f"<pre>{escape(current_value)}</pre>\n\n"
            "Пришли новый текст одним сообщением.\n"
            "Чтобы очистить текст, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_reviews_url")
    async def on_set_reviews_url(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_reviews_url)
        current_value = str(spec.template.reviews_url) if spec.template.reviews_url else "не задана"
        await callback.message.edit_text(
            "Текущая ссылка отзывов:\n\n"
            f"<pre>{escape(current_value)}</pre>\n\n"
            "Пришли новую ссылку одним сообщением.\n"
            "Чтобы убрать ссылку, пришли <code>-</code>.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:set_work_button_text")
    async def on_set_work_button_text(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_work_button_text)
        current_value = (spec.template.work_button_text or "").strip() or "10 000$ в месяц 🤑"
        await callback.message.edit_text(
            "Текущий текст кнопки дохода:\n\n"
            f"<pre>{escape(current_value)}</pre>\n\n"
            "Пришли новый текст одним сообщением.",
            reply_markup=admin_cancel_menu(),
        )

    @router.callback_query(F.data == "admin:add_admin")
    async def on_add_admin(callback: CallbackQuery, state: FSMContext) -> None:
        if not is_admin(callback.from_user.id if callback.from_user else None):
            return
        await safe_answer_callback(callback)
        await state.set_state(AdminState.waiting_for_admin_id)
        await callback.message.edit_text(
            "Пришли Telegram ID нового админа одним числом.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_products_text, F.document)
    async def on_products_document(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            raw_text = await read_document_text(message)
            await sync_products_text_for_all(raw_text)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        await show_products_panel(message, state)

    @router.message(AdminState.waiting_for_products_text)
    async def on_products_text(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        raw_text = (message.text or "").strip()
        if not raw_text:
            await message.answer("Список товаров не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        try:
            await sync_products_text_for_all(raw_text)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=admin_cancel_menu())
            return
        await show_products_panel(message, state)

    @router.message(AdminState.waiting_for_city_name)
    async def on_city_name(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        city_name = (message.text or "").strip()
        if not city_name:
            await message.answer("Название города не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        template_city = settings.cities[0] if settings.cities else None
        new_city = CityConfig(
            key=next_city_key(city_name),
            label=city_name,
            icon=template_city.icon if template_city is not None else "📍",
            country_key=template_city.country_key if template_city is not None else "default-country",
            country_label=template_city.country_label if template_city is not None else "Страна",
            districts=[],
            district_selection_percent=100,
            products=clone_products(settings.products),
        )
        settings.cities.append(new_city)
        await persist_catalog()
        await show_catalog_city(message, state, new_city.key)

    @router.message(AdminState.waiting_for_city_rename)
    async def on_city_rename(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_name = (message.text or "").strip()
        if not new_name:
            await message.answer("Название города не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        city = get_city(settings, city_key)
        city.label = new_name
        await persist_catalog()
        await show_catalog_city(message, state, city_key)

    @router.message(AdminState.waiting_for_district_name)
    async def on_district_name(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        district_name = (message.text or "").strip()
        if not district_name:
            await message.answer("Название района не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        city = get_city(settings, city_key)
        city.districts.append(district_name)
        await persist_catalog()
        await show_catalog_city(message, state, city_key)

    @router.message(AdminState.waiting_for_district_rename)
    async def on_district_rename(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        district_name = (message.text or "").strip()
        if not district_name:
            await message.answer("Название района не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        city_key = str(data["catalog_city_key"])
        district_index = int(data["catalog_district_index"])
        city = get_city(settings, city_key)
        if district_index < 0 or district_index >= len(city.districts):
            await show_catalog_city(message, state, city_key)
            return
        city.districts[district_index] = district_name
        await persist_catalog()
        await show_catalog_district(message, state, city_key, district_index)

    @router.message(AdminState.waiting_for_start_text)
    async def on_start_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Стартовый текст не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.start_text = new_text
        await sync_start_text_for_all(new_text)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_contacts_text)
    async def on_contacts_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст контактов не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.contacts_text = new_text
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_operator_url)
    async def on_operator_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_value = (message.text or "").strip()
        spec.template.operator_url = None if new_value in {"-", "—", "–"} else new_value
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_work_url)
    async def on_work_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_value = (message.text or "").strip()
        spec.template.work_url = None if new_value in {"-", "—", "–"} else new_value
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_site_text)
    async def on_site_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_value = (message.text or "").strip()
        spec.template.site_text = "" if new_value in {"-", "—", "–"} else new_value
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_reviews_url)
    async def on_reviews_url_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_value = (message.text or "").strip()
        spec.template.reviews_url = None if new_value in {"-", "—", "–"} else new_value
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_work_button_text)
    async def on_work_button_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_value = (message.text or "").strip()
        if not new_value:
            await message.answer("Текст кнопки не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        spec.template.work_button_text = new_value
        await sync_template_for_all(spec.template)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_payment_label)
    async def on_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        method = get_payment_method(spec, method_index)
        new_label = (message.text or "").strip()
        if not new_label:
            await message.answer("Название способа оплаты не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        method.label = new_label
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_text)
    async def on_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        method = get_payment_method(spec, method_index)
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст способа оплаты не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        method.details_text = new_text
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_payment_commission)
    async def on_payment_commission_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        data = await state.get_data()
        method_index = int(data["payment_method_index"])
        method = get_payment_method(spec, method_index)
        raw_value = (message.text or "").strip()
        method.commission_text = None if raw_value.casefold() in {"-", "—", "–", "нет", "none", "null"} else raw_value
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, method_index)

    @router.message(AdminState.waiting_for_new_payment_label)
    async def on_new_payment_label_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_label = (message.text or "").strip()
        if not new_label:
            await message.answer("Название способа оплаты не должно быть пустым.", reply_markup=admin_cancel_menu())
            return
        await state.set_state(AdminState.waiting_for_new_payment_text)
        await state.update_data(new_payment_label=new_label)
        await message.answer(
            f"Название сохранено: <b>{escape(new_label)}</b>\n\nТеперь пришли текст этого способа оплаты.",
            reply_markup=admin_cancel_menu(),
        )

    @router.message(AdminState.waiting_for_new_payment_text)
    async def on_new_payment_text_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        new_text = (message.text or "").strip()
        if not new_text:
            await message.answer("Текст способа оплаты не должен быть пустым.", reply_markup=admin_cancel_menu())
            return
        data = await state.get_data()
        new_label = (data.get("new_payment_label") or "").strip()
        if not new_label:
            await state.clear()
            await show_payments_admin_panel(message, state)
            return
        new_method = PaymentMethodConfig(
            key=build_payment_method_key(spec, new_label),
            label=new_label,
            commission_text=None,
            details_text=new_text,
            qr_enabled=False,
        )
        spec.payment_methods.append(new_method)
        await sync_payment_methods_for_all(spec.payment_methods)
        await show_payment_method_editor(message, state, len(spec.payment_methods) - 1)

    @router.message(AdminState.waiting_for_admin_id)
    async def on_admin_id_value(message: Message, state: FSMContext) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        value = (message.text or "").strip()
        if not value.isdigit():
            await message.answer("Нужен числовой Telegram ID.", reply_markup=admin_cancel_menu())
            return
        admin_id = int(value)
        if admin_id not in spec.admin_ids:
            spec.admin_ids.append(admin_id)
            spec.admin_ids.sort()
            await sync_admin_ids_for_all(spec.admin_ids)
        await show_admin_panel(message, state)

    @router.message(AdminState.waiting_for_bot_tokens, F.document)
    async def on_bot_tokens_document(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        try:
            raw_text = await read_document_text(message)
        except ValueError as exc:
            await message.answer(str(exc), reply_markup=bots_upload_menu())
            return
        await process_uploaded_tokens(message, raw_text)

    @router.message(AdminState.waiting_for_bot_tokens)
    async def on_bot_tokens_text(message: Message) -> None:
        if not is_admin(message.from_user.id if message.from_user else None):
            return
        raw_text = message.text or message.caption or ""
        await process_uploaded_tokens(message, raw_text)

    @router.callback_query(F.data.startswith("country:"))
    async def on_country(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        country_key = callback.data.split(":", maxsplit=1)[1]
        country = get_country(settings, country_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=country.key, last_city=None)
        await show_text_screen(callback, build_country_text(country), country_menu(country))

    @router.callback_query(F.data.startswith("city:"))
    async def on_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        if len(parts) == 3:
            _, country_key, city_key = parts
        elif len(parts) == 2:
            _, city_key = parts
            city = get_city(settings, city_key)
            country_key = city.country_key or ""
        else:
            await safe_answer_callback(callback, "Некорректный город")
            return
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=country_key, last_city=city.key)
        visible_products = await select_visible_products(city)
        await show_text_screen(callback, build_city_text(city), city_menu(city, visible_products))

    @router.callback_query(F.data.startswith("item:"))
    async def on_item(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        product = get_product(city, product_index)
        await safe_answer_callback(callback)
        await state.update_data(last_city=city.key, last_product=product_index)
        await show_text_screen(
            callback,
            build_option_text(city, product),
            reply_markup=option_menu(city, product_index, product),
        )

    @router.callback_query(F.data.startswith("variant:"))
    async def on_variant(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text = callback.data.split(":")
        city = get_city(settings, city_key)
        product_index = int(product_index_text)
        option_index = int(option_index_text)
        product = get_product(city, product_index)
        option = get_option(product, option_index)
        visible_districts = await select_visible_districts(city, product, option)
        await safe_answer_callback(callback)
        await state.update_data(
            last_city=city.key,
            last_product=product_index,
            last_option=option_index,
        )
        if not visible_districts:
            order = OrderSelection(
                city_key=city.key,
                product_index=product_index,
                option_index=option_index,
                district_index=0,
                order_id=create_order_id(),
            )
            await state.clear()
            await state.update_data(
                last_city=city.key,
                last_product=product_index,
                last_option=option_index,
            )
            await start_order_checkout(callback, state, order, announce_creation=False)
            return
        await edit_message_copy(
            callback.message,
            build_district_text(city, product, option),
            reply_markup=district_menu(
                city,
                product_index,
                option_index,
                visible_districts,
                back_callback=f"city:{city.key}",
            ),
        )

    @router.callback_query(F.data.startswith("district:"))
    async def on_district(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        district = get_district(city, order.district_index, product)
        await safe_answer_callback(callback)
        logger.debug("Selected district %s for %s", district, order)
        await state.clear()
        await state.update_data(
            last_city=city.key,
            last_product=order.product_index,
            last_option=order.option_index,
            last_district=order.district_index,
        )
        await show_order_confirm_screen(callback, order)

    @router.callback_query(F.data.startswith("confirm:"))
    async def on_confirm_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        _, city_key, product_index_text, option_index_text, district_index_text = callback.data.split(":")
        order = OrderSelection(
            city_key=city_key,
            product_index=int(product_index_text),
            option_index=int(option_index_text),
            district_index=int(district_index_text),
            order_id=create_order_id(),
        )
        await safe_answer_callback(callback)
        await start_order_checkout(callback, state, order, announce_creation=False)

    @router.callback_query(F.data == "action:promo")
    async def on_promo(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await show_text_screen(callback, "✅ Введите код купона следующим сообщением:", promo_menu())

    @router.callback_query(F.data == "action:orders")
    async def on_orders(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await show_orders_screen(callback, state)

    @router.callback_query(F.data.startswith("orderopen:order:"))
    async def on_order_open(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await safe_answer_callback(callback)
        await state.clear()
        user_id = get_actor_user_id(callback)
        order_payload = await get_user_order_payload(user_id, order.order_id)
        if order_payload is not None:
            parsed = parse_stored_order(order_payload)
            status = str(order_payload.get("status") or "").strip().casefold()
            if parsed is not None and status == "не оплаченный" and parsed[1] is not None:
                await show_order_payment_detail_screen(callback, state, parsed[0], parsed[1], resend=True)
                return
        await show_payment_selector(callback, order, state=state)

    @router.callback_query(F.data == "action:discounts")
    async def on_discounts(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (
            "Твоя персональная скидка - 0.00%, оборот - 0.00\n\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%\n"
            "Достижение оборота 0.00 - получи постоянную скидку 0.00%"
        )
        await show_text_screen(callback, text, main_only_menu())

    @router.callback_query(F.data.startswith("city_shortcut:"))
    async def on_city_shortcut(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        city_key = callback.data.split(":", maxsplit=1)[1]
        city = get_city(settings, city_key)
        await safe_answer_callback(callback)
        await state.clear()
        await state.update_data(last_country=city.country_key, last_city=city.key)
        visible_products = await select_visible_products(city)
        await show_text_screen(callback, build_city_text(city), city_menu(city, visible_products))

    @router.callback_query(F.data == "action:profile")
    async def on_profile(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, build_profile_text(), profile_menu(spec.template))

    @router.callback_query(F.data == "action:site")
    async def on_site(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, build_site_text(spec.template), simple_back_menu())

    @router.callback_query(F.data == "action:secret_phrase")
    async def on_secret_phrase(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.set_state(PromoState.waiting_for_code)
        await show_text_screen(callback, "Введите секретную фразу", promo_menu())

    @router.message(PromoState.waiting_for_code)
    async def on_promo_code(message: Message, state: FSMContext) -> None:
        code = (message.text or "").strip()
        del code
        await state.clear()
        await message.answer(
            "Купон не найден",
            reply_markup=promo_menu(),
        )

    @router.callback_query(F.data == "action:purchases")
    async def on_purchases(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, "Ваши покупки:", purchases_menu())

    @router.callback_query(F.data == "action:rules")
    async def on_rules(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, settings.rules_text, rules_menu())

    @router.callback_query(F.data == "action:topup")
    async def on_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_topup_method_selector(callback, state)

    @router.message(TopupState.waiting_for_amount)
    async def on_topup_amount(message: Message, state: FSMContext) -> None:
        try:
            amount_uah = parse_topup_amount(message.text or "")
        except ValueError:
            await message.answer("Введите сумму числом в гривнах.", reply_markup=simple_back_menu())
            return
        topup = create_topup_selection(amount_uah)
        data = await state.get_data()
        selected_method_index = data.get("selected_topup_method_index")
        if not isinstance(selected_method_index, int):
            await state.clear()
            await show_topup_method_selector(message, state)
            return
        await state.set_state(TopupState.waiting_for_payment)
        await state.update_data(
            topup=serialize_topup_selection(topup),
            selected_topup_method_index=selected_method_index,
        )
        method = get_payment_method(spec, selected_method_index)
        await message.answer(
            build_topup_payment_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
                method,
            ),
            reply_markup=payment_action_menu(
                f"paid:generic:{selected_method_index}",
                "paymenu:generic",
                "cancel:topup",
                f"qr:generic:{selected_method_index}" if method.qr_enabled else None,
            ),
        )

    @router.callback_query(F.data == "paymenu:generic")
    async def on_paymenu_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        if topup is None:
            await show_topup_method_selector(callback, state)
            return
        await state.set_state(TopupState.waiting_for_payment)
        await show_payment_selector(callback, None, topup, state=state)

    @router.callback_query(F.data.startswith("paymenu:order:"))
    async def on_paymenu_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await safe_answer_callback(callback)
        await state.clear()
        await show_payment_selector(callback, order, state=state)

    @router.callback_query(F.data.startswith("payment:generic:"))
    async def on_payment_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        topup = await load_topup_selection(state)
        current_state = await state.get_state()
        if topup is None and current_state == TopupState.waiting_for_method.state:
            await state.set_state(TopupState.waiting_for_amount)
            await state.update_data(selected_topup_method_index=method_index)
            await show_text_screen(callback, "Введите сумму", simple_back_menu())
            return
        if topup is None:
            await state.clear()
            text = f"<b>{escape(format_payment_method_title(method))}</b>\n\n{escape(render_payment_details_text(method))}"
        else:
            await state.set_state(TopupState.waiting_for_payment)
            text = build_topup_payment_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
                method,
            )
        await show_text_screen(
            callback,
            text,
            payment_action_menu(
                f"paid:generic:{method_index}",
                "paymenu:generic",
                "cancel:generic" if topup is None else "cancel:topup",
                f"qr:generic:{method_index}" if method.qr_enabled else None,
            ),
        )

    @router.callback_query(F.data.startswith("payment:order:"))
    async def on_payment_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await order_registry.upsert_user_order(
            get_actor_user_id(callback),
            {
                "order_id": order.order_id,
                "status": "Не оплаченный",
                "city_key": order.city_key,
                "product_index": order.product_index,
                "option_index": order.option_index,
                "district_index": order.district_index,
                "method_index": int(method_index_text),
                "created_at": datetime.now().astimezone().isoformat(),
            },
        )
        await state.clear()
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text), resend=False)

    @router.callback_query(F.data.startswith("paymentconfirm:order:"))
    async def on_payment_order_confirm(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await order_registry.upsert_user_order(
            get_actor_user_id(callback),
            {
                "order_id": order.order_id,
                "status": "Не оплаченный",
                "city_key": order.city_key,
                "product_index": order.product_index,
                "option_index": order.option_index,
                "district_index": order.district_index,
                "method_index": int(method_index_text),
                "created_at": datetime.now().astimezone().isoformat(),
            },
        )
        await state.clear()
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text), resend=True)

    @router.callback_query(F.data.startswith("paymentdetail:order:"))
    async def on_payment_detail_open(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await state.clear()
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text), resend=True)

    @router.callback_query(F.data.startswith("paymentstatus:order:"))
    async def on_payment_detail_refresh(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        city = get_city(settings, order.city_key)
        product = get_product(city, order.product_index)
        option = get_option(product, order.option_index)
        method = get_payment_method(spec, int(method_index_text))
        price_text = await resolve_payment_amount_label(option, method)
        if not price_text:
            _amount_text, base_price_text, discounted_price_text = _build_discounted_dollar_offer(option)
            price_source = discounted_price_text or base_price_text
            price_matches = re.findall(r"(\d+(?:[.,]\d+)?)", price_source)
            price_text = price_matches[-1] if price_matches else "0"
        deadline_text = await resolve_order_deadline_text(get_actor_user_id(callback), order.order_id)
        alert_text = (
            "Заказ проверен\n"
            "Оплачено: 0\n"
            f"Цена: {price_text}\n"
            "Ждёт подтверждения: 0\n"
            f"Конец заказа: {deadline_text}\n\n"
            "/cancel - отмена\n\n"
            "/current - показать заказ"
        )
        await safe_answer_callback(callback, alert_text, show_alert=True)

    @router.callback_query(F.data.startswith("qr:generic:"))
    async def on_qr_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("qr:order:"))
    async def on_qr_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        await safe_answer_callback(callback)
        await send_payment_qr(callback.message, method)

    @router.callback_query(F.data.startswith("paid:generic:"))
    async def on_paid_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        method_index = int(callback.data.rsplit(":", maxsplit=1)[1])
        method = get_payment_method(spec, method_index)
        topup = await load_topup_selection(state)
        await safe_answer_callback(callback)
        summary_text = None
        if topup is not None:
            summary_text = build_topup_request_text(
                topup.order_id,
                topup.topup_id,
                topup.amount_uah,
                topup.deadline_text,
            )
            await state.clear()
            await edit_message_copy(
                callback.message,
                PIN_TEXT,
                reply_markup=simple_back_menu(),
            )
        await notify_admins_about_payment(callback.message, method, summary_text)

    @router.callback_query(F.data.startswith("paid:order:"))
    async def on_paid_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        method = get_payment_method(spec, int(method_index_text))
        await safe_answer_callback(callback)
        await set_payment_guard(state, build_order_payment_callback(order, int(method_index_text)))
        await show_payment_not_found_screen(callback.message, order, int(method_index_text))
        await notify_admins_about_payment(callback.message, method, build_order_summary(settings, order))

    @router.callback_query(F.data == "cancel:generic")
    async def on_cancel_generic(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await edit_message_copy(callback.message, "Оплата отменена.")

    @router.callback_query(F.data == "cancel:topup")
    async def on_cancel_topup(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await edit_message_copy(callback.message, "Пополнение отменено.")

    @router.callback_query(F.data.startswith("cancel:order:"))
    async def on_cancel_order(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        order = parse_order_callback_values(callback.data.split(":")[2:])
        await edit_message_copy(
            callback.message,
            "Действительно желаешь отменить ?",
            cancel_order_confirmation_menu(
                f"cancelconfirm:{order_prefix(order)}",
                f"paymenu:{order_prefix(order)}",
            ),
        )

    @router.callback_query(F.data.startswith("cancelconfirm:order:"))
    async def on_cancel_order_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        user_id = get_actor_user_id(callback)
        order_to_remove = parse_order_callback_values(callback.data.split(":")[2:])
        if user_id is not None:
            orders = await order_registry.list_user_orders(user_id)
            filtered_orders: list[dict[str, Any]] = []
            for item in orders:
                parsed = parse_stored_order(item)
                if parsed is None or parsed[0].order_id != order_to_remove.order_id:
                    filtered_orders.append(item)
            await order_registry.save_user_orders(user_id, filtered_orders)
        await state.clear()
        await callback.message.answer("Заказ отменен.", reply_markup=ReplyKeyboardRemove())
        await show_main_screen(callback, state)

    @router.callback_query(F.data.startswith("paymentexit:detail:"))
    async def on_payment_exit_detail(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                build_order_payment_callback(order, int(method_index_text)),
            ),
        )

    @router.callback_query(F.data.startswith("paymentexit:waiting:"))
    async def on_payment_exit_waiting(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await edit_message_copy(
            callback.message,
            PAYMENT_EXIT_CONFIRMATION_TEXT,
            reply_markup=payment_exit_confirmation_menu(
                build_order_payment_callback(order, int(method_index_text)),
            ),
        )

    @router.callback_query(F.data.startswith("paymenthelp:order:"))
    async def on_payment_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await set_payment_guard(state, build_order_payment_callback(order, int(method_index_text)))
        await edit_message_copy(
            callback.message,
            PAYMENT_HELP_TEXT,
            reply_markup=payment_waiting_back_menu(
                f"paymentrefresh:{order_prefix(order)}:{method_index_text}",
                main_callback=f"paymentexit:waiting:{order_prefix(order)}:{method_index_text}",
            ),
        )

    @router.callback_query(F.data.startswith("paymentextend:order:"))
    async def on_payment_extend(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback, "Время для обработки заказа продлено.")
        await set_payment_guard(state, build_order_payment_callback(order, int(method_index_text)))
        await show_order_payment_detail_screen(callback, state, order, int(method_index_text), resend=True)

    @router.callback_query(F.data.startswith("paymentrefresh:order:"))
    async def on_payment_refresh(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        parts = callback.data.split(":")
        method_index_text = parts[-1]
        order = parse_order_callback_values(parts[2:-1])
        await safe_answer_callback(callback)
        await set_payment_guard(state, build_order_payment_callback(order, int(method_index_text)))
        await show_payment_not_found_screen(callback.message, order, int(method_index_text))

    @router.callback_query(F.data == "action:instructions")
    async def on_instructions(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, settings.instructions_text, simple_back_menu())

    @router.callback_query(F.data.in_({"action:medical_help", "action:overdose"}))
    async def on_medical_help(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, MEDICAL_HELP_TEXT, simple_back_menu())

    @router.callback_query(F.data == "action:operator")
    async def on_operator(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = (spec.template.contacts_text or "").strip()
        if spec.template.operator_url:
            text = f"Оператор\n{spec.template.operator_url}"
        elif not text:
            text = f"Оператор: @{escape(spec.template.operator_username)}"
        await show_text_screen(callback, text, simple_back_menu())

    @router.callback_query(F.data == "action:price")
    async def on_price(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        text = str(spec.template.vip_price_url) if spec.template.vip_price_url else "Временно нету"
        await show_text_screen(callback, text, simple_back_menu())

    @router.callback_query(F.data == "action:work")
    async def on_work(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, build_my_bots_text(), my_bots_menu())

    @router.callback_query(F.data == "action:work_add")
    async def on_work_add(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(
            callback,
            "Добавление бота доступно после первой покупки",
            my_bots_locked_menu(),
        )

    @router.callback_query(F.data == "action:reviews")
    async def on_reviews(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        user_id = get_actor_user_id(callback)
        bot_username = (spec.bot_username or "").strip()
        referral_url = (
            f"https://t.me/{bot_username}?start={user_id}"
            if bot_username and user_id is not None
            else "Реферальная ссылка временно недоступна."
        )
        text = (
            "🎉 Хотите получать вознаграждение за покупки людей,\n"
            "которых Вы пригласили, а также за их приглашенных и так\n"
            "далее до 10 уровней глубины! 🤑\n\n"
            "Приглашайте своих знакомых в этот бот, используя Вашу\n"
            "уникальную реферальную ссылку, и получайте бонусы за их\n"
            f"активность до 10 уровней вниз. {referral_url} 📲\n\n"
            "Засчитываться будут только новые рефералы. 🆕\n\n"
            "Твой доход за всё время: 0.00 💰\n\n"
            "Вознаграждения:\n\n"
            "1 уровень - 3.00% от суммы оплаты\n"
            "2 уровень - 0.50% от суммы оплаты\n"
            "3 уровень - 0.10% от суммы оплаты\n"
            "4 уровень - 0.00% от суммы оплаты\n"
            "5 уровень - 0.00% от суммы оплаты\n"
            "6 уровень - 0.00% от суммы оплаты\n"
            "7 уровень - 0.00% от суммы оплаты\n"
            "8 уровень - 0.00% от суммы оплаты\n"
            "9 уровень - 0.00% от суммы оплаты\n"
            "10 уровень - 0.00% от суммы оплаты 🚀"
        )
        await show_text_screen(callback, text, reviews_menu())

    @router.callback_query(F.data == "action:my_referrals")
    async def on_my_referrals(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await state.clear()
        await show_text_screen(callback, "У вас нет рефералов.", referrals_menu())

    @router.callback_query(F.data == "nav:last_city")
    async def on_back_to_city(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        data = await state.get_data()
        last_city_key = data.get("last_city")
        if not last_city_key:
            last_country_key = data.get("last_country")
            if isinstance(last_country_key, str) and last_country_key:
                country = get_country(settings, last_country_key)
                await show_text_screen(callback, build_country_text(country), country_menu(country))
                return
            await show_main_screen(callback, state)
            return
        city = get_city(settings, last_city_key)
        visible_products = await select_visible_products(city)
        await show_text_screen(callback, build_city_text(city), city_menu(city, visible_products))

    @router.callback_query(F.data == "nav:main")
    async def on_main(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        stay_callback = await get_payment_guard_stay_callback(state)
        if stay_callback is not None:
            await mark_payment_exit_prompt(state, True)
            await edit_message_copy(
                callback.message,
                PAYMENT_EXIT_CONFIRMATION_TEXT,
                reply_markup=payment_exit_confirmation_menu(
                    stay_callback,
                    leave_callback="nav:main:confirmed",
                ),
            )
            return
        await show_main_screen(callback, state)

    @router.callback_query(F.data == "nav:main:confirmed")
    async def on_main_confirmed(callback: CallbackQuery, state: FSMContext) -> None:
        if not await ensure_language_callback_access(callback, state):
            return
        await safe_answer_callback(callback)
        await clear_payment_guard(state)
        await show_main_screen(callback, state)

    @router.message(F.text == ACTIVE_ORDER_STATUS_BUTTON_TEXT)
    async def on_active_order_status_button(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        user_id = get_actor_user_id(message)
        if user_id is None or is_admin(user_id):
            await show_main_screen(message, state)
            return
        await maybe_notify_expired_orders(message)
        active_order = await get_active_unpaid_order_context(user_id)
        if active_order is None:
            await show_main_screen(message, state)
            return
        order, method_index = active_order
        await set_payment_guard(state, build_order_payment_callback(order, method_index))
        await send_active_order_payment_status(message, order, method_index)

    @router.message(F.text == ACTIVE_ORDER_CANCEL_BUTTON_TEXT)
    async def on_active_order_cancel_button(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        user_id = get_actor_user_id(message)
        if user_id is None or is_admin(user_id):
            await show_main_screen(message, state)
            return
        await maybe_notify_expired_orders(message)
        active_order = await get_active_unpaid_order_context(user_id)
        if active_order is None:
            await show_main_screen(message, state)
            return
        order, method_index = active_order
        await set_payment_guard(state, build_order_payment_callback(order, method_index))
        await send_active_order_cancel_confirmation(message, order)

    @router.message()
    async def on_fallback_message(message: Message, state: FSMContext) -> None:
        if not await ensure_language_access(message, state):
            return
        user_id = get_actor_user_id(message)
        if user_id is not None and not is_admin(user_id):
            await maybe_notify_expired_orders(message)
            active_order = await get_active_unpaid_order_context(user_id)
            if active_order is not None:
                order, method_index = active_order
                await set_payment_guard(state, build_order_payment_callback(order, method_index))
                notice_shown = bool((await state.get_data()).get("active_order_notice_shown"))
                if not notice_shown:
                    await state.update_data(active_order_notice_shown=True)
                    await message.answer(ACTIVE_ORDER_BLOCKED_COMMAND_TEXT)
                    return
        await show_main_screen(message, state)

    router.message.middleware(BanMessageMiddleware())
    router.callback_query.middleware(BanCallbackMiddleware())
    router.message.middleware(MessageCaptchaMiddleware())
    router.callback_query.middleware(CallbackCaptchaMiddleware())
    dp.include_router(router)
    setattr(dp, "_background_task_factories", [sweep_expired_unpaid_orders])
    dispatcher = dp
    return dispatcher


def get_country(settings: Settings, country_key: str) -> CountryConfig:
    return next(country for country in settings.countries if country.key == country_key)


def get_city(settings: Settings, city_key: str) -> CityConfig:
    return next(city for city in settings.cities if city.key == city_key)


def get_product(city: CityConfig, product_index: int) -> ProductConfig:
    return city.products[product_index]


def get_option(product: ProductConfig, option_index: int) -> ProductOption:
    return product.options[option_index]


def get_district(city: CityConfig, district_index: int, product: ProductConfig | None = None) -> str:
    districts = product.districts if product is not None and product.districts else city.districts
    if not districts:
        return city.label
    return districts[district_index]


def get_payment_method(spec: BotSpec, method_index: int) -> PaymentMethodConfig:
    return spec.payment_methods[method_index]


def build_payment_method_key(spec: BotSpec, label: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    if not base:
        base = "custom_payment"
    existing_keys = {method.key for method in spec.payment_methods}
    candidate = base
    suffix = 2
    while candidate in existing_keys:
        candidate = f"{base}_{suffix}"
        suffix += 1
    return candidate


def create_order_id() -> int:
    return random.randint(700_000, 999_999)


def parse_order_callback_values(values: list[str]) -> OrderSelection:
    if len(values) not in {4, 5}:
        raise ValueError("Invalid order callback payload.")
    return OrderSelection(
        city_key=values[0],
        product_index=int(values[1]),
        option_index=int(values[2]),
        district_index=int(values[3]),
        order_id=int(values[4]) if len(values) == 5 else None,
    )


def order_prefix(order: OrderSelection) -> str:
    parts = [
        order.city_key,
        str(order.product_index),
        str(order.option_index),
        str(order.district_index),
    ]
    if order.order_id is not None:
        parts.append(str(order.order_id))
    return f"order:{':'.join(parts)}"


def build_order_payment_callback(order: OrderSelection, method_index: int) -> str:
    return f"paymentdetail:{order_prefix(order)}:{method_index}"


def build_order_summary(settings: Settings, order: OrderSelection) -> str:
    city = get_city(settings, order.city_key)
    product = get_product(city, order.product_index)
    option = get_option(product, order.option_index)
    district = get_district(city, order.district_index)
    return (
        f"Город: {city.icon} {escape(city.label)}\n"
        f"Товар: {escape(product.label)}\n"
        f"Количество: {escape(option.label)}\n"
        f"Район: {escape(district)}"
    )


def parse_topup_amount(raw_value: str) -> int:
    normalized = (
        raw_value.strip()
        .lower()
        .replace("грн", "")
        .replace("uah", "")
        .replace("₴", "")
        .replace(" ", "")
    )
    if not normalized.isdigit():
        raise ValueError("Top-up amount must be numeric.")
    amount_uah = int(normalized)
    if amount_uah <= 0:
        raise ValueError("Top-up amount must be positive.")
    return amount_uah


def create_topup_selection(amount_uah: int) -> TopupSelection:
    deadline = datetime.now().astimezone() + timedelta(hours=1)
    return TopupSelection(
        order_id=random.randint(10_000_000, 99_999_999),
        topup_id=random.randint(10_000_000, 99_999_999),
        amount_uah=amount_uah,
        deadline_text=deadline.strftime("%d-%m | %H : %M : %S"),
    )


def serialize_topup_selection(topup: TopupSelection) -> dict[str, int | str]:
    return {
        "order_id": topup.order_id,
        "topup_id": topup.topup_id,
        "amount_uah": topup.amount_uah,
        "deadline_text": topup.deadline_text,
    }


async def load_topup_selection(state: FSMContext) -> TopupSelection | None:
    data = await state.get_data()
    payload = data.get("topup")
    if not isinstance(payload, dict):
        return None
    try:
        return TopupSelection(
            order_id=int(payload["order_id"]),
            topup_id=int(payload["topup_id"]),
            amount_uah=int(payload["amount_uah"]),
            deadline_text=str(payload["deadline_text"]),
        )
    except (KeyError, TypeError, ValueError):
        return None


def generate_qr_file(payload: str, filename_prefix: str = "payment") -> BufferedInputFile:
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=18,
        border=4,
    )
    qr.add_data(payload)
    qr.make(fit=True)
    image = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return BufferedInputFile(buffer.getvalue(), filename=f"{filename_prefix}.png")


def resolve_product_photo(product: ProductConfig, settings: Settings) -> str | FSInputFile | None:
    photo_id = (product.photo_id or "").strip()
    if photo_id:
        return photo_id

    photo_url = (product.photo_url or "").strip()
    if photo_url:
        return photo_url

    photo_path = (product.photo_path or "").strip()
    if not photo_path:
        return None
    if TELEGRAM_FILE_ID_RE.fullmatch(photo_path) and "/" not in photo_path and "\\" not in photo_path:
        return photo_path

    path = Path(photo_path)
    if not path.is_absolute():
        path = Path(settings.catalog_path).resolve().parent / path
    if not path.exists():
        return None
    return FSInputFile(path)


def validate_url_input(raw_value: str, allow_telegram_handle: bool = False) -> HttpUrl | None:
    value = raw_value.strip()
    if not value:
        raise ValueError("Пустое значение. Пришли ссылку или отправь - чтобы очистить.")
    if value.casefold() in {"-", "none", "null", "нет"}:
        return None
    if allow_telegram_handle and value.startswith("@"):
        value = f"https://t.me/{value[1:]}"
    elif allow_telegram_handle and USERNAME_RE.fullmatch(value):
        value = f"https://t.me/{value}"
    elif value.startswith("t.me/") or value.startswith("telegram.me/"):
        value = f"https://{value}"
    elif "://" not in value and "." in value:
        value = f"https://{value}"
    try:
        return HTTP_URL_ADAPTER.validate_python(value)
    except ValidationError as exc:
        raise ValueError("Некорректная ссылка. Пришли полный URL.") from exc


def extract_telegram_username(url: HttpUrl | None) -> str | None:
    if url is None:
        return None
    parsed = urlparse(str(url))
    if parsed.netloc not in TELEGRAM_HOSTS:
        return None
    candidate = parsed.path.strip("/").split("/", maxsplit=1)[0]
    if USERNAME_RE.fullmatch(candidate):
        return candidate
    return None


def extract_bot_tokens(raw_text: str) -> list[str]:
    tokens = TOKEN_RE.findall(raw_text)
    unique_tokens: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique_tokens.append(token)
    return unique_tokens


def mask_token(token: str) -> str:
    if len(token) <= 16:
        return token
    return f"{token[:10]}...{token[-4:]}"


def short_error(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return text[:160]


async def read_document_text(message: Message) -> str:
    if message.document is None:
        raise ValueError("Файл не найден.")
    buffer = io.BytesIO()
    await message.bot.download(message.document, destination=buffer)
    data = buffer.getvalue()
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("Не удалось прочитать файл. Используй обычный `.txt` с токенами.")


async def start_runtime(
    settings: Settings,
    spec: BotSpec,
    persist_spec: PersistSpec,
    register_bot: RegisterBotAction,
    list_bots: ListBotsAction,
    remove_bot_by_id: RemoveBotAction,
    toggle_bot_pause_by_id: ToggleBotPauseAction,
    sync_payment_methods_for_all: SyncPaymentMethodsAction,
    sync_start_text_for_all: SyncStartTextAction,
    sync_admin_ids_for_all: SyncAdminIdsAction,
    sync_template_for_all: SyncTemplateAction,
    sync_products_text_for_all: SyncProductsTextAction,
    get_products_text: GetProductsTextAction,
    save_bot_catalog: SaveBotCatalogAction,
    remember_recipient: RememberRecipientAction,
) -> BotRuntime:
    bot = Bot(
        token=spec.token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    try:
        # Some bots may still have a webhook configured from previous deployments.
        # Polling will fail immediately in that case, so clear the webhook first.
        await bot.delete_webhook(drop_pending_updates=False)
        dp = create_dispatcher(
            settings,
            spec,
            persist_spec,
            register_bot,
            list_bots,
            remove_bot_by_id,
            toggle_bot_pause_by_id,
            sync_payment_methods_for_all,
            sync_start_text_for_all,
            sync_admin_ids_for_all,
            sync_template_for_all,
            sync_products_text_for_all,
            get_products_text,
            save_bot_catalog,
            remember_recipient,
        )
        task = asyncio.create_task(dp.start_polling(bot, handle_signals=False))
        background_task_factories = getattr(dp, "_background_task_factories", [])
        background_tasks = [asyncio.create_task(factory(bot)) for factory in background_task_factories]
        logger.info("Started bot @%s", spec.bot_username)
        return BotRuntime(spec=spec, settings=settings, dispatcher=dp, bot=bot, task=task, background_tasks=background_tasks)
    except Exception:
        await bot.session.close()
        raise


async def stop_runtime(runtime: BotRuntime) -> None:
    for background_task in runtime.background_tasks:
        background_task.cancel()
    for background_task in runtime.background_tasks:
        try:
            await background_task
        except asyncio.CancelledError:
            pass
    try:
        await runtime.dispatcher.stop_polling()
    except RuntimeError:
        pass
    except Exception:
        logger.exception("Failed to stop polling for @%s", runtime.spec.bot_username)
    runtime.task.cancel()
    try:
        await runtime.task
    except asyncio.CancelledError:
        pass
    await runtime.bot.session.close()
