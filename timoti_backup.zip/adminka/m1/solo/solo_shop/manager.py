from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramConflictError, TelegramForbiddenError

from solo_shop.bot_runtime import BotRuntime, start_runtime, stop_runtime
from solo_shop.config import (
    BotSpec,
    BotSummary,
    CityConfig,
    CreateBotRequest,
    PaymentMethodConfig,
    Settings,
    SharedConfig,
    TemplateOverrides,
    apply_shared_products_to_cities,
    clone_cities,
    clone_products,
    cities_payload,
    flatten_countries,
    group_cities_by_country,
    normalize_template,
    parse_products_text,
    products_to_text,
    save_catalog_cities,
)
from solo_shop.storage import BanRegistry, BotCatalogRegistry, BotRegistry, RecipientRegistry, RequisiteClickRegistry, SharedConfigRegistry

logger = logging.getLogger(__name__)
DISABLED_PAYMENT_METHOD_KEYS: set[str] = set()
START_RETRY_DELAY_SECONDS = 5
START_RETRY_MAX_DELAY_SECONDS = 300
TELEGRAM_CONFLICT_MAX_RECHECKS = 3
TELEGRAM_CONFLICT_RECHECK_DELAY_SECONDS = 5
BROADCAST_CHAT_CONCURRENCY = 75
BROADCAST_BOT_CONCURRENCY = 12
_BOT_ID_LOG_PATTERN = re.compile(r"\bbot id = (\d+)\b")
_PLAUSIBLE_CARD_REQUISITES_PATTERN = re.compile(r"^\d(?:[\s-]?\d){11,18}$")
_PLAUSIBLE_GENERIC_REQUISITES_PATTERN = re.compile(r"^[A-Za-z0-9:_-]{12,}$")
_LEGACY_REQUISITES_PLACEHOLDERS = {
    "CARD_NUMBER_HERE",
    "USDT_TRC20_WALLET_HERE",
    "LTC_WALLET_HERE",
    "BTC_WALLET_HERE",
}


@dataclass(slots=True)
class RegisterResult:
    spec: BotSpec
    created: bool


class TelegramConflictLogHandler(logging.Handler):
    def __init__(self, manager: "BotManager") -> None:
        super().__init__(level=logging.WARNING)
        self.manager = manager
        self._last_conflict_at = 0.0

    def emit(self, record: logging.LogRecord) -> None:
        message = record.getMessage()
        now = time.monotonic()
        if "TelegramConflictError" in message or "terminated by other getUpdates request" in message:
            self._last_conflict_at = now
        match = _BOT_ID_LOG_PATTERN.search(message)
        if match is None or now - self._last_conflict_at > 2:
            return
        self.manager._handle_dispatcher_conflict_log(int(match.group(1)))


class BotManager:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.registry = BotRegistry(settings.data_path)
        self.shared_registry = SharedConfigRegistry(settings.shared_settings_path)
        self.bot_catalog_registry = BotCatalogRegistry(settings.bot_catalogs_path)
        self.recipient_registry = RecipientRegistry(settings.data_path.with_name(f"{settings.data_path.stem}_recipients.json"))
        self.ban_registry = BanRegistry(settings.data_path.with_name("banned_users.json"))
        self.requisite_click_registry = RequisiteClickRegistry(settings.data_path.with_name("requisite_clicks.json"))
        self._runtimes: dict[str, BotRuntime] = {}
        self._retry_tasks: dict[str, asyncio.Task[None]] = {}
        self._conflict_recheck_counts: dict[str, int] = {}
        self._conflict_log_handler: TelegramConflictLogHandler | None = None
        self._event_loop: asyncio.AbstractEventLoop | None = None

    async def start_registered_bots(self) -> None:
        self._ensure_conflict_log_handler()
        specs = await self.registry.load()
        specs = await self._dedupe_specs(specs)
        shared = await self._get_shared_config(specs)
        await self.shared_registry.save(shared)
        specs = await self._ensure_synced_payment_methods(specs, shared.payment_methods)
        logger.info("Restoring %s bot(s) from %s", len(specs), self.settings.data_path)
        for stored_spec in specs:
            try:
                runtime_spec = await self._hydrate_spec(stored_spec, shared)
                await self.registry.upsert(runtime_spec)
                await self._ensure_bot_catalog_exists(runtime_spec.token)
                if runtime_spec.is_paused:
                    logger.info("Skipping paused bot @%s", runtime_spec.bot_username)
                    continue
                self._schedule_start(runtime_spec)
            except Exception:
                logger.exception("Failed to start stored bot %s", stored_spec.bot_username or stored_spec.token[:10])

    async def shutdown(self) -> None:
        self._remove_conflict_log_handler()
        for task in self._retry_tasks.values():
            task.cancel()
        for task in list(self._retry_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._retry_tasks.clear()
        for runtime in list(self._runtimes.values()):
            await stop_runtime(runtime)
        self._runtimes.clear()

    async def list_bots(self) -> list[BotSummary]:
        shared = await self._get_shared_config()
        specs = await self.registry.load()
        items: list[BotSummary] = []
        for spec in specs:
            if spec.bot_id is None:
                continue
            items.append(
                BotSummary(
                    bot_id=spec.bot_id,
                    bot_username=spec.bot_username,
                    bot_name=spec.bot_name,
                    token=spec.token,
                    created_at=spec.created_at,
                    is_running=spec.token in self._runtimes and not spec.is_paused,
                    is_paused=spec.is_paused,
                    admin_ids=list(shared.admin_ids),
                    template=shared.template.model_copy(deep=True),
                )
            )
        return items

    async def register_bot(self, payload: CreateBotRequest) -> RegisterResult:
        existing = await self._find_by_token(payload.token)
        me = await self._fetch_me(payload.token)
        now = datetime.now(timezone.utc).isoformat()

        spec = BotSpec(
            token=payload.token,
            is_paused=existing.is_paused if existing else False,
            bot_id=me.id,
            bot_username=me.username,
            bot_name=me.full_name,
            created_at=existing.created_at if existing else now,
        )

        created = existing is None
        runtime_spec = await self._hydrate_spec(spec)
        await self.registry.upsert(runtime_spec)
        await self._ensure_bot_catalog_exists(runtime_spec.token)
        await self._restart(runtime_spec)
        return RegisterResult(spec=runtime_spec, created=created)

    async def remove_bot(self, token: str) -> bool:
        existed = await self._exists(token)
        self._cancel_retry_task(token)
        self._conflict_recheck_counts.pop(token, None)
        runtime = self._runtimes.pop(token, None)
        if runtime:
            await stop_runtime(runtime)
        await self.registry.delete(token)
        await self.bot_catalog_registry.delete_bot(token)
        return existed

    async def remove_bot_by_id(self, bot_id: int) -> bool:
        spec = await self._find_by_bot_id(bot_id)
        if spec is None:
            return False
        return await self.remove_bot(spec.token)

    async def toggle_bot_pause_by_id(self, bot_id: int) -> BotSpec | None:
        specs = await self.registry.load()
        stored_spec = next((item for item in specs if item.bot_id == bot_id), None)
        if stored_spec is None:
            return None

        if stored_spec.is_paused:
            stored_spec.is_paused = False
            self._conflict_recheck_counts.pop(stored_spec.token, None)
            await self.registry.upsert(stored_spec)
            runtime_spec = await self._hydrate_spec(stored_spec)
            self._schedule_start(runtime_spec)
            return runtime_spec

        stored_spec.is_paused = True
        await self.registry.upsert(stored_spec)
        self._cancel_retry_task(stored_spec.token)
        runtime = self._runtimes.pop(stored_spec.token, None)
        if runtime is not None:
            await stop_runtime(runtime)
        return await self._hydrate_spec(stored_spec)

    async def persist_spec(self, spec: BotSpec) -> None:
        await self.registry.upsert(spec)

    async def list_banned_users(self) -> list[int]:
        return await self.ban_registry.list_banned()

    async def ban_user(self, user_id: int) -> list[int]:
        return await self.ban_registry.ban(user_id)

    async def unban_user(self, user_id: int) -> list[int]:
        return await self.ban_registry.unban(user_id)

    async def list_requisite_clicks(self) -> list[dict[str, object]]:
        return await self.requisite_click_registry.list_clicks()

    async def sync_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> None:
        shared = await self._get_shared_config()
        shared_payment_methods = self._clone_payment_methods(
            payment_methods or self.settings.default_payment_methods
        )
        shared.payment_methods = self._clone_payment_methods(shared_payment_methods)
        await self.shared_registry.save(shared)
        self.settings.default_payment_methods = self._clone_payment_methods(shared.payment_methods)
        await self.registry.replace_payment_methods(shared.payment_methods)
        for runtime in self._runtimes.values():
            runtime.spec.payment_methods = self._clone_payment_methods(shared.payment_methods)
            runtime.settings.default_payment_methods = self._clone_payment_methods(shared.payment_methods)

    async def sync_start_text(self, start_text: str) -> None:
        shared = await self._get_shared_config()
        shared.template.start_text = start_text
        await self.shared_registry.save(shared)
        for runtime in self._runtimes.values():
            runtime.spec.template.start_text = start_text

    async def sync_template(self, template: TemplateOverrides) -> None:
        shared = await self._get_shared_config()
        shared.template = normalize_template(template)
        await self.shared_registry.save(shared)
        for runtime in self._runtimes.values():
            runtime.spec.template = shared.template.model_copy(deep=True)

    async def sync_admin_ids(self, admin_ids: list[int]) -> None:
        shared = await self._get_shared_config()
        shared.admin_ids = sorted(set(admin_ids))
        await self.shared_registry.save(shared)
        for runtime in self._runtimes.values():
            runtime.spec.admin_ids = list(shared.admin_ids)
            runtime.settings.default_admin_ids = list(shared.admin_ids)

    async def sync_products_from_text(self, raw_text: str) -> list[object]:
        products = parse_products_text(raw_text)
        shared = await self._get_shared_config()
        shared.products = clone_products(products)
        await self.shared_registry.save(shared)
        self.settings.products = clone_products(shared.products)
        self.settings.products_text_path.parent.mkdir(parents=True, exist_ok=True)
        self.settings.products_text_path.write_text(raw_text.strip() + "\n", encoding="utf-8")
        for token, runtime in self._runtimes.items():
            bot_cities = await self._get_bot_catalog(token)
            runtime.settings.products = clone_products(shared.products)
            runtime.settings.cities = apply_shared_products_to_cities(bot_cities, shared.products)
            runtime.settings.countries = group_cities_by_country(runtime.settings.cities)
        return clone_products(shared.products)

    async def save_bot_catalog(self, token: str, cities: list[CityConfig]) -> list[CityConfig]:
        await self.bot_catalog_registry.save_bot(token, cities)
        shared = await self._get_shared_config()
        applied_cities = apply_shared_products_to_cities(cities, shared.products)
        runtime = self._runtimes.get(token)
        if runtime is not None:
            runtime.settings.cities = applied_cities
            runtime.settings.countries = group_cities_by_country(applied_cities)
        return applied_cities

    async def get_family_catalog(self) -> list[CityConfig]:
        specs = await self.registry.load()
        if specs:
            return await self._get_bot_catalog(specs[0].token)
        return clone_cities(self.settings.cities)

    async def save_family_catalog(self, cities: list[CityConfig]) -> list[CityConfig]:
        normalized_cities = clone_cities(cities)
        self.settings.cities = clone_cities(normalized_cities)
        self.settings.countries = group_cities_by_country(self.settings.cities)
        save_catalog_cities(self.settings.catalog_path, normalized_cities)

        specs = await self.registry.load()
        for spec in specs:
            await self.save_bot_catalog(spec.token, normalized_cities)
        return clone_cities(normalized_cities)

    async def get_products_text(self) -> str:
        shared = await self._get_shared_config()
        return products_to_text(shared.products)

    async def remember_recipient(self, token: str, chat_id: int) -> list[int]:
        return await self.recipient_registry.remember_chat(token, chat_id)

    async def broadcast_message(self, text: str) -> dict[str, int]:
        specs = await self.registry.load()
        total_targets = 0
        send_semaphore = asyncio.Semaphore(BROADCAST_CHAT_CONCURRENCY)
        bot_semaphore = asyncio.Semaphore(BROADCAST_BOT_CONCURRENCY)

        async def send_to_chat(bot: Bot, token: str, chat_id: int) -> tuple[bool, bool]:
            async with send_semaphore:
                try:
                    await bot.send_message(chat_id, text)
                    return True, False
                except (TelegramForbiddenError, TelegramBadRequest):
                    await self.recipient_registry.forget_chat(token, chat_id)
                    return False, True
                except Exception:
                    logger.exception("Broadcast failed for %s chat %s", token[:10], chat_id)
                    return False, True

        async def process_spec(spec: BotSpec) -> tuple[int, int, int]:
            async with bot_semaphore:
                delivered = 0
                failed = 0
                recipients = await self.recipient_registry.get_chats(spec.token)
                target_count = len(recipients)
                if not recipients:
                    return 0, 0, 0
                runtime = self._runtimes.get(spec.token)
                bot = runtime.bot if runtime is not None else Bot(token=spec.token)
                owns_bot = runtime is None
                try:
                    results = await asyncio.gather(
                        *(send_to_chat(bot, spec.token, chat_id) for chat_id in recipients)
                    )
                    for was_delivered, was_failed in results:
                        if was_delivered:
                            delivered += 1
                        elif was_failed:
                            failed += 1
                finally:
                    if owns_bot:
                        await bot.session.close()
                return delivered, failed, target_count

        results: list[tuple[int, int, int]] = []
        for spec in specs:
            recipients = await self.recipient_registry.get_chats(spec.token)
            total_targets += len(recipients)
        if specs:
            results = await asyncio.gather(*(process_spec(spec) for spec in specs))
        delivered = sum(item[0] for item in results)
        failed = sum(item[1] for item in results)
        return {
            "delivered": delivered,
            "failed": failed,
            "skipped": max(total_targets - delivered - failed, 0),
        }

    async def _exists(self, token: str) -> bool:
        specs = await self.registry.load()
        return any(spec.token == token for spec in specs)

    async def _find_by_token(self, token: str) -> BotSpec | None:
        specs = await self.registry.load()
        found = next((spec for spec in specs if spec.token == token), None)
        if found is None:
            return None
        return await self._hydrate_spec(found)

    async def _find_by_bot_id(self, bot_id: int) -> BotSpec | None:
        specs = await self.registry.load()
        found = next((spec for spec in specs if spec.bot_id == bot_id), None)
        if found is None:
            return None
        return await self._hydrate_spec(found)

    async def _get_shared_payment_methods(self) -> list[PaymentMethodConfig]:
        shared = await self._get_shared_config()
        return self._clone_payment_methods(shared.payment_methods)

    async def _get_shared_template(self) -> TemplateOverrides:
        shared = await self._get_shared_config()
        return shared.template.model_copy(deep=True)

    async def _get_shared_admin_ids(self) -> list[int]:
        shared = await self._get_shared_config()
        return list(shared.admin_ids)

    async def _get_shared_config(self, specs: list[BotSpec] | None = None) -> SharedConfig:
        current_specs = specs if specs is not None else await self.registry.load()
        fallback = self._build_shared_config(current_specs)
        stored = await self.shared_registry.load()
        if stored is None:
            await self.shared_registry.save(fallback)
            return fallback
        return SharedConfig(
            template=self._clone_template(stored.template),
            payment_methods=self._clone_payment_methods(stored.payment_methods or fallback.payment_methods),
            admin_ids=sorted(set(stored.admin_ids or fallback.admin_ids)),
            products=clone_products(self.settings.products),
        )

    async def _ensure_bot_catalog_exists(self, token: str) -> list[CityConfig]:
        existing = await self.bot_catalog_registry.load_bot(token)
        if existing is not None:
            return existing
        return clone_cities(self.settings.cities)

    async def _get_bot_catalog(self, token: str) -> list[CityConfig]:
        existing = await self._ensure_bot_catalog_exists(token)
        return [city.model_copy(deep=True) for city in existing]

    async def _hydrate_spec(self, spec: BotSpec, shared: SharedConfig | None = None) -> BotSpec:
        if shared is None:
            shared = await self._get_shared_config()
        hydrated = spec.model_copy(deep=True)
        hydrated.template = shared.template.model_copy(deep=True)
        hydrated.payment_methods = self._clone_payment_methods(shared.payment_methods)
        hydrated.admin_ids = list(shared.admin_ids)
        return hydrated

    async def _fetch_me(self, token: str):
        bot = Bot(token=token)
        try:
            return await bot.get_me()
        finally:
            await bot.session.close()

    async def _restart(self, spec: BotSpec) -> None:
        self._cancel_retry_task(spec.token)
        if spec.token in self._runtimes:
            await stop_runtime(self._runtimes.pop(spec.token))
        if spec.is_paused:
            return
        self._schedule_start(spec)

    async def _start(self, spec: BotSpec) -> None:
        shared = await self._get_shared_config()
        bot_cities = await self._get_bot_catalog(spec.token)
        runtime_settings = self.settings.model_copy(deep=True)
        runtime_settings.products = clone_products(shared.products)
        runtime_settings.default_admin_ids = list(shared.admin_ids)
        runtime_settings.default_payment_methods = self._clone_payment_methods(shared.payment_methods)
        runtime_settings.cities = apply_shared_products_to_cities(bot_cities, shared.products)
        runtime_settings.countries = group_cities_by_country(runtime_settings.cities)
        runtime_spec = spec.model_copy(deep=True)
        runtime_spec.template = shared.template.model_copy(deep=True)
        runtime_spec.payment_methods = self._clone_payment_methods(shared.payment_methods)
        runtime_spec.admin_ids = list(shared.admin_ids)
        runtime = await start_runtime(
            runtime_settings,
            runtime_spec,
            self.persist_spec,
            self.register_bot,
            self.list_bots,
            self.remove_bot_by_id,
            self.toggle_bot_pause_by_id,
            self.sync_payment_methods,
            self.sync_start_text,
            self.sync_admin_ids,
            self.sync_template,
            self.sync_products_from_text,
            self.get_products_text,
            self.save_bot_catalog,
            self.remember_recipient,
        )
        self._runtimes[spec.token] = runtime
        runtime.task.add_done_callback(
            lambda task, token=spec.token: self._handle_runtime_done(token, task)
        )

    def _handle_runtime_done(self, token: str, task) -> None:
        runtime = self._runtimes.get(token)
        if runtime is not None and runtime.task is task:
            self._runtimes.pop(token, None)
        try:
            task.result()
        except asyncio.CancelledError:
            return
        except Exception as exc:
            if self._is_telegram_conflict_error(exc):
                self._handle_conflict_runtime_done(token)
                return
            logger.exception("Bot runtime stopped with error for %s", token[:10])
            self._schedule_retry_for_token(token)

    def _schedule_start(self, spec: BotSpec) -> None:
        if spec.token in self._runtimes:
            return
        current_task = self._retry_tasks.get(spec.token)
        if current_task is not None and not current_task.done():
            return
        self._retry_tasks[spec.token] = asyncio.create_task(self._start_with_retry(spec.token))

    async def _start_with_retry(self, token: str, initial_delay: int = 0) -> None:
        delay = START_RETRY_DELAY_SECONDS
        try:
            if initial_delay > 0:
                await asyncio.sleep(initial_delay)
            while True:
                spec = await self._find_by_token(token)
                if spec is None or spec.is_paused:
                    return
                try:
                    await self._start(spec)
                    return
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    if self._is_telegram_conflict_error(exc):
                        recheck_count = self._record_conflict_recheck(spec)
                        if recheck_count >= TELEGRAM_CONFLICT_MAX_RECHECKS:
                            await self._pause_after_conflict_rechecks(spec.token)
                            return
                        logger.warning(
                            "TelegramConflictError for @%s, recheck %s/%s in %s second(s)",
                            spec.bot_username or spec.token[:10],
                            recheck_count,
                            TELEGRAM_CONFLICT_MAX_RECHECKS,
                            TELEGRAM_CONFLICT_RECHECK_DELAY_SECONDS,
                        )
                        await asyncio.sleep(TELEGRAM_CONFLICT_RECHECK_DELAY_SECONDS)
                        continue
                    logger.exception(
                        "Failed to start bot %s, retrying in %s second(s)",
                        spec.bot_username or token[:10],
                        delay,
                    )
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, START_RETRY_MAX_DELAY_SECONDS)
        finally:
            current_task = self._retry_tasks.get(token)
            if current_task is asyncio.current_task():
                self._retry_tasks.pop(token, None)

    def _schedule_retry_for_token(self, token: str) -> None:
        if token in self._runtimes:
            return
        current_task = self._retry_tasks.get(token)
        if current_task is not None and not current_task.done():
            return
        self._retry_tasks[token] = asyncio.create_task(self._start_with_retry(token))

    def _handle_conflict_runtime_done(self, token: str) -> None:
        recheck_count = self._conflict_recheck_counts.get(token, 0) + 1
        self._conflict_recheck_counts[token] = recheck_count
        if recheck_count >= TELEGRAM_CONFLICT_MAX_RECHECKS:
            logger.error(
                "TelegramConflictError for bot %s reached %s/%s rechecks; pausing until manual enable",
                token[:10],
                recheck_count,
                TELEGRAM_CONFLICT_MAX_RECHECKS,
            )
            self._retry_tasks[token] = asyncio.create_task(self._pause_after_conflict_rechecks(token))
            return
        logger.warning(
            "TelegramConflictError for bot %s; recheck %s/%s in %s second(s)",
            token[:10],
            recheck_count,
            TELEGRAM_CONFLICT_MAX_RECHECKS,
            TELEGRAM_CONFLICT_RECHECK_DELAY_SECONDS,
        )
        self._retry_tasks[token] = asyncio.create_task(
            self._start_with_retry(token, TELEGRAM_CONFLICT_RECHECK_DELAY_SECONDS)
        )

    def _ensure_conflict_log_handler(self) -> None:
        if self._conflict_log_handler is not None:
            return
        self._event_loop = asyncio.get_running_loop()
        self._conflict_log_handler = TelegramConflictLogHandler(self)
        logging.getLogger("aiogram.dispatcher").addHandler(self._conflict_log_handler)

    def _remove_conflict_log_handler(self) -> None:
        if self._conflict_log_handler is None:
            return
        logging.getLogger("aiogram.dispatcher").removeHandler(self._conflict_log_handler)
        self._conflict_log_handler = None
        self._event_loop = None

    def _handle_dispatcher_conflict_log(self, bot_id: int) -> None:
        loop = self._event_loop
        if loop is None or not loop.is_running():
            return
        loop.call_soon_threadsafe(lambda: asyncio.create_task(self._handle_conflict_bot_id(bot_id)))

    async def _handle_conflict_bot_id(self, bot_id: int) -> None:
        spec = await self._find_by_bot_id(bot_id)
        if spec is None or spec.is_paused:
            return
        recheck_count = self._record_conflict_recheck(spec)
        if recheck_count >= TELEGRAM_CONFLICT_MAX_RECHECKS:
            logger.error(
                "TelegramConflictError for @%s reached %s/%s dispatcher rechecks; pausing until manual enable",
                spec.bot_username or spec.token[:10],
                recheck_count,
                TELEGRAM_CONFLICT_MAX_RECHECKS,
            )
            await self._pause_after_conflict_rechecks(spec.token)
            return
        logger.warning(
            "TelegramConflictError for @%s observed by dispatcher log, recheck %s/%s",
            spec.bot_username or spec.token[:10],
            recheck_count,
            TELEGRAM_CONFLICT_MAX_RECHECKS,
        )

    def _record_conflict_recheck(self, spec: BotSpec) -> int:
        recheck_count = self._conflict_recheck_counts.get(spec.token, 0) + 1
        self._conflict_recheck_counts[spec.token] = recheck_count
        return recheck_count

    def _is_telegram_conflict_error(self, exc: Exception) -> bool:
        if isinstance(exc, TelegramConflictError):
            return True
        message = str(exc)
        return (
            exc.__class__.__name__ == "TelegramConflictError"
            or "terminated by other getUpdates request" in message
            or "Conflict: terminated by other getUpdates request" in message
        )

    async def _pause_after_conflict_rechecks(self, token: str) -> None:
        current_task = asyncio.current_task()
        retry_task = self._retry_tasks.get(token)
        if retry_task is not None and retry_task is not current_task:
            self._cancel_retry_task(token)
        specs = await self.registry.load()
        stored_spec = next((item for item in specs if item.token == token), None)
        if stored_spec is None:
            self._conflict_recheck_counts.pop(token, None)
            return
        stored_spec.is_paused = True
        await self.registry.upsert(stored_spec)
        runtime = self._runtimes.pop(token, None)
        if runtime is not None:
            await stop_runtime(runtime)
        logger.error(
            "Paused @%s after %s TelegramConflictError recheck(s); manual enable is required",
            stored_spec.bot_username or token[:10],
            self._conflict_recheck_counts.get(token, TELEGRAM_CONFLICT_MAX_RECHECKS),
        )
        if self._retry_tasks.get(token) is current_task:
            self._retry_tasks.pop(token, None)

    def _cancel_retry_task(self, token: str) -> None:
        task = self._retry_tasks.pop(token, None)
        if task is not None:
            task.cancel()

    async def _ensure_synced_payment_methods(
        self,
        specs: list[BotSpec],
        shared_payment_methods: list[PaymentMethodConfig],
    ) -> list[BotSpec]:
        if not specs:
            return specs
        shared_payload = self._payment_methods_payload(shared_payment_methods)
        needs_sync = any(self._payment_methods_need_sync(spec.payment_methods, shared_payload) for spec in specs)
        if not needs_sync:
            for spec in specs:
                spec.payment_methods = self._clone_payment_methods(shared_payment_methods)
            return specs
        logger.info("Synchronizing payment methods for %s bot(s)", len(specs))
        return await self.registry.replace_payment_methods(shared_payment_methods)

    async def _dedupe_specs(self, specs: list[BotSpec]) -> list[BotSpec]:
        if len(specs) < 2:
            return specs
        deduped_specs = self._select_unique_specs(specs)
        removed_count = len(specs) - len(deduped_specs)
        if removed_count <= 0:
            return specs
        logger.warning("Removed %s duplicate bot spec(s) from %s", removed_count, self.settings.data_path)
        await self.registry.save(deduped_specs)
        return deduped_specs

    def _select_unique_specs(self, specs: list[BotSpec]) -> list[BotSpec]:
        unique_specs: dict[tuple[str, str], BotSpec] = {}
        for spec in specs:
            identity = self._spec_identity(spec)
            current = unique_specs.get(identity)
            if current is None or self._spec_rank(spec) > self._spec_rank(current):
                unique_specs[identity] = spec
        return list(unique_specs.values())

    def _spec_identity(self, spec: BotSpec) -> tuple[str, str]:
        if spec.bot_id is not None:
            return ("bot_id", str(spec.bot_id))
        if spec.bot_username:
            return ("bot_username", spec.bot_username.casefold())
        return ("token", spec.token)

    def _spec_rank(self, spec: BotSpec) -> tuple[int, str]:
        return (
            int(self._token_matches_bot_id(spec)),
            spec.created_at or "",
        )

    def _token_matches_bot_id(self, spec: BotSpec) -> bool:
        if spec.bot_id is None:
            return False
        token_prefix = spec.token.split(":", maxsplit=1)[0]
        return token_prefix.isdigit() and int(token_prefix) == spec.bot_id

    def _resolve_shared_payment_methods(self, specs: list[BotSpec]) -> list[PaymentMethodConfig]:
        best_methods: list[PaymentMethodConfig] = []
        best_priority: tuple[int, int, int, str] | None = None
        for spec in specs:
            if not spec.payment_methods:
                continue
            normalized_methods = self._clone_payment_methods(spec.payment_methods)
            if not normalized_methods:
                continue
            priority = self._payment_methods_priority(spec, normalized_methods)
            if best_priority is None or priority > best_priority:
                best_methods = normalized_methods
                best_priority = priority
        if best_methods:
            return best_methods
        return self._clone_payment_methods(self.settings.default_payment_methods)

    def _payment_methods_priority(
        self,
        spec: BotSpec,
        payment_methods: list[PaymentMethodConfig],
    ) -> tuple[int, int, int, str]:
        populated_fields = sum(
            int(bool((method.requisites or "").strip())) + int(bool((method.details_text or "").strip()))
            for method in payment_methods
        )
        return (len(payment_methods), populated_fields, int(self._token_matches_bot_id(spec)), spec.created_at or "")

    def _resolve_shared_template(self, specs: list[BotSpec]) -> TemplateOverrides:
        for spec in specs:
            if getattr(spec, "template", None) is not None:
                return self._clone_template(spec.template)
        return self._clone_template(None)

    def _resolve_shared_admin_ids(self, specs: list[BotSpec]) -> list[int]:
        for spec in specs:
            if getattr(spec, "admin_ids", None):
                return sorted(set(spec.admin_ids))
        return sorted(set(self.settings.default_admin_ids))

    def _build_shared_config(self, specs: list[BotSpec]) -> SharedConfig:
        return SharedConfig(
            template=self._resolve_shared_template(specs),
            payment_methods=self._resolve_shared_payment_methods(specs),
            admin_ids=self._resolve_shared_admin_ids(specs),
            products=clone_products(self.settings.products),
        )

    def _clone_template(self, template: TemplateOverrides | object | None) -> TemplateOverrides:
        return normalize_template(template).model_copy(deep=True)

    def _clone_payment_methods(
        self,
        payment_methods: list[PaymentMethodConfig],
    ) -> list[PaymentMethodConfig]:
        normalized_methods: list[PaymentMethodConfig] = []
        deduped_by_identity: dict[tuple[str, str], PaymentMethodConfig] = {}
        method_order: list[tuple[str, str]] = []
        for method in payment_methods:
            normalized = method.model_copy(deep=True)
            if normalized.key in DISABLED_PAYMENT_METHOD_KEYS:
                continue
            identity = (normalized.key.strip().casefold(), normalized.label.strip().casefold())
            if identity not in deduped_by_identity:
                deduped_by_identity[identity] = normalized
                method_order.append(identity)
                continue
            deduped_by_identity[identity] = self._pick_better_payment_method(
                deduped_by_identity[identity],
                normalized,
            )
        for identity in method_order:
            normalized_methods.append(deduped_by_identity[identity].model_copy(deep=True))
        return normalized_methods

    def _pick_better_payment_method(
        self,
        current: PaymentMethodConfig,
        candidate: PaymentMethodConfig,
    ) -> PaymentMethodConfig:
        current_score = self._payment_method_quality(current)
        candidate_score = self._payment_method_quality(candidate)
        winner = current.model_copy(deep=True) if current_score >= candidate_score else candidate.model_copy(deep=True)
        loser = candidate if current_score >= candidate_score else current

        if not (winner.requisites or "").strip() and (loser.requisites or "").strip():
            winner.requisites = loser.requisites
        if not (winner.commission_text or "").strip() and (loser.commission_text or "").strip():
            winner.commission_text = loser.commission_text
        if not (winner.details_text or "").strip() and (loser.details_text or "").strip():
            winner.details_text = loser.details_text
        winner.qr_enabled = bool(winner.qr_enabled or loser.qr_enabled)
        return winner

    def _payment_method_quality(self, method: PaymentMethodConfig) -> tuple[int, int, int, int]:
        requisites = (method.requisites or "").strip()
        details_text = (method.details_text or "").strip()
        commission_text = (method.commission_text or "").strip()
        requisites_score = self._payment_requisites_quality(requisites)
        placeholder_score = int("{requisites}" in details_text)
        details_score = int(bool(details_text))
        commission_score = int(bool(commission_text))
        return (requisites_score, placeholder_score, details_score, commission_score)

    def _payment_requisites_quality(self, requisites: str) -> int:
        if not requisites:
            return 0
        upper_value = requisites.upper()
        if upper_value in _LEGACY_REQUISITES_PLACEHOLDERS:
            return 1
        if _PLAUSIBLE_CARD_REQUISITES_PATTERN.fullmatch(requisites) is not None:
            return 4
        if _PLAUSIBLE_GENERIC_REQUISITES_PATTERN.fullmatch(requisites) is not None:
            return 3
        if len(requisites) >= 6:
            return 2
        return 0

    def _payment_methods_need_sync(
        self,
        payment_methods: list[PaymentMethodConfig],
        shared_payload: list[dict[str, object]],
    ) -> bool:
        normalized_methods = self._clone_payment_methods(payment_methods)
        if len(normalized_methods) != len(payment_methods):
            return True
        return self._payment_methods_payload(normalized_methods) != shared_payload

    def _payment_methods_payload(self, payment_methods: list[PaymentMethodConfig]) -> list[dict[str, object]]:
        return [method.model_dump(mode="json") for method in self._clone_payment_methods(payment_methods)]
