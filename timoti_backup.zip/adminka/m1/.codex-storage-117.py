from __future__ import annotations

import asyncio
import json
import os
import tempfile
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path
from typing import Any

from piohano_shop.config import (
    BotSpec,
    FamilyState,
    PaymentMethodConfig,
    TemplateOverrides,
    normalize_template,
)


def _write_json_atomically(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, ensure_ascii=False, indent=2)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
        text=True,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as temporary_file:
            temporary_file.write(encoded)
            temporary_file.flush()
            os.fsync(temporary_file.fileno())
        os.replace(temporary_name, path)
    except BaseException:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


class BotRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self) -> list[BotSpec]:
        async with self._lock:
            return self._read_specs()

    async def save(self, specs: list[BotSpec]) -> None:
        async with self._lock:
            self._write_specs(specs)

    async def upsert(self, spec: BotSpec) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            replaced = False
            for index, existing in enumerate(specs):
                if existing.token == spec.token:
                    specs[index] = spec
                    replaced = True
                    break
            if not replaced:
                specs.append(spec)
            self._write_specs(specs)
            return specs

    async def delete(self, token: str) -> list[BotSpec]:
        async with self._lock:
            specs = self._read_specs()
            filtered = [spec for spec in specs if spec.token != token]
            self._write_specs(filtered)
            return filtered

    async def replace_payment_methods(self, payment_methods: list[PaymentMethodConfig]) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_methods = [method.model_dump(mode="json") for method in payment_methods]
            for item in payload:
                item["payment_methods"] = deepcopy(normalized_methods)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_start_text(self, start_text: str) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            for item in payload:
                template_payload = item.get("template")
                if not isinstance(template_payload, dict):
                    template_payload = {}
                else:
                    template_payload = dict(template_payload)
                template_payload["start_text"] = start_text
                item["template"] = template_payload
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_template(self, template: TemplateOverrides) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_template = normalize_template(template).model_dump(mode="json")
            for item in payload:
                item["template"] = deepcopy(normalized_template)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    async def replace_admin_ids(self, admin_ids: list[int]) -> list[BotSpec]:
        async with self._lock:
            payload = self._read_specs_payload()
            normalized_admin_ids = sorted(set(admin_ids))
            for item in payload:
                item["admin_ids"] = list(normalized_admin_ids)
            self._write_specs_payload(payload)
            return [BotSpec.model_validate(item) for item in payload]

    def _read_specs(self) -> list[BotSpec]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [BotSpec.model_validate(item) for item in data]

    def _read_specs_payload(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        return [dict(item) for item in data if isinstance(item, dict)]

    def _write_specs(self, specs: list[BotSpec]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = [spec.model_dump(mode="json") for spec in specs]
        self._write_specs_payload(payload)

    def _write_specs_payload(self, payload: list[dict[str, Any]]) -> None:
        _write_json_atomically(self.path, payload)


class FamilyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def load(self, fallback: FamilyState) -> FamilyState:
        async with self._lock:
            return self._read_state(fallback)

    async def save(self, state: FamilyState) -> FamilyState:
        async with self._lock:
            normalized_state = FamilyState(
                template=normalize_template(state.template),
                payment_methods=[method.model_copy(deep=True) for method in state.payment_methods],
                admin_ids=sorted(set(state.admin_ids)),
            )
            self._write_state(normalized_state)
            return normalized_state

    def _read_state(self, fallback: FamilyState) -> FamilyState:
        normalized_fallback = FamilyState(
            template=normalize_template(fallback.template),
            payment_methods=[method.model_copy(deep=True) for method in fallback.payment_methods],
            admin_ids=sorted(set(fallback.admin_ids)),
        )
        if not self.path.exists():
            return normalized_fallback

        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return normalized_fallback

        payload = normalized_fallback.model_dump(mode="python")
        raw_template = data.get("template")
        if isinstance(raw_template, dict):
            template_payload = payload["template"]
            template_payload.update(raw_template)
            payload["template"] = template_payload
        if "payment_methods" in data:
            payload["payment_methods"] = data["payment_methods"]
        if "admin_ids" in data:
            payload["admin_ids"] = data["admin_ids"]
        return FamilyState.model_validate(payload)

    def _write_state(self, state: FamilyState) -> None:
        payload = state.model_dump(mode="json")
        _write_json_atomically(self.path, payload)


class CaptchaRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_user(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, dict):
                return {}
            return dict(user_payload)

    async def update_user(
        self,
        user_id: int,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[str(user_id)] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        _write_json_atomically(self.path, payload)


class OrderRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def list_user_orders(self, user_id: int) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, list):
                return []
            return [dict(item) for item in user_payload if isinstance(item, dict)]

    async def upsert_user_order(self, user_id: int, order_payload: dict[str, Any]) -> list[dict[str, Any]]:
        async with self._lock:
            payload = self._read_payload()
            current_items = payload.get(str(user_id))
            orders = [dict(item) for item in current_items if isinstance(item, dict)] if isinstance(current_items, list) else []
            order_id = order_payload.get("order_id")
            replaced = False
            for index, existing in enumerate(orders):
                if existing.get("order_id") == order_id:
                    orders[index] = dict(order_payload)
                    replaced = True
                    break
            if not replaced:
                orders.insert(0, dict(order_payload))
            payload[str(user_id)] = orders[:20]
            self._write_payload(payload)
            return [dict(item) for item in payload[str(user_id)]]

    async def update_user_order_status(
        self,
        user_id: int,
        order_id: int | str | None,
        status: str,
    ) -> bool:
        if order_id is None:
            return False

        async with self._lock:
            payload = self._read_payload()
            user_payload = payload.get(str(user_id))
            if not isinstance(user_payload, list):
                return False

            for index, raw_item in enumerate(user_payload):
                if not isinstance(raw_item, dict):
                    continue
                try:
                    item_order_id = int(raw_item.get("order_id"))
                except (TypeError, ValueError):
                    continue

                if item_order_id != int(order_id):
                    continue

                updated_item = dict(raw_item)
                updated_item["status"] = status
                user_payload[index] = updated_item
                payload[str(user_id)] = user_payload
                self._write_payload(payload)
                return True

            return False

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        _write_json_atomically(self.path, payload)


class OrderPenaltyRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_user(self, user_id: int) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            raw_record = payload.get(str(user_id))
            if not isinstance(raw_record, dict):
                return {}
            return dict(raw_record)

    async def update_user(
        self,
        user_id: int,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(str(user_id))
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[str(user_id)] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        _write_json_atomically(self.path, payload)


class DistrictRotationRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = asyncio.Lock()

    async def get_city(self, city_key: str) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            city_payload = payload.get(city_key)
            if not isinstance(city_payload, dict):
                return {}
            return dict(city_payload)

    async def update_city(
        self,
        city_key: str,
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any]:
        async with self._lock:
            payload = self._read_payload()
            current = payload.get(city_key)
            current_payload = dict(current) if isinstance(current, dict) else {}
            updated_payload = dict(updater(current_payload))
            payload[city_key] = updated_payload
            self._write_payload(payload)
            return updated_payload

    def _read_payload(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}

    def _write_payload(self, payload: dict[str, Any]) -> None:
        _write_json_atomically(self.path, payload)
